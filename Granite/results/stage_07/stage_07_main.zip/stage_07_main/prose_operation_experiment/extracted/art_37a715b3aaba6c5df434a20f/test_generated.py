import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retry strategy for handling transient errors
session = requests.Session()
retry_strategy = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

# Set up request headers including Authorization header
headers = {
    "Authorization": "Bearer <your_token>",  # Replace <your_token> with actual token
}

# Define test function
def test_mark_users():
    offering_id = "<offering_id>"  # Replace <offering_id> with actual value
    marker_email = "<marker_email>"  # Replace <marker_email> with actual value

    url = f"{BASE_URL}/offerings/{offering_id}/users/{marker_email}/marks"
    payload = ["<mark_id_1>", "<mark_id_2>"]  # Replace with actual mark IDs

    response = session.delete(
        url, json={"marks": payload}, headers=headers
    )

    assert response.status_code == 200, f"Expected status code 200, got {response.status_code}"

# Run the test if executed directly (pytest)
if __name__ == "__main__":
    pytest.main([__file__, "-vv"])