# -*- coding: utf-8 -*-
"""Tests for AreaController."""

import pytest
from requests import Response

BASE_URL = "http://openapi.test"

def test_area_areas_get():
    """Test GET /v2/tier1/{shortName}/area/areas."""
    
    # Given
    short_name = "example_short_name"
    offset = 0
    count = 10
    
    url = f"{BASE_URL}/v2/tier1/{short_name}/area/areas"
    params = {"offset": offset, "count": count}
    
    expected_status_code = 200
    
    # When
    response: Response = requests.get(url, params=params)
    
    # Then
    assert response.status_code == expected_status_code
    
    try:
        json_response = response.json()
    except ValueError:
        print(response.text)
        pytest.fail("Invalid JSON")
    
    assert isinstance(json_response, dict)
    assert "Count" in json_response
    assert isinstance(json_response["Count"], int)
    assert "Data" in json_response
    assert isinstance(json_response["Data"], list)
    
    for area in json_response["Data"]:
        assert isinstance(area, dict)
        assert "Branch" in area
        assert isinstance(area["Branch"], str)
        assert "ETag" in area
        assert isinstance(area["ETag"], str)
        assert "Name" in area
        assert isinstance(area["Name"], str)
        assert "OID" in area
        assert isinstance(area["OID"], str)
        assert "ShowOnSites" in area
        assert isinstance(area["ShowOnSites"], bool)

import requests