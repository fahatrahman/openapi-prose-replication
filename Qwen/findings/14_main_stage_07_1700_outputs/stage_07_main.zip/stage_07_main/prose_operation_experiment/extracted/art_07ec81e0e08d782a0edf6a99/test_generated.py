import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_report_file():
    profile_id = "your_profile_id"
    report_id = "your_report_id"
    file_id = "your_file_id"
    
    url = f"{BASE_URL}/userprofiles/{profile_id}/reports/{report_id}/files/{file_id}"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token",
        "alt": "json",
        "callback": "your_callback",
        "fields": "your_fields",
        "key": "your_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": False,
        "quotaUser": "your_quota_user",
        "uploadType": "your_upload_type",
        "upload_protocol": "your_upload_protocol"
    }
    
    headers = {
        "Authorization": "Bearer your_bearer_token"
    }
    
    response = requests.get(url, params=params, headers=headers)
    
    assert response.status_code == 200
    assert "application/json" in response.headers["Content-Type"]
    assert isinstance(response.json(), dict)
    assert "id" in response.json()
    assert "status" in response.json()
    assert response.json()["status"] == "REPORT_AVAILABLE"