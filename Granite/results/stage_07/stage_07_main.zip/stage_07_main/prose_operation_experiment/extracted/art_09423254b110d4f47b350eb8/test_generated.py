import os
import pytest
import requests
BASE_URL = "http://openapi.test"

@pytest.fixture
def account():
    headers = {
        'Content-Type': 'application/json'
    }
    response = requests.put(
        f"{BASE_URL}/userprofiles/profileId/accounts",
        json={
            "accountPermissionIds": [],
            "accountProfile": "ACCOUNT_PROFILE_STANDARD",
            "active": True,
            "activeAdsLimitTier": "ACTIVE_ADS_TIER_100K",
            "activeViewOptOut": False,
            "availablePermissionIds": [],
            "countryId": 123,
            "currencyId": "DMQ",
            "description": "",
            "id": 123,
            "kind": "dfareporting#account",
            "locale": "qw",
            "maximumImageSize": 10240,
            "name": "My Account Name",
            "nielsenOcrEnabled": False,
            "reportsConfiguration": {
                "exposureToConversionEnabled": True,
                "lookbackConfiguration": {
                    "clickDuration": 0,
                    "postImpressionActivitiesDuration": 90
                },
                "reportGenerationTimeZoneId": "1"
            },
            "shareReportsWithTwitter": False,
            "teaserSizeLimit": 10240
        },
        headers=headers
    )
    response.raise_for_status()
    return response.json()

def test_update_account(account):
    assert account["id"] == 123
    assert account["accountProfile"] == "ACCOUNT_PROFILE_STANDARD"
    assert account["active"] is True
    assert account["activeAdsLimitTier"] == "ACTIVE_ADS_TIER_100K"
    assert account["activeViewOptOut"] is False
    assert account["availablePermissionIds"] == []
    assert account["countryId"] == 123
    assert account["currencyId"] == "DMQ"
    assert account["description"] == ""
    assert account["id"] == 123
    assert account["kind"] == "dfareporting#account"
    assert account["locale"] == "qw"
    assert account["maximumImageSize"] == 10240
    assert account["name"] == "My Account Name"
    assert account["nielsenOcrEnabled"] is False
    assert account["reportsConfiguration"]["exposureToConversionEnabled"] is True
    assert account["reportsConfiguration"]["lookbackConfiguration"]["clickDuration"] == 0
    assert account["reportsConfiguration"]["lookbackConfiguration"]["postImpressionActivitiesDuration"] == 90
    assert account["reportsConfiguration"]["reportGenerationTimeZoneId"] == "1"
    assert account["shareReportsWithTwitter"] is False
    assert account["teaserSizeLimit"] == 10240