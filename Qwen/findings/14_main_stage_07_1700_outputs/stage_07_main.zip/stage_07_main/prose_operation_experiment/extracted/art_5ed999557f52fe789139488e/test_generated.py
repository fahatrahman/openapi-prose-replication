import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_folder_items():
    url = f"{BASE_URL}/api/v2/cddrive/folders/0/items"
    params = {
        "offset": 0,
        "limit": 20
    }
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "entries" in data
    assert isinstance(data["entries"], list)
    assert all(isinstance(item, dict) for item in data["entries"])
    assert "limit" in data
    assert isinstance(data["limit"], int)
    assert "offset" in data
    assert isinstance(data["offset"], int)
    assert "totalCount" in data
    assert isinstance(data["totalCount"], int)

if __name__ == "__main__":
    pytest.main()