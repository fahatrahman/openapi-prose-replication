import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session for retrying on failed requests
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

# Set X-API-Key header with your actual API key
headers = {"X-API-Key": "your_api_key"}

@pytest.fixture
def stored_payment_methods():
    response = session.get(
        f"{BASE_URL}/storedPaymentMethods", headers=headers, params={"shopperReference": "YOUR_SHOPPER_REFERENCE"}
    )
    assert response.status_code == 200

    return response.json()["storedPaymentMethods"]

def test_stored_payment_methods(stored_payment_methods):
    assert len(stored_payment_methods) > 0
    method = stored_payment_methods[0]
    assert method["brand"] == "visa"
    assert method["expiryMonth"] == "10"
    assert method["expiryYear"] == "30"
    assert method["holderName"] == "John Smith"
    assert method["id"] == "7219687191761347"
    assert method["issuerName"] == "ISSUER_NAME"
    assert method["lastFour"] == "1111"
    assert method["name"] == "VISA"
    assert method["shopperEmail"] == "john.smith@example.com"
    assert method["shopperReference"] == "YOUR_SHOPPER_REFERENCE"
    assert method["supportedRecurringProcessingModels"] == ["CardOnFile", "Subscription", "UnscheduledCardOnFile"]
    assert method["type"] == "scheme"