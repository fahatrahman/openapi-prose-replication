import pytest
import requests
BASE_URL = "http://openapi.test"

@pytest.fixture
def case_type_groups():
    url = f"{BASE_URL}/masterData/caseTypeGroup"
    params = {"q": "caseTypeGroupId: 'CTYGSpWaVityBQndsv'",
              "pageNumber": 1,
              "order": "asc",
             }

    response = requests.get(url, params=params)
    response.raise_for_status()
    return response.json()

def test_case_type_groups(case_type_groups):
    assert case_type_groups["object"] == "CaseTypeGroupResponse"
    assert len(case_type_groups["caseTypeGroupArray"]) == 1
    assert case_type_groups["caseTypeGroupArray"][0]["name"] == "Tax and Revenue"
    assert case_type_groups["totalPages"] == 1
    assert case_type_groups["totalCount"] == 1
    assert case_type_groups["pageNumber"] == 1
    assert case_type_groups["nextPageAPI"] is None
    assert case_type_groups["previousPageAPI"] is None