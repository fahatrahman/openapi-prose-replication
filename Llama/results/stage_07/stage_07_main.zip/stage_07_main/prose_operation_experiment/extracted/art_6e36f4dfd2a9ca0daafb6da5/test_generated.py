import pytest
import requests
from urllib.parse import urlencode

BASE_URL = "http://openapi.test"

def test_placements_generatetags():
    profile_id = "your_profile_id"
    campaign_id = "your_campaign_id"
    placement_ids = ["placement1", "placement2"]
    tag_formats = ["PLACEMENT_TAG_STANDARD", "PLACEMENT_TAG_IFRAME_JAVASCRIPT"]

    params = {
        "_xgafv": "1",
        "access_token": "",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "",
        "oauth_token": "",
        "prettyPrint": "false",
        "quotaUser": "",
        "upload_protocol": "upload_protocol",
        "uploadType": "uploadType",
        "profileId": profile_id,
        "campaignId": campaign_id,
        "placementIds": ",".join(placement_ids),
        "tagFormats": ",".join(tag_formats)
    }

    headers = {}
    response = requests.post(f"{BASE_URL}/userprofiles/{profile_id}/placements/generatetags", headers=headers, params=params)

    assert response.status_code == 200
    response_json = response.json()
    print(response_json)