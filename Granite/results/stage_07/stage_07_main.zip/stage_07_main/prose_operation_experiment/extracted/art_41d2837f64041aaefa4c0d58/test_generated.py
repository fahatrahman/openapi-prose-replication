import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

# Custom adapter for retries on failure
class Retry(HTTPAdapter):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def retry_session(self, method, url, **kwargs):
        session = requests.Session()

        def reraise_http_exception(e):
            if hasattr(e, "response"):
                # The response came back with a non-success status code
                e.response.raise_for_status()
            else:
                raise  # Re-raise the exception

        try:
            response = session.request(method, url, **kwargs)
            response.raise_for_status()
            return response
        except requests.exceptions.RequestException as e:
            reraise_http_exception(e)

        return None

requests.mount("https://", Retry())
requests.mount("http://", Retry())

@pytest.fixture
def songlist_for_edit():
    endpoint = "/api/songLists"
    payload = {
        "description": "Test Song List",
        "featuredCategory": "Concerts",
        "mainPicture": {"mime": "image/jpeg", "urlOriginal": "http://example.com/large.jpg"},
        "name": "My Test Playlist",
        "songLinks": [
            {
                "notes": "This is a test song.",
                "order": 1,
                "song": {"id": 123},
                "songInListId": 1,
            }
        ],
        "status": "Draft",
        "updateNotes": "Updated via tests",
    }

    response = requests.post(urljoin(BASE_URL, endpoint), json=payload)
    assert response.status_code == 200  # Ensure the request was successful
    return response.json()