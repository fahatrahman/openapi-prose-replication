import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retries for transient errors
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
session.mount("https://", adapter)
session.mount("http://", adapter)

# Set the Authorization header
os.environ["AUTHORIZATION"] = "Bearer <your_token>"

@pytest.fixture
def api():
    return session

def test_unpublish_version(api):
    version_id = "<your_version_id>"
    url = f"{BASE_URL}/versions/{version_id}/unpublish"

    response = api.put(url)

    assert response.status_code == 200, \
        f'Expected status code 200, received {response.status_code}'

    # Check if the response data is as expected (empty object in this case)
    assert response.json()["data"] == {}