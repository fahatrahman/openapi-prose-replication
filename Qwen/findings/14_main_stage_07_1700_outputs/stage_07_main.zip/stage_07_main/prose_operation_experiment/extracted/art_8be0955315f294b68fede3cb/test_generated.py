import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_photo_photos():
    short_name = "test_short_name"
    offset = 0
    count = 10

    url = f"{BASE_URL}/v2/tier1/{short_name}/photo/photos"
    params = {
        "offset": offset,
        "count": count
    }

    response = requests.get(url, params=params)

    assert response.status_code == 200
    assert "Content-Type" in response.headers
    content_type = response.headers["Content-Type"]

    if "application/json" in content_type:
        data = response.json()
        assert "Count" in data
        assert "Data" in data
        assert isinstance(data["Count"], int)
        assert isinstance(data["Data"], list)
        for item in data["Data"]:
            assert "ETag" in item
            assert "FileName" in item
            assert "InspectionItem" in item
            assert "InterimInspection" in item
            assert "InventoryItem" in item
            assert "Name" in item
            assert "OID" in item
            assert "PhotoNumber" in item
            assert "PhotoType" in item
            assert "Property" in item
            assert "Room" in item
    elif "application/xml" in content_type:
        # Implement XML parsing and validation here
        pass
    elif "text/json" in content_type:
        data = response.json()
        assert "Count" in data
        assert "Data" in data
        assert isinstance(data["Count"], int)
        assert isinstance(data["Data"], list)
        for item in data["Data"]:
            assert "ETag" in item
            assert "FileName" in item
            assert "InspectionItem" in item
            assert "InterimInspection" in item
            assert "InventoryItem" in item
            assert "Name" in item
            assert "OID" in item
            assert "PhotoNumber" in item
            assert "PhotoType" in item
            assert "Property" in item
            assert "Room" in item
    elif "text/xml" in content_type:
        # Implement XML parsing and validation here
        pass
    else:
        pytest.fail(f"Unexpected Content-Type: {content_type}")