import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Define custom retry strategy for requests
retries = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
adapter = HTTPAdapter(max_retries=retries)
http = requests.Session()
http.mount("https://", adapter)
http.mount("http://", adapter)
requests.adapters.HTTPAdapter.max_retries = retries

# Set up authorization header if needed
headers = {"Authorization": "GNA Brx - KqwbwovSppsxlo {yiuso}"}

@pytest.fixture
def brocade_switch_data_source():
    url = f"{BASE_URL}/data-sources/brocade-switches"
    response = http.post(url, json={
        "proxy_id": "1000:104:12313412",
        "nickname": "vc1",
        "credentials": {
            "username": "your_username",
            "password": "your_password"
        }
    }, headers=headers)

    response.raise_for_status()
    return response.json()

def test_add_brocade_switch(brocade_switch_data_source):
    assert brocade_switch_data_source["entity_type"] == "BrocadeSwitchDataSource"
    assert brocade_switch_data_source["nickname"] == "vc1"