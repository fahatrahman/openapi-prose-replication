import pytest
import requests

BASE_URL = "http://openapi.test"

def test_find_place():
    params = {
        "api_key": "ak_test",
        "query": "london"
    }
    response = requests.get(f"{BASE_URL}/places", params=params)
    assert response.status_code == 200
    data = response.json()
    assert data["code"] == 2000
    assert data["message"] == "Success"
    assert isinstance(data["result"]["hits"], list)

if __name__ == "__main__":
    pytest.main(["-v"])