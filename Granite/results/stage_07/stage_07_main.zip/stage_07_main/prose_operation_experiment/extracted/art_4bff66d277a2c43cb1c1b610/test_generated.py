import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Define custom retry strategy for handling TooManyRequestsException
retries = Retry(
    total=4,
    status_forcelist=[429],
    backoff_factor=1
)
adapter = HTTPAdapter(max_retries=retries)
http = requests.Session()
http.mount("https://", adapter)
http.mount("http://", adapter)

requests.adapters.DEFAULT_RETRIES = retries

@pytest.fixture
def api_client():
    return http

@pytest.mark.parametrize("api_id, model_id", [
    ("your_api_id", "your_model_id")
])
def test_get_model_template(api_client, api_id, model_id):
    url = f"{BASE_URL}/v2/apis/{api_id}/models/{model_id}/template"

    try:
        response = api_client.get(url)

        # Check for successful response
        response.raise_for_status()
        assert response.status_code == 200
        print("Test Passed: Model template retrieved successfully.")

    except requests.exceptions.HTTPError as errh:
        if response.status_code == 429:
            print("TooManyRequestsException: Rate limit exceeded.")
        else:
            print(f"HTTP Error: {errh}")
    except requests.exceptions.RequestException as err:
        print(f"Error: {err}")