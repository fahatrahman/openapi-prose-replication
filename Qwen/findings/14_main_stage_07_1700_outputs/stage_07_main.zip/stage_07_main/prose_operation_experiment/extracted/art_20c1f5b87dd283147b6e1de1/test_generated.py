import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_listing_extra_attributes():
    api_key = "your_api_key_here"
    listing_id = "some_listing_id_here"
    url = f"{BASE_URL}/listing/car/{listing_id}/extra?api_key={api_key}"
    
    response = requests.get(url)
    
    assert response.status_code == 200
    data = response.json()
    assert 'id' in data
    assert 'features' in data
    assert 'interior_f' in data
    assert 'exterior_f' in data
    assert 'standard_f' in data
    assert 'options' in data
    assert 'technical_f' in data
    assert 'safety_f' in data
    assert 'electronics_f' in data
    assert 'dealer_added_f' in data
    assert 'seller_cmts' in data

if __name__ == "__main__":
    pytest.main()