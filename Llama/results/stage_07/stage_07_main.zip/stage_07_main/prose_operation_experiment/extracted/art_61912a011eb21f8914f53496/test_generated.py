# pytest_module.py

import pytest
import requests
from jsonschema import validate

BASE_URL = "http://openapi.test"

def test_get_cards_containing_retreat_count():
    url = f"{BASE_URL}/retreats/{'base1-1'}"
    response = requests.get(url)
    assert response.status_code == 200
    schema = {
        "$ref": "#/components/schemas/StringEndpoint",
        "components": {
            "schemas": {
                "StringEndpoint": {
                    "type": "object",
                    "required": ["cards", "name"],
                    "properties": {
                        "cards": {"type": "array"},
                        "name": {"type": "string"}
                    }
                }
            }
        },
        "openapi": "3.0.3",
        "info": {"title": "Operation slice", "version": "1.0.0"}
    }
    validate(instance=response.json(), schema=schema)

def test_get_non_existent_retreat_count():
    url = f"{BASE_URL}/retreats/{'non-existent-retreat'}"
    response = requests.get(url)
    assert response.status_code == 404