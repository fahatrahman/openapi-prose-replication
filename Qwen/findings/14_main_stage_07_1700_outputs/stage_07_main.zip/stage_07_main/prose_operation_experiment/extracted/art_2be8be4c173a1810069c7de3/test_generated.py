import pytest
import requests

BASE_URL = "http://openapi.test"

def test_proximitybeacon_beacons_deactivate():
    url = f"{BASE_URL}/v1beta1/{beaconName}:deactivate"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token",
        "alt": "json",
        "callback": "your_callback_url",
        "fields": "your_fields",
        "key": "your_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": False,
        "quotaUser": "your_quota_user",
        "uploadType": "multipart/form-data",
        "upload_protocol": "raw",
        "beaconName": "your_beacon_name",
        "projectId": "your_project_id"
    }
    response = requests.post(url, params=params)
    assert response.status_code == 200
    assert response.json() == {}