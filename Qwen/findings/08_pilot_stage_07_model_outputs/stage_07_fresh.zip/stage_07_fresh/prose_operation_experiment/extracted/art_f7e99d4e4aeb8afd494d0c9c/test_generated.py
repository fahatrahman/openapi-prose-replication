import pytest
import requests

BASE_URL = "http://openapi.test"

def test_retrieve_prefix_pricing():
    api_key = "your_api_key_here"
    api_secret = "your_api_secret_here"
    prefix = "12345"
    url = f"{BASE_URL}/get-prefix-pricing/outbound/sms?api_key={api_key}&api_secret={api_secret}&prefix={prefix}"
    
    response = requests.get(url)
    
    assert response.status_code == 200
    data = response.json()
    assert 'count' in data
    assert 'countries' in data
    
    for country in data['countries']:
        assert 'countryDisplayName' in country
        assert 'countryName' in country
        assert 'currency' in country
        assert 'defaultPrice' in country
        assert 'dialingPrefix' in country
        assert 'networks' in country
        
        for network in country['networks']:
            assert 'currency' in network
            assert 'mcc' in network
            assert 'mnc' in network
            assert 'networkCode' in network
            assert 'networkName' in network
            assert 'price' in network
            assert 'type' in network

if __name__ == "__main__":
    pytest.main([__file__])