# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_assigned_inventory_source():
    url = f"{BASE_URL}/v2/inventorySourceGroups/{'inventorySourceGroupId'}"
    url += f"/assignedInventorySources/{'assignedInventorySourceId'}"

    headers = {
        'Content-Type': 'application/json'
    }

    params = {
        'key': '',
        'prettyPrint': False,
        'quotaUser': '',
        'upload_protocol': '',
        'uploadType': ''
    }
    # Add security scheme parameters if needed
    auth = ('', '')

    response = requests.request(
        'DELETE',
        url,
        headers=headers,
        params=params,
        auth=auth
    )

    assert response.status_code == 200

if __name__ == "__main__":
    pytest.main([__file__])