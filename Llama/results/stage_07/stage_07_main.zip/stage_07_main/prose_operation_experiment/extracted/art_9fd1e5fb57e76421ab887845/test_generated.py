import pytest
import requests
from jsonschema import ValidationError

BASE_URL = "http://openapi.test"

def test_get_image_policy_check_by_imageId():
    image_id = "example-image-id"
    policy_id = None
    tag = "example-tag"
    detail = False
    history = False
    account = None

    url = f"{BASE_URL}/images/by_id/{image_id}/check"
    params = {
        "policyId": policy_id,
        "tag": tag,
        "detail": detail,
        "history": history,
    }
    headers = {}
    if account:
        headers["x-anchore-account"] = account

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 200
    try:
        response.json()
    except ValueError as e:
        raise AssertionError("Invalid JSON response") from e
    except ValidationError as e:
        print(f"JSON schema validation error: {e}")
        pytest.fail("Failed to parse response")

    # Additional assertions can be added here based on the expected PolicyEvaluationList response