import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_tracking_snippet_success():
    url = f"{BASE_URL}/tracking/snippet"
    params = {"domain": "example.com"}
    headers = {
        "Authorization": "Bearer your-api-key"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert "meta" in data
    assert "data" in data
    assert "domain" in data["data"]
    assert "snippet" in data["data"]

def test_get_tracking_snippet_bad_request():
    url = f"{BASE_URL}/tracking/snippet"
    params = {"domain": ""}
    headers = {
        "Authorization": "Bearer your-api-key"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 400
    data = response.json()
    assert "meta" in data
    assert "message" in data["meta"]
    assert "errors" in data

def test_get_tracking_snippet_unauthorized():
    url = f"{BASE_URL}/tracking/snippet"
    params = {"domain": "example.com"}
    headers = {
        "Authorization": "Bearer invalid-api-key"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 401
    data = response.json()
    assert "meta" in data
    assert "message" in data["meta"]

def test_get_tracking_snippet_forbidden():
    url = f"{BASE_URL}/tracking/snippet"
    params = {"domain": "example.com"}
    headers = {
        "Authorization": "Bearer disabled-api-key"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 403
    data = response.json()
    assert "meta" in data
    assert "message" in data["meta"]

def test_get_tracking_snippet_not_found():
    url = f"{BASE_URL}/tracking/snippet"
    params = {"domain": "nonexistent.com"}
    headers = {
        "Authorization": "Bearer your-api-key"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 404
    data = response.json()
    assert "meta" in data
    assert "message" in data["meta"]

def test_get_tracking_snippet_too_many_requests():
    url = f"{BASE_URL}/tracking/snippet"
    params = {"domain": "example.com"}
    headers = {
        "Authorization": "Bearer your-api-key"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 429
    data = response.json()
    assert "meta" in data
    assert "message" in data["meta"]

def test_get_tracking_snippet_internal_error():
    url = f"{BASE_URL}/tracking/snippet"
    params = {"domain": "example.com"}
    headers = {
        "Authorization": "Bearer your-api-key"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 500
    data = response.json()
    assert "meta" in data
    assert "message" in data["meta"]