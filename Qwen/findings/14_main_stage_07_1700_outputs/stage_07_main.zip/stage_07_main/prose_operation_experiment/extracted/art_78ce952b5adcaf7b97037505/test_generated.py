import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_data_integration_associations():
    headers = {
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Date": "20230401T000000Z",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "access_key_id/20230401/us-east-1/appintegrations/aws4_request",
        "X-Amz-Security-Token": "session_token",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-algorithm;x-amz-credential;x-amz-security-token"
    }
    params = {
        "nextToken": "",
        "maxResults": 10
    }
    url = f"{BASE_URL}/dataIntegrations/test-data-integration/associations"
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    assert "DataIntegrationAssociations" in response.json()
    assert len(response.json()["DataIntegrationAssociations"]) <= params["maxResults"]