import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_public_action_revision():
    app_id = 12345
    definition_id = "abcdef"
    revision_id = "ghijkl"
    url = f"{BASE_URL}/automation/v4/actions/{app_id}/{definition_id}/revisions/{revision_id}"
    headers = {
        "Accept": "application/json",
        "hapikey": "your_hapikey_here"
    }
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert "id" in data
    assert "revisionId" in data
    assert "createdAt" in data
    assert "definition" in data
    assert "appId" in data["definition"]
    assert "definitionId" in data["definition"]
    assert "revisionId" in data["definition"]
    assert "published" in data["definition"]
    assert "inputFields" in data["definition"]
    assert "outputFields" in data["definition"]
    assert "objectTypes" in data["definition"]
    assert "actions" in data["definition"]
