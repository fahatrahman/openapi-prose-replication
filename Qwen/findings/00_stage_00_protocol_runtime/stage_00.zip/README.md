# Stage 00 — protocol and runtime

Status: **PASS**

This dataset contains the Stage 00 runtime and protocol archive for the prose-operation experiment.

Archive: `stage_00_protocol_runtime_v1.zip`

SHA-256: `496f3c14ca2715122d0134087714b1e3276ce125e070901595c994e3d50622a9`

Read `stage_00_manifest.json` before using the archive. A NEEDS_REVIEW archive is diagnostic only; use the verified PASS archive from the recorded Kaggle run for downstream work.
