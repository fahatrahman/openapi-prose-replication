import pytest
import requests

BASE_URL = "http://openapi.test"

def test_update_threat_intel_set():
    headers = {
        "X-Amz-Content-Sha256": "example-sha256",
        "X-Amz-Date": "20230401T123456Z",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "example-credential",
        "X-Amz-Security-Token": "example-token",
        "X-Amz-Signature": "example-signature",
        "X-Amz-SignedHeaders": "host"
    }
    payload = {
        "activate": True,
        "location": "example-location",
        "name": "example-name"
    }
    response = requests.post(
        f"{BASE_URL}/detector/example-detectorId/threatintelset/example-threatIntelSetId",
        headers=headers,
        json=payload
    )
    assert response.status_code == 200
    assert isinstance(response.json(), dict)