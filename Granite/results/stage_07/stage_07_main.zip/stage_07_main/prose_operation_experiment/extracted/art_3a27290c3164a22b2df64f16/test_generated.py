import os
import pytest
import requests
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def setup_service():
    # Assuming you have a service object here, replace with your actual service creation
    credentials = None  # Replace with your credentials
    http_authorized = credentials.authorize(requests.get)
    service = build('your_service', 'v1', http=http_authorized)

    return service

def test_add_items(setup_service):
    project_id = "your_project_id"
    location_id = "your_location_id"
    address_group_id = "your_address_group_id"

    request_body = {
        "items": ["item1", "item2"],
        "requestId": "your_request_id"
    }

    try:
        response = setup_service.projects().locations().addressGroups().addItems(
            name=f"{project_id}/{location_id}/{address_group_id}",
            body=request_body
        ).execute()

        assert response["name"] == f"{project_id}/{location_id}/{address_group_id}"
        print("Test passed.")
    except HttpError as error:
        print(f"An error occurred: {error}")