# -*- coding: utf-8 -*-
import pytest
import requests

BASE_URL = "http://openapi.test"

def test_listings_all():
    params = {
        'ecosystem_id': 'your_ecosystem_id',
        'cursor': None,
        'limit': 50,
        'external_id': None
    }
    response = requests.get(f"{BASE_URL}/ecosystems/{params['ecosystem_id']}/listings", 
                            params=params)
    assert response.status_code == 200
    response.raise_for_status()
    assert isinstance(response.json(), dict)