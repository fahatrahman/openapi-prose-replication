# -*- coding: utf-8 -*-
"""
Test GetEmployerRevisions endpoint.

.. note::
    This test suite is generated based on the provided OpenAPI specification.
"""

import pytest
import requests

BASE_URL = "http://openapi.test"

def get_employer_revisions(employer_id, authorization, api_version):
    """
    Test GetEmployerRevisions endpoint.

    :param employer_id: Employer ID
    :type employer_id: str
    :param authorization: Authorization header value
    :type authorization: str
    :param api_version: Api-Version header value
    :type api_version: str
    :return: Response content
    :rtype: dict
    """
    url = f"{BASE_URL}/Employer/{employer_id}/Revisions"
    headers = {
        "Authorization": authorization,
        "Api-Version": api_version
    }
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    return response.json()

def test_get_employer_revisions():
    """
    Test GetEmployerRevisions endpoint with default values.
    """
    employer_id = "GD001"
    authorization = "Auto"
    api_version = "default"
    response_content = get_employer_revisions(employer_id, authorization, api_version)
    assert isinstance(response_content, dict)

def test_get_employer_revisions_invalid_employer_id():
    """
    Test GetEmployerRevisions endpoint with invalid employer ID.
    """
    employer_id = "invalid_id"
    authorization = "Auto"
    api_version = "default"
    with pytest.raises(requests.exceptions.HTTPError):
        get_employer_revisions(employer_id, authorization, api_version)

def test_get_employer_revisions_invalid_authorization():
    """
    Test GetEmployerRevisions endpoint with invalid authorization.
    """
    employer_id = "GD001"
    authorization = "Invalid"
    api_version = "default"
    with pytest.raises(requests.exceptions.HTTPError):
        get_employer_revisions(employer_id, authorization, api_version)

def test_get_employer_revisions_invalid_api_version():
    """
    Test GetEmployerRevisions endpoint with invalid api version.
    """
    employer_id = "GD001"
    authorization = "Auto"
    api_version = "invalid"
    with pytest.raises(requests.exceptions.HTTPError):
        get_employer_revisions(employer_id, authorization, api_version)