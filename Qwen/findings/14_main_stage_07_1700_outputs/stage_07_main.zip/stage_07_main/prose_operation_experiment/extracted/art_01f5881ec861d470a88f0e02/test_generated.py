import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_losing_bids():
    url = f"{BASE_URL}/v2beta1/{filterSetName}/losingBids"
    params = {
        "_xgafv": "2",
        "access_token": "your_access_token_here",
        "alt": "json",
        "callback": "your_callback_here",
        "fields": "your_fields_here",
        "key": "your_key_here",
        "oauth_token": "your_oauth_token_here",
        "prettyPrint": False,
        "quotaUser": "your_quota_user_here",
        "uploadType": "multipart/form-data",
        "upload_protocol": "raw",
        "pageSize": 10,
        "pageToken": ""
    }
    headers = {
        "Authorization": "Bearer your_access_token_here"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    assert "creativeStatusRows" in response.json()

if __name__ == "__main__":
    pytest.main()