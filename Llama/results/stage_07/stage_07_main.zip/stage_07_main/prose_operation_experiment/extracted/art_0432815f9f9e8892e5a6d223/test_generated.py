# -*- coding: utf-8 -*-
import pytest
import json
import requests
from datetime import datetime
import hashlib
import hmac
import base64
import os

BASE_URL = "http://openapi.test"

def get_timestamp():
    return int(datetime.now().timestamp())

def get_signature(method, path, payload=None):
    timestamp = get_timestamp()
    date_string = datetime.utcfromtimestamp(timestamp).strftime('%Y%m%dT%H%M%SZ')
    credential_scope = f"{date_string}/{path}"
    string_to_sign = f"{method}\n{credential_scope}\n{get_hash(payload)}"
    signing_key = os.environ.get('AWS_SECRET_ACCESS_KEY').encode() + b'\n' + os.environ.get('AWS_SESSION_TOKEN').encode() if os.environ.get('AWS_SESSION_TOKEN') else os.environ.get('AWS_SECRET_ACCESS_KEY').encode()
    signature = base64.b64encode(hmac.new(signing_key, string_to_sign.encode(), hashlib.sha256).digest())
    return signature.decode()

def get_hash(payload):
    if payload is None:
        return ''
    return hashlib.sha256(json.dumps(payload).encode()).hexdigest()

def update_link(identifier, resource_types):
    headers = {
        'X-Amz-Algorithm': 'AWS4-HMAC-SHA256',
        'X-Amz-Content-Sha256': get_hash({}),
        'X-Amz-Date': get_timestamp(),
        'X-Amz-Credential': f'{os.environ.get("AWS_ACCESS_KEY_ID")}/20160904/eu-west-1/xray/aws4_request',
        'X-Amz-Security-Token': os.environ.get('AWS_SESSION_TOKEN'),
        'X-Amz-SignedHeaders': 'host;x-amz-date',
        'Authorization': f'AWS4-HMAC-SHA256 Credential={os.environ.get("AWS_ACCESS_KEY_ID")}/20160904/eu-west-1/xray/aws4_request, SignedHeaders=host;x-amz-date, Signature={get_signature("POST", "/UpdateLink", {"Identifier": identifier, "ResourceTypes": resource_types})}',
    }
    response = requests.post(f'{BASE_URL}/UpdateLink', headers=headers, json={"Identifier": identifier, "ResourceTypes": resource_types})
    assert response.status_code == 200
    return response.json()

@pytest.mark.parametrize("identifier,resource_types", [
    ("test_identifier", ["AWS::CloudWatch::Metric"]),
])
def test_update_link(identifier, resource_types):
    output = update_link(identifier, resource_types)
    print(output)

if __name__ == "__main__":
    pytest.main([__file__])