import os
import pytest
import requests
from requests.exceptions import RequestException
from base64 import b64encode

BASE_URL = "http://openapi.test"

# Basic auth credentials (replace with your actual credentials)
USERNAME = "your_username"
PASSWORD = "your_password"
CREDENTIALS = b64encode(f"{USERNAME}:{PASSWORD}".encode()).decode()

@pytest.fixture
def client():
    session = requests.Session()
    session.auth = ("your_username", "your_password")
    return session

def delete_target(service_id):
    endpoint = f"{BASE_URL}/api/services/{service_id}/targets"

    try:
        response = requests.delete(endpoint, verify=False)

        if response.status_code == 200:
            targets = response.json()
            assert isinstance(targets, list), "Targets should be an array"
            for target in targets:
                assert set(["host", "scheme"]).issubset(target.keys()), "Each target should have 'host' and 'scheme'"
            print("Test passed: Successfully deleted targets.")
        elif response.status_code == 400:
            print(f"Test failed: Bad resource format - {response.text}")
        elif response.status_code == 401:
            print("Test failed: You need to provide valid Api Key.")
        elif response.status_code == 404:
            print("Test failed: Resource not found.")
        else:
            print(f"Unexpected status code: {response.status_code} - {response.text}")

    except RequestException as e:
        print(f"Test failed: An error occurred while making the request - {e}")