import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_operations():
    url = f"{BASE_URL}/v1beta1/projects/your-project-id/operations"
    params = {
        "filter": "status=RUNNING",
        "pageSize": 10,
        "pageToken": ""
    }
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    data = response.json()
    assert "operations" in data
    assert isinstance(data["operations"], list)

if __name__ == "__main__":
    pytest.main()