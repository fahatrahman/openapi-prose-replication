import os
import requests
import pytest
BASE_URL = "http://openapi.test"

@pytest.fixture
def payment_reversal_payload():
    return {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "reference": "YOUR_UNIQUE_REFERENCE"
    }

def test_payment_reversal(payment_reversal_payload):
    url = f"{BASE_URL}/payments/{{paymentPspReference}}/reversals"
    headers = {"Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed"}  # Replace with actual idempotency key
    payload = payment_reversal_payload

    response = requests.post(url.format(paymentPspReference="your_payment_psp_reference"),
                            headers=headers, json=payload)

    assert response.status_code == 201
    assert response.json()["status"] == "received"