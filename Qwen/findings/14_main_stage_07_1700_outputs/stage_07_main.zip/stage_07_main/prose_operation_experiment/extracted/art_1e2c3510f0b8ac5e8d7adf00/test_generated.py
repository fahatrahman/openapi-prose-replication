import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_backup_runs():
    url = f"{BASE_URL}/v1/projects/project-id/instances/instance-id/backupRuns"
    params = {
        "maxResults": 10,
        "pageToken": ""
    }
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert "items" in data
    assert "kind" in data and data["kind"] == "sql#backupRunsList"