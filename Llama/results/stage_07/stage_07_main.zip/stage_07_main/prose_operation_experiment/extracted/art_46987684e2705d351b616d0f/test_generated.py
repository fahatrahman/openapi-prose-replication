# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urlencode

BASE_URL = "http://openapi.test"

def test_displayvideo_media_download():
    params = {
        "_xgafv": "1",
        "access_token": "",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "",
        "oauth_token": "",
        "prettyPrint": "false",
        "quotaUser": "",
        "upload_protocol": "",
        "uploadType": "",
        "resourceName": "example_resource_name"
    }
    
    response = requests.get(
        f"{BASE_URL}/download/{params['resourceName']}",
        params=urlencode(params)
    )
    
    assert response.status_code == 200
    
    # Assert that the response content type is application/json
    assert response.headers["Content-Type"].startswith("application/")
    
    # Assert that the response body is a valid JSON object
    try:
        response.json()
    except ValueError:
        pytest.fail("Response body is not a valid JSON object")