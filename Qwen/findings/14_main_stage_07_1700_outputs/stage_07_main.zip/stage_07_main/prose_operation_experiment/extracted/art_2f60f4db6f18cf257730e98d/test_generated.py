import pytest
import requests

BASE_URL = "http://openapi.test"

def test_patch_environment_folder():
    environment_id = "test_environment_id"
    folder_body = {
        "recentFolderPaths": ["path/to/folder"]
    }
    
    headers = {
        "Authorization": "Bearer your_jwt_token_here",
        "Content-Type": "application/json"
    }
    
    response = requests.patch(f"{BASE_URL}/api/v1/Environments/{environment_id}/folder", json=folder_body, headers=headers)
    
    assert response.status_code == 200
    assert "application/json" in response.headers["Content-Type"]
    cloud_environment_result = response.json()
    assert isinstance(cloud_environment_result, dict)
    # Add more assertions based on the expected structure of CloudEnvironmentResult