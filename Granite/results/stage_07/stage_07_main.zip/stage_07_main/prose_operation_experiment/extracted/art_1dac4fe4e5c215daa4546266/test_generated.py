import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

@pytest.fixture
def api_client():
    session = requests.Session()
    retry = Retry(total=3, backoff_factor=0.1, status_forcelist=[429, 500, 502, 503, 504])
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("https://", adapter)
    return session

def test_post_origin_keys_basic(api_client):
    endpoint = "/originKeys"
    headers = {"Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed"}

    response = api_client.post(BASE_URL + endpoint, json={"originDomains": ["https://www.your-domain1.com", "https://www.your-domain2.com", "https://www.your-domain3.com"]}, headers=headers)
    
    assert response.status_code == 200
    assert response.json()["originKeys"]["https://www.your-domain1.com"] == "pub.v2.8116178901076090.aHR0cHM6Ly93d3cueW91ci1kb21haW4xLmNvbQ.pvbYlrXz0ICP4kwMJXDGDLVMqALhwXr1MSRjT-fkhvw"
    assert response.json()["originKeys"]["https://www.your-domain2.com"] == "pub.v2.8116178901076090.aHR0cHM6Ly93d3cueW91ci1kb21haW4yLmNvbQ.LdN9kvJ35fYFFiBSJA4idMnwwxJ5_yXpeNS__Ap5wkg"
    assert response.json()["originKeys"]["https://www.your-domain3.com"] == "pub.v2.8116178901076090.aHR0cHM6Ly93d3cueW91ci1kb21haW4zLmNvbQ.FrTpVz7_RzAywKasM0kXCRoMfoMkKIKaxjFymRGORIc"