import pytest
import requests

BASE_URL = "http://openapi.test"

def test_synthesize_speech():
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20130524/us-east-1/polly/aws4_request",
        "X-Amz-Date": "20130524T230000Z",
        "X-Amz-Security-Token": "AQoDYXdzEPT//////////wEXAMPLEtc7NCLmni7LVvPjC6ZuQmYGzzqKTJphZ3fxBcdW9Ob+WXce9tvSUogtCYK9JDgMrEtgr3NkVbmd1SpJifNKXksVjdADcj4Px4WY3oHYGMgFhntTQqupkJtaP0MZxDyiDSjlPsGciEXErtDRRC5Q==",
        "X-Amz-Signature": "EXAMPLEkeTlKJnqj7VNi7NCZuwtibLJhgYZd78FWE33geXr8=",
        "X-Amz-SignedHeaders": "host"
    }
    payload = {
        "OutputFormat": "mp3",
        "Text": "Hello, world!",
        "VoiceId": "Joanna"
    }
    response = requests.post(f"{BASE_URL}/v1/speech", headers=headers, json=payload)
    assert response.status_code == 200
    assert "AudioStream" in response.json()
    assert "ContentType" in response.json()
    assert "RequestCharacters" in response.json()

if __name__ == "__main__":
    pytest.main()