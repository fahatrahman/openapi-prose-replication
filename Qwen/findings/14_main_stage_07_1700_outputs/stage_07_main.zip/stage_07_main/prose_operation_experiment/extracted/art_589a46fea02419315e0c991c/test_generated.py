import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_firewall_rules():
    url = f"{BASE_URL}/entities/firewall-rules"
    params = {
        "size": 10,
        "cursor": None,
        "start_time": 1509344618,
        "end_time": 1509344618
    }
    headers = {
        "Authorization": "Bearer YOUR_API_KEY"
    }
    
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "cursor" in data
    assert "end_time" in data
    assert isinstance(data["results"], list)
    assert all(isinstance(item, dict) for item in data["results"])
    assert "entity_id" in data["results"][0]
    assert "entity_type" in data["results"][0]
    assert "time" in data["results"][0]
    assert "start_time" in data
    assert "total_count" in data

def test_list_firewall_rules_400():
    url = f"{BASE_URL}/entities/firewall-rules"
    params = {
        "size": -1,
        "cursor": None,
        "start_time": 1509344618,
        "end_time": 1509344618
    }
    headers = {
        "Authorization": "Bearer YOUR_API_KEY"
    }
    
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 400
    data = response.json()
    assert isinstance(data, dict)
    assert "code" in data
    assert "message" in data
    assert "details" in data

def test_list_firewall_rules_401():
    url = f"{BASE_URL}/entities/firewall-rules"
    params = {
        "size": 10,
        "cursor": None,
        "start_time": 1509344618,
        "end_time": 1509344618
    }
    headers = {
        "Authorization": "Bearer INVALID_API_KEY"
    }
    
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 401

def test_list_firewall_rules_500():
    url = f"{BASE_URL}/entities/firewall-rules"
    params = {
        "size": 10,
        "cursor": None,
        "start_time": 1509344618,
        "end_time": 1509344618
    }
    headers = {
        "Authorization": "Bearer ERROR_API_KEY"
    }
    
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 500