import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_product_variants():
    authtoken = "your_authtoken_here"
    login = "your_login_here"
    product_id = 123  # Replace with actual product ID

    url = f"{BASE_URL}/products/{product_id}/variants.json"
    params = {
        "authtoken": authtoken,
        "login": login
    }

    response = requests.get(url, params=params)

    assert response.status_code == 200
    variants = response.json()
    assert isinstance(variants, list)
    for variant in variants:
        assert "variant" in variant
        variant_data = variant["variant"]
        assert "id" in variant_data
        assert "image" in variant_data
        assert "options" in variant_data
        assert "price" in variant_data
        assert "sku" in variant_data
        assert "stock" in variant_data
        assert "stock_unlimited" in variant_data