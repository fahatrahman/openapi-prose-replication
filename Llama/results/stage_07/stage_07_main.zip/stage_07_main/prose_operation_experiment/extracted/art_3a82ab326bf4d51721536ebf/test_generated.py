import pytest
import requests
from datetime import datetime
from urllib.parse import urlencode

BASE_URL = "http://openapi.test"

def get_list_streaming_sessions_response(studio_id, created_by=None, owned_by=None, session_ids=None, next_token=None):
    params = {}
    if created_by:
        params['createdBy'] = created_by
    if owned_by:
        params['ownedBy'] = owned_by
    if session_ids:
        params['sessionIds'] = session_ids
    if next_token:
        params['nextToken'] = next_token

    headers = {
        'X-Amz-Algorithm': '',
        'X-Amz-Content-Sha256': '',
        'X-Amz-Credential': '',
        'X-Amz-Date': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': '',
        'X-Amz-SignedHeaders': ''
    }

    response = requests.get(f'{BASE_URL}/2020-08-01/studios/{studio_id}/streaming-sessions', headers=headers, params=params)

    assert response.status_code == 200
    return response.json()

def test_list_streaming_sessions():
    response = get_list_streaming_sessions_response('studio-id')
    assert isinstance(response, dict)
    assert 'sessions' in response
    assert 'nextToken' in response

def test_list_streaming_sessions_with_created_by():
    response = get_list_streaming_sessions_response('studio-id', created_by='user-id')
    assert isinstance(response, dict)
    assert 'sessions' in response
    assert 'nextToken' in response

def test_list_streaming_sessions_with_owned_by():
    response = get_list_streaming_sessions_response('studio-id', owned_by='user-id')
    assert isinstance(response, dict)
    assert 'sessions' in response
    assert 'nextToken' in response

def test_list_streaming_sessions_with_session_ids():
    response = get_list_streaming_sessions_response('studio-id', session_ids=['session-id'])
    assert isinstance(response, dict)
    assert 'sessions' in response
    assert 'nextToken' in response

def test_list_streaming_sessions_with_next_token():
    response = get_list_streaming_sessions_response('studio-id', next_token='token')
    assert isinstance(response, dict)
    assert 'sessions' in response
    assert 'nextToken' in response

if __name__ == '__main__':
    pytest.main([__file__])