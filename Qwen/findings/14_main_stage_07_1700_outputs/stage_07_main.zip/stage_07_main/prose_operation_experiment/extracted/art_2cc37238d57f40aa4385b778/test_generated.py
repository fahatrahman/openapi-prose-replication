import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_remarketing_tag():
    url = f"{BASE_URL}/v1/jrvqgo/12345:getRemarketingTag"
    params = {
        "_xgafv": "1",
        "access_token": "fake_access_token",
        "alt": "json",
        "callback": "callback_function",
        "fields": "snippet",
        "key": "fake_key",
        "oauth_token": "fake_oauth_token",
        "prettyPrint": False,
        "quotaUser": "user@example.com",
        "uploadType": "multipart/form-data",
        "upload_protocol": "raw"
    }
    headers = {
        "Authorization": "Bearer fake_bearer_token"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    assert "snippet" in response.json()