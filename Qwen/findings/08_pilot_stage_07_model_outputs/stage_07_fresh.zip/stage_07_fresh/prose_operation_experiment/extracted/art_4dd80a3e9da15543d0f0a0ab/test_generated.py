import pytest
import requests

BASE_URL = "http://openapi.test"

def test_cancel_payment_with_own_reference():
    url = f"{BASE_URL}/cancels"
    headers = {
        "Content-Type": "application/json",
        "Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed"
    }
    payload = {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "paymentReference": "YOUR_UNIQUE_REFERENCE_FOR_THE_PAYMENT",
        "reference": "YOUR_UNIQUE_REFERENCE_FOR_THE_CANCELLATION"
    }
    
    response = requests.post(url, headers=headers, json=payload)
    
    assert response.status_code == 201
    assert response.json()["status"] == "received"
    assert "merchantAccount" in response.json()
    assert "paymentReference" in response.json()
    assert "pspReference" in response.json()
    assert "reference" in response.json()

def test_cancel_payment_with_missing_reference():
    url = f"{BASE_URL}/cancels"
    headers = {
        "Content-Type": "application/json",
        "Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed"
    }
    payload = {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "paymentReference": "YOUR_UNIQUE_REFERENCE_FOR_THE_PAYMENT"
    }
    
    response = requests.post(url, headers=headers, json=payload)
    
    assert response.status_code == 422
    assert response.json()["errorCode"] == 14030
    assert response.json()["errorType"] == "validation"
    assert response.json()["message"] == "Return URL is missing."

@pytest.mark.parametrize("status_code, error_code, error_type, message", [
    (400, "702", "validation", "Unexpected input: \", expected: }"),
    (401, "000", "security", "HTTP Status Response - Unauthorized"),
    (403, "901", "security", "Invalid Merchant Account"),
    (500, "905", "configuration", "Payment details are not supported")
])
def test_error_responses(status_code, error_code, error_type, message):
    url = f"{BASE_URL}/cancels"
    headers = {
        "Content-Type": "application/json",
        "Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed"
    }
    payload = {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "paymentReference": "YOUR_UNIQUE_REFERENCE_FOR_THE_PAYMENT",
        "reference": "YOUR_UNIQUE_REFERENCE_FOR_THE_CANCELLATION"
    }
    
    response = requests.post(url, headers=headers, json=payload)
    
    assert response.status_code == status_code
    assert response.json()["errorCode"] == error_code
    assert response.json()["errorType"] == error_type
    assert response.json()["message"] == message