import os
import pytest
import requests
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

BASE_URL = "http://openapi.test"
SCOPES = ['https://www.googleapis.com/auth/tagmanager.edit.containers']

def test_create_workspace():
    """Test creating a new Workspace."""
    # If modifying these scopes, delete the file token.json.
    token_file = 'token.json'
    credentials = None
    if os.path.exists(token_file):
        credentials = requests.model.json.load(open(token_file))

    if not credentials or not credentials['refresh_token']:
        flow = client.install(scope=SCOPES)
        credential_uri = flow.step1_get_authorize_url()
        print('Go to the following link in your browser then type the code:\n' +
              credential_uri + '\n')
        code = input("Enter verification code: ")

        # Exchange code for tokens
        credentials = flow.step2_exchange(code)

        # Save the tokens to a file
        with open(token_file, 'w') as token:
            requests.model.json.dump(credentials, token)

    service = build('tagmanager', 'v2', credentials=credentials)

    parent = 'accounts/{account_id}/containers/{container_id}'.format(
        account_id='your_account_id', container_id='your_container_id'
    )

    workspace = {
        "name": "New Workspace Name",
        "description": "New Workspace Description"
    }

    try:
        response = service.accounts().containers().workspaces().create(
            parent=parent, body=workspace
        ).execute()
        print(f"Workspace created successfully: {response}")
    except HttpError as error:
        print(f"An error occurred: {error}")