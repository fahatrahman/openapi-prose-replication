import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Retry mechanism for requests
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def photo_api():
    def _photo_api(shortName, offset, count):
        url = f"{BASE_URL}/v2/tier2/{shortName}/photo/photos"
        params = {"offset": offset, "count": count}
        response = session.get(url, params=params)
        response.raise_for_status()
        return response.json()

    yield _photo_api

def test_photo_api(photo_api):
    shortName = "example_shortName"
    offset = 0
    count = 10
    result = photo_api(shortName, offset, count)
    assert isinstance(result, dict)
    assert "data" in result
    assert isinstance(result["data"], list)
    for item in result["data"]:
        assert isinstance(item, dict)
        assert set(item.keys()) <= {"ETag", "FileName", "InspectionItem", "InterimInspection", "InventoryItem", "Name", "OID", "PhotoNumber", "PhotoType", "Property", "Room"}
    assert "count" in result