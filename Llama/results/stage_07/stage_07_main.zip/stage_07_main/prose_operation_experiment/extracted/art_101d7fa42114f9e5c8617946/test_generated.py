# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_aiplatform_projects_locations_metadatastores_contexts_create():
    parent = "/v1/test-parent"
    context_id = "test-context-id"
    headers = {"Content-Type": "application/json"}
    json_data = {
        "createTime": None,
        "description": None,
        "displayName": None,
        "etag": None,
        "labels": {},
        "metadata": {},
        "name": None,
        "parentContexts": [],
        "schemaTitle": None,
        "schemaVersion": None,
        "updateTime": None
    }
    
    response = requests.post(
        f"{BASE_URL}{parent}/contexts?contextId={context_id}",
        headers=headers,
        json=json_data,
        params={
            "$.xgafv": "1",
            "access_token": "",
            "alt": "json",
            "callback": "",
            "fields": "",
            "key": "",
            "oauth_token": "",
            "prettyPrint": "false",
            "quotaUser": "",
            "upload_protocol": "multipart",
            "uploadType": "media"
        },
        auth=None
    )

    assert response.status_code == 200