import pytest
import requests
from uuid import UUID

BASE_URL = "http://openapi.test"

def test_teams_listAll():
    # Get API token from environment variable or secure storage
    api_token = os.environ.get("API_TOKEN")

    if not api_token:
        pytest.skip("API token is required for this test")

    headers = {"X-API-Token": api_token}

    response = requests.get(
        f"{BASE_URL}/v0.1/orgs/{'test_org'}",
        headers=headers,
    )

    assert response.status_code == 200

    try:
        json_data = response.json()
        assert isinstance(json_data, list)
        for team in json_data:
            assert "id" in team
            assert "name" in team
            assert "display_name" in team
            assert "description" in team
            assert isinstance(team["id"], str)
            try:
                UUID(team["id"])
            except ValueError:
                pytest.fail(f"Invalid UUID: {team['id']}")
    except ValueError:
        pytest.fail("Expected JSON response")