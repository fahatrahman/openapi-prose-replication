import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retries
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def task_logs():
    id_ = "c2ada9df5af8"
    params = {
        "details": False,
        "follow": False,
        "stdout": True,
        "stderr": True,
        "since": 0,
        "timestamps": False,
        "tail": "all",
    }

    url = f"{BASE_URL}/tasks/{id_}/logs"
    response = session.get(url, params=params)

    if response.status_code == 101:
        # Handle streaming response
        response.raw._consume_transport_encoding = lambda: True
        return response.raw
    elif response.status_code == 200:
        # Return logs as a string
        return response.text
    else:
        # Raise an exception for other status codes
        raise Exception(
            f"Unexpected status code: {response.status_code}. Response content: {response.content}"
        )