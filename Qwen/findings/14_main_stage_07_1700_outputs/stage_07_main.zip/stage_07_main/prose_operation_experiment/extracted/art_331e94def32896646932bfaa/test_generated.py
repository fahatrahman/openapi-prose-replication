import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_operations():
    url = f"{BASE_URL}/v1/projects/locations/operations"
    params = {
        "_xgafv": "2",
        "access_token": "your_access_token_here",
        "alt": "json",
        "callback": "your_callback_url_here",
        "fields": "*",
        "key": "your_api_key_here",
        "oauth_token": "your_oauth_token_here",
        "prettyPrint": False,
        "quotaUser": "your_quota_user_here",
        "uploadType": "multipart/form-data",
        "upload_protocol": "raw",
        "name": "projects/your_project_id/locations/your_location",
        "filter": "status=RUNNING",
        "pageSize": 10,
        "pageToken": ""
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    assert "operations" in response.json()