import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def headers(api_key):
    return {
        "X-Api-Key": api_key,
        "Authorization": f"Bearer {api_key}"
    }

@pytest.fixture
def api_key():
    return "your_api_key_here"

def test_fetch_boundaries_success(api_key):
    url = f"{BASE_URL}/v4/boundaries/query"
    payload = {
        "ids": ["some_boundary_id"]
    }
    response = requests.post(url, json=payload, headers=headers(api_key))
    assert response.status_code == 200
    assert "features" in response.json()

def test_fetch_boundaries_invalid_request(api_key):
    url = f"{BASE_URL}/v4/boundaries/query"
    payload = {}
    response = requests.post(url, json=payload, headers=headers(api_key))
    assert response.status_code == 400

def test_fetch_boundaries_unauthorized(api_key):
    url = f"{BASE_URL}/v4/boundaries/query"
    payload = {
        "ids": ["some_boundary_id"]
    }
    response = requests.post(url, json=payload)
    assert response.status_code == 401

def test_fetch_boundaries_forbidden(api_key):
    url = f"{BASE_URL}/v4/boundaries/query"
    payload = {
        "ids": ["some_boundary_id"]
    }
    response = requests.post(url, json=payload, headers={"Authorization": "Bearer invalid_token"})
    assert response.status_code == 403

def test_fetch_boundaries_not_found(api_key):
    url = f"{BASE_URL}/v4/boundaries/query"
    payload = {
        "ids": ["non_existent_boundary_id"]
    }
    response = requests.post(url, json=payload, headers=headers(api_key))
    assert response.status_code == 404

def test_fetch_boundaries_too_many_requests(api_key):
    url = f"{BASE_URL}/v4/boundaries/query"
    payload = {
        "ids": ["some_boundary_id"]
    }
    response = requests.post(url, json=payload, headers=headers(api_key))
    assert response.status_code == 429

def test_fetch_boundaries_internal_server_error(api_key):
    url = f"{BASE_URL}/v4/boundaries/query"
    payload = {
        "ids": ["some_boundary_id"]
    }
    response = requests.post(url, json=payload, headers=headers(api_key))
    assert response.status_code == 500

def test_fetch_boundaries_service_unavailable(api_key):
    url = f"{BASE_URL}/v4/boundaries/query"
    payload = {
        "ids": ["some_boundary_id"]
    }
    response = requests.post(url, json=payload, headers=headers(api_key))
    assert response.status_code == 503