import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_get_bridge_service_details():
    """Test getting bridge service details by service ID."""
    
    # Get service profile response
    headers = {"Authorization": "access_token"}
    response = requests.get(
        urljoin(BASE_URL, "/v0.5/hi-services/service-id"),
        headers=headers,
        params={"service-id": "service-id"},
    )
    
    assert response.status_code == 200
    
    # Parse JSON response
    try:
        response_json = response.json()
    except ValueError:
        pytest.fail("Invalid JSON response")
    
    # Check response schema
    expected_schema = {
        "type": "object",
        "properties": {
            "active": {"type": "boolean"},
            "endpoints": {
                "type": "array",
                "items": {"$ref": "#/components/schemas/Endpoint"},
            },
            "id": {"type": "string"},
            "name": {"type": "string"},
            "type": {"$ref": "#/components/schemas/ServiceRole"},
        },
    }
    
    assert response_json.keys() >= expected_schema["properties"].keys()
    for key in expected_schema["properties"]:
        if isinstance(expected_schema["properties"][key], dict):
            items = response_json[key]
            if isinstance(expected_schema["properties"][key]["items"], str):
                items_ref = expected_schema["properties"][key]["items"]
                expected_items_schema = {"$ref": items_ref}
            else:
                expected_items_schema = expected_schema["properties"][key]["items"]
            
            # Check items schema
            assert len(items) > 0
            for item in items:
                assert item.keys() >= expected_items_schema.keys()
                for sub_key in expected_items_schema:
                    if isinstance(expected_items_schema[sub_key], dict):
                        sub_items = item[sub_key]
                        if isinstance(expected_items_schema[sub_key]["items"], str):
                            sub_items_ref = expected_items_schema[sub_key]["items"]
                            expected_sub_items_schema = {"$ref": sub_items_ref}
                        else:
                            expected_sub_items_schema = expected_items_schema[sub_key]["items"]
                        
                        # Check sub-items schema
                        assert len(sub_items) > 0
                        for sub_item in sub_items:
                            assert sub_item.keys() >= expected_sub_items_schema.keys()