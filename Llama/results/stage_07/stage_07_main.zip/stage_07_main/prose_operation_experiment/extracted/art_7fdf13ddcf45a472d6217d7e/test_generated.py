import pytest
import requests

BASE_URL = "http://openapi.test"

def test_baremetalsolution_projects_locations_instances_reset():
    url = f"{BASE_URL}/v2/{'name'}:reset"
    headers = {
        "Content-Type": "application/json",
    }
    data = {}
    
    response = requests.post(url, headers=headers, json=data)
    assert response.status_code == 200
    
    response_json = response.json()
    assert isinstance(response_json, dict)
    assert 'done' in response_json
    assert isinstance(response_json['done'], bool)
    assert 'error' in response_json
    assert isinstance(response_json['error'], dict)
    assert 'code' in response_json['error']
    assert isinstance(response_json['error']['code'], int)
    assert 'details' in response_json['error']
    assert isinstance(response_json['error']['details'], list)
    assert all(isinstance(item, dict) for item in response_json['error']['details'])
    assert 'message' in response_json['error']
    assert isinstance(response_json['error']['message'], str)
    assert 'metadata' in response_json
    assert isinstance(response_json['metadata'], dict)
    assert 'name' in response_json
    assert isinstance(response_json['name'], str)
    assert 'response' in response_json
    assert isinstance(response_json['response'], dict)

def test_baremetalsolution_projects_locations_instances_reset_oauth():
    url = f"{BASE_URL}/v2/{'name'}:reset"
    headers = {
        "Authorization": "Bearer access_token",
        "Content-Type": "application/json",
    }
    data = {}
    
    response = requests.post(url, headers=headers, json=data)
    assert response.status_code == 200
    
    response_json = response.json()
    assert isinstance(response_json, dict)
    assert 'done' in response_json
    assert isinstance(response_json['done'], bool)
    assert 'error' in response_json
    assert isinstance(response_json['error'], dict)
    assert 'code' in response_json['error']
    assert isinstance(response_json['error']['code'], int)
    assert 'details' in response_json['error']
    assert isinstance(response_json['error']['details'], list)
    assert all(isinstance(item, dict) for item in response_json['error']['details'])
    assert 'message' in response_json['error']
    assert isinstance(response_json['error']['message'], str)
    assert 'metadata' in response_json
    assert isinstance(response_json['metadata'], dict)
    assert 'name' in response_json
    assert isinstance(response_json['name'], str)
    assert 'response' in response_json
    assert isinstance(response_json['response'], dict)

def test_baremetalsolution_projects_locations_instances_reset_failure():
    url = f"{BASE_URL}/v2/{'name'}:reset"
    headers = {
        "Content-Type": "application/json",
    }
    data = {}
    
    response = requests.post(url, headers=headers, json=data)
    assert response.status_code != 200
    
    response_json = response.json()
    assert isinstance(response_json, dict)
    assert 'done' not in response_json
    assert 'error' in response_json
    assert isinstance(response_json['error'], dict)
    assert 'code' in response_json['error']
    assert isinstance(response_json['error']['code'], int)
    assert 'details' in response_json['error']
    assert isinstance(response_json['error']['details'], list)
    assert all(isinstance(item, dict) for item in response_json['error']['details'])
    assert 'message' in response_json['error']
    assert isinstance(response_json['error']['message'], str)
    assert 'metadata' in response_json
    assert isinstance(response_json['metadata'], dict)
    assert 'name' in response_json
    assert isinstance(response_json['name'], str)
    assert 'response' in response_json
    assert isinstance(response_json['response'], dict)