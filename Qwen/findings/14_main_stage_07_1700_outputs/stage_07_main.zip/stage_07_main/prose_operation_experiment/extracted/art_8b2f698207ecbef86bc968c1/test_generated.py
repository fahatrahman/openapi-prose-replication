import pytest
import requests

BASE_URL = "http://openapi.test"

def test_directory_users_aliases_insert():
    url = f"{BASE_URL}/admin/directory/v1/users/userKey/aliases"
    headers = {
        "Content-Type": "application/json",
    }
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token",
        "alt": "json",
        "callback": "your_callback",
        "fields": "your_fields",
        "key": "your_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": True,
        "quotaUser": "your_quota_user",
        "uploadType": "multipart",
        "upload_protocol": "simple",
        "userKey": "user@example.com",
    }
    data = {
        "alias": "new_alias@example.com",
        "etag": "your_etag",
        "id": "your_id",
        "kind": "admin#directory#alias",
        "primaryEmail": "user@example.com",
    }

    response = requests.post(url, headers=headers, params=params, json=data)
    assert response.status_code == 200
    assert response.json()["alias"] == "new_alias@example.com"