# Stage 10 Main metadata correction

This release corrects the registered analysis label from 0.8 to 0.70. The original planning inputs used 0.70. All 850 selections, planning inputs, qualification reports, and simulation outputs are byte-for-byte identical to the supplied release. Notebook 10 does not need to rerun for this correction.

Original internal manifest SHA-256: 46021026e09c02fca3a2b81a1917820ff848310c00602c3d2f659d0a2bccdd99
Corrected internal manifest SHA-256: 7978d8f18a1ceabeeb6454a87d310d4b94867572317d2dc1f5d8394a7893c17e

To mount the corrected version in Kaggle when the Main scenario plan is resolved, extract this outer ZIP. In a new Kaggle dataset, upload the contents of the extracted folder, keeping stage_10_main/ expanded beside stage_10_manifest.json. Use this dataset as the only Stage 10 input for Notebook 05 Main.

Keep the completed v5 draft as evidence. The original draft and signatures bind to the old Stage 10 manifest hash. The new hash will be recorded in packets rebuilt from the corrected release. The unresolved scenario mappings hold Checkpoint B under Project Pipeline.md §§10.6 and 15.3. Save this correction now and wait until the scenario rule is resolved before rebuilding review packets.
