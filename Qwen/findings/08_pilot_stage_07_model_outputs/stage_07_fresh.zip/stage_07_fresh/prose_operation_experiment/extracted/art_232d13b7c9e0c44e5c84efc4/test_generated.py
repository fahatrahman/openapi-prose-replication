import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_security_settings():
    url = f"{BASE_URL}/v3/projects//locations//securitySettings/"
    params = {
        "name": url,
        "force": True
    }
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    response = requests.delete(url, params=params, headers=headers)
    assert response.status_code == 200
    assert response.json() == {}