import pytest
import requests

BASE_URL = "http://openapi.test"

def test_raw_predict():
    endpoint = "projects/your-project/locations/your-location/endpoints/your-endpoint"
    url = f"{BASE_URL}{endpoint}:rawPredict"
    
    headers = {
        "Content-Type": "application/json",
    }
    
    data = {
        "httpBody": {
            "contentType": "application/json",
            "data": '{"key": "value"}'
        }
    }
    
    response = requests.post(url, headers=headers, json=data)
    
    assert response.status_code == 200
    assert "X-Vertex-AI-Endpoint-Id" in response.headers
    assert "X-Vertex-AI-Deployed-Model-Id" in response.headers
    assert response.json()  # Ensure the response is valid JSON