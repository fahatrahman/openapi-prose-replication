import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.mark.parametrize("guid", ["your_guid_here"])
def test_show_invoice_submission_evidence(guid):
    url = f"{BASE_URL}/invoice_submissions/{guid}/evidence"
    headers = {"Authorization": "Bearer your_token_here"}

    response = session.get(url, headers=headers)

    if response.status_code == 200:
        evidence = response.json()
        assert isinstance(evidence, dict)
        assert "actions" in evidence
        assert "guid" in evidence
        assert "status" in evidence
    elif response.status_code == 401:
        assert "Unauthorized" == response.text
    elif response.status_code == 403:
        assert "Forbidden" == response.text
    elif response.status_code == 404:
        assert "Not Found" == response.text
    else:
        raise Exception(f"Unexpected status code: {response.status_code}")