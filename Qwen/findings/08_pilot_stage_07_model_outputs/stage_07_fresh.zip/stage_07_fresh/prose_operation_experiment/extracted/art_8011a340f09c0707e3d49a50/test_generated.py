import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_domain_mapping():
    url = f"{BASE_URL}/v1beta/apps/myapp/domainMappings"
    headers = {
        "Content-Type": "application/json",
    }
    payload = {
        "id": "example.com",
        "sslSettings": {
            "sslManagementType": "AUTOMATIC"
        }
    }
    params = {
        "overrideStrategy": "OVERRIDE"
    }

    response = requests.post(url, headers=headers, json=payload, params=params)

    assert response.status_code == 200
    assert response.json().get("name")