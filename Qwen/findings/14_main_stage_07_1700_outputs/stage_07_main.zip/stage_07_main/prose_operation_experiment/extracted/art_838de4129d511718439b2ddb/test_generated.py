import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_statutory_instrument_by_id():
    statutory_instrument_id = "example_id"
    url = f"{BASE_URL}/api/v1/StatutoryInstrument/{statutory_instrument_id}"
    response = requests.get(url)
    
    assert response.status_code == 200
    statutory_instrument_resource = response.json()
    assert isinstance(statutory_instrument_resource, dict)
    assert 'links' in statutory_instrument_resource
    assert 'value' in statutory_instrument_resource
    statutory_instrument = statutory_instrument_resource['value']
    assert isinstance(statutory_instrument, dict)
    assert 'id' in statutory_instrument
    assert 'name' in statutory_instrument
    assert 'uri' in statutory_instrument

if __name__ == "__main__":
    pytest.main()