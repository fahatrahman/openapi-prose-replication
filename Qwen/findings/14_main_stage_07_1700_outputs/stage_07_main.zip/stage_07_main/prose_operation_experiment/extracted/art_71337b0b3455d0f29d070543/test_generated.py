import pytest
import requests

BASE_URL = "http://openapi.test"

def test_register_change():
    url = f"{BASE_URL}/api/oms/pvt/orders/v502538llux-01/changes"
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "X-VTEX-API-AppKey": "your_app_key",
        "X-VTEX-API-AppToken": "your_app_token"
    }
    payload = {
        "discountValue": 1000,
        "incrementValue": 0,
        "itemsAdded": [
            {"id": "234788", "price": 200, "quantity": 1}
        ],
        "itemsRemoved": [
            {"id": "234794", "price": 600, "quantity": 2}
        ],
        "reason": "Promoção dada por telefone",
        "requestId": "change-request-0123"
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert response.json()["orderId"] == "v502538llux-01"