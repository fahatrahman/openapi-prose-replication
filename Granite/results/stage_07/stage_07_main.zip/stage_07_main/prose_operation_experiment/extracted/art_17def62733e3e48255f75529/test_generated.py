import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_PATH = "credentials.json"

@pytest.fixture
def auth():
    credentials = service_account.Credentials.from_service_account_file(
        CREDENTIALS_PATH)
    return credentials

def test_list_data_taxonomies(auth):
    path = "zynntaco/your_autfnhu_loginoksl/yzvrewumc/your_vmdixebo_id"
    params = {
        "filter": "some filter",
        "orderBy": "some order by",
        "pageSize": 10,
        "pageToken": "some page token"
    }

    response = requests.get(
        f"{BASE_URL}/{path}/dataTaxonomies",
        headers={"Authorization": f"Bearer {auth.token}"},
        params=params)

    assert response.status_code == 200
    data = response.json()
    # Add assertions or further processing based on the expected structure of the returned data