import pytest
import requests

BASE_URL = "http://openapi.test"

def test_getfullnameparsedmatch():
    url = f"{BASE_URL}/getfullnameparsedmatch"
    params = {
        "license": "your_license_key",
        "firstname": "John",
        "lastname": "Doe"
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 200
    data = response.json()
    assert "Code" in data
    assert "Credits" in data
    assert "Simkey" in data

if __name__ == "__main__":
    pytest.main([__file__])