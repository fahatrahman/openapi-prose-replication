import pytest
import requests

BASE_URL = "http://openapi.test"

def test_submit_third_party():
    url = f"{BASE_URL}/submitThirdParty"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer YOUR_API_KEY"  # Replace with actual API key
    }
    payload = {
        "amount": {
            "currency": "EUR",
            "value": 1000
        },
        "dateOfBirth": "1990-01-01",
        "entityType": "Company",
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",  # Replace with actual merchant account
        "nationality": "NL",
        "recurring": {
            "contract": "PAYOUT"
        },
        "reference": "PayoutPayment-0001",
        "selectedRecurringDetailReference": "LATEST",
        "shopperEmail": "shopper@email.com",
        "shopperName": {
            "firstName": "Adyen",
            "lastName": "Test"
        },
        "shopperReference": "YOUR_UNIQUE_SHOPPER_ID"  # Replace with actual shopper reference
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 200
    assert "pspReference" in response.json()
    assert "resultCode" in response.json()

def test_submit_third_party_invalid_input():
    url = f"{BASE_URL}/submitThirdParty"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer YOUR_API_KEY"  # Replace with actual API key
    }
    payload = {
        "amount": {
            "currency": "USD",
            "value": 1000
        },
        "dateOfBirth": "1990-01-01",
        "entityType": "Individual",
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",  # Replace with actual merchant account
        "nationality": "US",
        "recurring": {
            "contract": "PAYOUT"
        },
        "reference": "InvalidPayment-0001",
        "selectedRecurringDetailReference": "LATEST",
        "shopperEmail": "shopper@email.com",
        "shopperName": {
            "firstName": "John",
            "lastName": "Doe"
        },
        "shopperReference": "INVALID_UNIQUE_SHOPPER_ID"  # Replace with actual shopper reference
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 400
    assert "errorCode" in response.json()
    assert response.json()["errorCode"] == "702"
    assert response.json()["errorType"] == "validation"
    assert "message" in response.json()
    assert "Unexpected input: I" in response.json()["message"]