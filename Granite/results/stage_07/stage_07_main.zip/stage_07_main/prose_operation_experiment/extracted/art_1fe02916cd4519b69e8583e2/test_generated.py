import os
import pytest
import requests
from google.rpc import Status

BASE_URL = "http://openapi.test"

@pytest.fixture
def get_operation():
    def _get_operation(project_id, location_id, operation_id):
        url = f"{BASE_URL}/v1/{operation_id}"
        headers = {"accept": "application/json"}
        response = requests.get(url, headers=headers)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Request failed with status code {response.status_code}")

    return _get_operation

def test_get_operation(get_operation):
    project_id = "your_project_id"
    location_id = "your_location_id"
    operation_id = "your_operation_id"

    operation = get_operation(project_id, location_id, operation_id)
    assert isinstance(operation, dict)
    assert 'done' in operation
    assert 'error' not in operation or operation['error'] is None
    assert 'response' in operation