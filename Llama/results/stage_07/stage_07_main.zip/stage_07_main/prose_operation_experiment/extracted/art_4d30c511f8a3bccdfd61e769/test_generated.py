# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_agent():
    url = f"{BASE_URL}/v2/{'projects/'}/agent"
    headers = {}
    params = {
        "$.xgafv": "1",
        "access_token": None,
        "alt": "json",
        "callback": None,
        "fields": None,
        "key": None,
        "oauth_token": None,
        "prettyPrint": False,
        "quotaUser": None,
        "upload_protocol": None,
        "uploadType": None
    }
    auth = ("", "")
    response = requests.delete(url, headers=headers, params=params, auth=auth)
    assert response.status_code == 200
    assert response.json() == {}