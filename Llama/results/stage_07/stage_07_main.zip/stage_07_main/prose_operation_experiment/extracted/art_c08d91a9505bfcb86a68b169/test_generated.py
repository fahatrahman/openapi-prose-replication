import pytest
import requests
from urllib.parse import urlencode

BASE_URL = "http://openapi.test"

def test_list_runtime_versions():
    url = f"{BASE_URL}/v2alpha1/{'projects/123456789012/locations/global'}"
    params = {
        'key': 'your_api_key',
        'prettyPrint': False,
        '_xgafv': '1'
    }
    headers = {'Content-Type': 'application/json'}
    
    response = requests.get(url, headers=headers, params=urlencode(params))
    
    assert response.status_code == 200
    
    try:
        response_json = response.json()
        assert isinstance(response_json, dict)
        assert 'runtimeVersions' in response_json
        assert isinstance(response_json['runtimeVersions'], list)
        
        for item in response_json['runtimeVersions']:
            assert isinstance(item, dict)
            assert 'name' in item
            assert 'version' in item
            
    except ValueError as e:
        print(f"Error parsing JSON response: {e}")
        raise
        
    finally:
        assert response.close() is None