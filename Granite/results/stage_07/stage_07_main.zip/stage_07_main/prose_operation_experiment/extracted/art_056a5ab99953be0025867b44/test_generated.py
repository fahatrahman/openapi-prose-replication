import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Retry mechanism for requests
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

@pytest.fixture
def collaborator_invitation():
    id = 1  # Replace with actual ID
    url = f"{BASE_URL}/collaborator_invitations/{id}"
    response = session.get(url)
    response.raise_for_status()
    return response.json()

def test_show_collaborator_invitation(collaborator_invitation):
    assert isinstance(collaborator_invitation, dict)
    assert 'accepted' in collaborator_invitation
    assert 'created_at' in collaborator_invitation
    assert 'email' in collaborator_invitation
    assert 'group' in collaborator_invitation
    assert 'id' in collaborator_invitation
    assert 'invited_by_user' in collaborator_invitation
    assert 'map' in collaborator_invitation
    assert 'sent' in collaborator_invitation
    assert 'updated_at' in collaborator_invitation
    assert 'user' in collaborator_invitation