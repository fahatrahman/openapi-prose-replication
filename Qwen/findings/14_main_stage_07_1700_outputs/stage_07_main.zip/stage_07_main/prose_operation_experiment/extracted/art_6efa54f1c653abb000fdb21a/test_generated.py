import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_song_list():
    url = f"{BASE_URL}/api/songLists"
    headers = {
        "Content-Type": "application/json",
    }
    payload = {
        "description": "Test song list",
        "name": "Test List",
        "songLinks": [
            {
                "notes": "First song",
                "order": 1,
                "song": {
                    "id": 12345
                },
                "songInListId": 67890
            }
        ]
    }
    response = requests.post(url, headers=headers, json=payload)
    
    assert response.status_code == 200
    assert isinstance(response.json(), int)