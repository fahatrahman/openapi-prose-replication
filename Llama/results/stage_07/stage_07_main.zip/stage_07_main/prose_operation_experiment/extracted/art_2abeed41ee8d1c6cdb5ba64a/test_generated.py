# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_fetch_reward_program_activations():
    url = f"{BASE_URL}/reward_program_activation"
    params = {
        "filter[patient]": "test_patient",
        "filter[groups]": "test_group",
        "filter[organization]": "test_organization"
    }
    
    response = requests.get(url, params=params)
    assert response.status_code == 200
    
    data = response.json()
    assert isinstance(data, dict) and 'data' in data
    assert isinstance(data['data'], list)

def test_fetch_reward_program_activations_unauthorized():
    url = f"{BASE_URL}/reward_program_activation"
    params = {
        "filter[patient]": "test_patient",
        "filter[groups]": "test_group",
        "filter[organization]": "test_organization"
    }
    
    response = requests.get(url, params=params)
    assert response.status_code == 401
    
    data = response.json()
    assert isinstance(data, dict) and 'errors' in data
    error = data['errors'][0]
    assert error['code'] == 'Unauthorized'
    assert error['detail'] == 'A valid bearer token is required'

def test_fetch_reward_program_activations_forbidden():
    url = f"{BASE_URL}/reward_program_activation"
    params = {
        "filter[patient]": "test_patient",
        "filter[groups]": "test_group",
        "filter[organization]": "test_organization"
    }
    
    response = requests.get(url, params=params)
    assert response.status_code == 403
    
    data = response.json()
    assert isinstance(data, dict) and 'errors' in data
    error = data['errors'][0]
    assert error['code'] == 'Forbidden'

if __name__ == "__main__":
    pytest.main([__file__])