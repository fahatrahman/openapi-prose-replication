import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from typing import Dict

BASE_URL = "http://openapi.test"

# Setup session with retry logic
session = requests.Session()
retry_strategy = HTTPAdapter(max_retries=3)
session.mount("http://", retry_strategy)
session.mount("https://", retry_strategy)

# Security credentials
SECURITY_CREDENTIALS: Dict[str, str] = {
    "access_token": "your_access_token",
    "key": "your_key",
    "oauth_token": "your_oauth_token",
}

def test_delete_product_certification():
    path_params = {"name": "tjnnzcqy/kwbkatwap/srohwzhy_ihlx/lauatduHbqmarwzxyqmwc/lg"}
    
    url = f"{BASE_URL}/v1{/name}"
    response = requests.request(
        method="DELETE",
        url=url.format(**path_params),
        headers={
            **SECURITY_CREDENTIALS,
            "Content-Type": "application/json",
        },
        verify=False,  # Disable SSL verification for testing purposes
    )

    assert response.status_code == 200
    assert response.json() == {}