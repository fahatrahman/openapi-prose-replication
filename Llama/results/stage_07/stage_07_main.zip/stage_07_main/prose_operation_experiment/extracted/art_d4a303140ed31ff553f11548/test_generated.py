import pytest
import requests
from typing import List

BASE_URL = "http://openapi.test"

def get_migrations(id: str, addonId: str) -> List[dict]:
    """Retrieve list of migrations for organisation's addon."""
    url = f"{BASE_URL}/organisations/{id}/addons/{addonId}/migrations"
    response = requests.get(url)
    assert response.status_code == 200, f"Unexpected status code {response.status_code}"
    return response.json()

def test_get_past_migrations():
    id = "your_organisation_id"
    addonId = "your_addon_id"
    migrations = get_migrations(id, addonId)
    assert isinstance(migrations, list), f"Expected list, got {type(migrations)}"
    for migration in migrations:
        assert isinstance(migration, dict), f"Expected dictionary, got {type(migration)}"

def test_get_empty_list():
    # Test edge case where organisation or addon does not exist
    id = "non_existent_id"
    addonId = "non_existent_addon_id"
    migrations = get_migrations(id, addonId)
    assert len(migrations) == 0, f"Expected empty list, got {len(migrations)}"

if __name__ == "__main__":
    pytest.main([__file__, "-v"])