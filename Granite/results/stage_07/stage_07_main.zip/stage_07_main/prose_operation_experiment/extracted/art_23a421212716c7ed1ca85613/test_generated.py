import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["GET", "OPTIONS"],
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

def test_jurisdiction_detail():
    jurisdiction_id = "ocd-jurisdiction/country:us/state:nc/government"
    include = ["organizations", "legislative_sessions"]
    api_key = "your_api_key_here"

    response = SESSION.get(
        f"{BASE_URL}/jurisdictions/{jurisdiction_id}",
        params={"include": include, "apikey": api_key},
    )

    assert response.status_code == 200
    jurisdiction_data = response.json()

    # Add more assertions based on expected data structure

    print("Test passed.")