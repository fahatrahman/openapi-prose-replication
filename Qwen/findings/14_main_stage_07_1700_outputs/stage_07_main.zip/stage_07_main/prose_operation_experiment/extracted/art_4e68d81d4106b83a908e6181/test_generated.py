import pytest
import requests

BASE_URL = "http://openapi.test"

def test_batch_delete_pipeline_jobs():
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    url = f"{BASE_URL}/v1beta1/projects/{YOUR_PROJECT}/locations/{YOUR_LOCATION}/pipelineJobs:batchDelete"
    payload = {
        "names": [
            "projects/{project}/locations/{location}/pipelineJobs/{pipelineJob}"
        ]
    }
    params = {
        "_xgafv": "2",
        "access_token": "YOUR_ACCESS_TOKEN",
        "alt": "json",
        "callback": "",
        "fields": "*",
        "key": "YOUR_API_KEY",
        "oauth_token": "",
        "prettyPrint": "true",
        "quotaUser": "",
        "uploadType": "",
        "upload_protocol": ""
    }
    response = requests.post(url, headers=headers, json=payload, params=params)
    assert response.status_code == 200
    assert response.json()["done"]