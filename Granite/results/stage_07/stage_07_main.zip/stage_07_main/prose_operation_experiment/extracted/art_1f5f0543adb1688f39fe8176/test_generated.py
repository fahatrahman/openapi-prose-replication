import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retry strategy
session = requests.Session()
retries = Retry(total=3, backoff_factor=0.1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount("http://", adapter)
session.mount("https://", adapter)

# Define request payload
device_features = {
    "ftp_banner": "",
    "hostname": "",
    "http_response": "",
    "https_response": "",
    "nic_mac": "",
    "snmp_sysdescr": "",
    "snmp_sysoid": "",
    "telnet_banner": "",
    "upnp_response": ""
}

@pytest.fixture
def client():
    return session

def test_detect_device(client):
    headers = {"x-api-key": "your_api_key_here"} # Replace with actual API key
    response = client.post(f"{BASE_URL}/device/detect", json=device_features, headers=headers)
    
    if response.status_code == 200:
        device_info = response.json()
        assert isinstance(device_info, dict)
        assert all(key in device_info for key in ("cve_list", "device_type", "firmware_info", "firmware_version", "is_discontinued", "latest_firmware_info", "manufacturer", "model_name"))

    elif response.status_code == 422:
        validation_errors = response.json()["detail"]
        for error in validation_errors:
            assert "loc" in error
            assert "msg" in error
            assert "type" in error
    
    else:
        raise Exception(f"Unexpected status code: {response.status_code}")