import pytest
import requests

BASE_URL = "http://openapi.test"

def test_test_iam_permissions():
    url = f"{BASE_URL}/v1/projects/location/registrations:testIamPermissions"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "permissions": ["storage.objects.get"]
    }
    params = {
        "_xgafv": "2",
        "access_token": "YOUR_ACCESS_TOKEN",
        "alt": "json",
        "callback": "",
        "fields": "*",
        "key": "YOUR_API_KEY",
        "oauth_token": "",
        "prettyPrint": True,
        "quotaUser": "user",
        "uploadType": "",
        "upload_protocol": ""
    }
    response = requests.post(url, headers=headers, json=payload, params=params)
    assert response.status_code == 200
    assert "permissions" in response.json()