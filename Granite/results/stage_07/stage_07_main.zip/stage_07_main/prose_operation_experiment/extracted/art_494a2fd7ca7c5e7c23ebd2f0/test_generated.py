import os
import json
import pytest
import requests

BASE_URL = "http://openapi.test"

def test_kick_chat_member():
    url = f"{BASE_URL}/kickChatMember"

    # Prepare the payload
    payload = {
        "chat_id": "<your_chat_id>",
        "user_id": "<target_user_id>"
    }

    # Send POST request
    response = requests.post(url, json=payload)

    # Check the status code
    assert response.status_code == 200

    # Parse the response
    result = response.json()

    # Assert the response contains 'ok' and 'result' keys
    assert "ok" in result and result["ok"] and "result" in result and result["result"]

    print("Test passed!")