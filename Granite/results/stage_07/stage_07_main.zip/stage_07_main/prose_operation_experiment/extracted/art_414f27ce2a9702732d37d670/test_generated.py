import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup a session with retry logic
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["GET", "OPTIONS"],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def http_client():
    return session

def test_list_gateways(http_client):
    """Test listing gateways."""
    path = "/v1/{parent}/gateways"
    parent = "zynntaco/xyz" # Replace with actual value

    params = {
        "pageSize": 10,
        "pageToken": "some_page_token",
    }

    response = http_client.get(
        f"{BASE_URL}{path}".replace("{parent}", parent), params=params
    )
    response.raise_for_status()

    assert response.status_code == 200

    result = response.json()
    assert "gateways" in result
    assert isinstance(result["gateways"], list)
    assert "nextPageToken" in result or "unreachable" in result