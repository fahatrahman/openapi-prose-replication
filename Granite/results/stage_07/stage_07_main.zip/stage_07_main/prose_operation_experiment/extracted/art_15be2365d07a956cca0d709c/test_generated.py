import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = "path/to/service_account.json"
SCOPES = ["https://www.googleapis.com/auth/cloud-platform"]

def get_authenticated_session():
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=SCOPES
    )
    return requests.Session(), credentials

@pytest.fixture
def http_client():
    session, credentials = get_authenticated_session()
    return session

def test_list_projects(http_client):
    response = http_client.get(
        f"{BASE_URL}/v1/projects",
        params={
            "filter": "name:example.*",
            "pageSize": 10,
            "pageToken": "some_page_token",
        },
    )

    assert response.status_code == 200

    projects_response = response.json()
    next_page_token = projects_response.get("nextPageToken")
    projects = projects_response["projects"]

    assert isinstance(next_page_token, str)
    assert isinstance(projects, list)
    for project in projects:
        assert isinstance(project, dict)
        required_keys = {"name", "createTime", "lifecycleState", "labels", "parent"}
        assert required_keys.issubset(project.keys())