import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_PATH = "path/to/credentials.json"

@pytest.fixture
def auth():
    credentials = service_account.Credentials.from_service_account_file(
        CREDENTIALS_PATH)
    return credentials

def test_invalidate_approval_request(auth):
    path = "/v1/projects/{}/approvalRequests/example".format("your_project_id")
    headers = {
        "Content-Type": "application/json",
    }

    response = requests.post(
        "{}/{}".format(BASE_URL, path),
        headers=headers,
        json={},
        verify=False,
        auth=auth
    )

    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "approveTime" in response.json()
    assert "autoApproved" in response.json()
    assert "expireTime" in response.json()
    assert "invalidateTime" in response.json()
    assert "signatureInfo" in response.json()