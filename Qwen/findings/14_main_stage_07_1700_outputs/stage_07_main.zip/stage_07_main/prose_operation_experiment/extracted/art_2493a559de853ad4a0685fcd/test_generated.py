import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_sink():
    headers = {
        "X-Amz-Content-Sha256": "example",
        "X-Amz-Date": "20230401T123456Z",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "example",
        "X-Amz-Security-Token": "example",
        "X-Amz-Signature": "example",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-algorithm;x-amz-credential;x-amz-security-token;x-amz-signature"
    }
    payload = {
        "Identifier": "example_identifier"
    }
    response = requests.post(f"{BASE_URL}/DeleteSink", headers=headers, json=payload)
    
    assert response.status_code == 200
    assert "application/json" in response.headers["Content-Type"]
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()