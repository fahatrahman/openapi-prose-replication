import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_photo():
    short_name = "example_short_name"
    photo_id = "example_photo_id"
    url = f"{BASE_URL}/v2/tier2/{short_name}/photo/photos/{photo_id}"
    
    response = requests.get(url)
    
    assert response.status_code == 200
    assert "ETag" in response.json()
    assert "FileName" in response.json()
    assert "InspectionItem" in response.json()
    assert "InterimInspection" in response.json()
    assert "InventoryItem" in response.json()
    assert "Name" in response.json()
    assert "OID" in response.json()
    assert "PhotoNumber" in response.json()
    assert "PhotoType" in response.json()
    assert "Property" in response.json()
    assert "Room" in response.json()
    assert response.json()["PhotoType"] in ["Photo", "Map", "FloorPlan", "SiteMap", "AerialPhoto"]