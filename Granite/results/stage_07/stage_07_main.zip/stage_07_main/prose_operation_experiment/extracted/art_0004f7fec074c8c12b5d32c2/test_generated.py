import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def category():
    response = requests.get(f"{BASE_URL}/providernetworks/providernetwork_uid/categories/category_uid", params={"expand": "attribute"})
    response.raise_for_status()
    return response.json()

def test_get_category(category):
    assert isinstance(category, dict)
    assert "_links" in category
    assert "attributes" in category
    assert "description" in category["attributes"]
    assert "expand" in category["attributes"]
    assert "href" in category["_links"]
    assert "name" in category["attributes"]
    assert "price" in category["_links"]