import pytest
import requests

BASE_URL = "http://openapi.test"

def test_post_authorization_code():
    url = f"{BASE_URL}/api/v2/AuthorizationCodes"
    payload = {
        "Code": "test_code",
        "CreatedByUserID": 1,
        "CreatedDate": "2023-04-01T00:00:00Z",
        "DataParameters": [
            {"Name": "param1", "Value": "value1"},
            {"Name": "param2", "Value": "value2"}
        ],
        "DefinitionID": "test_def_id",
        "DeletedByUserID": None,
        "DeletedDate": None,
        "EffectiveDate": "2023-04-01T00:00:00Z",
        "ID": 1,
        "IsDeleted": False,
        "ValidationParameters": [
            {"Name": "val_param1", "Value": "val_value1"},
            {"Name": "val_param2", "Value": "val_value2"}
        ]
    }
    headers = {
        "Content-Type": "application/json"
    }
    response = requests.post(url, json=payload, headers=headers)
    assert response.status_code == 200
    assert isinstance(response.json(), int)

if __name__ == "__main__":
    pytest.main()