import pytest
import requests
from json import JSONDecodeError

BASE_URL = "http://openapi.test"

def test_store_info():
    login = "your_login"
    authtoken = "your_authtoken"
    
    params = {
        "login": login,
        "authtoken": authtoken
    }
    
    response = requests.get(f"{BASE_URL}/store/info.json", params=params)
    
    assert response.status_code == 200
    
    try:
        response_json = response.json()
        
        required_fields = ["address", "code", "country", "currency", "email",
                           "hooks_token", "logo", "name", "timezone", "url", "weight_unit"]
        
        for field in required_fields:
            assert field in response_json
        
        address_required_fields = ["address", "city", "country", "country_code", "postal", "region", "region_code"]
        
        assert all(field in response_json["address"] for field in address_required_fields)
        
    except JSONDecodeError:
        pytest.fail("Failed to parse JSON response")