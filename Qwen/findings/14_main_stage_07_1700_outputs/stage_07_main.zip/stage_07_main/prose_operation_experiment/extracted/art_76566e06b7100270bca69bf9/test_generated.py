import pytest
import requests

BASE_URL = "http://openapi.test"

def get_team_members(team_id, limit=None, since=None, until=None, search=None, role=None, exclude_project=None):
    url = f"{BASE_URL}/v2/teams/{team_id}/members"
    params = {}
    if limit is not None:
        params["limit"] = limit
    if since is not None:
        params["since"] = since
    if until is not None:
        params["until"] = until
    if search is not None:
        params["search"] = search
    if role is not None:
        params["role"] = role
    if exclude_project is not None:
        params["excludeProject"] = exclude_project
    
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    
    response = requests.get(url, params=params, headers=headers)
    return response.json()

@pytest.mark.parametrize("team_id, expected_status", [
    ("valid_team_id", 200),
    ("invalid_team_id", 404),
])
def test_get_team_members(team_id, expected_status):
    response = get_team_members(team_id)
    assert response.status_code == expected_status

@pytest.mark.parametrize("params, expected_key", [
    ({"limit": 10}, "members"),
    ({"since": 1540095775951}, "members"),
    ({"until": 1540095775951}, "members"),
    ({"search": "jane"}, "members"),
    ({"role": "OWNER"}, "members"),
    ({"excludeProject": "project_name"}, "members"),
])
def test_get_team_members_with_params(params, expected_key):
    response = get_team_members("valid_team_id", **params)
    assert response[expected_key] is not None

def test_get_team_members_invalid_token():
    headers = {
        "Authorization": "Bearer INVALID_ACCESS_TOKEN"
    }
    response = requests.get(f"{BASE_URL}/v2/teams/valid_team_id/members", headers=headers)
    assert response.status_code == 403

def test_get_team_members_bad_request():
    response = get_team_members("valid_team_id", limit="not_a_number")
    assert response.status_code == 400