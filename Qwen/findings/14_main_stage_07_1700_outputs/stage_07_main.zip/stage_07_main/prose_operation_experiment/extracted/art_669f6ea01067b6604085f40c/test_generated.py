import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_pricing_plans():
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "YOUR_CREDENTIALS",
        "X-Amz-Date": "CURRENT_DATE",
        "X-Amz-Security-Token": "YOUR_SECURITY_TOKEN",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-security-token"
    }
    params = {
        "MaxResults": "10",
        "NextToken": ""
    }
    body = {
        "BillingPeriod": "2023-04",
        "Filters": {
            "Arns": ["arn:aws:billingconductor::123456789012:pricingplan/abcd1234"]
        },
        "MaxResults": 10,
        "NextToken": ""
    }
    response = requests.post(f"{BASE_URL}/list-pricing-plans", headers=headers, params=params, json=body)
    
    assert response.status_code == 200
    assert "BillingPeriod" in response.json()
    assert "NextToken" in response.json()
    assert "PricingPlans" in response.json()

if __name__ == "__main__":
    pytest.main([__file__])