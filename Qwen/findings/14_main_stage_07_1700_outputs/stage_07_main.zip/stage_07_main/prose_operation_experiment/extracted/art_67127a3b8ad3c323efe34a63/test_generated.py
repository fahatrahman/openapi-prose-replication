import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_repositories():
    url = f"{BASE_URL}/v1beta1/projects/location/repositories"
    params = {
        "filter": "your_filter_here",
        "orderBy": "name",
        "pageSize": 10,
        "pageToken": "your_page_token_here"
    }
    headers = {
        "Authorization": "Bearer your_access_token_here"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    assert "repositories" in response.json()

if __name__ == "__main__":
    pytest.main()