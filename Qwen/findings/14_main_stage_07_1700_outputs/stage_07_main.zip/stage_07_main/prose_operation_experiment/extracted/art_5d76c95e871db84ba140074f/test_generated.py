import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_nominal_code_from_employer():
    employer_id = "GD001"
    nominal_code_id = "IBI001"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    
    response = requests.get(
        f"{BASE_URL}/Employer/{employer_id}/NominalCode/{nominal_code_id}",
        headers=headers
    )
    
    assert response.status_code == 200
    assert "Description" in response.json()["NominalCode"]
    assert "Key" in response.json()["NominalCode"]

def test_get_nominal_code_from_employer_invalid_employer_id():
    employer_id = "invalid_id"
    nominal_code_id = "IBI001"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    
    response = requests.get(
        f"{BASE_URL}/Employer/{employer_id}/NominalCode/{nominal_code_id}",
        headers=headers
    )
    
    assert response.status_code == 404
    assert "ErrorCategory" in response.json()["ErrorModel"]
    assert response.json()["ErrorModel"]["ErrorCategory"] == "NotFound"

def test_get_nominal_code_from_employer_unauthorized():
    employer_id = "GD001"
    nominal_code_id = "IBI001"
    headers = {
        "Authorization": "InvalidToken",
        "Api-Version": "default"
    }
    
    response = requests.get(
        f"{BASE_URL}/Employer/{employer_id}/NominalCode/{nominal_code_id}",
        headers=headers
    )
    
    assert response.status_code == 401
    assert "ErrorCategory" in response.json()["ErrorModel"]
    assert response.json()["ErrorModel"]["ErrorCategory"] == "NotAuthorised"