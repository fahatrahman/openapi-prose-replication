import pytest
import requests

BASE_URL = "http://openapi.test"

def test_apps_list():
    headers = {
        "X-API-Token": "your_api_token_here"
    }
    params = {
        "$orderBy": "display_name"
    }
    response = requests.get(f"{BASE_URL}/v0.1/apps", headers=headers, params=params)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    for app in data:
        assert "id" in app
        assert "display_name" in app
        assert "name" in app
        assert "os" in app
        assert "owner" in app
        assert "release_type" in app
        owner = app["owner"]
        assert "id" in owner
        assert "display_name" in owner
        assert "name" in owner
        assert "type" in owner
        if app.get("app_secret"):
            assert "app_secret" in app
            assert "azure_subscription" in app
            azure_subscription = app["azure_subscription"]
            assert "is_billable" in azure_subscription
            assert "is_billing" in azure_subscription
            assert "is_microsoft_internal" in azure_subscription
            assert "subscription_id" in azure_subscription
            assert "subscription_name" in azure_subscription
            assert "tenant_id" in azure_subscription
            assert "created_at" in app
            assert "member_permissions" in app
            assert "origin" in app
            assert "platform" in app
            assert "updated_at" in app