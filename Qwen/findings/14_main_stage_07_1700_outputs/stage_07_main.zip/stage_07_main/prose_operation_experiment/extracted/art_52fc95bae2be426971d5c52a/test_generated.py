import pytest
import requests

BASE_URL = "http://openapi.test"

def test_global_config():
    response = requests.get(f"{BASE_URL}/api/globalconfig")
    assert response.status_code == 200
    global_config = response.json()
    assert isinstance(global_config, dict)
    required_fields = [
        "streamEntityOnly",
        "autoLinkToDefaultGroup",
        "limitConcurrentRequests",
        "maxConcurrentRequests",
        "useCircuitBreakers",
        "apiReadOnly",
        "u2fLoginOnly",
        "ipFiltering",
        "throttlingQuota",
        "perIpThrottlingQuota",
        "analyticsWebhooks",
        "alertsWebhooks",
        "alertsEmails",
        "endlessIpAddresses"
    ]
    for field in required_fields:
        assert field in global_config

@pytest.mark.parametrize("status_code", [400, 401, 404])
def test_global_config_error(status_code):
    response = requests.get(f"{BASE_URL}/api/globalconfig", headers={"Authorization": "Basic invalid"})
    assert response.status_code == status_code