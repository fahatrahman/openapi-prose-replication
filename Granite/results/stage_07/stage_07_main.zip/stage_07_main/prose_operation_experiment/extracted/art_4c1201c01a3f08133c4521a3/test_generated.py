import os
import pytest
import requests
from urllib3.exception import InsecureRequestWarning

# Ignore warnings from urllib3
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

BASE_URL = "http://openapi.test"

@pytest.fixture
def issuer_resource_id():
    return "your_issuer_resource_id"

def test_get_issuer(issuer_resource_id):
    url = f"{BASE_URL}/walletobjects/v1/issuer/{issuer_resource_id}"

    headers = {
        "Accept": "application/json",
    }

    response = requests.get(url, headers=headers)
    response.raise_for_status()

    assert response.status_code == 200
    issuer = response.json()

    # Add more assertions based on the expected Issuer schema
    assert isinstance(issuer, dict)
    assert "name" in issuer
    assert "homepageUrl" in issuer
    assert "issuerId" in issuer
    assert "contactInfo" in issuer
    assert isinstance(issuer["contactInfo"], dict)
    assert "email" in issuer["contactInfo"]
    assert "name" in issuer["contactInfo"]
    assert "phone" in issuer["contactInfo"]