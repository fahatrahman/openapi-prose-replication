import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_workflow_step():
    url = f"{BASE_URL}/workflowstep"
    headers = {
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Date": "20230401T123456Z",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20230401/us-east-1/apiGateway/aws4_request",
        "X-Amz-Security-Token": "AQoDYXdzEPT//////////wEaCjTMqRlXNqG0sV7YJ6pU+IYW3w==",
        "X-Amz-Signature": "b656512972fe95e4e23c00726776b98c120f5b704a65e23e29e90c844b658c63",
        "X-Amz-SignedHeaders": "host;x-amz-algorithm;x-amz-content-sha256;x-amz-credential;x-amz-date;x-amz-security-token;x-amz-signedheaders"
    }
    payload = {
        "name": "example-step",
        "stepGroupId": "example-group",
        "workflowId": "example-workflow",
        "stepActionType": "MANUAL",
        "outputs": [
            {
                "name": "output1",
                "dataType": "STRING",
                "value": "example-value"
            }
        ]
    }
    response = requests.post(url, json=payload, headers=headers)
    
    assert response.status_code == 200
    assert "id" in response.json()
    assert "name" in response.json()
    assert "stepGroupId" in response.json()
    assert "workflowId" in response.json()

if __name__ == "__main__":
    pytest.main([__file__])