import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_deployments():
    url = f"{BASE_URL}/v1/{name}/deployments"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token",
        "alt": "json",
        "callback": "your_callback",
        "fields": "your_fields",
        "key": "your_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": True,
        "quotaUser": "your_quota_user",
        "uploadProtocol": "your_upload_protocol",
        "uploadType": "your_upload_type",
        "name": "organizations/{org}/environments/{env}/sharedflows/{sharedflow}/revisions/{rev}"
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    assert "application/json" in response.headers["Content-Type"]
    assert isinstance(response.json(), dict)