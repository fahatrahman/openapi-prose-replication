import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_aiplatform_projects_locations_metadatastores_list():
    url = f"{BASE_URL}/v1/{'projects/%s/locations/%s'%('test_project','test_location')}/metadataStores"
    params = {
        "pageSize": 10,
        "pageToken": "",
        "$.xgafv": "1",
        "key": "test_key",
        "quotaUser": "test_quota_user",
        "uploadType": "media",
        "upload_protocol": "raw",
        "alt": "json",
        "prettyPrint": True,
        "fields": "metadataStores(name),metadataStores(state)",
        "callback": "test_callback",
        "oauth_token": "test_oauth_token",
        "access_token": "test_access_token",
    }

    headers = {"Content-Type": "application/json"}
    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 200
    response_data = response.json()
    assert isinstance(response_data, dict)
    assert 'metadataStores' in response_data.keys()

    # Check if the response contains at least one item in metadataStores list
    assert len(response_data['metadataStores']) >= 1
    for metadata_store in response_data['metadataStores']:
        assert isinstance(metadata_store, dict)
        assert 'name' in metadata_store.keys()
        assert 'state' in metadata_store.keys()
        assert isinstance(metadata_store['name'], str)
        assert isinstance(metadata_store['state'], dict)
        assert 'diskUtilizationBytes' in metadata_store['state'].keys()
        assert isinstance(metadata_store['state']['diskUtilizationBytes'], int)
        assert isinstance(datetime.fromisoformat(metadata_store['createTime']), datetime)
        assert isinstance(datetime.fromisoformat(metadata_store['updateTime']), datetime)

    print("Test passed")