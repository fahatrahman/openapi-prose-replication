import pytest
import requests

BASE_URL = "http://openapi.test"

def test_season_teams():
    url = f"{BASE_URL}/json/SeasonTeams/100000057"
    headers = {
        "Ocp-Apim-Subscription-Key": "your_subscription_key_here"
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert isinstance(response.json(), list)
    for item in response.json():
        assert isinstance(item, dict)
        assert 'Active' in item
        assert 'Gender' in item
        assert 'SeasonId' in item
        assert 'SeasonTeamId' in item
        assert 'Team' in item
        assert 'TeamId' in item
        assert 'TeamName' in item
        assert 'Type' in item
        team = item['Team']
        assert 'Active' in team
        assert 'AreaId' in team
        assert 'AreaName' in team
        assert 'Email' in team
        assert 'Facebook' in team
        assert 'Founded' in team
        assert 'Gender' in team
        assert 'Instagram' in team
        assert 'Key' in team
        assert 'Name' in team
        assert 'PrimaryColor' in team
        assert 'QuaternaryColor' in team
        assert 'SecondaryColor' in team
        assert 'ShortName' in team
        assert 'TeamId' in team
        assert 'TertiaryColor' in team
        assert 'Twitter' in team
        assert 'Type' in team
        assert 'Website' in team
        assert 'YouTube' in team

if __name__ == "__main__":
    pytest.main()