import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.mark.parametrize("format_param", ["XML", "JSON"])
def test_are_games_in_progress(format_param):
    headers = {
        "Ocp-Apim-Subscription-Key": "your_subscription_key_here"
    }
    params = {
        "key": "your_api_key_here"
    }
    url = f"{BASE_URL}/{format_param}/AreAnyGamesInProgress"
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    assert isinstance(response.json(), bool)

if __name__ == "__main__":
    pytest.main()