import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.mark.parametrize("format_param, season", [
    ("XML", "2017"),
    ("JSON", "2018")
])
def test_projected_player_season_stats_with_adp(format_param, season):
    headers = {
        "Ocp-Apim-Subscription-Key": "your_subscription_key"
    }
    url = f"{BASE_URL}/{format_param}/PlayerSeasonProjectionStats/{season}"
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert isinstance(response.json(), list)
    for item in response.json():
        assert isinstance(item, dict)
        assert 'PlayerID' in item
        assert 'Season' in item
        # Add more assertions based on the schema if needed