import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"

@pytest.fixture
def service():
    credentials = service_account.Credentials.from_service_account_file('path/to/credentials.json')
    return builds_transport_client(credentials=credentials).projects

def tests_delete_operation(service):
    project_id = 'your-project-id'
    environment_id = 'your-environment-id'
    name = f'projects/{project_id}/environments/{environment_id}/operations/your-operation-id'

    response = requests.delete(
        url=f"{BASE_URL}/{name}",
        headers={
            "x-goog-api-client": "gl-python",
            "x-goog-api-version": "1.134.0"
        },
        verify='path/to/certificate.pem',  # if using SSL
        auth=service()
    )

    assert response.status_code == 200