import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session for retries
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

@pytest.fixture
def wire_transfer_id():
    return "wire_transfer_5akynk7dqsq25qwk9q2u"

def test_approve_wire_transfer(wire_transfer_id):
    url = f"{BASE_URL}/wire_transfers/{wire_transfer_id}/approve"
    
    headers = {
        'Authorization': 'Bearer YOUR_ACCESS_TOKEN',
        'Content-Type': 'application/json'
    }

    response = session.post(url, headers=headers)

    if response.status_code == 200:
        assert response.json()['type'] == 'wire_transfer'
        assert response.json()['status'] in ['pending_approval', 'complete']
    else:
        error_response = response.json()
        assert error_response['type'] in [
            'invalid_parameters_error', 'invalid_operation_error', 'api_method_not_found_error',
            'environment_mismatch_error', 'insufficient_permissions_error', 'internal_server_error',
            'invalid_api_key_error', 'rate_limited_error', 'object_not_found_error', 'private_feature_error'
        ]