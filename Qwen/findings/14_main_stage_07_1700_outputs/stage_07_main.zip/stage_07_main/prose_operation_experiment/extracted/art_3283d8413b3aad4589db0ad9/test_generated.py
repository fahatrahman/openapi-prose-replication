import pytest
import requests

BASE_URL = "http://openapi.test"

def test_put_rti_transaction_tag():
    url = f"{BASE_URL}/Employer/ER001/RtiTransaction/FPS001/Tag/MyTag"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Api-Version": "default"
    }
    response = requests.put(url, headers=headers)
    
    assert response.status_code == 200
    assert "Content-Type" in response.headers
    assert response.headers["Content-Type"] == "application/json"
    assert "Tag" in response.json()
    assert "TaggedItem" in response.json()["Tag"]
    assert "@href" in response.json()["Tag"]["TaggedItem"]
    assert "@rel" in response.json()["Tag"]["TaggedItem"]
    assert "@title" in response.json()["Tag"]["TaggedItem"]

def test_put_rti_transaction_tag_bad_request():
    url = f"{BASE_URL}/Employer/ER001/RtiTransaction/FPS001/Tag/InvalidTag"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Api-Version": "default"
    }
    response = requests.put(url, headers=headers)
    
    assert response.status_code == 400
    assert "Content-Type" in response.headers
    assert response.headers["Content-Type"] == "application/json"
    assert "ErrorModel" in response.json()

def test_put_rti_transaction_tag_unauthorized():
    url = f"{BASE_URL}/Employer/ER001/RtiTransaction/FPS001/Tag/MyTag"
    headers = {
        "Authorization": "Bearer INVALID_ACCESS_TOKEN",
        "Api-Version": "default"
    }
    response = requests.put(url, headers=headers)
    
    assert response.status_code == 401
    assert "Content-Type" in response.headers
    assert response.headers["Content-Type"] == "application/json"
    assert "ErrorModel" in response.json()

def test_put_rti_transaction_tag_not_found():
    url = f"{BASE_URL}/Employer/ER001/RtiTransaction/FPS001/Tag/NonExistentTag"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Api-Version": "default"
    }
    response = requests.put(url, headers=headers)
    
    assert response.status_code == 404
    assert "Content-Type" in response.headers
    assert response.headers["Content-Type"] == "application/json"
    assert "ErrorModel" in response.json()

def test_put_rti_transaction_tag_internal_server_error():
    url = f"{BASE_URL}/Employer/ER001/RtiTransaction/FPS001/Tag/InternalServerErrorTag"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Api-Version": "default"
    }
    response = requests.put(url, headers=headers)
    
    assert response.status_code == 500
    assert "Content-Type" in response.headers
    assert response.headers["Content-Type"] == "application/json"
    assert "ErrorModel" in response.json()