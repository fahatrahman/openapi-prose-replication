# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_get_companies_companyId_androidCertificates():
    url = f"{BASE_URL}/companies/{'companyId'}"
    headers = {"Authorization": "Basic Auth"}
    
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    
    data = response.json()
    assert isinstance(data, dict)
    assert 'data' in data
    for certificate in data['data']:
        assert isinstance(certificate, dict)
        assert 'id' in certificate
        assert 'name' in certificate
        assert 'notAfter' in certificate
        assert 'notBefore' in certificate
        assert 'status' in certificate
        
        assert isinstance(certificate['notAfter'], str)
        assert isinstance(certificate['notBefore'], str)
        
        try:
            datetime.strptime(certificate['notAfter'], "%Y-%m-%dT%H:%M:%S%z")
            datetime.strptime(certificate['notBefore'], "%Y-%m-%dT%H:%M:%S%z")
        except ValueError:
            pytest.fail("Date format is incorrect")

def test_get_companies_companyId_androidCertificates_invalid_page_number():
    url = f"{BASE_URL}/companies/{'companyId'}"
    params = {'pageNumber': 'abc'}
    headers = {"Authorization": "Basic Auth"}
    
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 400
    
    error_response = response.json()
    assert isinstance(error_response, dict)
    assert 'errorCode' in error_response
    assert 'detail' in error_response
    assert 'instance' in error_response
    assert 'status' in error_response
    assert isinstance(error_response['status'], int)

def test_get_companies_companyId_androidCertificates_invalid_certificate_name():
    url = f"{BASE_URL}/companies/{'companyId'}"
    params = {'certificateName': 'abc'}
    headers = {"Authorization": "Basic Auth"}
    
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 400
    
    error_response = response.json()
    assert isinstance(error_response, dict)
    assert 'errorCode' in error_response
    assert 'detail' in error_response
    assert 'instance' in error_response
    assert 'status' in error_response
    assert isinstance(error_response['status'], int)