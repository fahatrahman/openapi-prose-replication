import pytest
import requests

BASE_URL = "http://openapi.test"

def test_datastore_projects_import():
    url = f"{BASE_URL}/v1/projects/{pytest.project_id}:import"
    headers = {
        "Authorization": pytest.auth_header,
        "Content-Type": "application/json"
    }
    payload = {
        "entityFilter": {
            "kinds": ["Kind1", "Kind2"],
            "namespaceIds": []
        },
        "inputUrl": "gs://bucket/path/to/file",
        "labels": {}
    }
    params = {
        "$.xgafv": "1",
        "access_token": pytest.access_token,
        "alt": "json",
        "callback": None,
        "fields": None,
        "key": pytest.api_key,
        "oauth_token": pytest.oauth_token,
        "prettyPrint": False,
        "quotaUser": None,
        "uploadProtocol": None,
        "uploadType": None
    }

    response = requests.post(url, headers=headers, json=payload, params=params)
    assert response.status_code == 200
    assert response.json()["name"].startswith("projects/" + pytest.project_id + "/operations/")