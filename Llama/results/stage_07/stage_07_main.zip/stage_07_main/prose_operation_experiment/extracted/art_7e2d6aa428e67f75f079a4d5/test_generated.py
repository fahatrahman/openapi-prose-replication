# -*- coding: utf-8 -*-

import pytest
import requests
from typing import Dict, List

BASE_URL = "http://openapi.test"

def test_update_group_subscriptions_get_update_group_subscriptions():
    url = f"{BASE_URL}/api/v2/UpdateGroupSubscriptions"
    params: Dict[str, str] = {}

    def get_params() -> Dict[str, str]:
        return params

    def set_param(name: str, value: str):
        nonlocal params
        params[name] = value

    set_param("UpdateGroupID", "Ieafpp_Wbdji")
    set_param("PackageTypeID", "Hxancja_Zxzf")
    set_param("ClientID", "DivwgbOR")
    set_param("limit", "10")
    set_param("offset", "0")

    response = requests.get(url, params=get_params())

    assert response.status_code == 200
    response.raise_for_status()

    # Parse JSON response
    data: Dict = response.json()
    metadata: Dict = data["Metadata"]
    entities: List[Dict] = data["Entities"]

    # Validate response structure
    assert "TotalCount" in metadata
    assert "Limit" in metadata
    assert "Offset" in metadata
    assert all(isinstance(entity, dict) for entity in entities)

    # Validate required fields
    assert "UpdateGroupID" in entities[0]
    assert "PackageTypeID" in entities[0]
    assert "ClientID" in entities[0]
    assert "Include" in entities[0]

if __name__ == "__main__":
    pytest.main([__file__])