import pytest
import requests

BASE_URL = "http://openapi.test"

def test_datastream_projects_locations_connectionprofiles_list():
    url = f"{BASE_URL}/v1alpha1/{parent}/connectionProfiles"
    headers = {}
    params = {
        "$.xgafv": "1",
        "access_token": "",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "",
        "oauth_token": "",
        "prettyPrint": "false",
        "quotaUser": "",
        "upload_protocol": "multipart",
        "uploadType": "media",
        "filter": "",
        "orderBy": "",
        "pageSize": 10,
        "pageToken": ""
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    response_json = response.json()
    assert isinstance(response_json, dict)
    assert "connectionProfiles" in response_json.keys()
    assert isinstance(response_json["connectionProfiles"], list)
    assert isinstance(response_json["nextPageToken"], str)
    assert isinstance(response_json["unreachable"], list)

@pytest.fixture
def parent():
    return "projects/your-project/locations/your-location"