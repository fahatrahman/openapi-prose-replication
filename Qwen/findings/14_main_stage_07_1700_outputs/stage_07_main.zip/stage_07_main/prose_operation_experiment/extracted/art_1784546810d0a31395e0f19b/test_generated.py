import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_schemas():
    url = f"{BASE_URL}/v1/registries/name/test/ schemas"
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20130524/us-east-1/iam/aws4_request",
        "X-Amz-Date": "20130524T000000Z",
        "X-Amz-Security-Token": "AQoDYXdzEPT//////////wEaHiqOiN2yORRZYQ==",
        "X-Amz-Signature": "d0e85dded98da387f3a2d6c69d530fc894cefd279e9474c2be1c48f6baac1328",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-security-token;x-amz-signature;x-amz-signedheaders"
    }
    params = {
        "limit": 10,
        "nextToken": "",
        "registryName": "test",
        "schemaNamePrefix": "",
        "Limit": "",
        "NextToken": ""
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    assert "NextToken" in response.json()
    assert isinstance(response.json()["Schemas"], list)

if __name__ == "__main__":
    pytest.main([__file__])