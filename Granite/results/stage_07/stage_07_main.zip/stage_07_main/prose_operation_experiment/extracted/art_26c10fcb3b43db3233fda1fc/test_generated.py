import os
import pytest
import requests
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def analytics_service():
    credentials = None
    if 'GOOGLE_APPLICATION_CREDENTIALS' in os.environ:
        credentials = os.path.abspath(os.environ['GOOGLE_APPLICATION_CREDENTIALALES'])

    service = build('analytics', 'v3', credentials=credentials)
    return service

def test_create_webproperty(analytics_service):
    try:
        account_id = "your_account_id"
        body = {
            "name": "Test Property",
            "websiteUrl": "http://www.example.com",
            "industryVertical": "AUTO"
        }

        request = analytics_service.management().webproperties().insert(
            accountId=account_id,
            body=body
        )
        response = request.execute()

        assert response["id"]
        print(f"Web property created with ID: {response['id']}")

    except HttpError as error:
        print(f"An error occurred: {error}")