import pytest
import requests

BASE_URL = "http://openapi.test"

def test_add_video_tags():
    video_id = 258684937
    headers = {
        'Authorization': 'Bearer YOUR_ACCESS_TOKEN',
        'Content-Type': 'application/vnd.vimeo.tag+json'
    }
    payload = {
        "name": "awesome",
        "page": 1,
        "per_page": 10
    }
    response = requests.put(f"{BASE_URL}/videos/{video_id}/tags", json=payload, headers=headers)
    
    assert response.status_code == 200
    assert isinstance(response.json(), list)
    for item in response.json():
        assert 'uri' in item
        assert 'name' in item
        assert 'resource_key' in item
        assert 'canonical' in item
        assert 'metadata' in item
        assert 'page' in item
        assert 'per_page' in item
        assert 'total' in item
        assert 'options' in item['metadata']['connections']['videos']

def test_add_video_tags_invalid_payload():
    video_id = 258684937
    headers = {
        'Authorization': 'Bearer YOUR_ACCESS_TOKEN',
        'Content-Type': 'application/vnd.vimeo.tag+json'
    }
    payload = {
        "invalid_field": "value"
    }
    response = requests.put(f"{BASE_URL}/videos/{video_id}/tags", json=payload, headers=headers)
    
    assert response.status_code == 400
    assert isinstance(response.json(), dict)
    assert 'error' in response.json()

def test_add_video_tags_unauthorized():
    video_id = 258684937
    headers = {
        'Authorization': 'Bearer INVALID_ACCESS_TOKEN',
        'Content-Type': 'application/vnd.vimeo.tag+json'
    }
    payload = {
        "name": "awesome",
        "page": 1,
        "per_page": 10
    }
    response = requests.put(f"{BASE_URL}/videos/{video_id}/tags", json=payload, headers=headers)
    
    assert response.status_code == 403
    assert isinstance(response.json(), dict)
    assert 'error' in response.json()