import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def setup():
    session = requests.Session()
    retry = Retry(
        total=3,
        backoff_factor=1,
        status_forcelist=[429, 500, 502, 503, 504],
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("https://", adapter)
    session.mount("http://", adapter)

    return session


def test_create_restapi(setup):
    response = setup.post(
        f"{BASE_URL}/restapis",
        headers={
            "X-Amz-Algorithm": "AWSv4",
            "X-Amz-Content-Sha256": "CONTENT_SHA256",
            "X-Amz-Date": "DATE",
            "X-Amz-Credential": "CREDENTIAL",
            "X-Amz-Security-Token": "SECURITY_TOKEN",
            "X-Amz-Signature": "SIGNATURE",
            "X-Amz-SignedHeaders": "SIGNED_HEADERS",
        },
        json={
            "apiKeySource": "HEADER",
            "binaryMediaTypes": ["TYPE"],
            "cloneFrom": "LG",
            "description": "DESCRIPTION",
            "disableExecuteApiEndpoint": True,
            "endpointConfiguration": {
                "types": ["ENDPOINT_TYPE"],
                "vpcEndpointIds": ["VPC_ENDPOINT_ID"],
            },
            "minimumCompressionSize": 10240,
            "name": "NAME",
            "policy": "POLICY",
            "tags": {"TAG_KEY": "TAG_VALUE"},
            "version": "VERSION",
        },
    )

    assert response.status_code == 201