# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_displayvideo_advertisers_locationlists_assignedlocations_list():
    url = f"{BASE_URL}/v3/advertisers/{'test_advertiser_id'}/locationLists/{'test_location_list_id'}{/assignedLocations"
    
    params = {
        "$.xgafv": "1",
        "access_token": "test_access_token",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "test_key",
        "oauth_token": "test_oauth_token",
        "prettyPrint": "false",
        "quotaUser": "test_quota_user",
        "upload_protocol": "multipart",
        "uploadType": "media"
    }
    
    headers = {}
    
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 200
    
    # Assert the response content type is JSON
    assert response.headers["Content-Type"] == "application/json"
    
    # Parse the JSON response
    response_json = response.json()
    
    # Assert the expected structure of the response
    assert isinstance(response_json, dict)
    assert "assignedLocations" in response_json.keys()
    assert "nextPageToken" in response_json.keys()
