import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def api_client():
    session = requests.Session()
    retry = Retry(total=3, backoff_factor=0.1, status_forcelist=[429, 500, 502, 503, 504])
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("http://", adapter)
    return session

def test_submit_third_party_payout(api_client):
    url = f"{BASE_URL}/submitThirdParty"
    headers = {"X-API-Key": "YOUR_API_KEY"}

    payload = {
        "amount": {
            "currency": "EUR",
            "value": 1000,
        },
        "dateOfBirth": "1990-01-01",
        "entityType": "Company",
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "nationality": "NL",
        "recurring": {
            "contract": "PAYOUT",
        },
        "reference": "PayoutPayment-0001",
        "selectedRecurringDetailReference": "LATEST",
        "shopperEmail": "shopper@email.com",
        "shopperName": {
            "firstName": "Adyen",
            "lastName": "Test",
        },
        "shopperReference": "YOUR_UNIQUE_SHOPPER_ID",
    }

    response = api_client.post(url, json=payload, headers=headers)

    assert response.status_code == 200
    assert response.json()["resultCode"] == "payout-submit-received"