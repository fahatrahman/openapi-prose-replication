# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_discoveryengine_projects_locations_data_stores_site_search_engine_target_sites_patch():
    url = f"{BASE_URL}/v1alpha/{'projects/{project}/locations/{location}/collections/{collection}/dataStores/{data_store}/siteSearchEngine/targetSites/{target_site}'}"
    headers = {"Content-Type": "application/json"}
    params = {
        "$.xgafv": "1",
        "access_token": "",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "",
        "oauth_token": "",
        "prettyPrint": "true",
        "quotaUser": "",
        "upload_protocol": "raw",
        "uploadType": "media"
    }
    data = {
        "exactMatch": False,
        "failureReason": {},
        "generatedUriPattern": "",
        "indexingStatus": "INDEXING_STATUS_UNSPECIFIED",
        "name": "projects/{project}/locations/{location}/collections/{collection}/dataStores/{data_store}/siteSearchEngine/targetSites/{target_site}",
        "providedUriPattern": "example.com",
        "siteVerificationInfo": {},
        "type": "INCLUDE",
        "updateTime": ""
    }

    response = requests.request("PATCH", url, json=data, headers=headers, params=params)

    assert response.status_code == 200
    assert response.json()["done"]