import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_actions():
    url = f"{BASE_URL}/v1/projects/locations/lakes/zones/assets/actions"
    params = {
        "_xgafv": "2",
        "access_token": "your_access_token_here",
        "alt": "json",
        "callback": "your_callback_url_here",
        "fields": "*",
        "key": "your_api_key_here",
        "oauth_token": "your_oauth_token_here",
        "prettyPrint": False,
        "quotaUser": "your_quota_user_here",
        "uploadType": "multipart/form-data",
        "upload_protocol": "raw",
        "pageSize": 10,
        "pageToken": ""
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    assert 'actions' in response.json()