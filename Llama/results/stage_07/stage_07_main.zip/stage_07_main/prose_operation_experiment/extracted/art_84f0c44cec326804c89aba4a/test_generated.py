# -*- coding: utf-8 -*-
import pytest
import requests

BASE_URL = "http://openapi.test"

def test_workstations_projects_locations_operations_list():
    url = f"{BASE_URL}/v1/{'name'}"
    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
    }
    params = {
        '$.xgafv': '1',
        'access_token': '',
        'alt': 'json',
        'callback': '',
        'fields': '',
        'key': '',
        'oauth_token': '',
        'prettyPrint': 'false',
        'quotaUser': '',
        'upload_protocol': 'upload_protocol',
        'uploadType': 'media',
        'filter': '',
        'pageSize': '10',
        'pageToken': ''
    }

    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    assert response.json()['nextPageToken'] is None or isinstance(response.json()['nextPageToken'], str)
    assert isinstance(response.json()['operations'], list)
    for op in response.json()['operations']:
        assert isinstance(op, dict)
        assert 'done' in op.keys()
        assert isinstance(op['done'], bool)
        assert 'error' in op.keys()
        assert isinstance(op['error'], dict)
        assert 'code' in op['error'].keys()
        assert isinstance(op['error']['code'], int)
        assert 'details' in op['error'].keys()
        assert isinstance(op['error']['details'], list)
        for detail in op['error']['details']:
            assert isinstance(detail, dict)
        assert 'message' in op['error'].keys()
        assert isinstance(op['error']['message'], str)
        assert 'metadata' in op.keys()
        assert isinstance(op['metadata'], dict)
        assert 'name' in op.keys()
        assert isinstance(op['name'], str)
        assert 'response' in op.keys()
        assert isinstance(op['response'], dict)