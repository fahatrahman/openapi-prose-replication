import pytest
import requests

BASE_URL = "http://openapi.test"

def test_simulate_an_inbound_wire_drawdown_request_being_created():
    url = f"{BASE_URL}/simulations/inbound_wire_drawdown_requests"
    headers = {
        "Authorization": "Bearer your_access_token_here",
        "Content-Type": "application/json"
    }
    payload = {
        "amount": 10000,
        "beneficiary_account_number": "987654321",
        "beneficiary_address_line1": "33 Liberty Street",
        "beneficiary_address_line2": "New York, NY, 10045",
        "beneficiary_name": "Ian Crease",
        "beneficiary_routing_number": "101050001",
        "currency": "USD",
        "message_to_recipient": "Invoice 29582",
        "originator_account_number": "987654321",
        "originator_address_line1": "33 Liberty Street",
        "originator_address_line2": "New York, NY, 10045",
        "originator_name": "Ian Crease",
        "originator_routing_number": "101050001",
        "recipient_account_number_id": "account_number_v18nkfqm6afpsrvy82b2",
        "originator_to_beneficiary_information_line1": None,
        "originator_to_beneficiary_information_line2": None,
        "originator_to_beneficiary_information_line3": None,
        "originator_to_beneficiary_information_line4": None,
        "type": "inbound_wire_drawdown_request"
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 200
    assert 'id' in response.json()
    assert 'type' in response.json() and response.json()['type'] == 'inbound_wire_drawdown_request'