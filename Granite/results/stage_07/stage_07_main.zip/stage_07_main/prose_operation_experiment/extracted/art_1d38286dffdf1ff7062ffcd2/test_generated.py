import os
import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def setup():
    return HTTPBasicAuth("username", "password") if "username" in os.environ else None

def get_vulnerability_summary(parent, filter=None):
    url = f"{BASE_URL}/v1/{parent}/occurrences:vulnerabilitySummary"
    params = {"filter": filter}

    response = requests.get(url, auth=setup(), params=params)

    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Failed to fetch vulnerability summary: {response.text}")

def test_get_vulnerability_summary(setup):
    parent = "your_project_id"
    filter_value = "some_filter_value" if "filter" in os.environ else None

    try:
        result = get_vulnerability_summary(parent, filter_value)
        assert isinstance(result, dict)
        print("Test passed.")
    except Exception as e:
        print(f"Test failed: {str(e)}")