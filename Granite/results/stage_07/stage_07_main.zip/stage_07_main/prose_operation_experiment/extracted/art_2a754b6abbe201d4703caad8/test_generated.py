import os
import json
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["GET", "OPTIONS"],
)
SESSION.mount("https://", HTTPAdapter(max_retries=RETRY_STRATEGY))
SESSION.mount("http://", HTTPAdapter(max_retries=RETRY_STRATEGY))

@pytest.fixture
def list_integrations():
    domain_name = "your_domain_name" # Replace this with your actual domain name
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "YOUR_ACCESS_KEY:YOUR_SECRET_KEY/region/service/aws4request",
        "X-Amz-Date": "YYYYMMDDTHHMMSSZ",
        "X-Amz-Security-Token": "YOUR_SECURITY_TOKEN",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date",
    }

    params = {
        "next-token": "NEXT_TOKEN",
        "max-results": 100,
        "include-hidden": True,
    }

    url = f"{BASE_URL}/domains/{domain_name}/integrations"
    response = SESSION.get(url, headers=headers, params=params)

    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Error fetching integrations: {response.text}")