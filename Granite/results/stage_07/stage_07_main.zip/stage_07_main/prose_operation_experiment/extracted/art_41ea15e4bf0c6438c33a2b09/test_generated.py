import os
import pytest
import requests
from google.rpc import Status

BASE_URL = "http://openapi.test"

@pytest.fixture
def test_client():
    def _test_client(request):
        url = f"{BASE_URL}/v1beta/{request.param}"
        headers = {
            "x-goog-api-client": "gl-python",
            "x-goog-api-version": "1.1346.0",
        }

        response = requests.delete(url, headers=headers)
        response.raise_for_status()

        return response.json()

    return _test_client

def test_workflow_delete(test_client):
    workflow_name = "projects/your_project/locations/your_location/workflows/your_workflow"
    response = test_client(workflow_name)

    assert response["name"] == workflow_name
    assert response["done"] is True
    assert "error" not in response
    assert "response" in response
    assert isinstance(response["response"], dict)