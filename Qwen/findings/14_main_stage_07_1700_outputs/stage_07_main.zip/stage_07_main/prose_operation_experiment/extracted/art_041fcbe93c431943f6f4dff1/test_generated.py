import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_webhook():
    url = f"{BASE_URL}/v3/projects/{parent}/webhooks"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "displayName": "Test Webhook",
        "genericWebService": {
            "uri": "https://example.com/webhook"
        }
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert "name" in response.json()
    assert response.json()["displayName"] == "Test Webhook"

if __name__ == "__main__":
    pytest.main()