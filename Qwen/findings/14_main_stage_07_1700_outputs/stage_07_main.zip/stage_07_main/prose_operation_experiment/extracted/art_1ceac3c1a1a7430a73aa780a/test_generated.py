import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_application():
    url = f"{BASE_URL}/organisations/{'org_id'}/applications/{'app_id'}"
    response = requests.get(url)
    
    assert response.status_code == 200
    application = response.json()
    assert isinstance(application, dict)
    assert 'archived' in application
    assert 'branch' in application
    assert 'buildFlavor' in application
    assert 'cancelOnPush' in application
    assert 'commitId' in application
    assert 'creationDate' in application
    assert 'deployUrl' in application
    assert 'deployment' in application
    assert 'description' in application
    assert 'favourite' in application
    assert 'homogeneous' in application
    assert 'id' in application
    assert 'instance' in application
    assert 'last_deploy' in application
    assert 'name' in application
    assert 'ownerId' in application
    assert 'separateBuild' in application
    assert 'state' in application
    assert 'stickySessions' in application
    assert 'vhosts' in application
    assert 'webhookSecret' in application
    assert 'webhookUrl' in application
    assert 'zone' in application