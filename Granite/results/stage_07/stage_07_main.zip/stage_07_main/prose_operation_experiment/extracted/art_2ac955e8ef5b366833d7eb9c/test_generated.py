import os
import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def recommender():
    headers = {
        "User-Agent": "py-tests/1.0",
    }

    def api_call(method, path, params=None):
        url = f"{BASE_URL}{path}"
        response = requests.request(method, url, headers=headers, params=params)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Request failed with status code {response.status_code}")

    yield api_call

def test_list_insights(recommender):
    parent = "zynntaco/1234/yzvrewumc/wtikhxkWagxk/insights" # Replace with actual value
    filter_ = "state=ACTIVE" # Example filter, replace with actual requirements
    page_size = 10
    page_token = None

    insights = recommender("GET", f"/v1/{parent}/insights", params={"filter": filter_, "pageSize": page_size, "pageToken": page_token})
    
    assert len(insights["insights"]) > 0
    print("Test passed: Insights were successfully retrieved.")
