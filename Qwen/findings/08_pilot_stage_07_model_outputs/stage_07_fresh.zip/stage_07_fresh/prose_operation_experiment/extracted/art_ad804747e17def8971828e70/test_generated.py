import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_email_template():
    url = f"{BASE_URL}/v2/email/templates"
    headers = {
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Date": "20230401T000000Z",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "access_key_id/20230401/us-east-1/sts/aws4_request",
        "X-Amz-Security-Token": "token",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-algorithm;x-amz-credential;x-amz-security-token"
    }
    payload = {
        "TemplateName": "test-template",
        "TemplateContent": {
            "Subject": "Test Subject",
            "Html": "<html><body><h1>Hello World</h1></body></html>",
            "Text": "Hello World"
        }
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 200
    assert isinstance(response.json(), dict)