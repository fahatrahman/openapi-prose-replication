import pytest
import requests

BASE_URL = "http://openapi.test"

def test_movePad():
    url = f"{BASE_URL}/movePad"
    params = {
        "sourceID": "test_source",
        "destinationID": "test_destination",
        "force": "true"
    }
    headers = {
        "apikey": "test_apikey"
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 200
    assert response.json()["code"] == 0
    assert response.json()["message"] == "ok"

def test_movePad_400():
    url = f"{BASE_URL}/movePad"
    params = {
        "sourceID": "invalid_source",
        "destinationID": "invalid_destination",
        "force": "false"
    }
    headers = {
        "apikey": "test_apikey"
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 400
    assert response.json()["code"] == 1
    assert response.json()["message"] == "error message"

def test_movePad_401():
    url = f"{BASE_URL}/movePad"
    params = {
        "sourceID": "test_source",
        "destinationID": "test_destination",
        "force": "true"
    }
    headers = {
        "apikey": "wrong_apikey"
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 401
    assert response.json()["code"] == 4
    assert response.json()["message"] == "no or wrong API key"

def test_movePad_500():
    url = f"{BASE_URL}/movePad"
    params = {
        "sourceID": "test_source",
        "destinationID": "test_destination",
        "force": "true"
    }
    headers = {
        "apikey": "test_apikey"
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 500
    assert response.json()["code"] == 2
    assert response.json()["message"] == "internal error"