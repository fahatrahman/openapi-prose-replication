# -*- coding: utf-8 -*-
import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_get_retreat():
    retreat = "test-retreat"
    response = requests.get(urljoin(BASE_URL, f"/retreats/{retreat}"))
    assert response.status_code == 200, f"Expected status code 200, got {response.status_code}"
    response_json = response.json()
    assert isinstance(response_json, dict), f"Expected JSON object, got {type(response_json)}"
    cards = response_json["cards"]
    assert all(isinstance(card, dict) for card in cards), f"Expected list of CardResume objects, got {type(cards[0])}"
    name = response_json["name"]
    assert isinstance(name, str), f"Expected string name, got {type(name)}"

def test_get_non_existent_retreat():
    retreat = "non-existent-retreat"
    response = requests.get(urljoin(BASE_URL, f"/retreats/{retreat}"))
    assert response.status_code == 404, f"Expected status code 404, got {response.status_code}"

if __name__ == "__main__":
    pytest.main([__file__])