import os
import hmac
import hashlib
import datetime
from urllib.parse import urlencode
import requests
import pytest

BASE_URL = "http://openapi.test"

# AWS SigV4 signing
def sign(method, path, headers, payload):
    # Generate string to sign
    string_to_sign = (
        "AWS4-HMAC-SHA256\n"
        + str(datetime.datetime.utcnow())
        + "\n"
        + "20220327T000000Z/"
        + "aws4_request"
        + "/"
        + "aws1.amazonaws.com/"
        + "aws4_region=us-east-1"
    )

    # Create signing key
    signing_key = get_signing_key()

    # Sign the request
    signature = hmac.new(
        signing_key.encode(),
        (method + "\n" + path + "\n" + header_string(headers) + "\n" + hashlib.sha256(payload.encode()).hexdigest()).encode(),
    ).hexdigest()

    return signature


def get_signing_key():
    date_stamp = datetime.datetime.utcnow().strftime("%Y%m%d")
    current_date = datetime.datetime.utcnow().strftime("%m%d%H%M%S") + "Z"
    scoped_date = f"{date_stamp}/{current_date}"

    credential_scope = f"{scoped_date}/aws4_region=us-east-1"

    string_to_sign = (
        "aws4_request"
        + "/"
        + "host"
        + "/"
        "/aws4_region=us-east-1"
        + "/"
        + scoped_date
    )

    kSecret = os.environ["AWS_SECRET_ACCESS_KEY"]
    kDateKey = hmac.new(kSecret.encode(), (date_stamp + current_date).encode(), hashlib.sha256).digest()
    kSigningKey = hmac.new(kDateKey, "aws4_request".encode(), hashlib.sha256).digest()

    return hmac.new(kSigningKey, string_to_sign.encode(), hashlib.sha256).digest()


def header_string(headers):
    return "\n".join([f"{k}:{v}" for k, v in headers.items()])


@pytest.fixture
def client():
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": f"AKIAIOSFODNN7EXAMPLE/20220327/us-east-1/s3/aws4_request",
        "X-Amz-Date": datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ"),
        "X-Amz-Expires": "3600",
        "X-Amz-SignedHeaders": "host;x-amz-algorithm;x-amz-credential;x-amz-date;x-amz_expires",
        "X-Amz-Signature": sign("GET", "/", {}, ""),
    }

    identifier = "example_identifier"
    next_token = "example_next_token"
    max_results = 10

    params = {"Identifier": identifier, "nextToken": next_token, "maxResults": max_results}
    query_string = urlencode(params)
    path = f"/dataIntegrations/{identifier}/associations?{query_string}"

    response = requests.get(BASE_URL + path, headers=headers)
    assert response.status_code == 200

    return response.json()