# pytest_tpu_tensorflow_versions.py

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_tensorflow_versions():
    url = f"{BASE_URL}/v1/{'parent'}"
    headers = {}
    params = {
        'key': 'your_api_key',
        'page_size': 10,
        'page_token': ''
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    response.raise_for_status()
    data = response.json()
    assert isinstance(data, dict)
    assert 'nextPageToken' in data
    assert isinstance(data['nextPageToken'], str)
    assert isinstance(data['tensorflowVersions'], list)

def test_list_tensorflow_versions_with_filter():
    url = f"{BASE_URL}/v1/{'parent'}"
    headers = {}
    params = {
        'key': 'your_api_key',
        'filter': 'some_filter',
        'page_size': 10,
        'page_token': ''
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    response.raise_for_status()
    data = response.json()
    assert isinstance(data, dict)
    assert 'nextPageToken' in data
    assert isinstance(data['nextPageToken'], str)
    assert isinstance(data['tensorflowVersions'], list)

def test_list_tensorflow_versions_with_order_by():
    url = f"{BASE_URL}/v1/{'parent'}"
    headers = {}
    params = {
        'key': 'your_api_key',
        'order_by': 'some_order_by',
        'page_size': 10,
        'page_token': ''
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    response.raise_for_status()
    data = response.json()
    assert isinstance(data, dict)
    assert 'nextPageToken' in data
    assert isinstance(data['nextPageToken'], str)
    assert isinstance(data['tensorflowVersions'], list)