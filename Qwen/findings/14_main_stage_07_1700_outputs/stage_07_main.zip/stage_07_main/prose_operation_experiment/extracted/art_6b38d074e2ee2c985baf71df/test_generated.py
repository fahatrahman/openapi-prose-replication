import pytest
import requests

BASE_URL = "http://openapi.test"

def get_domain(domain_key):
    url = f"{BASE_URL}/domain/{domain_key}"
    headers = {
        "Authorization": "Bearer YOUR_API_KEY"
    }
    response = requests.get(url, headers=headers)
    return response.json()

@pytest.mark.parametrize("domain_key", ["48cf1c9b-f027-4223-b405-d48018ffb900"])
def test_get_domain(domain_key):
    response = get_domain(domain_key)
    assert response["status_code"] == 200
    assert "result" in response
    assert "domain" in response["result"]
    assert "domain_key" in response["result"]["domain"]
    assert "name" in response["result"]["domain"]
    assert "port" in response["result"]["domain"]

if __name__ == "__main__":
    pytest.main()