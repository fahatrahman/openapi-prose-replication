# pytest-openapi.py

import pytest
import requests
from unittest.mock import Mock

BASE_URL = "http://openapi.test"

def test_tagmanager_accounts_containers_folders_list():
    url = f"{BASE_URL}/tagmanager/v1/accounts/{pytest.params.accountId}/containers/{pytest.params.containerId}/folders"
    headers = {"Content-Type": "application/json"}

    response = requests.get(url, params=pytest.params, headers=headers)

    assert response.status_code == 200
    assert response.json()["folders"]

class TestTagManagerAccountsContainersFoldersList:
    @pytest.fixture(autouse=True)
    def setup(self):
        self.requests_get_mock = Mock()
        self.patcher = pytest.fixture(autouse=True)(requests.get).return_value = self.requests_get_mock

    @pytest.mark.parametrize(
        "accountId,containerId",
        [
            ("123456789", "012345678901234567890"),
        ],
    )
    def test_tagmanager_accounts_containers_folders_list_success(
        self,
        accountId,
        containerId,
    ):
        pytest.params = {
            "_xgafv": "1",
            "access_token": None,
            "alt": "json",
            "callback": None,
            "fields": "*",
            "key": None,
            "oauth_token": None,
            "prettyPrint": False,
            "quotaUser": None,
            "upload_protocol": "raw",
            "uploadType": "media",
            "accountId": accountId,
            "containerId": containerId,
        }

        self.requests_get_mock.return_value.status_code = 200
        self.requests_get_mock.return_value.json.return_value = {
            "folders": [{"name": "test_folder"}]
        }

        test_tagmanager_accounts_containers_folders_list()

        self.requests_get_mock.assert_called_once_with(
            f"{BASE_URL}/tagmanager/v1/accounts/{accountId}/containers/{containerId}/folders",
            params=pytest.params,
            headers={"Content-Type": "application/json"},
        )

    def test_tagmanager_accounts_containers_folders_list_failure(self):
        pytest.params = {
            "_xgafv": "1",
            "access_token": None,
            "alt": "json",
            "callback": None,
            "fields": "*",
            "key": None,
            "oauth_token": None,
            "prettyPrint": False,
            "quotaUser": None,
            "upload_protocol": "raw",
            "uploadType": "media",
            "accountId": "invalid_account_id",
            "containerId": "invalid_container_id",
        }

        self.requests_get_mock.return_value.status_code = 404

        with pytest.raises(AssertionError):
            test_tagmanager_accounts_containers_folders_list()

        self.requests_get_mock.assert_called_once_with(
            f"{BASE_URL}/tagmanager/v1/accounts/{pytest.params['accountId']}/containers/{pytest.params['containerId']}/folders",
            params=pytest.params,
            headers={"Content-Type": "application/json"},
        )