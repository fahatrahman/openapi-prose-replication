# -*- coding: utf-8 -*-
import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

def test_get_site():
    """Test getting site."""
    response = requests.get(
        f"{BASE_URL}/targets/{'target_id'}",
        auth=HTTPBasicAuth('username', 'password')
    )
    assert response.status_code == 200
    assert response.json()['name'] != ''

def test_get_site_unauthorized():
    """Test getting site without authentication."""
    response = requests.get(f"{BASE_URL}/targets/{'target_id'}")
    assert response.status_code == 401

def test_get_site_not_found():
    """Test getting non-existent site."""
    response = requests.get(f"{BASE_URL}/targets/{'non_existent_target_id'}", auth=HTTPBasicAuth('username', 'password'))
    assert response.status_code == 404