import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_sample_findings():
    url = f"{BASE_URL}/detector/{detectorId}/findings/create"
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Credential": "your-access-key-id/20230401/us-east-1/sts/aws4_request",
        "X-Amz-Date": "20230401T123456Z",
        "X-Amz-Security-Token": "your-security-token",
        "X-Amz-Signature": "your-signature",
        "X-Amz-SignedHeaders": "host;x-amz-algorithm;x-amz-content-sha256;x-amz-credential;x-amz-date;x-amz-security-token;x-amz-signedheaders",
        "Authorization": "AWS4-HMAC-SHA256 Credential=your-access-key-id/20230401/us-east-1/sts/aws4_request,SignedHeaders=host;x-amz-algorithm;x-amz-content-sha256;x-amz-credential;x-amz-date;x-amz-security-token;x-amz-signedheaders,Signature=your-signature"
    }
    payload = {
        "findingTypes": ["type1", "type2"]
    }
    response = requests.post(url, json=payload, headers=headers)
    
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

# Replace 'detectorId' with the actual value you want to test
detectorId = "example-detector-id"
test_create_sample_findings()