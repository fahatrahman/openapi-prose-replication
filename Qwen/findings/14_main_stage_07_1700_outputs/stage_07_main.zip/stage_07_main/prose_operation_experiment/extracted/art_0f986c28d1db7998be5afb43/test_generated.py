import pytest
import requests

BASE_URL = "http://openapi.test"

def test_dns_policies_list():
    url = f"{BASE_URL}/dns/v1/projects/example-project/policies"
    params = {
        "maxResults": 10,
        "pageToken": None,
        "_xgafv": "1",
        "access_token": "example_access_token",
        "alt": "json",
        "callback": None,
        "fields": None,
        "key": "example_key",
        "oauth_token": "example_oauth_token",
        "prettyPrint": True,
        "quotaUser": "example_quota_user",
        "uploadProtocol": None,
        "uploadType": None
    }
    headers = {
        "Authorization": "Bearer example_access_token"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    policies_list_response = response.json()
    assert "header" in policies_list_response
    assert "kind" in policies_list_response
    assert "nextPageToken" in policies_list_response
    assert "policies" in policies_list_response
    for policy in policies_list_response["policies"]:
        assert "alternativeNameServerConfig" in policy
        assert "description" in policy
        assert "enableInboundForwarding" in policy
        assert "enableLogging" in policy
        assert "id" in policy
        assert "kind" in policy
        assert "name" in policy
        assert "networks" in policy
        for network in policy["networks"]:
            assert "kind" in network
            assert "networkUrl" in network
        assert "alternativeNameServerConfig" in policy
        for target_name_server in policy["alternativeNameServerConfig"]["targetNameServers"]:
            assert "forwardingPath" in target_name_server
            assert "ipv4Address" in target_name_server
            assert "ipv6Address" in target_name_server
            assert "kind" in target_name_server
        assert "kind" in policy["alternativeNameServerConfig"]
    assert "kind" in policies_list_response["header"]

if __name__ == "__main__":
    pytest.main([__file__])