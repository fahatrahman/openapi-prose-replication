import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

retries = Retry(total=5, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
http = requests.Session()
http.mount("https://", adapter)
http.mount("http://", adapter)

@pytest.fixture
def waterlinked_wifi_config():
    response = http.get(f"{BASE_URL}/api/v1/config/wifi")
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Request failed with status {response.status_code}")

def test_waterlinked_wifi_config(waterlinked_wifi_config):
    assert isinstance(waterlinked_wifi_config, dict)
    assert set(["ssid", "password", "mode"]) <= set(waterlinked_wifi_config.keys())