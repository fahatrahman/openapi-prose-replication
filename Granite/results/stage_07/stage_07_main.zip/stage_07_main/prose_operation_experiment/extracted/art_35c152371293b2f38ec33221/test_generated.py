import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def api():
    return requests.Session()

def test_get_stats(api):
    url = f"{BASE_URL}/getStats"

    # Successful response
    response = api.post(url, json={"apikey": "valid_key"})
    assert response.status_code == 200
    assert response.json()["code"] == 0
    assert response.json()["message"] == "ok"
    assert response.json()["data"] is None

    # Bad request response
    response = api.post(url, json={"apikey": ""})
    assert response.status_code == 400
    assert response.json()["code"] == 1
    assert response.json()["message"] == "error message"
    assert response.json()["data"] is None

    # Unauthorized response
    response = api.post(url, json={"apikey": "wrong_key"})
    assert response.status_code == 401
    assert response.json()["code"] == 4
    assert response.json()["message"] == "no or wrong API key"
    assert response.json()["data"] is None

    # Internal server error response
    response = api.post(url, json={"apikey": "invalid_key"}, headers={"Content-Type": "text/plain"})
    assert response.status_code == 500
    assert response.json()["code"] == 2
    assert response.json()["message"] == "internal error"
    assert response.json()["data"] is None