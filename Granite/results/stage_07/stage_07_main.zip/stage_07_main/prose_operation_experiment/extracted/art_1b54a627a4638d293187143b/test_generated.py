import pytest
import requests
from requests.auth import HTTPBasicAuth
BASE_URL = "http://openapi.test"

@pytest.fixture
def auth():
    return HTTPBasicAuth("client_id", "client_secret")

def test_create_workspace(auth):
    url = f"{BASE_URL}/tagmanager/v2/{workspace_id}/workspaces"
    headers = {
        "Content-Type": "application/json",
    }

    workspace = {
        "accountId": "test_account_id",
        "containerId": "test_container_id",
        "description": "Test workspace description",
        "fingerprint": "test_fingerprint",
        "name": "Test workspace name",
        "path": "/test/path",
        "tagManagerUrl": "https://www.googletagmanager.com",
        "workspaceId": "test_workspace_id",
    }

    response = requests.post(url, headers=headers, json=workspace, auth=auth)
    assert response.status_code == 200
    created_workspace = response.json()
    # Add more assertions as needed