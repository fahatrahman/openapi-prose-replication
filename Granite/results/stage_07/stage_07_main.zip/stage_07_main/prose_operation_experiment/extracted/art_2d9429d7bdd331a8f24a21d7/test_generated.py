import os
import json
import pytest
from requests import Session
from requests.adapters import HTTPAdapter
from typing import Dict

BASE_URL = "http://openapi.test"
SESSION = Session()
SESSION.mount("http://", HTTPAdapter(max_retries=0))

@pytest.fixture
def update_recipe():
    def _update_recipe(recipe_name: str, description: str = None, steps: list = None):
        url = f"{BASE_URL}/recipes/{recipe_name}"
        payload = {
            "Description": description,
            "Steps": steps
        } if description or steps else {}

        headers = {
            "Authorization": f"AWS4-HMAC-SHA256 Credential={os.environ['AWS_ACCESS_KEY_ID']}/{os.environ['AWS_SECRET_ACCESS_KEY']}, SignedHeaders=host;x-amz-date, Signature={os.environ['AWS_SIGNATURE']}"
        }

        response = SESSION.put(url, headers=headers, json=payload)
        response.raise_for_status()
        return response.json()

    yield _update_recipe