import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_instance_config_operations():
    url = f"{BASE_URL}/v1/projects/-/instanceConfigOperations"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token_here",
        "alt": "json",
        "callback": "your_callback_here",
        "fields": "nextPageToken,operations(name,status)",
        "key": "your_api_key_here",
        "oauth_token": "your_oauth_token_here",
        "prettyPrint": False,
        "quotaUser": "your_quota_user_here",
        "uploadProtocol": "raw",
        "uploadType": "media",
        "filter": "done:true",
        "pageSize": 10,
        "pageToken": ""
    }
    headers = {
        "Authorization": "Bearer your_access_token_here"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "nextPageToken" in data
    assert "operations" in data
    for op in data["operations"]:
        assert "name" in op
        assert "status" in op