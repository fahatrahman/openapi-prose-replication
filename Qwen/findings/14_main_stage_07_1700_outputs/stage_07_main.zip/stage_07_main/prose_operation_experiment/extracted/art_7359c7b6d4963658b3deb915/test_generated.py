import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_collection_ids():
    url = f"{BASE_URL}/v1/zynntaco/pe-autfnhu/cxfctbqdz/pe-swpfuuek/wgziqdxyn/qbweyntpd/pe-dpudhdfg:listCollectionIds"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "pageSize": 10,
        "pageToken": "",
        "readTime": ""
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert "collectionIds" in response.json()
    assert isinstance(response.json()["collectionIds"], list)