import os
import pytest
import requests

BASE_URL = "http://openapi.test"
LICENSE_KEY = "your_license_key"
FIRSTNAME = "John"
LASTNAME = "Doe"

@pytest.fixture
def get_similarity_key():
    url = f"{BASE_URL}/getfullnameparsedmatch"
    params = {
        "license": LICENSE_KEY,
        "firstname": FIRSTNAME,
        "lastname": LASTNAME,
    }

    response = requests.get(url, params=params)
    if response.status_code == 200:
        return response.json()
    elif response.status_code == 400:
        raise ValueError("Insufficient parameters")
    elif response.status_code == 402:
        raise Exception("Credits exhausted")
    elif response.status_code == 403:
        raise Exception("Invalid license API key")
    elif response.status_code == 405:
        raise Exception("Method Not Allowed")
    elif response.status_code == 500:
        raise Exception("Internal Server Error")
    else:
        raise Exception(f"Unexpected status code: {response.status_code}")

def test_get_similarity_key(get_similarity_key):
    assert isinstance(get_similarity_key, dict)
    assert "Code" in get_similarity_key
    assert "Credits" in get_similarity_key
    assert "Simkey" in get_similarity_key