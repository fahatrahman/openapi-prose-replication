import pytest
import requests

BASE_URL = "http://openapi.test"

def test_update_application():
    headers = {
        "x-apideck-app-id": "dSBdXd2H6Mqwfg0atXHXYcysLJE9qyn1VwBtXHX",
        "x-apideck-consumer-id": "LG co ajh jkubpsls rukwd lfz eqcy wd qib sg vrrf stzf aetu",
        "x-apideck-service-id": "Fuznyji ajh zqlxfuz lg lfz eqcy wd funr (h.p., rrljzitrl). Rrxq iodrbl jawt p jkubpsls yhh vvuehcgka ijsewxpn bkbsmzkykmqc nrf p Xwotajz GNA."
    }
    url = f"{BASE_URL}/ats/applications/{id}"
    payload = {
        "applicant_id": "12345",
        "job_id": "12345",
        "status": "open",
        "stage": {
            "id": "12345",
            "name": "12345"
        },
        "custom_mappings": {}
    }
    response = requests.patch(url, headers=headers, json=payload)
    
    assert response.status_code == 200
    assert response.json()["status"] == "OK"
    assert response.json()["service"] == "sap-successfactors"
    assert response.json()["resource"] == "Applications"
    assert response.json()["operation"] == "update"
    assert "data" in response.json()
    assert "id" in response.json()["data"]