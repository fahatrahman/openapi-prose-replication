# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_domains_projects_locations_registrations_retrieve_importable_domains():
    params = {
        "_xgafv": None,
        "access_token": None,
        "alt": None,
        "callback": None,
        "fields": None,
        "key": None,
        "oauth_token": None,
        "prettyPrint": None,
        "quotaUser": None,
        "upload_protocol": None,
        "uploadType": None,
        "location": "zynntaco/yzvrewumc",
        "pageSize": 100,
        "pageToken": None,
    }

    response = requests.get(
        f"{BASE_URL}/v1/{params['location']}/registrations",
        params=params,
        headers={
            "Accept": "application/json"
        }
    )

    assert response.status_code == 200

    data = response.json()
    assert isinstance(data, dict)
    assert 'domains' in data.keys()

    # Add more assertions here as needed