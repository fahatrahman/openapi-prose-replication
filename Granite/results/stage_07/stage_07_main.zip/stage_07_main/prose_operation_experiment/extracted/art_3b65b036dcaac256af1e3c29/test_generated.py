import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"

@pytest.fixture
def auth():
    credentials = service_account.Credentials.from_service_account_file('path/to/credentials.json')
    return credentials

def test_move_billing_account(auth):
    path = "/v1/{name}:move"
    name = "projects/your-project-id/billingAccounts/your-billing-account-id"

    request_body = {
        "destinationParent": f"organizations/{os.environ['GOOGLE_CLOUD_PROJECT']}"
    }

    headers = {
        'Content-Type': 'application/json'
    }

    response = requests.post(f"{BASE_URL}{path}", json=request_body, headers=headers, auth=auth)

    assert response.status_code == 200
    billing_account = response.json()
    # Add additional assertions based on expected response structure