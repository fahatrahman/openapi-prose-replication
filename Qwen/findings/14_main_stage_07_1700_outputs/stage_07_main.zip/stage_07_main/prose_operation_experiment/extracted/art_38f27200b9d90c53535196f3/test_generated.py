import pytest
import requests

BASE_URL = "http://openapi.test"

def test_migrationcenter_projects_locations_sources_patch():
    url = f"{BASE_URL}/v1/projects/location/sources/source"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    payload = {
        "source": {
            "name": "projects/location/sources/source",
            "displayName": "Updated Display Name",
            "description": "Updated Description"
        },
        "updateMask": "display_name,description"
    }
    params = {
        "_xgafv": "2",
        "access_token": "YOUR_ACCESS_TOKEN",
        "alt": "json",
        "prettyPrint": "true",
        "quotaUser": "user@example.com",
        "uploadProtocol": "raw",
        "uploadType": "multipart",
        "requestId": "unique_request_id"
    }

    response = requests.patch(url, headers=headers, json=payload, params=params)
    assert response.status_code == 200
    assert "Operation" in response.json()