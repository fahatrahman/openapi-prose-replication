import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_stored_payment_methods():
    params = {
        "shopperReference": "YOUR_SHOPPER_REFERENCE",
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT"
    }
    headers = {
        "Authorization": "Bearer YOUR_API_KEY"  # Replace with actual API key
    }
    url = f"{BASE_URL}/storedPaymentMethods"
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "merchantAccount" in data
    assert "shopperReference" in data
    assert "storedPaymentMethods" in data
    assert isinstance(data["storedPaymentMethods"], list)

if __name__ == "__main__":
    pytest.main([__file__])