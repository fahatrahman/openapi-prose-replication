import os
import pytest
import requests
from google.protobuf.timestamp_pb2 import Timestamp

BASE_URL = "http://openapi.test"

@pytest.fixture
def review_reply():
    return {
        "comment": "This is a sample reply.",
        "updateTime": None  # To be set by actual test case
    }

def update_review_reply(account_id, location_id, review_id, comment):
    path = f"/v4/{location_id}/reviews/{review_id}/reply"
    headers = {}

    payload = {
        "comment": comment,
        "updateTime": Timestamp().GetCurrentTime()
    }

    response = requests.put(
        BASE_URL + path,
        json=payload,
        headers=headers
    )

    assert response.status_code == 200
    return response.json()