import pytest
import requests

BASE_URL = "http://openapi.test"

def test_erc20_post():
    response = requests.post(f"{BASE_URL}/erc20")
    assert response.status_code == 200
    assert response.json() == {}