import pytest
import requests

BASE_URL = "http://openapi.test"

def test_put_bot_alias():
    url = f"{BASE_URL}/bots/botName/aliases/name"
    headers = {
        "X-Amz-Content-Sha256": "example-sha256",
        "X-Amz-Date": "example-date",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "example-credential",
        "X-Amz-Security-Token": "example-token",
        "X-Amz-Signature": "example-signature",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-algorithm;x-amz-credential;x-amz-security-token"
    }
    payload = {
        "botVersion": "$LATEST",
        "checksum": "example-checksum",
        "conversationLogs": {
            "iamRoleArn": "arn:aws:iam::123456789012:role/example-role",
            "logSettings": [
                {
                    "destination": "CLOUDWATCH_LOGS",
                    "kmsKeyArn": "arn:aws:kms:us-west-2:123456789012:key/12345678-1234-1234-1234-123456789012",
                    "logType": "AUDIO",
                    "resourceArn": "arn:aws:logs:us-west-2:123456789012:log-group:/aws/lambda/example-function"
                }
            ]
        },
        "description": "Example description",
        "tags": [
            {
                "key": "example-key",
                "value": "example-value"
            }
        ]
    }
    response = requests.put(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert "botName" in response.json()
    assert "botVersion" in response.json()
    assert "checksum" in response.json()
    assert "conversationLogs" in response.json()
    assert "createdDate" in response.json()
    assert "description" in response.json()
    assert "lastUpdatedDate" in response.json()
    assert "name" in response.json()
    assert "tags" in response.json()

if __name__ == "__main__":
    pytest.main()