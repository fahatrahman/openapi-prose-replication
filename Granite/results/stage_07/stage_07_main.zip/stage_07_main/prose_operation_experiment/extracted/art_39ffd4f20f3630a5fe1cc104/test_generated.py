import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"

# Set up service account credentials
credentials = service_account.Credentials.from_service_account_file(
    "path/to/your-service-account-file.json")

# Create an authenticated session
session = requests.Session()
session.auth = (credentials.service_account_email, credentials.id_token)
headers = {"accept": "application/json"}

@pytest.fixture
def list_rbac_role_bindings():
    """Fixture to list all Scope RBACRoleBindings."""

    def _list_rbac_role_bindings(parent):
        url = f"{BASE_URL}/{parent}/rbacrolebindings"
        params = {
            "pageSize": 10,
            "pageToken": None
        }
        response = requests.get(url, headers=headers, params=params, verify=False)

        if response.status_code == 200:
            return response.json()
        else:
            print(f"Error: {response.status_code} - {response.text}")
            return None

    return _list_rbac_role_bindings

def test_list_rbac_role_bindings(list_rbac_role_bindings):
    parent = "projects/my-project/locations/us-central1/scopes/my-scope"
    result = list_rbac_role_bindings(parent)
    assert isinstance(result, dict), "The response is not a valid JSON object"
    assert "rbacrolebindings" in result, "The response does not contain the expected list of RBACRoleBindings"