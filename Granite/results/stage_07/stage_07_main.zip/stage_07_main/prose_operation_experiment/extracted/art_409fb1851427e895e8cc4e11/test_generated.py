import os
import requests
import pytest
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retry logic
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["POST"],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

# Security headers
headers = {
    "Authorization": "AWS4-HMAC-SHA256 Credential={access_key}/{short_date}/{region}/s3/aws4_request, SignedHeaders=host;x-amz-content-sha256;x-amz-date, Signature={signature}"
}

@pytest.fixture
def detector_id():
    return "detector_id_example"

@pytest.fixture
def finding_types():
    return ["LOW", "MEDIUM", "HIGH"]

def create_sample_findings(detector_id, finding_types):
    endpoint = f"{BASE_URL}/detector/{detector_id}/findings/create"

    payload = {
        "findingTypes": finding_types
    }

    response = session.post(endpoint, json=payload, headers=headers)

    assert response.status_code == 200, f"Request failed with status code {response.status_code}: {response.text}"

    return response.json()

def test_create_sample_findings(detector_id, finding_types):
    result = create_sample_findings(detector_id, finding_types)
    assert isinstance(result, dict), "Expected a dictionary in the response."