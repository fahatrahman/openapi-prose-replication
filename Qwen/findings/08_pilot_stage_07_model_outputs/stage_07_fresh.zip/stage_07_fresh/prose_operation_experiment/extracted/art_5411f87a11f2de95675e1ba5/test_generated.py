import pytest
import requests

BASE_URL = "http://openapi.test"

def test_search_success():
    url = f"{BASE_URL}/v3/search/example"
    params = {
        "route_types": [0, 1],
        "latitude": 37.7749,
        "longitude": -122.4194,
        "max_distance": 5.0,
        "include_addresses": True,
        "include_outlets": False,
        "match_stop_by_suburb": True,
        "match_route_by_suburb": False,
        "match_stop_by_gtfs_stop_id": False,
        "token": "example_token",
        "devid": "example_devid",
        "signature": "example_signature"
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    assert "outlets" in response.json()
    assert "routes" in response.json()
    assert "stops" in response.json()

def test_search_bad_request():
    url = f"{BASE_URL}/v3/search/invalid"
    params = {}
    response = requests.get(url, params=params)
    assert response.status_code == 400
    assert "error" in response.json()["message"]

def test_search_forbidden():
    url = f"{BASE_URL}/v3/search/forbidden"
    params = {}
    response = requests.get(url, params=params)
    assert response.status_code == 403
    assert "error" in response.json()["message"]