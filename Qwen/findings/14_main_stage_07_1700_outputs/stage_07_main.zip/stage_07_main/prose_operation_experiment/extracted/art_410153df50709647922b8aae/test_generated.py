import pytest
import requests

BASE_URL = "http://openapi.test"

def test_directory_groups_get():
    url = f"{BASE_URL}/admin/directory/v1/groups/groupKey"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token",
        "alt": "json",
        "callback": "your_callback",
        "fields": "your_fields",
        "key": "your_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": True,
        "quotaUser": "your_quota_user",
        "upload_protocol": "your_upload_protocol",
        "uploadType": "your_upload_type",
        "groupKey": "your_groupKey"
    }
    headers = {
        "Authorization": "Bearer your_access_token"
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    assert "application/json" in response.headers["Content-Type"]
    group_data = response.json()
    assert isinstance(group_data, dict)
    assert "kind" in group_data
    assert group_data["kind"] == "admin#directory#group"