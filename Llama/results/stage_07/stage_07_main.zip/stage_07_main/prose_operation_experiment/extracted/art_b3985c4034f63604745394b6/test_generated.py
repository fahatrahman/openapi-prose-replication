# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_network_interfaces_list_virtual_machine_scale_set_vm_network_interfaces():
    api_version = "2016-09-01"
    resource_group_name = "myResourceGroup"
    virtual_machine_scale_set_name = "myScaleSet"
    virtual_machine_index = "0"
    subscription_id = "my_subscription_id"

    url = urljoin(BASE_URL, 
                  f"/subscriptions/{subscription_id}/resourceGroups/{resource_group_name}/providers/microsoft.Compute/virtualMachineScaleSets/{virtual_machine_scale_set_name}/virtualMachines/{virtual_machine_index}/networkInterfaces")
    headers = {"Authorization": "Bearer token", "Content-Type": "application/json"}
    params = {"api-version": api_version}

    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 200