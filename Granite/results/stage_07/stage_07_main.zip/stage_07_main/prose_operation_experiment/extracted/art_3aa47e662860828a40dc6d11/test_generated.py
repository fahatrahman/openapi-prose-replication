import os
import pytest
import requests
from google.oauth2 import error

BASE_URL = "http://openapi.test"

@pytest.fixture
def auth():
    try:
        credentials = os.environ["GOOGLE_APPLICATION_CREDENTIALS"]
        if not credentials:
            raise KeyError("Environment variable GOOGLE_APPLICATION_CREDENTIALS not set")
        else:
            return requests.auth.HTTPBasicAuth(
                credentials.split(":")[0], credentials.split(":")[1]
            )
    except KeyError:
        print("Authentication failed.")
        raise error.Unauthorized()

def test_create_configuration(auth):
    url = f"{BASE_URL}/v1/{os.environ['CUSTOMER_ID']}/configurations"
    headers = {"Content-Type": "application/json"}

    configuration = {
        "companyName": "Test Company",
        "configurationName": "Test Configuration",
        "contactEmail": "test@example.com",
        "contactPhone": "+1-555-123-4567",
        "dpcResourcePath": f"customers/{os.environ['CUSTOMER_ID']}/dpcs/*",
    }

    response = requests.post(url, headers=headers, json=configuration, auth=auth)

    assert response.status_code == 200
    assert response.json()["configurationName"] == configuration["configurationName"]