import pytest
import requests

BASE_URL = "http://openapi.test"

def test_add_text_broadcast_batch():
    url = f"{BASE_URL}/texts/broadcasts/{123}/batches"
    headers = {
        'Authorization': 'Basic dXNlcjpwYXNzd29yZA==',  # Replace with actual credentials
        'Content-Type': 'application/json'
    }
    payload = {
        "contactListId": 123,
        "name": "Test Batch",
        "recipients": [
            {
                "contactId": 456,
                "fromNumber": "1234567890",
                "phoneNumber": "12132000384"
            }
        ],
        "scrubDuplicates": False
    }
    params = {
        'strictValidation': True
    }

    response = requests.post(url, headers=headers, json=payload, params=params)

    assert response.status_code == 201
    assert 'id' in response.json()