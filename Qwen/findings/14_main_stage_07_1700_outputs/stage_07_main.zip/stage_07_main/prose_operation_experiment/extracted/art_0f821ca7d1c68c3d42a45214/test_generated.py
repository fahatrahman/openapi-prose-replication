import pytest
import requests

BASE_URL = "http://openapi.test"

def test_show_invoice_submission_evidence():
    guid = "example-guid"  # Replace with actual GUID
    url = f"{BASE_URL}/invoice_submissions/{guid}/evidence"
    headers = {
        "Authorization": "Bearer your_access_token"  # Replace with actual token
    }
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "actions" in data
    assert "guid" in data
    assert "status" in data
    
    actions = data["actions"]
    assert isinstance(actions, list)
    for action in actions:
        assert "receiver_response" in action
        assert "transmission_datetime" in action
        assert "transmission_result" in action
        assert "transmission_type" in action
        assert "transmitted_document" in action
        assert action["transmission_result"] in ["unknown", "accepted", "rejected", "send_error", "internal_error"]
        assert action["transmission_type"] in ["email", "edi", "as2", "peppol", "sandbox"]

if __name__ == "__main__":
    pytest.main()