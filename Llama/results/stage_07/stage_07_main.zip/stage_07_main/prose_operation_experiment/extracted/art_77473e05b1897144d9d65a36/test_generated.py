# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime
import hashlib
import hmac
import json

BASE_URL = "http://openapi.test"

def sign_request(method, path, payload=None):
    # Generate a date string
    amz_date = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")

    # Create a payload if none exists
    if payload is None:
        payload = {}

    # Sort and encode the parameters
    params = sorted(payload.items())
    encoded_params = "&".join(f"{key}={value}" for key, value in params)

    # Calculate the content SHA256 hash
    content_hash = hashlib.sha256(encoded_params.encode()).hexdigest()

    # Construct the signature
    algorithm = "AWS4-HMAC-SHA256"
    credential_scope = f"{amz_date}/aws4_request"
    signing_key = get_signing_key(algorithm, amz_date, "aws4_request", "us-east-1")
    signature = hmac.new(signing_key, (algorithm + "\n" + amz_date + "\n" + credential_scope + "\n" + content_hash).encode(), "sha256").hexdigest()

    return {
        "X-Amz-Algortithm": algorithm,
        "X-Amz-Content-Sha256": content_hash,
        "X-Amz-Credential": "your_aws_access_key_id/20190831/us-east-1/data-sets/aws4_request",
        "X-Amz-Date": amz_date,
        "X-Amz-Security-Token": "",
        "X-Amz-Signature": signature,
        "X-Amz-SignedHeaders": "host"
    }

def get_signing_key(algorithm, date, service, region):
    key_date = hmac.new(b"AWS4" + b"your_secret_access_key", date.encode(), "sha256").digest()
    key_region = hmac.new(key_date, region.encode(), "sha256").digest()
    key_service = hmac.new(key_region, service.encode(), "sha256").digest()
    return hmac.new(key_service, b"aws4_request".encode(), "sha256").digest()

def test_list_data_sets():
    headers = sign_request("GET", "/v1/data-sets")
    response = requests.get(BASE_URL + "/v1/data-sets", headers=headers)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert 'DataSets' in response.json() and 'NextToken' in response.json()

def test_list_data_sets_with_next_token():
    first_response = requests.get(BASE_URL + "/v1/data-sets")
    first_response.raise_for_status()
    data = first_response.json()
    headers = sign_request("GET", "/v1/data-sets", {"nextToken": data["NextToken"]})
    second_response = requests.get(BASE_URL + "/v1/data-sets", headers=headers)
    second_response.raise_for_status()
    data = second_response.json()
    assert 'DataSets' in data and 'NextToken' in data

if __name__ == "__main__":
    pytest.main([__file__])