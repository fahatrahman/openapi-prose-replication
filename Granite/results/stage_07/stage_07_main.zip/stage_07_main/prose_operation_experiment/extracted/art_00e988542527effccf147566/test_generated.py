import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.fixture
def certificate_site_seal():
    certificate_id = "your_certificate_id"
    theme = "LIGHT"
    locale = "en"

    url = f"{BASE_URL}/v1/certificates/{certificate_id}/siteSeal"

    try:
        response = SESSION.get(url, params={"theme": theme, "locale": locale})
        response.raise_for_status()
        return response.json()
    except requests.exceptions.HTTPError as errh:
        return {"error": f"HTTP Error: {errh}"}
    except Exception as err:
        return {"error": f"Something went wrong: {err}"}

def test_certificate_site_seal(certificate_site_seal):
    assert isinstance(certificate_site_seal, dict)
    assert "html" in certificate_site_seal