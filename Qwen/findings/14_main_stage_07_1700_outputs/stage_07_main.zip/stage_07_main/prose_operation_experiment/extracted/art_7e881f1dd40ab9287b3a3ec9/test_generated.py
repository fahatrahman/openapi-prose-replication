import pytest
import requests

BASE_URL = "http://openapi.test"

def test_upload_image():
    url = f"{BASE_URL}/v2/images"
    headers = {
        "Authorization": "Basic your_base64_encoded_credentials",
        "Content-Type": "application/json"
    }
    payload = {
        "base64_image": "your_base64_encoded_image_data"
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 201
    assert 'id' in response.json()

if __name__ == "__main__":
    pytest.main()