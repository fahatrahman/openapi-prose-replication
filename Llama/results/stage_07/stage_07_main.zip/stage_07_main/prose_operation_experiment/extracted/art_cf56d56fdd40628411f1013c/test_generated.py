# -*- coding: utf-8 -*-

import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

def test_get_photos():
    url = f"{BASE_URL}/v2/tier1/{'test_short_name'}/photo/photos"
    params = {"offset": 0, "count": 10}
    response = requests.get(url, params=params)
    assert response.status_code == 200
    response.raise_for_status()
    assert isinstance(response.json(), dict)

def test_get_photos_invalid_offset():
    url = f"{BASE_URL}/v2/tier1/{'test_short_name'}/photo/photos"
    params = {"offset": -1, "count": 10}
    response = requests.get(url, params=params)
    assert response.status_code == 400
    assert response.json()["error"]["message"].startswith("Offset")

def test_get_photos_invalid_count():
    url = f"{BASE_URL}/v2/tier1/{'test_short_name'}/photo/photos"
    params = {"offset": 0, "count": 10001}
    response = requests.get(url, params=params)
    assert response.status_code == 400
    assert response.json()["error"]["message"].startswith("Count")