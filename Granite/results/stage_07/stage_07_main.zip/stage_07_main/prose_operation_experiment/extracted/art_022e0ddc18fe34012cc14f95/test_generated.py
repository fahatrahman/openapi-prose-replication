import os
import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def client():
    return requests.Session()

def test_get_playlist_privacy_policies(client):
    url = f"{BASE_URL}/api/v1/video-playlists/privacities"
    response = client.get(url)
    assert response.status_code == 200

    data = response.json()["data"]["items"]
    expected_values = ["public", "unlisted", "private", "unlistable"]

    for item in data:
        assert item in expected_values