import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_3ds_availability():
    url = f"{BASE_URL}/get3dsAvailability"
    headers = {
        "Content-Type": "application/json",
        "X-API-Key": "your_api_key_here"
    }
    payload = {
        "cardNumber": "4111111111111111",
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT"
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 200
    assert response.json()["threeDS1Supported"] is True
    assert isinstance(response.json()["threeDS2CardRangeDetails"], list)
    assert isinstance(response.json()["dsPublicKeys"], list)
    assert response.json()["threeDS2supported"] is False

if __name__ == "__main__":
    pytest.main()