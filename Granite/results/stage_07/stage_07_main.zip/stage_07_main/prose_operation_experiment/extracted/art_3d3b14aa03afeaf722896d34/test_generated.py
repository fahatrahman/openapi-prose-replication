import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Configure retry strategy for requests
retries = Retry(
    total=5,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
adapter = HTTPAdapter(max_retries=retries)
http = requests.Session()
http.mount("https://", adapter)
http.mount("http://", adapter)

requests.models.Response.encoding = requests.models.Response.original_encoder

@pytest.fixture
def headers():
    return {
        "Authorization": f"Bearer {os.environ['DIGITALOCEAN_TOKEN']}"
    }

def test_list_associated_resources(http):
    cluster_id = "bd5f5959-5e1e-4205-a714-a914373942af"
    url = f"{BASE_URL}/v2/kubernetes/clusters/{cluster_id}/destroy_with_associated_resources"

    response = http.get(url, headers=headers)
    assert response.status_code == 200

    result = response.json()
    assert isinstance(result, dict)
    assert "load_balancers" in result
    assert "volume_snapshots" in result
    assert "volumes" in result
