import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup a session for retrying on failures
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def create_volume():
    headers = {"Content-Type": "application/json"}
    url = f"{BASE_URL}/volumes"

    volume_data = {
        "automount": False,
        "format": "xfs",
        "labels": {"labelkey": "value"},
        "location": "nbg1",
        "name": "test-database",
        "size": 42
    }

    response = session.post(url, json=volume_data, headers=headers)
    response.raise_for_status()
    
    return response.json()

def test_create_volume(create_volume):
    assert create_volume['volume']['status'] == 'available'
    assert create_volume['volume']['size'] == 42
    assert create_volume['volume']['name'] == 'test-database'