import pytest
import requests

BASE_URL = "http://openapi.test"

def test_analytics_management_profiles_get():
    url = f"{BASE_URL}/management/accounts/{pytest.account_id}/webproperties/{pytest.web_property_id}/profiles/{pytest.profile_id}"
    params = {
        "alt": "json",
        "fields": "id,name,websiteUrl",
        "key": pytest.api_key,
        "oauth_token": pytest.oauth_token,
        "prettyPrint": False,
        "quotaUser": "test_user",
        "userIp": "127.0.0.1"
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    profile = response.json()
    assert isinstance(profile, dict)
    assert "id" in profile
    assert "name" in profile
    assert "websiteUrl" in profile