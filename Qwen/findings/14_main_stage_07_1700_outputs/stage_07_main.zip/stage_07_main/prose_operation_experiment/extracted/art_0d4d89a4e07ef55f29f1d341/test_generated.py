import pytest
import requests

BASE_URL = "http://openapi.test"

def test_cancel_execution():
    url = f"{BASE_URL}/v2/zynntaco/{autfnhu}/yzvrewumc/{vmdixebo}/tdnx/{dfl}/arsechxhtw/{wfsfcxtia}:cancel"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "etag": "YOUR_ETAG",
        "validateOnly": False
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert response.json().get("name")
    assert response.json().get("metadata")

if __name__ == "__main__":
    pytest.main()