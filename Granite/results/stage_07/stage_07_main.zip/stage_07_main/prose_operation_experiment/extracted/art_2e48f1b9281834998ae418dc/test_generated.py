import os
import json
import requests
import pytest

BASE_URL = "http://openapi.test"
HEADERS = {"Content-Type": "application/json"}

@pytest.fixture
def org_options():
    return {
        "description": "All subdivisions of my company",
        "expiration_assets_offline": "365",
        "expiration_assets_stale": "365",
        "expiration_scans": "365",
        "export_token": "ETXXXXXXXXXXXXXXXX",
        "name": "My Organization",
        "parent_id": "e77602e0-3fb8-4734-aef9-fbc6fdcb0fa8",
        "project": False,
    }

def create_account_organization(org_options):
    url = f"{BASE_URL}/account/orgs"
    response = requests.put(url, headers=HEADERS, data=json.dumps(org_options))

    if response.status_code == 200:
        return response.json()
    elif response.status_code == 401:
        raise Exception("Access token is missing or invalid")
    elif response.status_code == 404:
        raise Exception("Resource not found")
    else:
        raise Exception(f"Unexpected status code: {response.status_code}")

def test_create_account_organization(org_options):
    try:
        result = create_account_organization(org_options)
        assert isinstance(result, dict)
        assert set(result.keys()) == {"asset_count", "client_id", "created_at", "deactivated_at", "description", "download_token", "download_token_created_at", "expiration_assets_offline", "expiration_assets_stale", "expiration_scans", "export_token", "export_token_counter", "export_token_created_at", "export_token_last_used_at", "export_token_last_used_by", "id", "inactive", "name", "parent_id", "permanent", "project", "service_count", "service_count_arp", "service_count_icmp", "service_count_tcp", "service_count_udp", "updated_at"}
    except Exception as e:
        pytest.fail(str(e))