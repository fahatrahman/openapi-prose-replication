# -*- coding: utf-8 -*-
"""Tests for Messaging V1 Brand Registration."""

import pytest
from requests import Session
from twilio.http.client import TwilioHttpClient
from twilio.rest import Client
from twilio.rest.api.v2010.account import Account

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def twilio_client():
    """Create a test client."""
    account_sid = "your_account_sid"
    auth_token = "your_auth_token"
    return Client(account_sid, auth_token)

@pytest.mark.parametrize(
    "twilio_client",
    ["test_twilio_client"],
    indirect=True,
)
class TestMessagingV1BrandRegistration:
    def test_list_brand_registrations(self, twilio_client):
        """Test listing brand registrations."""
        session = Session()
        session.proxies.update(TwilioHttpClient().proxies)
        response = session.get(f"{BASE_URL}/v1/a2p/BrandRegistrations", params={
            "PageSize": 10,
            "Page": 1,
            "PageToken": ""
        })
        assert response.status_code == 200
        assert response.json()["meta"]["first_page_url"].startswith(BASE_URL)
        assert response.json()["meta"]["next_page_url"] is None or response.json()["meta"]["next_page_url"].startswith(BASE_URL)
        assert response.json()["meta"]["previous_page_url"] is None or response.json()["meta"]["previous_page_url"].startswith(BASE_URL)
        assert response.json()["meta"]["url"].startswith(BASE_URL)
        assert isinstance(response.json()["data"], list)
        assert all(isinstance(item, dict) for item in response.json()["data"])