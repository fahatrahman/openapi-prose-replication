import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_model():
    url = f"{BASE_URL}/v3/projects/your-project/locations/us-central1/models"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "displayName": "My Translation Model",
        "sourceLanguageCode": "en-US",
        "targetLanguageCode": "es-MX"
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert "name" in response.json()
    assert "operation" in response.json()

if __name__ == "__main__":
    pytest.main([__file__])