import os
import pytest
import requests
from urllib3.exception import InsecureRequestWarning

os.environ['REQUESTS_CA_BUNDLE'] = None
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

BASE_URL = "http://openapi.test"

@pytest.fixture
def auth():
    # Implement your authentication logic here
    pass

def get_remarketing_tag(name, auth):
    url = f"{BASE_URL}/v1/{name}:getRemarketingTag"
    headers = {"Authorization": f"Bearer {auth}"}

    response = requests.get(url, headers=headers)
    response.raise_for_status()

    return response.json()["snippet"]

def test_get_remarketing_tag(auth):
    name = "buyers/123/userLists/456"
    snippet = get_remarketing_tag(name, auth)

    assert snippet is not None
    assert isinstance(snippet, str)