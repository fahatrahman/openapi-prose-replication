# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_tag_from_rti_transaction():
    employer_id = "GD001"
    rti_transaction_id = "LAR001"
    tag_id = "DpFoa"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }

    response = requests.get(
        f"{BASE_URL}/Employer/{employer_id}/RtiTransaction/{rti_transaction_id}/Tag/{tag_id}",
        headers=headers
    )

    assert response.status_code == 200, response.text
    assert response.json()["Tag"]["Text"], response.text

def test_get_tag_from_rti_transaction_400():
    employer_id = "GD001"
    rti_transaction_id = "LAR001"
    tag_id = "DpFoa"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }

    response = requests.get(
        f"{BASE_URL}/Employer/{employer_id}/RtiTransaction/{rti_transaction_id}/Tag/{tag_id}",
        headers=headers,
        params={"invalid_param": True}
    )

    assert response.status_code == 400, response.text
    error_model = response.json()
    assert error_model["ErrorCategory"] in ["General", "NotFound", "NotAuthorised", "ValidationFailure"], response.text
    assert len(error_model["Errors"]) > 0, response.text

def test_get_tag_from_rti_transaction_401():
    employer_id = "GD001"
    rti_transaction_id = "LAR001"
    tag_id = "DpFoa"
    headers = {
        "Authorization": "InvalidToken",
        "Api-Version": "default"
    }

    response = requests.get(
        f"{BASE_URL}/Employer/{employer_id}/RtiTransaction/{rti_transaction_id}/Tag/{tag_id}",
        headers=headers
    )

    assert response.status_code == 401, response.text
    error_model = response.json()
    assert error_model["ErrorCategory"] in ["General", "NotFound", "NotAuthorised", "ValidationFailure"], response.text
    assert len(error_model["Errors"]) > 0, response.text

def test_get_tag_from_rti_transaction_404():
    employer_id = "GD001"
    rti_transaction_id = "LAR001"
    tag_id = "InvalidTagId"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }

    response = requests.get(
        f"{BASE_URL}/Employer/{employer_id}/RtiTransaction/{rti_transaction_id}/Tag/{tag_id}",
        headers=headers
    )

    assert response.status_code == 404, response.text
    error_model = response.json()
    assert error_model["ErrorCategory"] in ["General", "NotFound", "NotAuthorised", "ValidationFailure"], response.text
    assert len(error_model["Errors"]) > 0, response.text

def test_get_tag_from_rti_transaction_500():
    employer_id = "GD001"
    rti_transaction_id = "LAR001"
    tag_id = "DpFoa"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }

    # Simulate server error by setting a timeout
    response = requests.get(
        f"{BASE_URL}/Employer/{employer_id}/RtiTransaction/{rti_transaction_id}/Tag/{tag_id}",
        headers=headers,
        timeout=0.00001
    )

    assert response.status_code == 500, response.text
    error_model = response.json()
    assert error_model["ErrorCategory"] in ["General", "NotFound", "NotAuthorised", "ValidationFailure"], response.text
    assert len(error_model["Errors"]) > 0, response.text