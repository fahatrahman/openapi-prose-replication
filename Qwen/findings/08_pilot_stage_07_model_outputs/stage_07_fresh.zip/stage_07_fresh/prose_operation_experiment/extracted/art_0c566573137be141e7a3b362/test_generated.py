import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_related_skills():
    skill_id = "test_skill_id"
    url = f"{BASE_URL}/skills/{skill_id}/related_skills"
    
    response = requests.get(url)
    
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert 'related_skill_name' in response.json()
    assert isinstance(response.json()['related_skill_name'], list)
    for item in response.json()['related_skill_name']:
        assert isinstance(item, dict)
        assert 'skill_name' in item
        assert isinstance(item['skill_name'], str)
        assert 'uuid' in item
        assert isinstance(item['uuid'], str)

def test_get_related_skills_error():
    invalid_skill_id = "invalid_skill_id"
    url = f"{BASE_URL}/skills/{invalid_skill_id}/related_skills"
    
    response = requests.get(url)
    
    assert response.status_code >= 400
    assert isinstance(response.json(), dict)
    assert 'code' in response.json()
    assert isinstance(response.json()['code'], int)
    assert 'message' in response.json()
    assert isinstance(response.json()['message'], str)