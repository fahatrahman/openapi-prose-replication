import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_datasets():
    url = f"{BASE_URL}/v2/vision/datasets"
    params = {
        "offset": "0",
        "count": "25",
        "global": False
    }
    headers = {
        "Authorization": "Bearer your_access_token_here"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert "data" in data
    assert isinstance(data["data"], list)
    for item in data["data"]:
        assert "id" in item
        assert "name" in item