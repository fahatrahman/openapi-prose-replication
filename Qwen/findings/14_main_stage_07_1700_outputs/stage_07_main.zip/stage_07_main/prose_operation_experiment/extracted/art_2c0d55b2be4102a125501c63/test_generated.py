import pytest
import requests

BASE_URL = "http://openapi.test"

def test_reimport_api():
    api_id = "your_api_id_here"
    openapi_definition = """
    {
        "swagger": "2.0",
        "info": {
            "title": "Test API",
            "version": "1.0.0"
        },
        "paths": {
            "/test": {
                "get": {
                    "responses": {
                        "200": {
                            "description": "OK"
                        }
                    }
                }
            }
        }
    }
    """

    headers = {
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Date": "20230401T000000Z",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "your_credential_here/20230401/us-east-1/apigateway/aws4_request",
        "X-Amz-Security-Token": "your_security_token_here",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-algorithm;x-amz-credential;x-amz-security-token"
    }

    params = {
        "basepath": "ignore",
        "failOnWarnings": False
    }

    response = requests.put(f"{BASE_URL}/v2/apis/{api_id}", json={"body": openapi_definition}, headers=headers, params=params)

    assert response.status_code == 201
    assert "apiEndpoint" in response.json()
    assert "apiGatewayManaged" in response.json()
    assert "apiId" in response.json()
    assert "apiKeySelectionExpression" in response.json()
    assert "corsConfiguration" in response.json()
    assert "createdDate" in response.json()
    assert "description" in response.json()
    assert "disableExecuteApiEndpoint" in response.json()
    assert "disableSchemaValidation" in response.json()
    assert "importInfo" in response.json()
    assert "name" in response.json()
    assert "protocolType" in response.json()
    assert "routeSelectionExpression" in response.json()
    assert "tags" in response.json()
    assert "version" in response.json()
    assert "warnings" in response.json()

if __name__ == "__main__":
    pytest.main([__file__])