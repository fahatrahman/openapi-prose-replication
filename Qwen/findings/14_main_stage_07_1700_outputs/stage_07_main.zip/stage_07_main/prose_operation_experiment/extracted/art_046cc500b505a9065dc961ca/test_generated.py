import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_perf_metrics_summary():
    url = f"{BASE_URL}/toolresults/v1beta3/projects/projectId/histories/historyId/executions/executionId/steps/stepId/perfMetricsSummary"
    headers = {
        "Content-Type": "application/json",
    }
    payload = {
        "appStartTime": {
            "fullyDrawnTime": {
                "seconds": "1234567890",
                "nanos": 123456789
            },
            "initialDisplayTime": {
                "seconds": "9876543210",
                "nanos": 987654321
            }
        },
        "executionId": "executionId",
        "historyId": "historyId",
        "perfEnvironment": {
            "cpuInfo": {
                "cpuProcessor": "processor",
                "cpuSpeedInGhz": 2.5,
                "numberOfCores": 4
            },
            "memoryInfo": {
                "memoryCapInKibibyte": 8192,
                "memoryTotalInKibibyte": 16384
            }
        },
        "perfMetrics": [
            "memory",
            "cpu",
            "network",
            "graphics"
        ],
        "projectId": "projectId",
        "stepId": "stepId"
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 200
    assert response.json()["executionId"] == "executionId"
    assert response.json()["historyId"] == "historyId"
    assert response.json()["projectId"] == "projectId"
    assert response.json()["stepId"] == "stepId"