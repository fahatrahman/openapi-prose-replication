import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_sample_data():
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20130302/us-east-1/ec2/aws4_request",
        "X-Amz-Date": "20130302T120000Z",
        "X-Amz-Security-Token": "AQoDYXdzEPT//////////wEaJHM+qibwbK3jQACzKUqCz5Wc8HxY9kpw6i45Gq0f0w==",
        "X-Amz-Signature": "f45b73e20bcb0b53c9edc16de1e2b20e200ec592a5eb0f67b006c8eaab8e715a",
        "X-Amz-SignedHeaders": "host"
    }
    payload = {
        "S3SourceConfig": {
            "FileFormatDescriptor": {},
            "HistoricalDataPathList": [],
            "RoleArn": "",
            "TemplatedPathList": []
        }
    }
    response = requests.post(f"{BASE_URL}/GetSampleData", json=payload, headers=headers)
    assert response.status_code == 200
    assert "HeaderValues" in response.json()
    assert "SampleRows" in response.json()

if __name__ == "__main__":
    pytest.main()