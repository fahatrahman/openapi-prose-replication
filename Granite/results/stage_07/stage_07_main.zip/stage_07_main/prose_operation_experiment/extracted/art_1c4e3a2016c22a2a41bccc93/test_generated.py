import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_PATH = "path/to/credentials.json"

# Authenticate using service account credentials
credentials = service_account.Credentials.from_service_account_file(
    CREDENTIALS_PATH, scopes=["https://www.googleapis.com/auth/cloud-platform"]
)

# Create authenticated session
session = requests.Session()
session.auth = (credentials.client_id, credentials.secret)

@pytest.fixture
def firewallepolicies_list():
    parent = "zynntaco/your_project_id"

    params = {
        "pageSize": 10,
        "pageToken": "some_page_token",
    }

    response = session.get(
        f"{BASE_URL}/v1/{parent}/firewallpolicies",
        params=params,
    )

    response.raise_for_status()

    return response.json()

def test_list_firewallepolicies(firewallepolicies_list):
    assert isinstance(firewallepolicies_list, dict)
    assert "firewallPolicies" in firewallepolicies_list
    assert isinstance(firewallepolicies_list["firewallPolicies"], list)