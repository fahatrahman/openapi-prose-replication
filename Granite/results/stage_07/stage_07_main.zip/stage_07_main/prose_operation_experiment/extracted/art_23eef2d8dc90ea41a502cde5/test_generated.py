import os
import hmac
import hashlib
import requests
import pytest
from datetime import datetime, timezone

BASE_URL = "http://openapi.test"
SERVICE_NAME = "your_service_name"  # Replace with actual service name
REGION = "your_region"  # Replace with actual region

def sign(message, secret):
    return hmac.new(secret.encode(), message.encode(), hashlib.sha256).hexdigest()

def get_authorization_header(access_key, secret, region, service, timestamp, payload_hash):
    string_to_sign = f"{SERVICE_NAME}\n{REGION}\n{timestamp}\n{payload_hash}"
    signature = sign(string_to_sign, secret)

    authorization_header = (
        f"AWS4-HMAC-SHA256 Credential={access_key}, SignedHeaders=host;x-amz-algorithm;x-amz-content-sha256;x-amz-date;x-amz-security-token;x-amz-signedheaders, Signature={signature}"
    )
    return authorization_header

@pytest.mark.parametrize("application_id", ["your_app_id"])  # Replace with actual application IDs
def test_list_application_versions(application_id):
    access_key = "your_access_key"  # Replace with actual access key
    secret_key = "your_secret_key"  # Replace with actual secret key

    url = f"{BASE_URL}/applications/{application_id}/versions"

    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": f"{access_key}:{secret_key}",
        "X-Amz-Date": datetime.utcnow().replace(tzinfo=timezone.utc).isoformat() + "Z",
    }

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        print("Test passed: ListApplicationVersions successful")
    else:
        print(f"Test failed: Received status code {response.status_code}")
        print(response.json())