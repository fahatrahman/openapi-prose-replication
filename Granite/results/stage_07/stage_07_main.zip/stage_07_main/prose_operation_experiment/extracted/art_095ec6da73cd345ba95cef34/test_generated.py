import os
import pytest
import requests
from googleapiclient.errors import HttpError

BASE_URL = "http://openapi.test"

@pytest.fixture
def auth_header():
    credentials = {"access_token": os.environ["GOOGLE_ACCESS_TOKEN"]}
    return {"Authorization": f"Bearer {credentials['access_token']}"}

def test_batch_delete_alerts(auth_header):
    endpoint = "/v1beta1/alerts:batchDelete"

    request_body = {
        "alertId": ["alert_id_1", "alert_id_2"],
        "customerId": "customer_id"
    }

    response = requests.post(
        url=f"{BASE_URL}{endpoint}",
        headers=auth_header,
        json=request_body
    )

    if response.status_code == 200:
        result = response.json()
        print("Successfully deleted alerts.")
        assert len(result["successAlertIds"]) > 0
    else:
        error = response.json()["error"]
        print(f"Error occurred: {error}")
        raise AssertionError(f"Failed to batch delete alerts: {error}")