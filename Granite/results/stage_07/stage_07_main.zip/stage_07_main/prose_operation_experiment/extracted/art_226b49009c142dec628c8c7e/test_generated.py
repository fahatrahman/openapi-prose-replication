import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.fixture
def header():
    return {"xero-tenant-id": os.getenv("XERO_TENANT_ID")}

def test_create_file_association(header):
    file_id = "4ff1e5cc-9835-40d5-bb18-09fdb118db9c"
    association_data = {
        "ObjectId": "1270bf7c-5d18-473a-9231-1e36c4bd33ed",
        "ObjectGroup": "Contact",
        "ObjectType": "Business",
    }

    response = SESSION.post(
        f"{BASE_URL}/Files/{file_id}/Associations", headers=header, json=association_data
    )

    assert response.status_code == 201
    assert response.json() == {
        "FileId": "6beccb4a-0d7d-4518-93f3-e0cd1dccb254",
        "ObjectId": "1270bf7c-5d18-473a-9231-1e36c4bd33ed",
        "ObjectType": "Business",
        "ObjectGroup": "Contact",
    }