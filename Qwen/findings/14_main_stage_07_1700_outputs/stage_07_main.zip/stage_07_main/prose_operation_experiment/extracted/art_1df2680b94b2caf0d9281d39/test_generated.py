import pytest
import requests

BASE_URL = "http://openapi.test"

def test_update_remarketing_list_share():
    profile_id = "test_profile_id"
    access_token = "test_access_token"
    remarketing_list_share_data = {
        "kind": "remarketingListShare#remarketingListShare",
        "remarketingListId": "123456789",
        "sharedAccountIds": ["987654321"],
        "sharedAdvertiserIds": ["111111111"]
    }
    
    headers = {
        "Authorization": f"Bearer {access_token}"
    }
    
    response = requests.put(
        f"{BASE_URL}/userprofiles/{profile_id}/remarketingListShares",
        json=remarketing_list_share_data,
        headers=headers
    )
    
    assert response.status_code == 200
    assert response.json()["kind"] == "remarketingListShare#remarketingListShare"
    assert response.json()["remarketingListId"] == "123456789"
    assert response.json()["sharedAccountIds"] == ["987654321"]
    assert response.json()["sharedAdvertiserIds"] == ["111111111"]

if __name__ == "__main__":
    pytest.main()