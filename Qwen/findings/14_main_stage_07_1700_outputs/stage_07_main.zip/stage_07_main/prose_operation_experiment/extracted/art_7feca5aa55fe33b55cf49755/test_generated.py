import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_transaction_category():
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    params = {
        "companyId": "8a210b68-6988-11ed-a1eb-0242ac120002",
        "connectionId": "2e9d2c44-f675-40ba-8049-353bfcb5e171",
        "transactionCategoryId": "auto-and-transport"
    }
    response = requests.get(f"{BASE_URL}/companies/{params['companyId']}/connections/{params['connectionId']}/data/banking-transactionCategories/{params['transactionCategoryId']}", headers=headers)
    assert response.status_code == 200
    assert 'application/json' in response.headers['Content-Type']
    transaction_category = response.json()
    assert isinstance(transaction_category, dict)
    assert 'id' in transaction_category
    assert 'name' in transaction_category
    assert 'status' in transaction_category
    assert 'modifiedDate' in transaction_category
    assert 'sourceModifiedDate' in transaction_category
    assert 'hasChildren' in transaction_category
    assert 'parentId' in transaction_category