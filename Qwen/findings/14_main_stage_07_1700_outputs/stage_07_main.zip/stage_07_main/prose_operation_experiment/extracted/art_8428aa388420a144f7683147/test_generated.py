import pytest
import requests

BASE_URL = "http://openapi.test"

def test_forms_watches_create():
    url = f"{BASE_URL}/v1/forms/formId/watches"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "createWatchRequest": {
            "watch": {
                "target": {
                    "topic": {
                        "topicName": "YOUR_TOPIC_NAME"
                    }
                },
                "watchId": "YOUR_WATCH_ID"
            }
        }
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert "watch" in response.json()