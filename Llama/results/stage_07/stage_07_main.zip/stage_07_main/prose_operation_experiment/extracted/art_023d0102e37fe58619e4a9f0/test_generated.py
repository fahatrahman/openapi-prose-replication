# -*- coding: utf-8 -*-
"""Tests for the ListAdaptiveMtFiles endpoint."""
import json
from pathlib import Path
import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_adaptive_mt_files():
    """Test the ListAdaptiveMtFiles endpoint."""
    url = f"{BASE_URL}/v3/projects/12345/locations/default/adaptiveMtDatasets/default/adaptiveMtFiles"
    params = {"key": "your_api_key", "pageSize": 100}
    headers = {"Content-Type": "application/json"}

    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200

    data = json.loads(response.text)
    assert isinstance(data, dict)
    assert 'adaptiveMtFiles' in data
    assert 'nextPageToken' in data

if __name__ == "__main__":
    pytest.main([Path(__file__).name])