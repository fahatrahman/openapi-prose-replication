import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_call_broadcast_batches():
    url = f"{BASE_URL}/calls/broadcasts/123456789/batches"
    params = {
        "fields": "id,name,status",
        "limit": 5,
        "offset": 0
    }
    headers = {
        "Authorization": "Basic dGVzdDpwYXNzd29yZA=="  # Example basic auth credentials
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 200
    data = response.json()
    assert "items" in data
    assert isinstance(data["items"], list)
    for batch in data["items"]:
        assert "id" in batch
        assert "name" in batch
        assert "status" in batch
        assert batch["status"] in ["NEW", "VALIDATING", "ERRORS", "SOURCE_ERROR", "ACTIVE"]

def test_get_call_broadcast_batches_with_invalid_id():
    url = f"{BASE_URL}/calls/broadcasts/invalid/batches"
    params = {
        "fields": "id,name,status",
        "limit": 5,
        "offset": 0
    }
    headers = {
        "Authorization": "Basic dGVzdDpwYXNzd29yZA=="  # Example basic auth credentials
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 404

def test_get_call_broadcast_batches_with_unauthorized_request():
    url = f"{BASE_URL}/calls/broadcasts/123456789/batches"
    params = {
        "fields": "id,name,status",
        "limit": 5,
        "offset": 0
    }
    headers = {
        "Authorization": "Basic invalid_credentials"  # Invalid basic auth credentials
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 401