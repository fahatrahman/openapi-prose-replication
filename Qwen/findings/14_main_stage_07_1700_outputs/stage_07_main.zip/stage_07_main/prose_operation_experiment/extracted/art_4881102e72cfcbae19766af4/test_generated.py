import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_payees_invitation_status_v4():
    url = f"{BASE_URL}/v4/payees/payors/9ac75325-5dcd-42d5-b992-175d7e0a035e"
    params = {
        "payeeId": "2aa5d7e0-2ecb-403f-8494-1865ed0454e9",
        "invitationStatus": "ACCEPTED",
        "page": 1,
        "pageSize": 25
    }
    headers = {
        "Authorization": "Bearer ed73aa9a-b51b-44cb-a8e9-11e2fb85046b"
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "page" in response.json()
    assert "content" in response.json()

    page = response.json()["page"]
    assert isinstance(page, dict)
    assert "numberOfElements" in page
    assert "page" in page
    assert "pageSize" in page
    assert "totalElements" in page
    assert "totalPages" in page

    content = response.json()["content"]
    assert isinstance(content, list)
    for item in content:
        assert "payeeId" in item
        assert isinstance(item["payeeId"], str)
        assert "invitationStatus" in item
        assert isinstance(item["invitationStatus"], str)
        assert "gracePeriodEndDate" in item
        assert isinstance(item["gracePeriodEndDate"], str)

    links = response.json().get("links", [])
    assert isinstance(links, list)
    for link in links:
        assert "href" in link
        assert isinstance(link["href"], str)
        assert "rel" in link
        assert isinstance(link["rel"], str)