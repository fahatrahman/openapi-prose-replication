import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_voucher():
    url = f"{BASE_URL}/api/v2/Vouchers"
    payload = {
        "DealerCode": "test_dealer",
        "Email": "test@example.com",
        "Type": "Commercial",
        "VoucherCode": "TEST1234"
    }
    headers = {
        "Content-Type": "application/json"
    }
    response = requests.post(url, json=payload, headers=headers)
    assert response.status_code == 200
    assert isinstance(response.json(), str)

if __name__ == "__main__":
    pytest.main()