# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime
import json
import hashlib
import hmac
import base64

BASE_URL = "http://openapi.test"

def get_current_date():
    return datetime.now().strftime("%Y%m%dT%H%M%SZ")

def sign_request(method, url, secret_key):
    date = get_current_date()
    message = f"{method}\n{date}\n/{url.split(BASE_URL)[1]}"
    signing_key = f"AWS4-HMAC-SHA256 Credential={secret_key}, SignedHeaders=host;x-amz-date, Signature="
    digest = hmac.new(secret_key.encode(), message.encode(), hashlib.sha256).digest()
    signature = base64.b64encode(digest).decode()
    return signing_key + signature

def create_workflow_step(name, stepGroupId, workflowId, stepActionType, description=""):
    headers = {
        'X-Amz-Algorithm': 'AWS4-HMAC-SHA256',
        'X-Amz-Content-Sha256': hashlib.sha256(json.dumps({
            "name": name,
            "stepGroupId": stepGroupId,
            "workflowId": workflowId,
            "stepActionType": stepActionType,
            "description": description
        }).encode()).hexdigest(),
        'X-Amz-Date': get_current_date(),
        'X-Amz-Credential': 'YOUR_AWS_CREDENTIAL',
        'X-Amz-Security-Token': '',
        'X-Amz-SignedHeaders': 'host;x-amz-date',
        'X-Amz-Signature': sign_request('POST', '/workflowstep', 'YOUR_AWS_SECRET_KEY')
    }
    response = requests.post(f'{BASE_URL}/workflowstep', headers=headers, json={
        "name": name,
        "stepGroupId": stepGroupId,
        "workflowId": workflowId,
        "stepActionType": stepActionType,
        "description": description
    })
    assert response.status_code == 200
    response.raise_for_status()

@pytest.mark.parametrize("name, stepGroupId, workflowId, stepActionType", [
    ("test-step", "step-group-id", "workflow-id", "MANUAL"),
])
def test_create_workflow_step(name, stepGroupId, workflowId, stepActionType):
    create_workflow_step(name, stepGroupId, workflowId, stepActionType)