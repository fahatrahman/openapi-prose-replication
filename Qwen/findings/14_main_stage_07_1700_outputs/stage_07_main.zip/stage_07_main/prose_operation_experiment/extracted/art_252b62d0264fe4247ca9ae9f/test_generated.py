import pytest
import requests

BASE_URL = "http://openapi.test"

def test_erc20_post():
    url = f"{BASE_URL}/erc20"
    payload = {}
    headers = {
        'Content-Type': 'application/json'
    }
    response = requests.post(url, json=payload, headers=headers)
    assert response.status_code == 200
    assert response.json() == {}