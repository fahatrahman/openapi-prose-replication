import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retry mechanism for handling transient errors
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["HEAD", "GET", "OPTIONS", "PUT", "PATCH"],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def google_search_ideahub_v1alpha():
    """Fixture for Google Search Ideahub V1ALPHA operations"""

    def _google_search_ideahub_v1alpha(
        name, update_mask="": str
    ) -> dict:
        url = f"{BASE_URL}/v1alpha/{name}"

        headers = {}
        if os.getenv("GOOGLE_APPLICATION_CREDENTIALS"):
            headers["Authorization"] = f"Bearer {os.getenv('GOOGLE_APPLICATION_CREDENTIALS')}"

        payload = {
            "dismissed": False,
            "name": name,
            "saved": False,
        }

        response = session.patch(
            url, json=payload, headers=headers, params={"updateMask": update_mask}
        )
        response.raise_for_status()

        return response.json()

    yield _google_search_ideahub_v1alpha