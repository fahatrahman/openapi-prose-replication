import pytest
import requests

BASE_URL = "http://openapi.test"

def test_certificate_site_seal():
    url = f"{BASE_URL}/v1/certificates/{pytest.certificate_id}/siteSeal"
    params = {
        "theme": "LIGHT",
        "locale": "en"
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 200
    assert 'html' in response.json()

def test_certificate_site_seal_invalid_theme():
    url = f"{BASE_URL}/v1/certificates/{pytest.certificate_id}/siteSeal"
    params = {
        "theme": "INVALID",
        "locale": "en"
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 422
    assert 'error' in response.json()

def test_certificate_site_seal_missing_credential():
    url = f"{BASE_URL}/v1/certificates/{pytest.certificate_id}/siteSeal"
    params = {
        "theme": "LIGHT",
        "locale": "en"
    }
    response = requests.get(url, headers={"Authorization": ""}, params=params)
    
    assert response.status_code == 401
    assert 'error' in response.json()

def test_certificate_site_seal_forbidden_access():
    url = f"{BASE_URL}/v1/certificates/{pytest.certificate_id}/siteSeal"
    params = {
        "theme": "LIGHT",
        "locale": "en"
    }
    response = requests.get(url, headers={"Authorization": "Bearer invalid_token"}, params=params)
    
    assert response.status_code == 403
    assert 'error' in response.json()

def test_certificate_site_seal_not_found():
    url = f"{BASE_URL}/v1/certificates/nonexistent/siteSeal"
    params = {
        "theme": "LIGHT",
        "locale": "en"
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 404
    assert 'error' in response.json()

def test_certificate_site_seal_invalid_locale():
    url = f"{BASE_URL}/v1/certificates/{pytest.certificate_id}/siteSeal"
    params = {
        "theme": "LIGHT",
        "locale": "invalid_locale"
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 422
    assert 'error' in response.json()