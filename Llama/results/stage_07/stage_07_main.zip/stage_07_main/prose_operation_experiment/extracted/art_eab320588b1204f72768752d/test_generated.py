# pylint: disable=invalid-name
import pytest
from requests.auth import HTTPBasicAuth
import requests

BASE_URL = "http://openapi.test"

def get_resources(userId=None, collectionType=None, limit=None, marker=None):
    """Test GetResources endpoint."""
    headers = {
        'X-Amz-Algorithm': '',
        'X-Amz-Content-Sha256': '',
        'X-Amz-Credential': '',
        'X-Amz-Date': '',
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': '',
        'X-Amz-SignedHeaders': '',
        'Authentication': ''
    }
    params = {}
    if userId:
        params['userId'] = userId
    if collectionType:
        params['collectionType'] = collectionType
    if limit:
        params['limit'] = limit
    if marker:
        params['marker'] = marker

    response = requests.get(f"{BASE_URL}/api/v1/resources", headers=headers, params=params, auth=HTTPBasicAuth('', ''))

    assert response.status_code == 200, f"Unexpected status code {response.status_code}"
    return response.json()

@pytest.mark.asyncio
async def test_get_resources():
    """Test GetResources endpoint."""
    result = await get_resources()
    assert result is not None
    assert result['Documents'] is not None
    assert result['Folders'] is not None
    assert result['Marker'] is not None

def test_get_resources_invalid_user_id():
    """Test GetResources endpoint with invalid user id."""
    result = get_resources('invalid-user-id')
    assert result.status_code == 480

def test_get_resources_invalid_collection_type():
    """Test GetResources endpoint with invalid collection type."""
    result = get_resources(collectionType='invalid-collection-type')
    assert result.status_code == 480

def test_get_resources_invalid_limit():
    """Test GetResources endpoint with invalid limit."""
    result = get_resources(limit=-1)
    assert result.status_code == 480

def test_get_resources_invalid_marker():
    """Test GetResources endpoint with invalid marker."""
    result = get_resources(marker='invalid-marker')
    assert result.status_code == 480