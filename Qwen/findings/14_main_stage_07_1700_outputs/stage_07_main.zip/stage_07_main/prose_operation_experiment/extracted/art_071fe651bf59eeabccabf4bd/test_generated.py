import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_resources():
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20130524/us-east-1/ec2/aws4_request",
        "X-Amz-Date": "20130524T000000Z",
        "X-Amz-Security-Token": "AQoDYXdzEPT//////////wEXAMPLEtc7rz7MdY6EGOijDqoyi5huNcVS46brZEJ2QhmUO0dBJeH49ldwtYTM4QL44S8Fe94CGcsMU0Uwu1kZlrDA5cfxOJ6B9cSRPyF5wBAICmbCB0KAkjURCp9zl8qkIxNq8pZL4izdwmtXTQheQgjgCeb94I7Zv7RpCvw2WSSbwbneJi6Aic4Az9AHwf8zX7RZ6YHdnBVtW7SsPAoC0q5yB4/JMcb94yqeFzbxjsrcPhgBvmbXwPpJZQMYRrpzjnMuVMbTPwJ1QFzUXqVZ85paNBmtfrgGyDa/VCCm3I38dzF/zPQ6387tW0p2ld5Kb5t91SO71hgk5pdy64IbSYsdgfeKq980wVRY1w==",
        "X-Amz-Signature": "b6a195972afda975226074631ad683a8f606b41c63f7db7a585eddd8d1a9a1d9",
        "X-Amz-SignedHeaders": "host"
    }
    params = {
        "userId": "exampleUser",
        "collectionType": "SHARED_WITH_ME",
        "limit": 1,
        "marker": "exampleMarker"
    }
    response = requests.get(f"{BASE_URL}/api/v1/resources", headers=headers, params=params)
    
    assert response.status_code == 200
    assert "Documents" in response.json()
    assert "Folders" in response.json()

@pytest.mark.parametrize("status_code, expected_exception", [
    (480, "UnauthorizedResourceAccessException"),
    (481, "UnauthorizedOperationException"),
    (482, "InvalidArgumentException"),
    (483, "FailedDependencyException"),
    (484, "ServiceUnavailableException")
])
def test_error_responses(status_code, expected_exception):
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20130524/us-east-1/ec2/aws4_request",
        "X-Amz-Date": "20130524T000000Z",
        "X-Amz-Security-Token": "AQoDYXdzEPT//////////wEXAMPLEtc7rz7MdY6EGOijDqoyi5huNcVS46brZEJ2QhmUO0dBJeH49ldwtYTM4QL44S8Fe94CGcsMU0Uwu1kZlrDA5cfxOJ6B9cSRPyF5wBAICmbCB0KAkjURCp9zl8qkIxNq8pZL4izdwmtXTQheQgjgCeb94I7Zv7RpCvw2WSSbwbneJi6Aic4Az9AHwf8zX7RZ6YHdnBVtW7SsPAoC0q5yB4/JMcb94yqeFzbxjsrcPhgBvmbXwPpJZQMYRrpzjnMuVMbTPwJ1QFzUXqVZ85paNBmtfrgGyDa/VCCm3I38dzF/zPQ6387tW0p2ld5Kb5t91SO71hgk5pdy64IbSYsdgfeKq980wVRY1w==",
        "X-Amz-Signature": "b6a195972afda975226074631ad683a8f606b41c63f7db7a585eddd8d1a9a1d9",
        "X-Amz-SignedHeaders": "host"
    }
    params = {
        "userId": "exampleUser",
        "collectionType": "SHARED_WITH_ME",
        "limit": 1,
        "marker": "exampleMarker"
    }
    response = requests.get(f"{BASE_URL}/api/v1/resources", headers=headers, params=params)
    
    assert response.status_code == status_code
    assert expected_exception in str(response.text)
