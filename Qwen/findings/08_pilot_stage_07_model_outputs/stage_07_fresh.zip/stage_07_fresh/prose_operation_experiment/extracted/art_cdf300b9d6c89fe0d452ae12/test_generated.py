import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_txs():
    params = {
        "address": "example_address",
        "block": "example_block",
        "pageNum": 1
    }
    response = requests.get(f"{BASE_URL}/ins/txs", params=params)
    assert response.status_code == 200
    data = response.json()
    assert "pagesTotal" in data
    assert "txs" in data
    for tx in data["txs"]:
        assert "blockhash" in tx
        assert "blockheight" in tx
        assert "blocktime" in tx
        assert "confirmations" in tx
        assert "fee" in tx
        assert "fees" in tx
        assert "locktime" in tx
        assert "size" in tx
        assert "time" in tx
        assert "totalsent" in tx
        assert "txid" in tx
        assert "valueIn" in tx
        assert "valueOut" in tx
        assert "version" in tx
        assert "vin" in tx
        assert "vout" in tx
        for vin in tx["vin"]:
            assert "n" in vin
            assert "scriptSig" in vin
            assert "sequence" in vin
            assert "txid" in vin
            assert "value" in vin
            assert "valueSat" in vin
            assert "vout" in vin
        for vout in tx["vout"]:
            assert "blockheight" in vout
            assert "n" in vout
            assert "scriptPubKey" in vout
            assert "used" in vout
            if vout["used"]:
                assert "usedBlockheight" in vout
                assert "usedTxid" in vout
            assert "value" in vout