import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_employee_secrets():
    url = f"{BASE_URL}/Employer/ER001/Employee/EE001/Secrets"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert "application/json" in response.headers["Content-Type"]
    assert isinstance(response.json(), dict)

def test_get_employee_secrets_400():
    url = f"{BASE_URL}/Employer/ER001/Employee/EE001/Secrets"
    headers = {
        "Authorization": "Invalid",
        "Api-Version": "default"
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 400
    assert "application/json" in response.headers["Content-Type"]
    assert isinstance(response.json(), dict)

def test_get_employee_secrets_401():
    url = f"{BASE_URL}/Employer/ER001/Employee/EE001/Secrets"
    headers = {
        "Authorization": "",
        "Api-Version": "default"
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 401
    assert "application/json" in response.headers["Content-Type"]
    assert isinstance(response.json(), dict)

def test_get_employee_secrets_404():
    url = f"{BASE_URL}/Employer/ER001/Employee/NonExistent/Secrets"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 404
    assert "application/json" in response.headers["Content-Type"]
    assert isinstance(response.json(), dict)

def test_get_employee_secrets_500():
    url = f"{BASE_URL}/Employer/ER001/Employee/EE001/Secrets"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "broken"
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 500
    assert "application/json" in response.headers["Content-Type"]
    assert isinstance(response.json(), dict)