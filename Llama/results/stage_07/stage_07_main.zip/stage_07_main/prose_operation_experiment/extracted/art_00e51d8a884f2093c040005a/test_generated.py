import pytest
import requests

BASE_URL = "http://openapi.test"

def test_dataplex_projects_locations_lakes_content_list():
    url = f"{BASE_URL}/v1/{'zynntaco/{autfnhu_lg}/yzvrewumc/{vmdixebo_lg}/wkxgf/{orga_lg}'}/content"
    headers = {"accept": "application/json"}
    params = {
        "filter": "svtwq1",
        "pageSize": 10,
        "pageToken": ""
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    response.raise_for_status()
    data = response.json()
    assert isinstance(data, dict)
    assert "content" in data
    assert isinstance(data["content"], list)
    assert len(data["content"]) > 0
    content_item = data["content"][0]
    assert isinstance(content_item, dict)
    assert "name" in content_item
    assert isinstance(content_item["name"], str)
    assert "description" in content_item
    assert isinstance(content_item["description"], str)

if __name__ == "__main__":
    pytest.main([__file__])