import os
import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

@pytest.fixture
def auth_result():
    url = f"{BASE_URL}/auth"
    response = requests.get(url, auth=HTTPBasicAuth("username", "password"))
    response.raise_for_status()

    result = response.json()
    assert "accessToken" in result
    assert "registrierkasseUuid" in result

    return result