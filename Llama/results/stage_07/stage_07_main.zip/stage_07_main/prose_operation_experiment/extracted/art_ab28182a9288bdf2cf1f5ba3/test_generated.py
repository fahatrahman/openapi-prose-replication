# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_service():
    url = f"{BASE_URL}/v1/Services"
    params = {
        "FriendlyName": "",
        "PageSize": 10,
        "Page": 0,
        "PageToken": ""
    }
    
    response = requests.get(url, params=params)
    assert response.status_code == 200
    
    data = response.json()
    assert 'services' in data
    assert len(data['services']) > 0
    for service in data['services']:
        required_properties = ["sid", "friendly_name", "date_created"]
        for prop in required_properties:
            assert prop in service
        
def test_list_service_with_friendly_name():
    url = f"{BASE_URL}/v1/Services"
    params = {
        "FriendlyName": "test",
        "PageSize": 10,
        "Page": 0,
        "PageToken": ""
    }
    
    response = requests.get(url, params=params)
    assert response.status_code == 200
    
    data = response.json()
    assert 'services' in data
    assert len(data['services']) > 0
    for service in data['services']:
        if service['friendly_name'] == "test":
            required_properties = ["sid", "friendly_name", "date_created"]
            for prop in required_properties:
                assert prop in service
            
def test_list_service_invalid_page_size():
    url = f"{BASE_URL}/v1/Services"
    params = {
        "FriendlyName": "",
        "PageSize": 1500,
        "Page": 0,
        "PageToken": ""
    }
    
    response = requests.get(url, params=params)
    assert response.status_code != 200

def test_list_service_invalid_page_token():
    url = f"{BASE_URL}/v1/Services"
    params = {
        "FriendlyName": "",
        "PageSize": 10,
        "Page": -1,
        "PageToken": "invalid"
    }
    
    response = requests.get(url, params=params)
    assert response.status_code != 200

def test_list_service_without_params():
    url = f"{BASE_URL}/v1/Services"
    params = {}
    
    response = requests.get(url, params=params)
    assert response.status_code == 200
    
    data = response.json()
    assert 'services' in data
    assert len(data['services']) > 0
    for service in data['services']:
        required_properties = ["sid", "friendly_name", "date_created"]
        for prop in required_properties:
            assert prop in service