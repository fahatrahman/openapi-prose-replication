import pytest
import requests

BASE_URL = "http://openapi.test"

def test_regions_list():
    url = f"{BASE_URL}/userprofiles/{profileId}/regions"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token",
        "alt": "json",
        "callback": "your_callback",
        "fields": "your_fields",
        "key": "your_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": False,
        "quotaUser": "your_quota_user",
        "uploadType": "multipart",
        "upload_protocol": "raw"
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    assert response.json()["kind"] == "ttjzyodfuopc#regions#list"