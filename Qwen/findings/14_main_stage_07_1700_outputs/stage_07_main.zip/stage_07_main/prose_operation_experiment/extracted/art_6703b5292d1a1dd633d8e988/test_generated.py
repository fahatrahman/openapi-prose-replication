import pytest
import requests

BASE_URL = "http://openapi.test"

def test_risk_address():
    url = f"{BASE_URL}/risk/address"
    params = {
        "chain": "ETH",
        "address": "test_address",
        "include_exposure": False,
        "X-API-KEY": "your_api_key_here"
    }
    response = requests.get(url, headers=params)
    
    assert response.status_code == 200
    data = response.json()
    assert "closest_incoming_exposure" in data
    assert "closest_outgoing_exposure" in data
    assert "entity_tags" in data
    assert "risk_score" in data

def test_unauthorized_access():
    url = f"{BASE_URL}/risk/address"
    params = {
        "chain": "ETH",
        "address": "test_address",
        "include_exposure": False,
        "X-API-KEY": "invalid_api_key"
    }
    response = requests.get(url, headers=params)
    
    assert response.status_code == 401
    data = response.json()
    assert "error" in data
    assert "status" in data
    assert data["status"] == 401

def test_invalid_chain_value():
    url = f"{BASE_URL}/risk/address"
    params = {
        "chain": "INVALID_CHAIN",
        "address": "test_address",
        "include_exposure": False,
        "X-API-KEY": "your_api_key_here"
    }
    response = requests.get(url, headers=params)
    
    assert response.status_code == 422
    data = response.json()
    assert "error" in data
    assert "status" in data
    assert data["status"] == 422