import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_areas():
    short_name = "test_short_name"
    offset = 0
    count = 10

    url = f"{BASE_URL}/v2/tier1/{short_name}/area/areas"
    params = {
        "offset": offset,
        "count": count
    }

    response = requests.get(url, params=params)

    assert response.status_code == 200
    assert response.headers["Content-Type"].startswith("application/json")
    data = response.json()
    assert isinstance(data, dict)
    assert "Count" in data
    assert "Data" in data
    assert isinstance(data["Count"], int)
    assert isinstance(data["Data"], list)
    for item in data["Data"]:
        assert isinstance(item, dict)
        assert "Branch" in item
        assert "ETag" in item
        assert "Name" in item
        assert "OID" in item
        assert "ShowOnSites" in item
        assert isinstance(item["Branch"], str)
        assert isinstance(item["ETag"], str)
        assert isinstance(item["Name"], str)
        assert isinstance(item["OID"], str)
        assert isinstance(item["ShowOnSites"], bool)