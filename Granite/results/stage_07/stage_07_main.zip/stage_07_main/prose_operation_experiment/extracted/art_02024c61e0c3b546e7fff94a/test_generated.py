import os
import pytest
import requests
from datetime import datetime
from datetime import timezone
from svix.client import Client
from svix.models import RecoverIn

BASE_URL = "http://openapi.test"

def test_recover_failed_webhooks():
    # Setup
    app_id = "app_1srOrx2ZWZBpBUvZwXKQmoEYga2"
    endpoint_id = "ep_1srOrx2ZWZBpBUvZwXKQmoEYga2"
    idempotency_key = None

    # Create client instance
    client = Client("AUTH_TOKEN", base_url=BASE_URL)

    # Prepare request body
    recover_in = RecoverIn(
        since=datetime(2019, 8, 24, 14, 15, 22, tzinfo=timezone.utc),
        until=datetime(2019, 8, 24, 14, 15, 22, tzinfo=timezone.utc),
    )

    # Send POST request
    response = client.endpoint.recover(
        app_id,
        endpoint_id,
        recover_in,
        idempotency_key=idempotency_key,
    )

    # Assertions
    assert response.status_code == 202
    # Add more assertions based on the expected output schema