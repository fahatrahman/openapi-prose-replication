import pytest
import requests

BASE_URL = "http://openapi.test"

def test_memberships_active():
    headers = {
        "Ocp-Apim-Subscription-Key": "your_subscription_key"
    }
    params = {
        "key": "your_api_key"
    }
    response = requests.get(f"{BASE_URL}/xml/ActiveMemberships", headers=headers, params=params)
    assert response.status_code == 200
    assert isinstance(response.json(), list)
    for item in response.json():
        assert isinstance(item, dict)
        assert "Active" in item
        assert isinstance(item["Active"], bool)
        assert "EndDate" in item
        if item["EndDate"] is not None:
            assert isinstance(item["EndDate"], str)
        assert "Jersey" in item
        if item["Jersey"] is not None:
            assert isinstance(item["Jersey"], int)
        assert "MembershipId" in item
        assert isinstance(item["MembershipId"], int)
        assert "PlayerId" in item
        assert isinstance(item["PlayerId"], int)
        assert "PlayerName" in item
        if item["PlayerName"] is not None:
            assert isinstance(item["PlayerName"], str)
        assert "StartDate" in item
        if item["StartDate"] is not None:
            assert isinstance(item["StartDate"], str)
        assert "TeamArea" in item
        if item["TeamArea"] is not None:
            assert isinstance(item["TeamArea"], str)
        assert "TeamId" in item
        assert isinstance(item["TeamId"], int)
        assert "TeamName" in item
        if item["TeamName"] is not None:
            assert isinstance(item["TeamName"], str)
        assert "Updated" in item
        if item["Updated"] is not None:
            assert isinstance(item["Updated"], str)

if __name__ == "__main__":
    pytest.main()