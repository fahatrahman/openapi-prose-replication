import pytest
import requests
import json
BASE_URL = "http://openapi.test"

def test_add_text_broadcast_batch():
    url = f"{BASE_URL}/texts/broadcasts/1/batches"

    payload = {
        "contactListId": 2,
        "name": "Test Batch",
        "recipients": [
            {
                "attributes": {"key1": "value1"},
                "contactId": 3,
                "fromNumber": "+1234567890",
                "phoneNumber": "1234567890"
            }
        ],
        "scrubDuplicates": True
    }

    headers = {}

    response = requests.post(url, json=payload, headers=headers)

    assert response.status_code == 201
    result = response.json()
    assert result["id"] is not None