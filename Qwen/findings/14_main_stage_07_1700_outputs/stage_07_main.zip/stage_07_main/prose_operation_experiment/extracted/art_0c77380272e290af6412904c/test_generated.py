import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_nh_interior():
    headers = {
        "X-API-KEY": "your_api_key_here",
        "Accept-Version": "1.0.0"
    }
    params = {
        "color": ["White", "Colorful"],
        "thumbsize": 100
    }
    response = requests.get(f"{BASE_URL}/nh/interior/Abstract_Wall", headers=headers, params=params)
    
    assert response.status_code == 200
    data = response.json()
    assert "name" in data
    assert data["name"] == "Abstract Wall"
    assert "category" in data
    assert data["category"] == "Wallpaper"
    assert "colors" in data
    assert sorted(data["colors"]) == ["Colorful", "White"]
    assert "availability" in data
    assert len(data["availability"]) == 1
    assert "buy" in data
    assert len(data["buy"]) == 1
    assert "sell" in data
    assert data["sell"] == 200
    assert "hha_base" in data
    assert data["hha_base"] == 0
    assert "hha_category" in data
    assert data["hha_category"] == "Dresser"
    assert "image_url" in data
    assert "item_series" in data
    assert "item_set" in data
    assert "notes" in data
    assert "tag" in data
    assert "themes" in data
    assert "unlocked" in data
    assert data["unlocked"] is True
    assert "url" in data
    assert "version_added" in data

def test_get_nh_interior_unauthorized():
    headers = {
        "X-API-KEY": "invalid_api_key",
        "Accept-Version": "1.0.0"
    }
    response = requests.get(f"{BASE_URL}/nh/interior/Abstract_Wall", headers=headers)
    
    assert response.status_code == 401
    data = response.json()
    assert "title" in data
    assert data["title"] == "Failed to validate UUID."
    assert "details" in data
    assert data["details"].startswith("UUID is either missing or invalid")

def test_get_nh_interior_internal_error():
    headers = {
        "X-API-KEY": "your_api_key_here",
        "Accept-Version": "1.0.0"
    }
    response = requests.get(f"{BASE_URL}/nh/interior/NonExistentItem", headers=headers)
    
    assert response.status_code == 500
    data = response.json()
    assert "title" in data
    assert data["title"] == "API experienced a fatal error."
    assert "details" in data
    assert data["details"] == "Details unknown."

if __name__ == "__main__":
    pytest.main()