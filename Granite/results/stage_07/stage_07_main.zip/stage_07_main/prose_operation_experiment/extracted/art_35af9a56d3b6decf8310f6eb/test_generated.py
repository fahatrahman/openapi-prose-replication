import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retry mechanism for handling potential network issues
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

# Define security header for API authentication
headers = {
    'x-api-key': os.environ['OPENAPI_API_KEY']
}

@pytest.fixture
def aliases():
    """
    Fixture to fetch aliases from the API.
    """
    url = f"{BASE_URL}/aliases/all"

    params = {
        "domainName": "short.fyi",
        "continueFrom": "1588788835614657618",
        "limit": 100
    }

    response = session.get(url, headers=headers, params=params)
    response.raise_for_status()

    return response.json()

def test_get_aliases(aliases):
    """
    Test fetching aliases using the provided parameters.
    """
    assert isinstance(aliases, dict)
    assert "aliases" in aliases
    assert isinstance(aliases["aliases"], list)
    assert "lastId" in aliases