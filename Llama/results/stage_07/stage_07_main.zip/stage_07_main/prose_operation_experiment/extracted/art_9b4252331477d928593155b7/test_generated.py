# -*- coding: utf-8 -*-

import pytest
import requests
from unittest.mock import patch, MagicMock

BASE_URL = "http://openapi.test"

def test_products_variants_get():
    # Given
    id = 12345
    authtoken = "my_token"
    login = "my_login"

    # When
    response = requests.get(
        f"{BASE_URL}/products/{id}/variants.json",
        params={"authtoken": authtoken, "login": login}
    )

    # Then
    assert response.status_code == 200
    assert response.json() is not None

@patch('requests.get')
def test_products_variants_get_not_found(mock_get):
    # Given
    id = 12345
    authtoken = "my_token"
    login = "my_login"
    mock_response = MagicMock(status_code=404)
    mock_response.json.return_value = {"message": "Not found"}
    mock_get.return_value = mock_response

    # When
    response = requests.get(
        f"{BASE_URL}/products/{id}/variants.json",
        params={"authtoken": authtoken, "login": login}
    )

    # Then
    assert response.status_code == 404
    assert response.json()["message"] == "Not found"

def test_products_variants_get_invalid_response():
    # Given
    id = 12345
    authtoken = "my_token"
    login = "my_login"

    # When
    response = requests.get(
        f"{BASE_URL}/products/{id}/variants.json",
        params={"authtoken": authtoken, "login": login},
        timeout=0.00001
    )

    # Then
    assert response.status_code != 200

if __name__ == "__main__":
    pytest.main([__file__, "-v"])