import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_agent():
    url = f"{BASE_URL}/v2/projects/-/agent"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token_here",
        "alt": "json",
        "callback": "your_callback_function",
        "fields": "your_fields",
        "key": "your_api_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": False,
        "quotaUser": "your_quota_user",
        "uploadType": "media",
        "upload_protocol": "raw"
    }
    headers = {
        "Authorization": "Bearer your_oauth_token"
    }
    response = requests.delete(url, headers=headers, params=params)
    assert response.status_code == 200
    assert response.json() == {}