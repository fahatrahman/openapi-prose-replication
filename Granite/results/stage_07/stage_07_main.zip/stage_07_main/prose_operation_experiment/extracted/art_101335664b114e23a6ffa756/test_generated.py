import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

def test_create_workspace():
    workspace_data = {
        "collections": [
            {"id": "e1fc3c38-a0b8-44a3-bd44-d753a96b2e9d", "name": "Straw hats", "uid": "8154-e1fc3c38-a0b8-44a3-bd44-d753a96b2e9d"}
        ],
        "description": "Some description",
        "environments": [
            {"id": "83a1aaa2-a204-4bd8-9b92-4d486918906b", "name": "env", "uid": "8154-83a1aaa2-a204-4bd8-9b92-4d486918906b"}
        ],
        "mocks": [{"id": "cda672ef-1375-40e9-baee-e20ece8d7b65"}],
        "monitors": [{"id": "1e889bd2-3862-4be0-b2c2-9b1fe9673aec"}],
        "name": "New Workspace",
        "type": "personal"
    }

    retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
    adapter = HTTPAdapter(max_retries=retries)
    http = requests.Session()
    http.mount("https://", adapter)
    http.mount("http://", adapter)

    response = http.post(f"{BASE_URL}/workspaces", json=workspace_data)

    assert response.status_code == 200
    assert response.json()["workspace"]["name"] == "New Workspace"