import pytest
import requests

BASE_URL = "http://openapi.test"

def test_jurisdiction_detail():
    jurisdiction_id = "ocd-jurisdiction/country:us/state:nc/government"
    include = ["organizations", "legislative_sessions"]
    apikey = "your_api_key_here"

    headers = {
        "x-api-key": apikey,
    }

    params = {
        "include": include,
        "apikey": apikey,
    }

    url = f"{BASE_URL}/jurisdictions/{jurisdiction_id}"

    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 200
    assert response.json()["id"] == jurisdiction_id
    assert all(item in response.json() for item in include)