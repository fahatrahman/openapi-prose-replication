import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_keys():
    headers = {
        "X-Emby-Authorization": "Bearer your_access_token"
    }
    response = requests.get(f"{BASE_URL}/Auth/Keys", headers=headers)
    assert response.status_code == 200
    result = response.json()
    assert "Items" in result
    assert isinstance(result["Items"], list)

if __name__ == "__main__":
    pytest.main(["-v"])