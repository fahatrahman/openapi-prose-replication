import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_update_connector_registration():
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "YOUR_CREDENTIALS",
        "X-Amz-Date": datetime.utcnow().strftime("%Y%m%dT%H%M%SZ"),
        "X-Amz-Security-Token": "YOUR_SECURITY_TOKEN",
        "X-Amz-Signature": "YOUR_SIGNATURE",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-security-token;x-amz-signal"
    }
    
    payload = {
        "clientToken": "unique-client-token",
        "connectorLabel": "example-connector",
        "connectorProvisioningConfig": {
            "lambda": {
                "lambdaArn": "arn:aws:lambda:us-east-1:123456789012:function:example-lambda"
            }
        },
        "description": "Updating connector registration"
    }
    
    response = requests.post(f"{BASE_URL}/update-connector-registration", headers=headers, json=payload)
    
    assert response.status_code == 200
    assert "connectorArn" in response.json()