import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_perf_metrics_summary():
    url = f"{BASE_URL}/toolresults/v1beta3/projects/projectId/histories/historyId/executions/executionId/steps/stepId/perfMetricsSummary"
    headers = {
        "Content-Type": "application/json",
    }
    payload = {
        "appStartTime": {
            "fullyDrawnTime": {
                "seconds": "0",
                "nanos": "0"
            },
            "initialDisplayTime": {
                "seconds": "0",
                "nanos": "0"
            }
        },
        "executionId": "executionId",
        "graphicsStats": {
            "buckets": [
                {
                    "frameCount": "0",
                    "renderMillis": "0"
                }
            ],
            "highInputLatencyCount": "0",
            "jankyFrames": "0",
            "missedVsyncCount": "0",
            "p50Millis": "0",
            "p90Millis": "0",
            "p95Millis": "0",
            "p99Millis": "0",
            "slowBitmapUploadCount": "0",
            "slowDrawCount": "0",
            "slowUiThreadCount": "0",
            "totalFrames": "0"
        },
        "historyId": "historyId",
        "perfEnvironment": {
            "cpuInfo": {
                "cpuProcessor": "cpuProcessor",
                "cpuSpeedInGhz": 0,
                "numberOfCores": 0
            },
            "memoryInfo": {
                "memoryCapInKibibyte": 0,
                "memoryTotalInKibibyte": 0
            }
        },
        "perfMetrics": [
            "perfMetricTypeUnspecified"
        ],
        "projectId": "projectId",
        "stepId": "stepId"
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert "appStartTime" in response.json()
    assert "executionId" in response.json()
    assert "graphicsStats" in response.json()
    assert "historyId" in response.json()
    assert "perfEnvironment" in response.json()
    assert "perfMetrics" in response.json()
    assert "projectId" in response.json()
    assert "stepId" in response.json()

if __name__ == "__main__":
    pytest.main([__file__])