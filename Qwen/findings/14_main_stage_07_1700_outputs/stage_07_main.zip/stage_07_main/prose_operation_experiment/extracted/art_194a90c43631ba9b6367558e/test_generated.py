import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_custom_verification_email_template():
    headers = {
        "X-Amz-Content-Sha256": "example-sha256",
        "X-Amz-Date": "example-date",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "example-credential",
        "X-Amz-Security-Token": "example-token",
        "X-Amz-Signature": "example-signature",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-algorithm;x-amz-credential;x-amz-security-token"
    }
    template_name = "example-template-name"
    url = f"{BASE_URL}/v2/email/custom-verification-email-templates/{template_name}"
    
    response = requests.delete(url, headers=headers)
    
    assert response.status_code == 200
    assert response.json() == {"description": "On ajh yiqwuj fj aonedncmfr, ajh zqlxfuz gxtwx uvsn li RLEH 200 ubbiwvwr hpwr li wlsud RLEH xqta."}