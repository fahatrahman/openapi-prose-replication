# -*- coding: utf-8 -*-
"""Tests for testnet_getTxs."""

import pytest
from requests import Response

BASE_URL = "http://openapi.test"

def test_testnet_getTxs() -> None:
    """Test /testnet/ins/txs."""
    params = {
        'address': '',
        'block': '',
        'pageNum': ''
    }
    
    response: Response = requests.get(f"{BASE_URL}/testnet/ins/txs", params=params)
    assert response.status_code == 200
    assert response.json()