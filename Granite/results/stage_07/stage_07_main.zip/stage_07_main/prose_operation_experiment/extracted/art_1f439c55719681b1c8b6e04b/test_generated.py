import os
import pytest
import requests
from requests.exceptions import HTTPError

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def setup():
    headers = {
        "Accept": "application/json",
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
    }
    return headers

def test_update_team(setup):
    try:
        payload = {
            "data": {
                "description": "Updated description.",
                "name": "Updated Team Name",
                "html_description": "<strong>Updated description</strong>",
                "organization": "YOUR_ORGANIZATION_ID",
                "visibility": "public",
            }
        }

        url = f"{BASE_URL}/teams"
        response = requests.put(url, json=payload, headers=setup)
        response.raise_for_status()

        assert response.status_code == 200
        print("Test Successful!")

    except HTTPError as http_err:
        print(f"HTTP error occurred: {http_err}")
    except Exception as err:
        print(f"Other error occurred: {err}")