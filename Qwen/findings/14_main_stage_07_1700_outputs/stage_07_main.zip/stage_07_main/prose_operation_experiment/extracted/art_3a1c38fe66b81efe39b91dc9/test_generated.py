import pytest
import requests

BASE_URL = "http://openapi.test"

def test_builds_appEncryptionDeclaration_get_to_one_relationship():
    headers = {
        "Authorization": "Bearer YOUR_BEARER_TOKEN"
    }
    params = {
        "id": "example_id"
    }
    response = requests.get(f"{BASE_URL}/v1/builds/{params['id']}/relationships/appEncryptionDeclaration", headers=headers)
    
    assert response.status_code == 200
    assert "data" in response.json()
    assert "id" in response.json()["data"]
    assert response.json()["data"]["type"] == "appEncryptionDeclarations"
    assert "links" in response.json()
    assert "self" in response.json()["links"]

def test_builds_appEncryptionDeclaration_get_to_one_relationship_with_invalid_id():
    headers = {
        "Authorization": "Bearer YOUR_BEARER_TOKEN"
    }
    params = {
        "id": "invalid_id"
    }
    response = requests.get(f"{BASE_URL}/v1/builds/{params['id']}/relationships/appEncryptionDeclaration", headers=headers)
    
    assert response.status_code == 404
    assert "errors" in response.json()
    assert isinstance(response.json()["errors"], list)

def test_builds_appEncryptionDeclaration_get_to_one_relationship_without_auth():
    params = {
        "id": "example_id"
    }
    response = requests.get(f"{BASE_URL}/v1/builds/{params['id']}/relationships/appEncryptionDeclaration")
    
    assert response.status_code == 403
    assert "errors" in response.json()
    assert isinstance(response.json()["errors"], list)