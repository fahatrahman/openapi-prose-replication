import os
import pytest
import requests
from googleapiclient.discovery import build
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"

# Load credentials from a JSON file
credentials = service_account.Credentials.from_service_account_file(
    filename="path/to/your/credentials.json", scopes=["https://www.googleapis.com/auth/cloud-platform"]
)

def test_get_screenshot_cluster():
    project_id = "YOUR_PROJECT_ID"
    history_id = "YOUR_HISTORY_ID"
    execution_id = "YOUR_EXECUTION_ID"
    cluster_id = "YOUR_CLUSTER_ID"

    url = f"{BASE_URL}/toolresults/v1beta3/projects/{project_id}/histories/{history_id}/executions/{execution_id}/clusters/{cluster_id}"

    # Create a request object
    request = build("toolresults", "v1beta3").projects().histories().executions().clusters().get(
        projectId=project_id,
        historyId=history_id,
        executionId=execution_id,
        clusterId=cluster_id,
    )

    # Make the API call
    response = request.execute(credentials=credentials)

    # Assert the response status code
    assert response["code"] == 200

    # Assert the response content type
    assert response["contentType"] == "application/json"

    # Assert the expected structure of the ScreenshotCluster schema
    assert set(["activity", "clusterId", "keyScreen", "screens"]).issubset(response.keys())

    print("Test passed!")

if __name__ == "__main__":
    pytest.main([__file__, "-v"])