import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.exceptions import Retry

BASE_URL = "http://openapi.test"

# Create a session with retry logic for handling transient errors
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["HEAD", "GET", "OPTIONS", "PUT"],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

# Define test function
def test_insert_rti_transaction_tag():
    # Test parameters
    employer_id = "TEST_EMPLOYER_ID"
    rti_transaction_id = "TEST_RTI_TRANSACTION_ID"
    tag_id = "TEST_TAG_ID"

    # Prepare headers
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default",
    }

    # Path parameters
    url = f"{BASE_URL}/Employer/{employer_id}/RtiTransaction/{rti_transaction_id}/Tag/{tag_id}"

    # Send PUT request
    response = session.put(url, headers=headers)

    # Assert response status code
    assert response.status_code == 200, f"Expected status code 200, got {response.status_code}. Response content: {response.json()}"

if __name__ == "__main__":
    pytest.main([__file__, "-v"])