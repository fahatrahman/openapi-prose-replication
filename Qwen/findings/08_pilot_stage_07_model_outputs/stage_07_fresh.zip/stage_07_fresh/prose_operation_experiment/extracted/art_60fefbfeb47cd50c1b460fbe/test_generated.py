import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_holiday_schemes_with_tag():
    url = f"{BASE_URL}/Employer/ER001/HolidaySchemes/Tag/MyTag"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert "application/json" in response.headers["Content-Type"]
    response_json = response.json()
    assert isinstance(response_json, dict)
    assert "LinkCollection" in response_json

def test_get_holiday_schemes_with_tag_400():
    url = f"{BASE_URL}/Employer/ER001/HolidaySchemes/Tag/MyTag"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    params = {
        "EmployerId": "",
        "TagId": "MyTag"
    }
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 400
    assert "application/json" in response.headers["Content-Type"]
    response_json = response.json()
    assert isinstance(response_json, dict)
    assert "ErrorModel" in response_json

def test_get_holiday_schemes_with_tag_401():
    url = f"{BASE_URL}/Employer/ER001/HolidaySchemes/Tag/MyTag"
    headers = {
        "Authorization": "",
        "Api-Version": "default"
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 401
    assert "application/json" in response.headers["Content-Type"]
    response_json = response.json()
    assert isinstance(response_json, dict)
    assert "ErrorModel" in response_json

def test_get_holiday_schemes_with_tag_404():
    url = f"{BASE_URL}/Employer/ER001/HolidaySchemes/Tag/NonExistentTag"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 404
    assert "application/json" in response.headers["Content-Type"]
    response_json = response.json()
    assert isinstance(response_json, dict)
    assert "ErrorModel" in response_json

def test_get_holiday_schemes_with_tag_500():
    url = f"{BASE_URL}/Employer/ER001/HolidaySchemes/Tag/MyTag"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 500
    assert "application/json" in response.headers["Content-Type"]
    response_json = response.json()
    assert isinstance(response_json, dict)
    assert "ErrorModel" in response_json