import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retries for transient errors
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

@pytest.fixture
def create_ethereum_address():
    url = f"{BASE_URL}/v2/ethereum/addresses"

    payload = {
        "password": "test123"
    }

    response = session.post(url, json=payload)
    response.raise_for_status()

    return response.json()

def test_create_ethereum_address(create_ethereum_address):
    assert create_ethereum_address["ok"]
    assert create_ethereum_address["status"] == 200
    assert create_ethereum_address["message"] == "Success! Ethereum Address was successfully created."
    assert len(create_ethereum_address["data"]["ethereumaddress"]) > 0