# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_get_ship_nav():
    ship_symbol = "test_ship"
    url = f"{BASE_URL}/my/ships/{ship_symbol}/nav"
    
    headers = {"Authorization": f"Bearer AgentToken"}
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    
    data = response.json()
    assert isinstance(data, dict)
    assert "data" in data
    
    nav_data = data["data"]
    assert isinstance(nav_data, dict)
    
    required_keys = ["destination", "departure", "departureTime", "arrival"]
    for key in required_keys:
        assert key in nav_data
        
    # Test date/time fields are in ISO format
    arrival_time = nav_data["arrival"]
    departure_time = nav_data["departureTime"]
    assert isinstance(arrival_time, str) and arrival_time.startswith("20")
    assert isinstance(departure_time, str) and departure_time.startswith("20")
    
    # Test date/time fields can be parsed into datetime objects
    arrival_date = datetime.fromisoformat(arrival_time)
    departure_date = datetime.fromisoformat(departure_time)
    assert isinstance(arrival_date, datetime)
    assert isinstance(departure_date, datetime)

if __name__ == "__main__":
    pytest.main([__file__])