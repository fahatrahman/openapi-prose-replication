import pytest
import requests

BASE_URL = "http://openapi.test"

def test_disable_database_instance():
    url = f"{BASE_URL}/v1beta/{'projects/12345/locations/global/instances/my-instance'}:disable"
    headers = {
        'Content-Type': 'application/json',
        # Add other required headers here if necessary
    }
    
    payload = {
        "name": "projects/12345/locations/global/instances/my-instance",
    }

    response = requests.post(url, headers=headers, json=payload)
    
    assert response.status_code == 200
    
    try:
        response.json()
    except ValueError:
        print("Response was not valid JSON.")
        
    assert response.json()['databaseUrl'] != None
    assert response.json()['name'] != None
    assert response.json()['project'] != None
    assert response.json()['state'] != None
    assert response.json()['type'] != None