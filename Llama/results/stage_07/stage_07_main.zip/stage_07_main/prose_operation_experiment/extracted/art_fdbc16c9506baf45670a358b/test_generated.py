# -*- coding: utf-8 -*-
import pytest
import requests
from typing import Dict

BASE_URL = "http://openapi.test"

def get_history(project_id: str, history_id: str) -> Dict:
    """Get a History."""
    params = {
        "$.xgafv": None,
        "access_token": None,
        "alt": None,
        "callback": None,
        "fields": None,
        "key": None,
        "oauth_token": None,
        "prettyPrint": None,
        "quotaUser": None,
        "upload_protocol": None,
        "uploadType": None,
        "projectId": project_id,
        "historyId": history_id
    }
    
    headers = {}
    query_params = {k: v for k, v in params.items() if v is not None}
    response = requests.get(f"{BASE_URL}/toolresults/v1beta3/projects/{project_id}/histories/{history_id}", 
                            params=query_params, headers=headers)
    
    assert response.status_code == 200
    
    # Check if the response content type is application/json
    assert response.headers['Content-Type'] == 'application/json'
    
    return response.json()

def test_get_history():
    project_id = "my-project-id"
    history_id = "my-history-id"
    
    try:
        get_history(project_id, history_id)
    except AssertionError as e:
        pytest.fail(str(e))