import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.mark.parametrize("address", ["your_erc20_address"])
def test_get_erc20_data(address):
    url = f"{BASE_URL}/erc20/{address}"
    response = requests.options(url)

    assert response.status_code == 200
    assert response.headers["Access-Control-Allow-Headers"] is not None
    assert response.headers["Access-Control-Allow-Methods"] is not None
    assert response.headers["Access-Control-Allow-Origin"] is not None