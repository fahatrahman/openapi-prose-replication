# -*- coding: utf-8 -*-

import pytest
import requests
from json import JSONDecodeError

BASE_URL = "http://openapi.test"

def test_get_pico_loadmanagement_group():
    url = f"{BASE_URL}/api/pico/loadmanagementgroup"
    response = requests.get(url)

    assert response.status_code == 200
    try:
        response_json = response.json()
        assert isinstance(response_json, list)
        for item in response_json:
            assert isinstance(item, dict)
            required_keys = ["Id", "MaxCurrent", "Name", "NumberOfStations"]
            for key in required_keys:
                assert key in item
    except JSONDecodeError:
        assert False, "Invalid JSON response"