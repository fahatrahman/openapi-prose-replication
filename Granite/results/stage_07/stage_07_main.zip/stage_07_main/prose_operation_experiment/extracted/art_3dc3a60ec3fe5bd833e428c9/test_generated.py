import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session for retry on failure
session = requests.Session()
retries = Retry(total=3, backoff_factor=0.1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

@pytest.fixture
def employer_id():
    return 'GD001'

@pytest.fixture
def authorization():
    return 'Auto'

@pytest.fixture
def api_version():
    return 'default'

def test_get_all_cis_line_type_tags(session):
    url = f"{BASE_URL}/Employer/{employer_id()}/CisLineTypes/Tags"
    headers = {
        'Authorization': authorization(),
        'Api-Version': api_version()
    }

    response = session.get(url, headers=headers)

    assert response.status_code == 200, f"Unexpected status code: {response.status_code}"

    # Add more assertions based on expected response structure if needed
    # response.json() can be used to access the JSON content of the response