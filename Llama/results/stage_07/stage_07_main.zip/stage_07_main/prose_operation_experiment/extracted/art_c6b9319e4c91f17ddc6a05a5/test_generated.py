import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_recipe_taste_by_id():
    api_key = "YOUR_API_KEY"
    headers = {"x-api-key": api_key}
    params = {"normalize": True}

    id = 69095
    url = f"{BASE_URL}/recipes/{id}/tasteWidget.json"

    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 200
    result = response.json()
    required_fields = ["bitterness", "fattiness", "saltiness", "savoriness", "sourness", "spiciness", "sweetness"]
    for field in required_fields:
        assert field in result.keys()

def test_get_recipe_taste_by_id_401():
    api_key = "INVALID_API_KEY"
    headers = {"x-api-key": api_key}
    params = {"normalize": True}

    id = 69095
    url = f"{BASE_URL}/recipes/{id}/tasteWidget.json"

    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 401

def test_get_recipe_taste_by_id_403():
    headers = {}
    params = {"normalize": True}

    id = 69095
    url = f"{BASE_URL}/recipes/{id}/tasteWidget.json"

    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 403

def test_get_recipe_taste_by_id_404():
    api_key = "YOUR_API_KEY"
    headers = {"x-api-key": api_key}
    params = {"normalize": True}

    id = 99999
    url = f"{BASE_URL}/recipes/{id}/tasteWidget.json"

    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 404