import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Retry mechanism for requests
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
session.mount("https://", adapter)
session.mount("http://", adapter)

# API key for authentication
API_KEY = os.environ.get("API_KEY")

@pytest.fixture
def live_plays():
    headers = {"Authorization": f"Bearer {API_KEY}"} if API_KEY else {}

    def _get_live_plays(game_id):
        response = session.get(
            f"{BASE_URL}/live/plays",
            headers=headers,
            params={"id": game_id},
        )

        response.raise_for_status()
        return response.json()["data"]

    yield _get_live_plays

def test_get_live_plays(live_plays):
    game_id = 12345  # Replace this with an actual game ID
    plays = live_plays(game_id)

    assert isinstance(plays, list)
    for play in plays:
        assert all(key in play for key in ["clock", "distance", "down", "drives"])
        assert isinstance(play["drives"], list)
        assert all(
            all(key in drive for key in ["defense", "defenseId", "duration", "endClock", "endPeriod", "endYardsToGoal", "id", "offense", "offenseId", "playCount", "plays"])
            for drive in play["drives"]
        )