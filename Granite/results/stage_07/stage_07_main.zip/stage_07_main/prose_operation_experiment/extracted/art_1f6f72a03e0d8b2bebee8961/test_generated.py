import os
import pytest
import requests
from google.rpc import status_pb2
from google.type import expr_pb2

BASE_URL = "http://openapi.test"

def test_update_source():
    project_id = "your_project_id"
    location = "your_location"
    source_id = "your_source_id"

    # Prepare the request payload
    update_mask = "displayName,priority"
    source = {
        "displayName": "Updated Display Name",
        "priority": 10
    }

    # Construct the URL
    url = f"{BASE_URL}/v1/{source_id}"

    # Send the PATCH request
    response = requests.patch(
        url,
        json={"source": source},
        headers={
            "Content-Type": "application/json",
            "Accept": "application/json"
        },
        params={
            "access_token": "YOUR_ACCESS_TOKEN",
            "key": "YOUR_API_KEY",
            "prettyPrint": "false",
            "requestId": "unique_request_id",
            "updateMask": update_mask
        }
    )

    # Check the response status code
    assert response.status_code == 200

    # Parse the response JSON
    data = response.json()

    # Assert the response contains Operation
    assert "operation" in data

    # Create a Status object to parse the error detail
    status = status_pb2.Status()
    status.ParseFromString(data["operation"]["response"].get("error").data)

    # Assert there is no error
    assert status.code == status_pb2.Code.OK