import pytest
import requests
from urllib.parse import urlencode

BASE_URL = "http://openapi.test"

def test_create_configuration():
    parent = "/v1/test_parent"
    configuration = {
        "companyName": "Test Company",
        "configurationId": 123,
        "configurationName": "Test Configuration",
        "contactEmail": "test@example.com",
        "contactPhone": "1234567890",
        "customMessage": "Hello World!",
        "dpcExtras": "Extra information",
        "dpcResourcePath": "https://example.com/path",
        "forcedResetTime": "PT12H",
        "isDefault": True,
        "name": "Test Name"
    }

    params = {
        "$.xgafv": "1",
        "access_token": "",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "",
        "oauth_token": "",
        "prettyPrint": "false",
        "quotaUser": "",
        "upload_protocol": "upload",
        "uploadType": "media",
        "parent": parent
    }
    url = f"{BASE_URL}{parent}"
    headers = {}
    body = {"configuration": configuration}

    response = requests.post(url, headers=headers, json=body, params=urlencode(params))
    assert response.status_code == 200
    assert response.json() == configuration