import pytest
import requests
from requests.exceptions import HTTPError
BASE_URL = "http://openapi.test"

@pytest.mark.parametrize("certificate_id, customer_id", [
    ("cert_id_example", "customer_id_example"),
    # Add more test cases here...
])
def test_get_certificate_detail(certificate_id, customer_id):
    url = f"{BASE_URL}/v2/customers/{customer_id}/certificates/{certificate_id}"

    try:
        response = requests.get(url)
        response.raise_for_status()
        certificate_detail = response.json()["certificateDetailV2"]

        assert certificate_detail["certificateId"] == certificate_id
        assert certificate_detail["commonName"]
        assert certificate_detail["period"]
        assert certificate_detail["type"]
        assert certificate_detail["status"]
        assert certificate_detail["createdAt"]
        assert certificate_detail["contact"]["nameFirst"]
        assert certificate_detail["contact"]["nameLast"]
        assert certificate_detail["contact"]["email"]
        assert certificate_detail["contact"]["phone"]

    except HTTPError as http_err:
        print(f"HTTP error occurred: {http_err}")
    except Exception as err:
        print(f"Other error occurred: {err}")