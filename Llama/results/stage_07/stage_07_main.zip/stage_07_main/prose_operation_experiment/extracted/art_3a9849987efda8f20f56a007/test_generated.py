# -*- coding: utf-8 -*-

import pytest
import json
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

def test_create_attribute():
    url = f"{BASE_URL}/attributes/computed"
    
    # Basic authentication is required for this endpoint
    auth = HTTPBasicAuth("your_email", "your_password")
    
    attribute_data = {
        "attribute": "new_attribute",
        "description": "This is a new computed attribute.",
        "expression": "some_expression",
        "id": 123,
        "type": "String"
    }
    
    response = requests.post(url, 
                             json=attribute_data, 
                             auth=auth)
    
    assert response.status_code == 200
    
    response_json = response.json()
    
    assert isinstance(response_json, dict)
    assert 'attribute' in response_json
    assert 'description' in response_json
    assert 'expression' in response_json
    assert 'id' in response_json
    assert 'type' in response_json
    
    assert response_json['attribute'] == attribute_data['attribute']
    assert response_json['description'] == attribute_data['description']
    assert response_json['expression'] == attribute_data['expression']
    assert response_json['id'] == attribute_data['id']
    assert response_json['type'] == attribute_data['type']

if __name__ == "__main__":
    pytest.main([__file__])