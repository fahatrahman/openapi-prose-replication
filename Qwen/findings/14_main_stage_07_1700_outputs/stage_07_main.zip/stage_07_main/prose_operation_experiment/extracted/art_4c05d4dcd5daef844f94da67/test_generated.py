import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_deployment_files():
    url = f"{BASE_URL}/v6/deployments/12345/files"
    params = {
        "teamId": "example-team"
    }
    headers = {
        "Authorization": "Bearer your_access_token_here"
    }
    
    response = requests.get(url, params=params, headers=headers)
    
    assert response.status_code == 200
    assert isinstance(response.json(), list)
    assert all(isinstance(item, dict) for item in response.json())

if __name__ == "__main__":
    pytest.main()