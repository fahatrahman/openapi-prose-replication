import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_query():
    url = f"{BASE_URL}/v1/query"
    params = {
        "q": "{\"query\": \"data.servers[i].ports[_] = \\\"p2\\\"; data.servers[i].name = name\"}",
        "pretty": True,
        "explain": "full",
        "metrics": False
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 200
    assert response.json()["success"]
    assert "result" in response.json()
    assert "explanation" in response.json()
    assert "metrics" in response.json()

def test_get_query_bad_request():
    url = f"{BASE_URL}/v1/query"
    params = {
        "q": "{\"query\": \"invalid query\"}"
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 400
    assert response.json()["code"] == "invalid_parameter"
    assert "errors" in response.json()

def test_get_query_server_error():
    # This test assumes there's a way to simulate a server error for testing purposes
    # In a real scenario, you would need to set up a mock server or modify the OpenAPI document
    pass