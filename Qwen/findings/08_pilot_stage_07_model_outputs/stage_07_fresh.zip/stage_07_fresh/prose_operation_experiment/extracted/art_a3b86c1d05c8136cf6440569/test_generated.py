import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_watches():
    url = f"{BASE_URL}/v1/forms/{formId}/watches"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token",
        "alt": "json",
        "callback": "your_callback",
        "fields": "watches(id,eventType,state)",
        "key": "your_api_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": False,
        "quotaUser": "your_quota_user",
        "uploadType": "media",
        "upload_protocol": "raw"
    }
    headers = {
        "Authorization": "Bearer your_access_token"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert "watches" in data
    for watch in data["watches"]:
        assert "id" in watch
        assert "eventType" in watch
        assert "state" in watch