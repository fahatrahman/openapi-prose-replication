import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = "path/to/service_account.json"

# Load credentials using service account file
credentials = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE, scopes=["https://www.googleapis.com/auth/cloud-platform"]
)

def test_update_recommender_config():
    recommender_id = "recsai"
    location = "global"
    project_number = "123456789012"
    recommender_name = f"projects/{project_number}/locations/{location}/recommenders/{recommender_id}/config"

    # Update Recommender Config
    update_mask = "annotations"
    validate_only = False
    recommender_config = {
        "displayName": "Test Recommender",
        "recommenderGenerationConfig": {
            "params": {}
        },
        "annotations": {"my_annotation": "data"}
    }

    url = f"{BASE_URL}/{recommender_name}"
    headers = {
        "Content-Type": "application/json",
    }

    response = requests.patch(url, json=recommender_config, headers=headers, verify=False, auth=credentials)

    assert response.status_code == 200
    updated_recommender_config = response.json()

    # Check if the annotations were updated correctly
    assert updated_recommender_config["annotations"]["my_annotation"] == "data"