import pytest
import requests
BASE_URL = "http://openapi.test"

def test_sources():
    url = f"{BASE_URL}/resources/sources.json"
    response = requests.get(url)

    if response.status_code == 200:
        sources = response.json()["items"]
        assert isinstance(sources, list)
        for source in sources:
            assert isinstance(source, dict)
            assert all(key in source for key in ["acronym", "contactEmail", "id", "largeLogoUrl", "name", "smallLogoUrl", "websiteUrl"])
    else:
        assert False, f"Unexpected status code {response.status_code}"