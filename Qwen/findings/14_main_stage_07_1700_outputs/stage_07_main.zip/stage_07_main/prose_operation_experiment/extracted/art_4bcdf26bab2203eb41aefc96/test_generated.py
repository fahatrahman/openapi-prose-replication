import pytest
import requests

BASE_URL = "http://openapi.test"

def test_monitoring_projects_location_prometheus_api_v1_query():
    url = f"{BASE_URL}/v1/{name}/location/{location}/prometheus/api/v1/query"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "query": "your_query_here",
        "time": "your_time_here",
        "timeout": "your_timeout_here"
    }
    response = requests.post(url, headers=headers, json=payload)
    
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

# Replace 'your_name', 'your_location', 'your_query_here', 'your_time_here', and 'your_timeout_here' with actual values before running the tests.