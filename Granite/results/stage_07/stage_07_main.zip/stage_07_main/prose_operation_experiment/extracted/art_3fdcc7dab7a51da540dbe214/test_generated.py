import pytest
import requests
from requests.auth import HTTPBasicAuth
BASE_URL = "http://openapi.test"

@pytest.fixture
def auth():
    return HTTPBasicAuth("your_username", "your_password")

def test_create_page(auth):
    endpoint = f"{BASE_URL}/v1alpha1/pages"
    payload = {
        "name": "Test Page Name",
        "pageUrl": "https://example.com/page",
        "publishDate": "2022-01-01",
        "versionId": "1",
        "claimReviewAuthor": {
            "name": "John Doe",
            "imageUrl": "https://example.com/john-doe.jpg"
        },
        "claimReviewMarkups": [
            {
                "claimAppearances": ["claim_appearance_1", "claim_appearance_2"],
                "claimAuthor": {
                    "name": "Jane Smith",
                    "imageUrl": "https://example.com/jane-smith.jpg"
                },
                "claimDate": "2022-02-01",
                "claimFirstAppearance": "2022-01-15",
                "claimLocation": "New York City",
                "claimReviewed": "2022-02-15",
                "rating": {
                    "bestRating": 5,
                    "ratingExplanation": "This claim is mostly true.",
                    "ratingValue": 4,
                    "textualRating": "Mostly True",
                    "worstRating": 1
                },
                "url": "https://example.com/claim"
            }
        ]
    }

    response = requests.post(endpoint, json=payload, auth=auth)
    assert response.status_code == 200
    created_page = response.json()
    # Add more assertions if needed to validate the response content