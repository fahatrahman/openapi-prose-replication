import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_ecosystem():
    ecosystem_id = "test-ecosystem-id"
    url = f"{BASE_URL}/ecosystems/{ecosystem_id}"
    response = requests.get(url)
    
    assert response.status_code == 200
    assert response.json()["status"] == "OK"
    assert "data" in response.json()
    assert isinstance(response.json()["data"], dict)

if __name__ == "__main__":
    pytest.main(["-v", "--tb=short"])