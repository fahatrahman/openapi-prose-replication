import pytest
import requests

BASE_URL = "http://openapi.test"

def test_generate_download_url():
    url = f"{BASE_URL}/v2beta/projects/location/functions/generateDownloadUrl"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    params = {
        "name": "projects/location/functions/function_name",
        "access_token": "YOUR_ACCESS_TOKEN",
        "alt": "json",
        "prettyPrint": False,
        "quotaUser": "user"
    }
    response = requests.post(url, headers=headers, json={}, params=params)
    
    assert response.status_code == 200
    assert 'downloadUrl' in response.json()
    assert isinstance(response.json()['downloadUrl'], str)

if __name__ == "__main__":
    pytest.main(["-v", "-k", "test_generate_download_url"])