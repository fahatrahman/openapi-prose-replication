import pytest
import requests

BASE_URL = "http://openapi.test"

def test_service_principals_list_owners():
    url = f"{BASE_URL}/fake-tenant-id/servicePrincipals/fake-object-id/owners"
    params = {
        "api-version": "1.0.0"
    }
    headers = {
        "Authorization": "Bearer fake_token"
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 200
    assert response.json()["value"] is not None

if __name__ == "__main__":
    pytest.main()