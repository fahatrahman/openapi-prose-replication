import os
import pytest
import requests
from googleapiclient.discovery import build

BASE_URL = "http://openapi.test"

@pytest.fixture
def setup():
    os.environ["OAUTH2_CLIENT_ID"] = "<Your_Client_ID>"
    os.environ["OAUTH2_CLIENT_SECRET"] = "<Your_Client_Secret>"
    oauth2_service = build('content', 'v2.1', credentials=requests.Authorizer(
        access_token='<Your_Access_Token>',
        refresh_url='https://accounts.google.com/o/oauth2/token'))

    return oauth2_service

def test_cancel_line_item(setup):
    merchant_id = '<Your_Merchant_ID>'
    order_id = '<Your_Order_ID>'
    
    request_body = {
        "lineItemId": "<Your_Line_Item_ID>",
        "operationId": "<Your_Operation_ID>",
        "productId": "<Your_Product_ID>",
        "quantity": <Your_Quantity>,
        "reason": "<Your_Reason>",
        "reasonText": "<Your_Reason_Text>"
    }

    response = setup.orders().cancelLineItem(merchantId=merchant_id, orderId=order_id, body=request_body).execute()

    assert response['kind'] == 'content#ordersCancelLineItemResponse'
    assert response['executionStatus'] in ['justProcessable', 'done']