import pytest
import requests

BASE_URL = "http://openapi.test"

def test_publish_recipe():
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "YOUR_CREDENTIALS",
        "X-Amz-Date": "20230401T000000Z",
        "X-Amz-Security-Token": "YOUR_SECURITY_TOKEN",
        "X-Amz-Signature": "YOUR_SIGNATURE",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-security-token"
    }
    url = f"{BASE_URL}/recipes/testrecipe/publishRecipe"
    payload = {
        "Description": "Test recipe description"
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert "Name" in response.json()
    assert response.json()["Name"] == "testrecipe"