# -*- coding: utf-8 -*-
import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_get_api_key():
    url = urljoin(BASE_URL, "/targets/{target_id}/keys/{id}/".format(target_id="TARGET_ID", id="KEY_ID"))
    response = requests.get(url)
    assert response.status_code == 200
    api_key_response = response.json()
    assert "id" in api_key_response
    assert "key" in api_key_response
    assert "name" in api_key_response

def test_forbidden_error():
    url = urljoin(BASE_URL, "/targets/{target_id}/keys/{id}/".format(target_id="TARGET_ID", id="KEY_ID"))
    response = requests.get(url, headers={"Authorization": "Bearer INVALID_TOKEN"})
    assert response.status_code == 403
    forbidden_error_response = response.json()
    assert "detail" in forbidden_error_response

def test_not_found_error():
    url = urljoin(BASE_URL, "/targets/{target_id}/keys/{id}/".format(target_id="INVALID_TARGET_ID", id="KEY_ID"))
    response = requests.get(url)
    assert response.status_code == 404
    not_found_error_response = response.json()
    assert "detail" in not_found_error_response