import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS = service_account.Credentials.from_service_account_file('path/to/credentials.json')

def test_managed_zone_patch():
    path_params = {"name": "projects/my-project/locations/global/managedZones/my-managed-zone"}
    update_mask = "description,labels,target_project,target_network"

    payload = {
        "description": "Updated description",
        "labels": {"env": "prod"},
        "target_project": "updated-project",
        "target_network": "updated-network"
    }

    headers = {
        'x-goog-api-client': 'gl-python',
        'x-goog-api-version': '2'
    }

    response = requests.patch(
        url=BASE_URL + '/' + '/'.join(path_params.values()),
        json=payload,
        headers=headers,
        auth=CREDENTIALS,
        verify=False  # Disable SSL verification for local testing
    )

    assert response.status_code == 200

    operation = response.json()
    assert operation['name']
    assert operation['done']
    assert operation['response']['description'] == 'Updated description'
    assert operation['response']['labels'] == {'env': 'prod'}
    assert operation['response']['targetProject'] == 'updated-project'
    assert operation['response']['targetVpc'] == 'updated-network'