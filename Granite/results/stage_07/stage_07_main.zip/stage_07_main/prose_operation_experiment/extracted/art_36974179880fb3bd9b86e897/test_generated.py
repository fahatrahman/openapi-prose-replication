import pytest
import requests
from requests.auth import HTTPBasicAuth
BASE_URL = "http://openapi.test"

def test_terms_of_service():
    endpoint = "/legalEntities/0/termsOfService"
    headers = {"Content-Type": "application/json"}

    # Prepare request body
    request_body = {
        "type": "adyenIssuing",
        "language": "en"
    }

    url = BASE_URL + endpoint
    response = requests.post(url, headers=headers, json=request_body, auth=HTTPBasicAuth("username", "password"))

    assert response.status_code == 200
    assert response.json()["type"] == "adyenIssuing"
    assert response.json()["language"] == "en"
    assert response.json()["id"].startswith("LE00000000000000000000001")
    assert response.json()["termsOfServiceDocumentId"] == "abc123"