import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Configure session with retry strategy
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

@pytest.fixture
def auth_header():
    # Replace with actual authentication logic
    return {"Authorization": "Bearer your_access_token"}

@pytest.mark.parametrize("conv_id, item_id", [
    ("conv123", "item456"),
    ("invalid_conv_id", "item789")
])
def test_unpin_conversation(conv_id, item_id):
    url = f"{BASE_URL}/conversations/{conv_id}/pins/{item_id}"
    
    response = session.delete(url, headers=auth_header())

    assert response.status_code == 200, f"Unexpected status code: {response.status_code}"
    assert response.json()["type"] == "Conversation"