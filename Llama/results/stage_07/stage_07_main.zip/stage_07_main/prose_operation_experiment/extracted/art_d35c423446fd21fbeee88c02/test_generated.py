# -*- coding: utf-8 -*-
import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_get_outbound_message_dump():
    # Get the server token
    server_token_response = requests.get(urljoin(BASE_URL, "/servers"), auth=("username", "password"))
    assert server_token_response.status_code == 200
    server_token = server_token_response.json()["token"]

    # Get the outbound message dump
    headers = {"X-Postmark-Server-Token": server_token}
    response = requests.get(
        urljoin(BASE_URL, f"/messages/outbound/{message_id}")),
        headers=headers)
    assert response.status_code == 200
    response.raise_for_status()
    dump = response.json()["Body"]
    assert isinstance(dump, str)

@pytest.fixture
def message_id():
    # For demonstration purposes, we'll just hardcode a message ID here.
    # In a real application, you'd want to get this dynamically or through some other means.
    return "example-message-id"