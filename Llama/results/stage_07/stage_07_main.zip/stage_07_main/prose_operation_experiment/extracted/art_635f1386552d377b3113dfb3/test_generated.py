import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_collection_ids():
    url = f"{BASE_URL}/v1/{'projects/my-project/databases/my-database/documents/chatrooms/my-chatroom'}:listCollectionIds"
    headers = {"Content-Type": "application/json"}
    params = {
        "$.xgafv": "1",
        "access_token": None,
        "alt": "json",
        "callback": None,
        "fields": None,
        "key": None,
        "oauth_token": None,
        "prettyPrint": False,
        "quotaUser": None,
        "upload_protocol": None,
        "uploadType": None,
    }
    body = {
        "pageSize": 10,
        "pageToken": None,
        "readTime": None,
    }

    response = requests.post(url, headers=headers, params=params, json=body)
    assert response.status_code == 200
    assert response.json()["collectionIds"]
    assert response.json().get("nextPageToken") is None