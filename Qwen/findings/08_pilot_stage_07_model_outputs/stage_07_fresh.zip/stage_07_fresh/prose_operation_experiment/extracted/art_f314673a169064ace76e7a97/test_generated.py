import pytest
import requests

BASE_URL = "http://openapi.test"

def test_deregister_data_lake_delegated_administrator():
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Credential": "exampleCredential/20230401/us-east-1/example/aws4_request",
        "X-Amz-Date": "20230401T123456Z",
        "X-Amz-Security-Token": "exampleSecurityToken",
        "X-Amz-Signature": "exampleSignature",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-security-token"
    }
    response = requests.delete(f"{BASE_URL}/v1/datalake/delegate", headers=headers)
    
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()