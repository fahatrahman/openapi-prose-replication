import pytest
import requests

BASE_URL = "http://openapi.test"

def test_reset_instance():
    url = f"{BASE_URL}/v2/projects/locations/instances/reset"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "name": "projects/locations/instances/example-instance"
    }
    response = requests.post(url, headers=headers, json=payload)
    
    assert response.status_code == 200
    assert "Operation" in response.json()