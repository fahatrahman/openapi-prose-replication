import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_voice_profile():
    url = f"{BASE_URL}/voice-profiles/test-voice-profile-id"
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Credential": "test-access-key-id/test-date/us-east-1/aws4_request",
        "X-Amz-Date": "test-dateTtest-timeZ",
        "X-Amz-Security-Token": "test-session-token",
        "X-Amz-Signature": "test-signature",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-security-token;x-amz-signal;x-amz-signedheaders"
    }
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    assert "VoiceProfile" in response.json()