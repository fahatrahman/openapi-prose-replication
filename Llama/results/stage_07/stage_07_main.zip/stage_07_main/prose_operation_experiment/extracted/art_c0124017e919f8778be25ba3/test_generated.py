# -*- coding: utf-8 -*-
"""Tests for Search Paragraph endpoint."""

import pytest
import json
from requests import Response

BASE_URL = "http://openapi.test"

def test_Search_Paragraph_reference():
    """Test GET /api/Search/Paragraph/{reference}."""
    
    # Arrange
    reference = "test_reference"
    url = f"{BASE_URL}/api/Search/Paragraph/{reference}"
    
    # Act
    response: Response = requests.get(url)
    
    # Assert
    assert response.status_code == 200
    
    try:
        response_json = response.json()
    except json.JSONDecodeError:
        pytest.fail("Failed to parse JSON in response")
        
    assert isinstance(response_json, dict)
    assert 'id' in response_json
    assert 'title' in response_json or 'titleChain' in response_json
    assert 'subSections' in response_json or response_json['subSections'] is None

def test_Search_Paragraph_reference_400():
    """Test GET /api/Search/Paragraph/{reference} returns 400."""
    
    # Arrange
    reference = ""
    url = f"{BASE_URL}/api/Search/Paragraph/{reference}"
    
    # Act
    response: Response = requests.get(url)
    
    # Assert
    assert response.status_code == 400

def test_Search_Paragraph_reference_404():
    """Test GET /api/Search/Paragraph/{reference} returns 404."""
    
    # Arrange
    reference = "non_existent_reference"
    url = f"{BASE_URL}/api/Search/Paragraph/{reference}"
    
    # Act
    response: Response = requests.get(url)
    
    # Assert
    assert response.status_code == 404

import requests