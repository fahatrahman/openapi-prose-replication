import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retry strategy
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

# Set API token for authentication
headers = {"X-API-Token": os.environ["API_TOKEN"]}

@pytest.fixture
def team_details():
    def get_team_details(org_name, team_name):
        url = f"{BASE_URL}/v0.1/orgs/{org_name}/teams/{team_name}"
        response = session.get(url, headers=headers)

        if response.status_code == 200:
            return response.json()
        else:
            error_response = response.json()
            raise Exception(f"Error: {error_response['error']['code']}, {error_response['error']['message']}")

    return get_team_details

def test_teams_getTeam(team_details):
    org_name = "your_org_name"
    team_name = "your_team_name"
    expected_keys = ["id", "name", "display_name"]
    
    try:
        team_data = team_details(org_name, team_name)
        assert all(key in team_data for key in expected_keys), \
            f"Missing keys in team data: {set(expected_keys) - set(team_data.keys())}"
    except Exception as e:
        pytest.fail(f"Test failed with error: {str(e)}")