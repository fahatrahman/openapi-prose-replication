import pytest
import json
import requests

BASE_URL = "http://openapi.test"

def test_get_wifi_config():
    url = f"{BASE_URL}/api/v1/config/wifi"
    response = requests.get(url)
    assert response.status_code == 200
    data = response.json()
    required_keys = ["ssid", "password", "mode"]
    for key in required_keys:
        assert key in data
    schema = {
        "type": "object",
        "required": ["ssid", "password", "mode"],
        "properties": {
            "mode": {"type": "string", "enum": ["ap", "client"]},
            "password": {"type": "string"},
            "ssid": {"type": "string"}
        }
    }
    assert validate_json_schema(data, schema)

def validate_json_schema(instance, schema):
    try:
        json.dumps(instance, check_circular=False, indent=4)
        return True
    except TypeError as e:
        if 'cyclic references' in str(e):
            # Ignore cyclic references
            pass
        else:
            raise
    for key, value in schema.items():
        if isinstance(value, dict):
            if key not in instance or not validate_json_schema(instance[key], value):
                return False
        elif isinstance(value, list):
            if key not in instance or not all(validate_json_schema(item, value[0]) for item in instance[key]):
                return False
        else:
            if key not in instance or instance[key] != value:
                return False
    return True