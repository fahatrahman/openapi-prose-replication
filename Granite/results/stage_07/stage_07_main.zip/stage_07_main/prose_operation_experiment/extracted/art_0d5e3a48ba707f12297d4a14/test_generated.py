import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Retry mechanism for requests
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def statutory_instrument():
    id_ = "example_id"  # Replace with actual value or use a variable

    url = f"{BASE_URL}/api/v1/StatutoryInstrument/{id}"

    response = session.get(url)
    response.raise_for_status()

    return response.json()

def test_get_statutory_instrument_by_id(statutory_instrument):
    assert isinstance(statutory_instrument, dict)
    assert all(key in statutory_instrument for key in ("links", "value"))
    assert isinstance(statutory_instrument["value"], dict)
    assert all(key in statutory_instrument["value"]
               for key in ("commonsLayingDate", "commonsPublishedDate",
                          "departmentId", "id", "layingBodyDepartment",
                          "layingBodyId", "layingBodyName", "link",
                          "lordsLayingDate", "lordsPublishedDate", "name",
                          "paperComingIntoForceDate", "paperComingIntoForceNote",
                          "paperMadeDate", "paperNumber", "paperPrefix",
                          "paperYear", "procedure", "procedureName",
                          "procedureUri", "proposedNegativeStatutoryInstrument",
                          "proposedNegativeStatutoryInstrumentPaperId",
                          "proposedNegativeStatutoryInstrumentPaperName",
                          "uri"))