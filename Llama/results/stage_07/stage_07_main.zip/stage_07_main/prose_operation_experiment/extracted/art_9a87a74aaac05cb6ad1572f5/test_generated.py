import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_project():
    response = requests.delete(f"{BASE_URL}/projects/1234567", headers={"Authorization": "Bearer <ACCESS_TOKEN>"})
    assert response.status_code == 200
    project_details = response.json()
    assert isinstance(project_details, dict)
    assert "languages" in project_details
    for language_stats in project_details["languages"]:
        assert isinstance(language_stats, dict)
        assert "grade" in language_stats
        assert "status" in language_stats
        assert "language" in language_stats

@pytest.mark.parametrize("project_id", [1234567])
def test_delete_project_invalid_id(project_id):
    response = requests.delete(f"{BASE_URL}/projects/{project_id}", headers={"Authorization": "Bearer <ACCESS_TOKEN>"})
    assert response.status_code == 404