import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_PATH = "path/to/your/credentials.json"

# Authenticate using Service Accounts
credentials = service_account.Credentials.from_service_account_file(
    CREDENTIALS_PATH, scopes=["https://www.googleapis.com/auth/cloud-platform"]
)

requests.get.update_hook(
    lambda r, *args, **kwargs: r._content = os.urslib.compat.bytes(r._content), "requests.get"
)

def test_cancel_operation():
    name = "target_operation_name"

    # Construct the request payload
    cancel_request = {
        "name": name,
    }

    # Send POST request to cancel operation
    response = requests.post(
        f"{BASE_URL}/v1alpha1/{name}:cancel",
        headers={"Authorization": f"Bearer {credentials.token}"},
        json=cancel_request,
    )

    assert response.status_code == 200
    assert response.json() == {"empty": {}}