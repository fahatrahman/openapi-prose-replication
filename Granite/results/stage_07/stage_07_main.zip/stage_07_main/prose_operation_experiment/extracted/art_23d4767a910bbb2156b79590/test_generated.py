import os
import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

@pytest.fixture
def auth():
    """Mock authentication fixture"""
    return HTTPBasicAuth("username", "password")

def test_get_screenshot_cluster(auth):
    """Test GET request to retrieve a screenshot cluster"""
    url = f"{BASE_URL}/toolresults/v1beta3/projects/project_id/histories/history_id/executions/execution_id/clusters/cluster_id"
    response = requests.get(url, auth=auth)

    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "activity" in response.json()
    assert "clusterId" in response.json()
    assert "keyScreen" in response.json()
    assert "screens" in response.json()