import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
SESSION.mount("https://", HTTPAdapter(max_retries=10))
SESSION.mount("http://", HTTPAdapter(max_retries=10))

@pytest.fixture
def new_token():
    headers = {"Token": "your_silj_psppsygwerkjbd_yiuso"}

    response = SESSION.post(
        urljoin(BASE_URL, "/administration/token"),
        json={"entityToken": "some_uuid",
              "expirationDate": "2022-12-31T23:59:59Z",
              "userToken": "some_uuid"},
        headers=headers,
    )

    assert response.status_code == 200
    return response.json()

def test_new_token(new_token):
    token = new_token
    assert isinstance(token, str)