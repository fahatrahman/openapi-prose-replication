import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_api():
    owner = "test_owner"
    api = "test_api"
    headers = {
        "Authorization": "Bearer your_token_here"
    }
    response = requests.delete(f"{BASE_URL}/apis/{owner}/{api}", headers=headers)
    
    assert response.status_code == 200
    assert isinstance(response.json(), list)

def test_delete_api_not_found():
    owner = "nonexistent_owner"
    api = "nonexistent_api"
    headers = {
        "Authorization": "Bearer your_token_here"
    }
    response = requests.delete(f"{BASE_URL}/apis/{owner}/{api}", headers=headers)
    
    assert response.status_code == 404

def test_delete_api_forbidden():
    owner = "test_owner"
    api = "test_api"
    headers = {
        "Authorization": "Bearer invalid_token"
    }
    response = requests.delete(f"{BASE_URL}/apis/{owner}/{api}", headers=headers)
    
    assert response.status_code == 403