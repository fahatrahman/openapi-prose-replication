import os
import pytest
import requests
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def bigtable_client():
    """Create a Bigtable client."""
    credentials = None  # Replace this with actual authentication logic
    service = build('bigtable', 'v2', credentials=credentials)
    return service

def test_update_cluster(bigtable_client):
    """Test updating a cluster."""
    project_id = "your-project-id"
    instance_id = "your-instance-id"
    cluster_id = "your-cluster-id"

    cluster = {
        "name": f"projects/{project_id}/instances/{instance_id}/clusters/{cluster_id}",
        "clusterConfig": {
            "clusterAutoscalingConfig": {
                "autoscalingTargets": {
                    "cpuUtilizationPercent": 50,
                    "storageUtilizationGibPerNode": 1024
                }
            }
        },
        "serveNodes": 10
    }

    try:
        response = bigtable_client.projects().instances().clusters().update(
            name=cluster["name"],
            body=cluster
        ).execute()

        assert response['name'] == cluster["name"]
        assert response['clusterConfig']['clusterAutoscalingConfig']['autoscalingTargets']['cpuUtilizationPercent'] == 50
        assert response['clusterConfig']['clusterAutoscalingConfig']['autoscalingTargets']['storageUtilizationGibPerNode'] == 1024
        assert response['serveNodes'] == 10

        print("Cluster updated successfully.")

    except HttpError as error:
        print(f"An error occurred: {error}")