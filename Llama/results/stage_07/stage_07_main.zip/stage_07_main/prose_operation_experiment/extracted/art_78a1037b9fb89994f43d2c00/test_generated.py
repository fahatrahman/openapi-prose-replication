# pytest_openapi.py
import pytest
import json
import requests

BASE_URL = "http://openapi.test"

def test_create_workspace():
    url = f"{BASE_URL}/workspaces"
    headers = {"Content-Type": "application/json"}
    data = {
        "workspace": {
            "collections": [
                {"id": "e1fc3c38-a0b8-44a3-bd44-d753a96b2e9d", "name": "Straw hats", "uid": "8154-e1fc3c38-a0b8-44a3-bd44-d753a96b2e9d"}
            ],
            "description": "Some description",
            "environments": [{"id": "83a1aaa2-a204-4bd8-9b92-4d486918906b", "name": "env", "uid": "8154-83a1aaa2-a204-4bd8-9b92-4d486918906b"}],
            "mocks": [{"id": "cda672ef-1375-40e9-baee-e20ece8d7b65"}],
            "monitors": [{"id": "1e889bd2-3862-4be0-b2c2-9b1fe9673aec"}],
            "name": "New Workspace",
            "type": "personal"
        }
    }

    response = requests.post(url, headers=headers, data=json.dumps(data))
    assert response.status_code == 200
    response_data = response.json()
    workspace_id = response_data["workspace"]["id"]
    assert workspace_id is not None

    # Verify workspace was created correctly
    get_url = f"{url}/{workspace_id}"
    get_response = requests.get(get_url)
    assert get_response.status_code == 200
    get_response_data = get_response.json()
    assert get_response_data["workspace"]["id"] == workspace_id
    assert get_response_data["workspace"]["name"] == "New Workspace"