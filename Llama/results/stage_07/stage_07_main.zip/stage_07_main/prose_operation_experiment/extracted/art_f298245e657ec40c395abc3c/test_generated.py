# -*- coding: utf-8 -*-

import pytest
import requests
from typing import Dict

BASE_URL = "http://openapi.test"

def test_patch_topic_state():
    # Create a valid JSON payload
    topic_state: Dict[str, str] = {
        "name": "/v1alpha/my-topic-state",
        "dismissed": "false",
        "saved": "false"
    }

    # Convert the dictionary into a JSON formatted string
    json_payload = {"topicState": topic_state}

    # Convert the JSON payload into a JSON formatted string
    json_str = '{"topicState": {"name": "/v1alpha/my-topic-state", "dismissed": "false", "saved": "false"}}'

    # Send a PATCH request to the specified endpoint
    response = requests.patch(
        f"{BASE_URL}/v1alpha/{topic_state['name']}",
        headers={"Content-Type": "application/json"},
        params={
            "$.xgafv": "1",
            "access_token": "",
            "alt": "json",
            "callback": "",
            "fields": "",
            "key": "",
            "oauth_token": "",
            "prettyPrint": "false",
            "quotaUser": "",
            "upload_protocol": "raw",
            "uploadType": "media"
        },
        data=json_str,
        json=json_payload
    )

    # Check if the response was successful
    assert response.status_code == 200