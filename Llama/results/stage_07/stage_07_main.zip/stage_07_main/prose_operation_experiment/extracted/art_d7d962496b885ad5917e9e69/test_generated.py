# -*- coding: utf-8 -*-
import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

def test_get_integration_branding():
    platform_key = 'your_platform_key'
    auth = HTTPBasicAuth('username', 'password')
    response = requests.get(f'{BASE_URL}/config/integrations/{platform_key}/branding', auth=auth)
    assert response.status_code == 200
    branding = response.json()
    assert branding['sourceId'] is not None
    logo_full = branding['logo']['full']
    assert logo_full['image'] is not None
    assert logo_full['image']['alt'] is not None
    assert logo_full['image']['src'] is not None