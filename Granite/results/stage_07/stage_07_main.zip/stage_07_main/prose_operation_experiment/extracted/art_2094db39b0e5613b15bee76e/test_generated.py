import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup a session with retries for idempotent requests
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def client():
    return session

def test_get_court_types(client):
    url = f"{BASE_URL}/masterData/courtType"

    # Test case for successful response
    response = client.get(url, params={"q": "courtTypeId:\"COTPm8jjc2PAydpFhq\""})
    assert response.status_code == 200
    court_types = response.json()["courtTypeArray"]
    assert len(court_types) == 1
    assert court_types[0]["courtTypeId"] == "COTPm8jjc2PAydpFhq"
    assert court_types[0]["name"] == "State"

    # Test case for invalid input query
    response = client.get(url, params={"q": "courtTypId:\"COTPm8jjc2PAydpFhq\""})
    assert response.status_code == 400
    exception = response.json()
    assert exception["code"] == "UN400"
    assert exception["message"] == "INVALID_INPUT"
