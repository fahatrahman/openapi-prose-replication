import pytest
import requests
from jsonschema import ValidationError, SchemaError

BASE_URL = "http://openapi.test"

def test_get_pension_from_employer():
    url = f"{BASE_URL}/Employer/{EmployerId}/Pension/{PensionId}"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }

    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    try:
        response.json()
    except ValidationError as err:
        print(err)
        assert False
    except SchemaError as err:
        print(err)
        assert False

@pytest.fixture
def EmployerId():
    return "ER001"

@pytest.fixture
def PensionId():
    return "PEN001"