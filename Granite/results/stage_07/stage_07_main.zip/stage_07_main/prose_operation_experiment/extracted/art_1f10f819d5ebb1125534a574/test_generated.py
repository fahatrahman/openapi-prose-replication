import os
import json
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session for the requests
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

@pytest.fixture
def get_sample_data():
    payload = {
        "S3SourceConfig": {
            "FileFormatDescriptor": {
                "CsvFormatDescriptor": {
                    "Charset": "utf-8",
                    "ContainsHeader": True,
                    "Delimiter": ",",
                    "FileCompression": "NONE",
                    "HeaderList": [],
                    "QuoteSymbol": "\""
                }
            },
            "HistoricalDataPathList": [
                "s3://bucket/path/"
            ],
            "RoleArn": "arn:aws:iam::account-id:role/role-name",
            "TemplatedPathList": []
        }
    }

    headers = {
        "Content-Type": "application/json"
    }

    response = session.post(
        f"{BASE_URL}/GetSampleData",
        headers=headers,
        data=json.dumps(payload),
        verify=False # Disable SSL verification for local testing
    )

    assert response.status_code == 200
    return response.json()

def test_get_sample_data(get_sample_data):
    assert isinstance(get_sample_data, dict)
    assert 'HeaderValues' in get_sample_data
    assert 'SampleRows' in get_sample_data