import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_menu_deal_groups():
    url = f"{BASE_URL}/restaurants/uk/95224345321/catalogue/items/534685/dealgroups"
    params = {
        "limit": 2,
        "after": "NDMyNzQyODI3OTQw"
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 200
    assert "dealGroups" in response.json()
    assert isinstance(response.json()["dealGroups"], list)
    assert all(isinstance(item, dict) for item in response.json()["dealGroups"])
    assert "id" in next(iter(response.json()["dealGroups"]))
    assert "name" in next(iter(response.json()["dealGroups"]))
    assert "numberOfChoices" in next(iter(response.json()["dealGroups"]))

def test_get_menu_deal_groups_invalid_limit():
    url = f"{BASE_URL}/restaurants/uk/95224345321/catalogue/items/534685/dealgroups"
    params = {
        "limit": 0,
        "after": "NDMyNzQyODI3OTQw"
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 400
    assert "errors" in response.json()
    assert isinstance(response.json()["errors"], list)
    assert any(error["description"] == "Invalid value 0 for parameter limit." for error in response.json()["errors"])

def test_get_menu_deal_groups_not_found():
    url = f"{BASE_URL}/restaurants/uk/95224345321/catalogue/items/99999999999/dealgroups"
    params = {
        "limit": 2,
        "after": "NDMyNzQyODI3OTQw"
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 404
    assert "errors" in response.json()
    assert isinstance(response.json()["errors"], list)
    assert any(error["description"].startswith("Resource with identifier") for error in response.json()["errors"])

def test_get_menu_deal_groups_internal_server_error(monkeypatch):
    def mock_response(*args, **kwargs):
        return requests.Response(status_code=500, json={"errors": [{"description": "Internal Server Error"}], "faultId": "25bbe062-c53d-4fbc-9d6c-3df6127b94fd", "traceId": "H3TKh4QSJUSwVBCBqEtkKw=="})
    
    monkeypatch.setattr(requests, 'get', mock_response)
    
    url = f"{BASE_URL}/restaurants/uk/95224345321/catalogue/items/534685/dealgroups"
    params = {
        "limit": 2,
        "after": "NDMyNzQyODI3OTQw"
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 500
    assert "errors" in response.json()
    assert isinstance(response.json()["errors"], list)
    assert any(error["description"] == "Internal Server Error" for error in response.json()["errors"])