import pytest
import requests

BASE_URL = "http://openapi.test"

def test_teams_by_season():
    url = f"{BASE_URL}/json/Teams/2015REG"
    headers = {
        "Ocp-Apim-Subscription-Key": "your_subscription_key_here"
    }
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    assert isinstance(response.json(), list)
    for team in response.json():
        assert isinstance(team, dict)
        assert "Name" in team
        assert "PlayerID" in team
        assert isinstance(team["PlayerID"], int)

if __name__ == "__main__":
    pytest.main()