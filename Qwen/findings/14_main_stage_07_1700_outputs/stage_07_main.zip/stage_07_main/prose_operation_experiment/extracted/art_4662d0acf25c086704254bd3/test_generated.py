import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_api_mapping():
    url = f"{BASE_URL}/v2/domainnames/example-domain/apimappings/example-id"
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20130524/us-east-1/sts/aws4_request",
        "X-Amz-Date": "20130524T000000Z",
        "X-Amz-Security-Token": "AQoDYXdzEPT//////////wEaDDtNp+HjW5JmOuGzDdUqJkxg==",
        "X-Amz-Signature": "f478d3c247d62ee9890415380e50ed83cbeff46ee7fa78cbada8b4c1edfadec7",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-security-token;x-amz-signal"
    }
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    assert "ApiId" in response.json()
    assert "ApiMappingId" in response.json()
    assert "ApiMappingKey" in response.json()
    assert "Stage" in response.json()

if __name__ == "__main__":
    pytest.main()