import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_placement_groups():
    params = {
        "sort": "id",
        "name": "my Placement Group",
        "label_selector": "key=value",
        "type": "spread"
    }
    response = requests.get(f"{BASE_URL}/placement_groups", params=params)
    assert response.status_code == 200
    data = response.json()
    assert "placement_groups" in data
    placement_groups = data["placement_groups"]
    assert isinstance(placement_groups, list)
    for group in placement_groups:
        assert "created" in group
        assert "id" in group
        assert "labels" in group
        assert "name" in group
        assert "servers" in group
        assert "type" in group
        assert isinstance(group["created"], str)
        assert isinstance(group["id"], int)
        assert isinstance(group["labels"], dict)
        assert isinstance(group["name"], str)
        assert isinstance(group["servers"], list)
        assert isinstance(group["type"], str)

if __name__ == "__main__":
    pytest.main()