import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_nh_fossil():
    fossil_name = "Spino Skull"
    headers = {
        "X-API-KEY": "your_api_key_here",
        "Accept-Version": "1.0.0"
    }
    params = {
        "thumbsize": 100
    }
    response = requests.get(f"{BASE_URL}/nh/fossils/individuals/{fossil_name}", headers=headers, params=params)
    
    assert response.status_code == 200
    fossil_data = response.json()
    assert "name" in fossil_data
    assert fossil_data["name"] == fossil_name
    assert "colors" in fossil_data
    assert isinstance(fossil_data["colors"], list)
    assert "fossil_group" in fossil_data
    assert "hha_base" in fossil_data
    assert "image_url" in fossil_data
    assert "interactable" in fossil_data
    assert "length" in fossil_data
    assert "sell" in fossil_data
    assert "url" in fossil_data
    assert "width" in fossil_data

def test_get_nh_fossil_unauthorized():
    fossil_name = "Spino Skull"
    headers = {
        "X-API-KEY": "invalid_api_key",
        "Accept-Version": "1.0.0"
    }
    response = requests.get(f"{BASE_URL}/nh/fossils/individuals/{fossil_name}", headers=headers)
    
    assert response.status_code == 401
    error_data = response.json()
    assert "title" in error_data
    assert error_data["title"] == "Failed to validate UUID."

def test_get_nh_fossil_internal_error():
    fossil_name = "NonExistentFossil"
    headers = {
        "X-API-KEY": "your_api_key_here",
        "Accept-Version": "1.0.0"
    }
    response = requests.get(f"{BASE_URL}/nh/fossils/individuals/{fossil_name}", headers=headers)
    
    assert response.status_code == 500
    error_data = response.json()
    assert "title" in error_data
    assert error_data["title"] == "API experienced a fatal error."