import pytest
import requests

BASE_URL = "http://openapi.test"

def test_dialogflow_projects_locations_agents_restore():
    url = f"{BASE_URL}/v3beta1/{'pkkenp'}:restore"
    headers = {
        'Content-Type': 'application/json'
    }
    body = {
        "agentContent": "byte string",
        "agentUri": "string",
        "restoreOption": "KEEP"
    }

    response = requests.post(url, headers=headers, json=body)
    assert response.status_code == 200
    operation = response.json()
    assert operation['done'] is False
    assert operation['metadata']['@type'] == 'type.googleapis.com/google.cloud.dialogflow.cx.v3beta1.RestoreAgentProgress'

def test_dialogflow_projects_locations_agents_restore_invalid_name():
    url = f"{BASE_URL}/v3beta1/{'invalid-name'}:restore"
    headers = {
        'Content-Type': 'application/json'
    }
    body = {
        "agentContent": "byte string",
        "agentUri": "string",
        "restoreOption": "KEEP"
    }

    response = requests.post(url, headers=headers, json=body)
    assert response.status_code == 400
    error = response.json()['error']
    assert error['code'] == 400
    assert error['message'] == 'Invalid agent name.'

def test_dialogflow_projects_locations_agents_restore_missing_body():
    url = f"{BASE_URL}/v3beta1/{'pkkenp'}:restore"
    headers = {
        'Content-Type': 'application/json'
    }

    response = requests.post(url, headers=headers)
    assert response.status_code == 400
    error = response.json()['error']
    assert error['code'] == 400
    assert error['message'] == 'Missing required fields.'