import pytest
import requests

BASE_URL = "http://openapi.test"

def get_pay_code_by_effective_date(employer_id, pay_code_id, effective_date, auth_token="Auto", api_version="default"):
    url = f"{BASE_URL}/Employer/{employer_id}/PayCode/{pay_code_id}/{effective_date}"
    headers = {
        "Authorization": auth_token,
        "Api-Version": api_version
    }
    response = requests.get(url, headers=headers)
    return response.json()

@pytest.mark.parametrize("employer_id, pay_code_id, effective_date, expected_status_code", [
    ("ER001", "BASIC", "2016-04-06", 200),
    ("ER001", "INVALID", "2016-04-06", 404),
    ("ER001", "BASIC", "INVALID_DATE", 400),
    ("INVALID_EMPLOYER", "BASIC", "2016-04-06", 401)
])
def test_get_pay_code_by_effective_date(employer_id, pay_code_id, effective_date, expected_status_code):
    response = get_pay_code_by_effective_date(employer_id, pay_code_id, effective_date)
    assert response.status_code == expected_status_code