import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_map():
    params = {
        "q.qid": "test_qid",
        "q.callback": "test_callback",
        "q.tablelist": "Y",
        "q.c1_lat": 38.798026,
        "q.c1_long": -77.062981,
        "q.c2_lat": 38.798026,
        "q.c2_long": -77.062981,
        "q.p_id": "test_p_id"
    }
    response = requests.get(f"{BASE_URL}/rcra_rest_services.get_map", params=params)
    assert response.status_code == 200
    assert "MapOutput" in response.json()