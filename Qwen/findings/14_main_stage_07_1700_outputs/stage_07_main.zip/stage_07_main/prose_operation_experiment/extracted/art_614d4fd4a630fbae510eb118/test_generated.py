import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_catalogs():
    url = f"{BASE_URL}/v2beta/projects/locations/catalogs"
    params = {
        "_xgafv": "2",
        "access_token": "your_access_token_here",
        "alt": "json",
        "prettyPrint": False,
        "quotaUser": "user@example.com",
        "uploadProtocol": "raw",
        "uploadType": "media",
        "pageSize": 50,
        "pageToken": ""
    }
    headers = {
        "Authorization": "Bearer your_oauth_token_here"
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    assert "catalogs" in response.json()
    assert isinstance(response.json()["catalogs"], list)

if __name__ == "__main__":
    pytest.main([__file__])