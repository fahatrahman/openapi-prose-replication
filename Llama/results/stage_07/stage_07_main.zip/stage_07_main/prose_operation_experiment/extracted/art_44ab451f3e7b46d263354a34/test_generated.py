# tests/test_tagmanager_accounts_containers_update.py
import pytest
import requests

BASE_URL = "http://openapi.test"

def test_tagmanager_accounts_containers_update():
    # Create a sample JSON payload for the request body
    json_payload = {
        "accountId": "sample_account_id",
        "containerId": "sample_container_id",
        "name": "Sample Container Name",
        "notes": "Sample Container Notes"
    }

    headers = {"Content-Type": "application/json"}

    response = requests.put(
        f"{BASE_URL}/tagmanager/v1/accounts/sample_account_id/containers/sample_container_id",
        headers=headers,
        json=json_payload
    )

    assert response.status_code == 200
    assert response.json() is not None