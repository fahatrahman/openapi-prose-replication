import pytest
import requests

BASE_URL = "http://openapi.test"

def test_post_holiday_scheme_into_employer():
    url = f"{BASE_URL}/Employer/ER001/HolidaySchemes"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    payload = {
        "HolidayScheme": {
            "Code": "HSC001",
            "SchemeName": "Test Scheme",
            "YearStartMonth": 1,
            "YearStartDay": 1,
            "EffectiveDate": "2023-01-01",
            "SchemeCeasedDate": None,
            "AllowNegativeBalance": False,
            "AllowExceedAnnualEntitlement": True,
            "BankHolidayInclusive": True,
            "MaxCarryOverDays": 365,
            "AnnualEntitlementWeeks": 52,
            "Revision": 1,
            "OffsetPayment": False,
            "AccrualPayCodes": {
                "PayCode": ["PC001", "PC002"]
            }
        }
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 201
    assert 'Location' in response.headers
    assert response.json() is not None

if __name__ == "__main__":
    pytest.main()