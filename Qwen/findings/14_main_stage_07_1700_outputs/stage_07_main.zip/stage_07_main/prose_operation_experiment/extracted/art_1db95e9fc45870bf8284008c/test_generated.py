import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_history():
    url = f"{BASE_URL}/toolresults/v1beta3/projects/project_id/histories/history_id"
    params = {
        "_xgafv": "1",
        "access_token": "access_token_value",
        "alt": "json",
        "callback": "callback_value",
        "fields": "fields_value",
        "key": "key_value",
        "oauth_token": "oauth_token_value",
        "prettyPrint": True,
        "quotaUser": "quota_user_value",
        "uploadType": "upload_type_value",
        "upload_protocol": "upload_protocol_value"
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    assert "displayName" in response.json()
    assert "historyId" in response.json()
    assert "name" in response.json()
    assert "testPlatform" in response.json()

if __name__ == "__main__":
    pytest.main()