import pytest
import requests
from requests.exceptions import HTTPError

BASE_URL = "http://openapi.test"

def get_update_group_subscriptions(update_group_id=None, package_type_id=None, client_id=None, limit=10, offset=0):
    url = f"{BASE_URL}/api/v2/UpdateGroupSubscriptions"
    params = {}

    if update_group_id:
        params["UpdateGroupID"] = update_group_id
    if package_type_id:
        params["PackageTypeID"] = package_type_id
    if client_id:
        params["ClientID"] = client_id
    if limit:
        params["limit"] = limit
    if offset:
        params["offset"] = offset

    response = requests.get(url, params=params)

    if response.status_code == 200:
        return response.json()
    else:
        error_response = response.json()
        raise Exception(f"API Request Failed with status {response.status_code}: {error_response['error']}")

@pytest.mark.parametrize("update_group_id,package_type_id,client_id,limit,offset", [
    (None, None, None, 10, 0),
    ("example_id", None, None, 5, 0),
    (None, "example_type_id", None, 10, 0),
    (None, None, "example_client_id", 10, 0),
    (None, None, None, 20, 10),
])
def test_get_update_group_subscriptions(update_group_id, package_type_id, client_id, limit, offset):
    try:
        result = get_update_group_subscriptions(update_group_id, package_type_id, client_id, limit, offset)
        assert isinstance(result, dict)
        assert all(key in result for key in ["Metadata", "Entities"])
    except Exception as e:
        pytest.fail(f"Test failed with exception: {str(e)}")