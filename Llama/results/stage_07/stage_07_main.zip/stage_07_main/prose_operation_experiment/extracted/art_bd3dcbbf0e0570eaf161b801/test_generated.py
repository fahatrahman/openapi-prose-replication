# -*- coding: utf-8 -*-
import pytest
import requests

BASE_URL = "http://openapi.test"

def test_query_status_names_v1_asn_status_all_get():
    url = f"{BASE_URL}/v1/asn/status/all"
    headers = {"Authorization": "Bearer"}
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    
    data = response.json()
    assert isinstance(data, list)
    
    for item in data:
        assert isinstance(item, dict)
        assert "code" in item
        assert "name" in item
        assert "self" in item
        
        assert isinstance(item["code"], str)
        assert isinstance(item["name"], str)
        assert isinstance(item["self"], str)

if __name__ == "__main__":
    pytest.main([__file__])