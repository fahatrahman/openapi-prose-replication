# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_get_monatsbelege():
    url = f"{BASE_URL}/registrierkassen/{'some_registrierkasseUuid'}"
    params = {"year": 2022, "month": 12}
    
    response = requests.get(url, headers={"Authorization": "Bearer some_jwt_token"}, params=params)
    response.raise_for_status()
    
    assert response.json()[0]["Jahr"] == 2022
    assert response.json()[0]["Monat"] == 12
    
    # Validate date format in FON-Geprueft-Datum-Uhrzeit field
    monatsbeleg = response.json()[0]
    date_string = monatsbeleg["FON-Geprueft-Datum-Uhrzeit"]
    try:
        datetime.fromisoformat(date_string)
    except ValueError:
        pytest.fail(f"Invalid date string: {date_string}")
    
    assert monatsbeleg["FON-Geprueft-Erfolgreich"]

def test_get_monatsbelege_without_year_and_month_query_params():
    url = f"{BASE_URL}/registrierkassen/{'some_registrierkasseUuid'}"
    
    response = requests.get(url, headers={"Authorization": "Bearer some_jwt_token"})
    response.raise_for_status()
    
    assert len(response.json()) > 0
    
def test_get_monatsbelege_with_invalid_year_query_param():
    url = f"{BASE_URL}/registrierkassen/{'some_registrierkasseUuid'}"
    params = {"year": "invalid", "month": 12}
    
    response = requests.get(url, headers={"Authorization": "Bearer some_jwt_token"}, params=params)
    assert response.status_code == 422
    
def test_get_monatsbelege_with_invalid_month_query_param():
    url = f"{BASE_URL}/registrierkassen/{'some_registrierkasseUuid'}"
    params = {"year": 2022, "month": "invalid"}
    
    response = requests.get(url, headers={"Authorization": "Bearer some_jwt_token"}, params=params)
    assert response.status_code == 422