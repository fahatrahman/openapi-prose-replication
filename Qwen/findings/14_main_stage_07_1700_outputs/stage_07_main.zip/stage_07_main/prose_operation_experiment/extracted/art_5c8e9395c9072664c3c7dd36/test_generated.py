import pytest
import requests

BASE_URL = "http://openapi.test"

def test_retrieve_hook():
    hook_id = 123  # Replace with actual hook ID
    authtoken = "your_authtoken_here"  # Replace with actual authtoken
    login = "your_login_here"  # Replace with actual login

    url = f"{BASE_URL}/hooks/{hook_id}.json"
    params = {
        "authtoken": authtoken,
        "login": login
    }

    response = requests.get(url, params=params)

    assert response.status_code == 200
    assert 'hook' in response.json()

def test_retrieve_nonexistent_hook():
    non_existent_id = 999999  # Use a non-existent ID
    authtoken = "your_authtoken_here"  # Replace with actual authtoken
    login = "your_login_here"  # Replace with actual login

    url = f"{BASE_URL}/hooks/{non_existent_id}.json"
    params = {
        "authtoken": authtoken,
        "login": login
    }

    response = requests.get(url, params=params)

    assert response.status_code == 404
    assert response.json() == {"message": "Hook Not Found."}