import os
import json
import pytest
from requests import Session

BASE_URL = "http://openapi.test"
SESSION = Session()


@pytest.fixture(scope="function")
def setup():
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "mijaldfa/20220406/us-west-2/s3/aws4_request",
        "X-Amz-Date": "20220406T000000Z",
        "X-Amz-Expires": "3600",
        "X-Amz-SignedHeaders": "host;x-amz-algorithm;x-amz-credential;x-amz-date;x-amz-expires",
        "X-Amz-Security-Token": "AKIAIOSFODNN7EXAMPLE",
    }

    return SESSION, headers


def test_describe_cluster(setup):
    session, headers = setup

    cluster_arn = "arn:aws:eks:us-west-2:123456789012:cluster/my-cluster"

    response = session.get(
        f"{BASE_URL}/cluster/{cluster_arn}", headers=headers
    )

    assert response.status_code == 200

    describe_cluster_response = response.json()
    assert "Cluster" in describe_cluster_response
    cluster = describe_cluster_response["Cluster"]
    assert all(key in cluster for key in ["ClusterArn", "ClusterEndpoints", "Name", "Status"])
