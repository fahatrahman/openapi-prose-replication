import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_get_contacts_lists():
    # Define query parameters
    offset = 0
    limit = 10
    sort = "-created"

    # Construct URL
    url = f"{BASE_URL}/contacts/lists"
    params = {"offset": offset, "limit": limit, "sort": sort}

    try:
        response = requests.get(url, headers={"Authorization": "mqApiKey"}, params=params)
        response.raise_for_status()
        assert response.json()["page"][0]["_id"]
    except requests.exceptions.HTTPError as errh:
        print(f"HTTP Error occurred: {errh}")
        raise
    except Exception as e:
        print(f"An error occurred: {e}")
        raise

def test_invalid_offset():
    # Define invalid query parameter
    offset = -1

    # Construct URL
    url = f"{BASE_URL}/contacts/lists"
    params = {"offset": offset, "limit": 10, "sort": "-created"}

    try:
        response = requests.get(url, headers={"Authorization": "mqApiKey"}, params=params)
        response.raise_for_status()
        assert False, "Expected 422 response for invalid offset"
    except requests.exceptions.HTTPError as errh:
        if errh.response.status_code == 422:
            pass
        else:
            raise
    except Exception as e:
        print(f"An error occurred: {e}")
        raise