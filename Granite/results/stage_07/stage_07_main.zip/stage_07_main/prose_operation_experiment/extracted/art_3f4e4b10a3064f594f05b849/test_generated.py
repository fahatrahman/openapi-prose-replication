import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
BASE_URL = "http://openapi.test"

# Define custom retry strategy for handling rate limiting and other transient errors
class OpenApiRetryStrategy(Retry):
    def __init__(self):
        super().__init__(
            total=3,  # Number of retries
            backoff_factor=0.1,  # Factor by which to multiply wait time
            status_forcelist=[
                429,  # Carry on if we get a 429 (Too Many Requests)
                500,  # Carry on if we get a 500 (Internal Server Error)
                503,  # Carry on if we get a 503 (Service Unavailable)
                504,  # Carry on if we get a 504 (Gateway Timeout)
            ],
            allowed_methods=["POST"]  # Only retry POST requests
        )

# Configure session with custom retry strategy
session = requests.Session()
session.mount("https://", HTTPAdapter(max_retries=OpenApiRetryStrategy()))
session.mount("http://", HTTPAdapter(max_retries=OpenApiRetryStrategy()))

@pytest.mark.parametrize(
    "input_data,expected_status",
    [
        ({
            "IdentityProvider": {
                "ActiveDirectoryIdentityProvider": {
                    "DirectoryId": "test-directory-id"
                }
            },
            "InstanceId": "test-instance-id",
            "Username": "test-username"
        }, 200),
        # Add more test cases here...
    ],
)
def test_disassociate_user(input_data, expected_status):
    url = f"{BASE_URL}/user/DisassociateUser"

    response = session.post(url, json=input_data)

    assert response.status_code == expected_status
    assert response.headers["Content-Type"] == "application/json"