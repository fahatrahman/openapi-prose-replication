import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_playlist_privacy_policies():
    response = requests.get(f"{BASE_URL}/api/v1/video-playlists/privacies")
    assert response.status_code == 200
    assert isinstance(response.json(), list)
    assert all(isinstance(item, str) for item in response.json())