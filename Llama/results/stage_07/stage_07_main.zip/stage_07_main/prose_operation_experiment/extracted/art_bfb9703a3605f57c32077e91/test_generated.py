# -*- coding: utf-8 -*-
"""Tests for the /servers/{id}/actions/remove_from_placement_group endpoint."""

import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_remove_from_placement_group():
    """Test removing a server from a placement group."""
    
    # Construct the full URL for the request
    url = f"{BASE_URL}/servers/123/actions/remove_from_placement_group"
    
    # Define the JSON payload for the request
    payload = {}
    
    # Send the POST request
    response = requests.post(url, json=payload)
    
    # Check that the request was successful
    assert response.status_code == 201
    
    # Parse the JSON response
    response_json = response.json()
    
    # Check that the response matches the expected schema
    assert response_json["action"]["command"] == "remove_from_placement_group"
    assert response_json["action"]["status"] == "success"
    
    # Check that the action has finished
    finished_at = response_json["action"]["finished"]
    assert isinstance(finished_at, str) or finished_at is None
    if finished_at:
        assert datetime.fromisoformat(finished_at) >= datetime.fromisoformat(response_json["action"]["started"])
    
    # Check that the action resources are valid
    resources = response_json["action"]["resources"]
    assert all(isinstance(resource, dict) for resource in resources)
    assert all("id" in resource and "type" in resource for resource in resources)

if __name__ == "__main__":
    pytest.main([__file__])