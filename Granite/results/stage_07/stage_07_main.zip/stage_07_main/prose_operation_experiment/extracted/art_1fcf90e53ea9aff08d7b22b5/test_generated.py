import os
import requests
import pytest

BASE_URL = "http://openapi.test"
HEADERS = {"Authorization": "Bearer {token}"}

@pytest.fixture
def auth_header():
    token = os.environ.get("API_TOKEN")
    if not token:
        pytest.skip("API token not provided")
    return HEADERS.format(token=token)

def test_get_sites(auth_header):
    response = requests.get(f"{BASE_URL}/org/sites", headers=auth_header)

    assert response.status_code == 200, f"Unexpected status code: {response.status_code}"
    assert isinstance(response.json(), list), "Response content type should be a list"