import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

requests.packages.urllib3.disable_warnings()
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

@pytest.fixture
def client():
    return session

def test_merge_balance(client):
    url = f"{BASE_URL}/mergeBalance"

    # Prepare the request body
    request_body = {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "reference": "UNIQUE_REFERENCE",
        "paymentMethod": {"type": "scheme", "storedValue": {}},
        "sourcePaymentMethod": {"type": "scheme", "storedValue": {}}
    }

    headers = {"Content-Type": "application/json"}

    try:
        response = client.post(url, json=request_body, headers=headers, auth=('YOUR_USERNAME', 'YOUR_PASSWORD'))

        assert response.status_code == 200

        response_data = response.json()
        print("pspReference:", response_data['pspReference'])
        print("resultCode:", response_data['resultCode'])
        print("currentBalance:", response_data['currentBalance'])

    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")