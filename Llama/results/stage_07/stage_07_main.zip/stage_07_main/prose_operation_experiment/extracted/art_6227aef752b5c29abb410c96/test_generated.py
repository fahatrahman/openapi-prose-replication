# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_discussion_comment():
    topic_id = 12345
    comment_data = {
        "author": {"id": 67890},
        "authorName": None,
        "created": datetime.now().isoformat(),
        "entry": {},
        "id": 54321,
        "message": "This is a comment"
    }

    response = requests.post(
        f"{BASE_URL}/api/discussions/topics/{topic_id}/comments",
        json=comment_data,
        headers={"Content-Type": "application/json"}
    )

    assert response.status_code == 200
    assert response.json() == comment_data