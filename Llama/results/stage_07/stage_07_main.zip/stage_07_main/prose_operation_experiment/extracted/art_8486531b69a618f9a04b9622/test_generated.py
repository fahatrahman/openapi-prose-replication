# pytest_module.py

import pytest
import requests
from jsonschema import validate, ValidationError

BASE_URL = "http://openapi.test"

def test_get_oauth_rights():
    url = f"{BASE_URL}/oauth/rights"
    response = requests.get(url)

    assert response.status_code == 200
    
    try:
        schema = {
            "type": "object",
            "properties": {
                "description": {"type": "string"},
                "name": {"type": "string"}
            },
            "required": ["description", "name"]
        }
        validate(instance=response.json(), schema=schema)
    except ValidationError as e:
        pytest.fail(f"JSON validation failed: {e}")