import pytest
import requests

BASE_URL = "http://openapi.test"

def test_share_screenshot():
    params = {
        "id": 123,
        "note": "example note"
    }
    headers = {
        "key": "your_api_key_here"
    }
    response = requests.get(f"{BASE_URL}/screenshot/share", params=params, headers=headers)
    
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    for item in data:
        assert isinstance(item, dict)
        assert "id" in item
        assert "status" in item
        assert "url" in item
        assert item["status"] in ["error", "ok", "in_queue"]
        assert isinstance(item["id"], int)
        assert isinstance(item["url"], str)

def test_share_screenshot_error():
    params = {
        "id": 456,
        "note": "another example note"
    }
    headers = {
        "key": "your_api_key_here"
    }
    response = requests.get(f"{BASE_URL}/screenshot/share", params=params, headers=headers)
    
    assert response.status_code != 200
    data = response.json()
    assert isinstance(data, dict)
    assert "error" in data
    assert "id" in data
    assert "status" in data
    assert data["status"] in ["vb_nccns", "vysiycqcra", "iblcrnpw", "phbnl"]
    assert isinstance(data["id"], int)
    assert isinstance(data["error"], str)