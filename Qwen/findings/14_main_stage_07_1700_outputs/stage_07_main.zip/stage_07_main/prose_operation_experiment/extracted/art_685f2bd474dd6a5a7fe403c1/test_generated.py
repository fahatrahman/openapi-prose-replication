import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_attributes():
    url = f"{BASE_URL}/v1/name"
    params = {
        "_xgafv": "1",
        "access_token": "test_access_token",
        "alt": "json",
        "callback": "test_callback",
        "fields": "test_fields",
        "key": "test_key",
        "oauth_token": "test_oauth_token",
        "prettyPrint": True,
        "quotaUser": "test_quota_user",
        "uploadType": "test_upload_type",
        "upload_protocol": "test_upload_protocol"
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    assert "attributes" in response.json()
    assert isinstance(response.json()["attributes"], list)

if __name__ == "__main__":
    pytest.main([__file__])