import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_payees_invitation_status():
    url = f"{BASE_URL}/v4/payees/payors/9ac75325-5dcd-42d5-b992-175d7e0a035e/invitationStatus"
    params = {
        "payeeId": "2aa5d7e0-2ecb-403f-8494-1865ed0454e9",
        "invitationStatus": "ACCEPTED",
        "page": 1,
        "pageSize": 25
    }
    headers = {
        "Authorization": "Bearer ed73aa9a-b51b-44cb-a8e9-11e2fb85046b"
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 200
    assert response.json()["page"]["numberOfElements"] == 1
    assert response.json()["page"]["totalElements"] == 1
    assert response.json()["page"]["totalPages"] == 1
    assert response.json()["page"]["page"] == 1
    assert response.json()["page"]["pageSize"] == 25
    assert len(response.json()["links"]) == 5
    assert all("href" in link and "rel" in link for link in response.json()["links"])
    assert "payeeId" in response.json()["content"][0]
    assert isinstance(response.json()["content"][0]["payeeId"], str)