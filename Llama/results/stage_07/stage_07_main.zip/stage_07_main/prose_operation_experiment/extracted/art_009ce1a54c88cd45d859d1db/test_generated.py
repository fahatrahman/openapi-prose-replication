# -*- coding: utf-8 -*-
import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_get_cis_instruction_from_sub_contractor():
    employer_id = "ER001"
    sub_contractor_id = "SUB001"
    cis_instruction_id = "CIS001"
    auth_header = "Auto"
    api_version = "default"

    url = urljoin(BASE_URL, f"/Employer/{employer_id}/SubContractor/{sub_contractor_id}/CisInstruction/{cis_instruction_id}")
    headers = {
        "Authorization": auth_header,
        "Api-Version": api_version
    }

    response = requests.get(url, headers=headers)

    assert response.status_code == 200, f"Expected status code 200, got {response.status_code}"
    assert response.json()["CisLineTag"], "Missing CisLineTag field in response"
    assert response.json()["CisLineType"], "Missing CisLineType field in response"
    assert response.json()["Description"], "Missing Description field in response"
    assert response.json()["PayFrequency"] in ["Monthly", "Weekly"], "Invalid PayFrequency field in response"
    assert isinstance(response.json()["PeriodEnd"], int), "Invalid PeriodEnd field in response"
    assert isinstance(response.json()["PeriodStart"], int), "Invalid PeriodStart field in response"
    assert isinstance(response.json()["TaxYearEnd"], int), "Invalid TaxYearEnd field in response"
    assert isinstance(response.json()["TaxYearStart"], int), "Invalid TaxYearStart field in response"
    assert response.json()["UOM"] in ["NotSet", "Minute", "Hour", "Day", "Week", "Month", "Year", "Unit"], "Invalid UOM field in response"
    assert isinstance(response.json()["Units"], float), "Invalid Units field in response"
    assert isinstance(response.json()["VAT"], float), "Invalid VAT field in response"
    assert isinstance(response.json()["Value"], float), "Invalid Value field in response"