import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_company_account():
    url = f"{BASE_URL}/companies/YOUR_COMPANY_ACCOUNT"
    headers = {
        "X-API-Key": "YOUR_API_KEY",
        "Authorization": "Basic YOUR_BASIC_AUTH"
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    data = response.json()
    assert "dataCenters" in data
    assert "id" in data
    assert "name" in data
    assert "status" in data
    assert data["status"] == "Active"

if __name__ == "__main__":
    pytest.main()