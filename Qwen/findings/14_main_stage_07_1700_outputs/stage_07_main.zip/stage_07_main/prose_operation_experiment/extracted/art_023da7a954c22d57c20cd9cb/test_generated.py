import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_project():
    project_id = "pe-autfnhu-123"
    params = {
        "access_token": "your_access_token",
        "prettyPrint": False,
        "quotaUser": "user@example.com"
    }
    headers = {
        "Authorization": "Bearer your_oauth_token"
    }
    response = requests.get(f"{BASE_URL}/v1/projects/{project_id}", params=params, headers=headers)
    assert response.status_code == 200
    assert "name" in response.json()
    assert response.json()["name"] == project_id

if __name__ == "__main__":
    pytest.main([__file__])