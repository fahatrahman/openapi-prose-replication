import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_issuer():
    resource_id = "test_resource_id"
    params = {
        "_xgafv": "1",
        "access_token": "test_access_token",
        "alt": "json",
        "callback": "test_callback",
        "fields": "test_fields",
        "key": "test_key",
        "oauth_token": "test_oauth_token",
        "prettyPrint": True,
        "quotaUser": "test_quota_user",
        "uploadType": "test_upload_type",
        "upload_protocol": "test_upload_protocol"
    }
    response = requests.get(f"{BASE_URL}/walletobjects/v1/issuer/{resource_id}", params=params)
    assert response.status_code == 200
    assert "application/json" in response.headers["Content-Type"]
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()