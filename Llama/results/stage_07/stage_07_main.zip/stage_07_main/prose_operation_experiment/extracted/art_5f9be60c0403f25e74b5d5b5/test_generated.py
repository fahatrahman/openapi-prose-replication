# -*- coding: utf-8 -*-
"""Tests for Twilio Messaging V1 Brand Registrations."""

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_brand_registrations():
    """Test ListBrandRegistrations."""
    
    # Set headers
    auth = ('your_account_sid', 'your_auth_token')  # Replace with your credentials
    
    url = f"{BASE_URL}/v1/a2p/BrandRegistrations"
    
    response = requests.get(url, auth=auth)
    
    assert response.status_code == 200