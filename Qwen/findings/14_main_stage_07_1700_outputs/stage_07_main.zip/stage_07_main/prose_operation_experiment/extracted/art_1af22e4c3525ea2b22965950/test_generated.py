import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_domain():
    domain_name = "example.com"
    response = requests.get(f"{BASE_URL}/domains/{domain_name}", params={"domain_name": domain_name})
    assert response.status_code == 200
    domain_detail = response.json()
    assert isinstance(domain_detail, dict)
    assert "domain_name" in domain_detail
    assert "expiration_date" in domain_detail
    assert "name_servers" in domain_detail
    assert "registrant" in domain_detail
    assert "can_toggle_renew" in domain_detail
    assert "will_renew" in domain_detail
    for name_server in domain_detail["name_servers"]:
        assert "ip" in name_server
        assert "name" in name_server
    assert "address" in domain_detail["registrant"]
    assert "city" in domain_detail["registrant"]
    assert "company_name" in domain_detail["registrant"]
    assert "country_code" in domain_detail["registrant"]
    assert "email" in domain_detail["registrant"]
    assert "enterprise_number" in domain_detail["registrant"]
    assert "fax" in domain_detail["registrant"]
    assert "first_name" in domain_detail["registrant"]
    assert "language_code" in domain_detail["registrant"]
    assert "last_name" in domain_detail["registrant"]
    assert "phone" in domain_detail["registrant"]
    assert "postal_code" in domain_detail["registrant"]

if __name__ == "__main__":
    pytest.main()