import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_networks():
    url = f"{BASE_URL}/v1/Networks"
    params = {
        "IsoCountry": "US",
        "Mcc": "310",
        "Mnc": "410",
        "PageSize": 50,
        "Page": 0,
        "PageToken": None
    }
    response = requests.get(url, params=params, auth=("your_account_sid", "your_auth_token"))
    assert response.status_code == 200
    response_data = response.json()
    assert "networks" in response_data
    for network in response_data["networks"]:
        assert "sid" in network
        assert len(network["sid"]) == 34
        assert network["sid"].startswith("HW")
        assert re.match(r'^HW[0-9a-fA-F]{32}$', network["sid"])