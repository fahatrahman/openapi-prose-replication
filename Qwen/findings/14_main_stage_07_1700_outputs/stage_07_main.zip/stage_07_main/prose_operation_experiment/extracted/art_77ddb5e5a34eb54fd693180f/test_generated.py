import pytest
import requests

BASE_URL = "http://openapi.test"

def test_fetch_health_profile_answer():
    url = f"{BASE_URL}/health_profile_answer/59d441ac21741161bbe266b5"
    params = {"include": "patient"}
    headers = {
        "Authorization": "Bearer your_access_token_here"
    }
    
    response = requests.get(url, params=params, headers=headers)
    
    assert response.status_code == 200
    data = response.json()
    assert "data" in data
    assert "type" in data["data"]
    assert data["data"]["type"] == "health_profile_answer"
    assert "id" in data["data"]
    assert "attributes" in data["data"]
    assert "history" in data["data"]["attributes"]
    assert "latest" in data["data"]["attributes"]
    assert "question_id" in data["data"]["attributes"]
    assert "relationships" in data["data"]
    assert "patient" in data["data"]["relationships"]
    assert "data" in data["data"]["relationships"]["patient"]
    assert "id" in data["data"]["relationships"]["patient"]["data"]
    assert "type" in data["data"]["relationships"]["patient"]["data"]

def test_fetch_health_profile_answer_unauthorized():
    url = f"{BASE_URL}/health_profile_answer/59d441ac21741161bbe266b5"
    params = {"include": "patient"}
    headers = {
        "Authorization": "Bearer invalid_token"
    }
    
    response = requests.get(url, params=params, headers=headers)
    
    assert response.status_code == 401
    error_response = response.json()
    assert "errors" in error_response
    assert len(error_response["errors"]) == 1
    error = error_response["errors"][0]
    assert "code" in error
    assert error["code"] == "Unauthorized"
    assert "detail" in error
    assert error["detail"] == "A valid bearer token is required"
    assert "status" in error
    assert error["status"] == "401"

def test_fetch_health_profile_answer_forbidden():
    url = f"{BASE_URL}/health_profile_answer/59d441ac21741161bbe266b5"
    params = {"include": "patient"}
    headers = {
        "Authorization": "Bearer forbidden_token"
    }
    
    response = requests.get(url, params=params, headers=headers)
    
    assert response.status_code == 403
    error_response = response.json()
    assert "errors" in error_response
    assert len(error_response["errors"]) == 1
    error = error_response["errors"][0]
    assert "code" in error
    assert error["code"] == "Forbidden"
    assert "detail" in error
    assert error["detail"] == "Access denied"
    assert "status" in error
    assert error["status"] == "403"