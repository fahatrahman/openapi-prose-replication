import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_data_sets():
    url = f"{BASE_URL}/v1/data-sets"
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20230101/us-east-1/service/aws4_request",
        "X-Amz-Date": "20230101T000000Z",
        "X-Amz-Security-Token": "AQoDYXdzEPT//////////wEXAMPLEtc7IRISlTMqV7sGE43DYOidAmzUepvMPxSuRTBHwvwMVG3FkKICszclQ==",
        "X-Amz-Signature": "EXAMPLESIGNATURE",
        "X-Amz-SignedHeaders": "host;x-amz-algorithm;x-amz-content-sha256;x-amz-credential;x-amz-date;x-amz-security-token;x-amz-signedheaders"
    }
    params = {
        "maxResults": 10,
        "nextToken": "",
        "origin": "OWNED"
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    assert "DataSets" in response.json()