import pytest
import requests
from datetime import datetime, timedelta

BASE_URL = "http://openapi.test"

def get_retention_settings(account_id):
    headers = {
        'X-Amz-Algorithm': '',
        'X-Amz-Content-Sha256': '',
        'X-Amz-Credential': '',
        'X-Amz-Date': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': '',
        'X-Amz-SignedHeaders': '',
        'Authorization': ''
    }
    
    params = {
        'accountId': account_id
    }

    response = requests.get(f"{BASE_URL}/accounts/{account_id}/retention-settings", 
                            headers=headers,
                            params=params)
    
    assert response.status_code == 200
    
    return response.json()

def test_get_retention_settings():
    response = get_retention_settings('test_account_id')
    assert 'InitiateDeletionTimestamp' in response
    assert 'RetentionSettings' in response
    assert 'ConversationRetentionSettings' in response['RetentionSettings']
    assert 'RoomRetentionSettings' in response['RetentionSettings']

if __name__ == '__main__':
    test_get_retention_settings()