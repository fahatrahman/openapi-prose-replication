import pytest
import requests

BASE_URL = "http://openapi.test"

def test_flight_status():
    url = f"{BASE_URL}/operations/flightstatus/LH400/2023-04-01"
    headers = {
        "Accept": "application/json"
    }
    params = {
        "limit": "20",
        "offset": "0"
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()