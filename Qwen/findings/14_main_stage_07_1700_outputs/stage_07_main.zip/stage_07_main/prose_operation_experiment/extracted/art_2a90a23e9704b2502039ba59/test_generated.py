import pytest
import requests

BASE_URL = "http://openapi.test"

def test_gdprExportHashFile():
    url = f"{BASE_URL}/v0.1/apps/owner_name/app_name/test/export/hashFiles"
    headers = {
        "X-API-Token": "your_api_token_here"
    }
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert "filename" in data
    assert "id" in data
    assert isinstance(data["id"], str)
    assert len(data["id"]) == 36  # UUID format