import pytest
import requests

BASE_URL = "http://openapi.test"

def test_search_detailed_lead_reports():
    url = f"{BASE_URL}/v1/detailedLeadReports:search"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token",
        "alt": "json",
        "callback": "your_callback",
        "fields": "your_fields",
        "key": "your_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": True,
        "quotaUser": "your_quota_user",
        "uploadType": "multipart",
        "upload_protocol": "raw",
        "endDate.day": 31,
        "endDate.month": 12,
        "endDate.year": 2023,
        "pageSize": 10,
        "pageToken": "your_page_token",
        "query": "your_query",
        "startDate.day": 1,
        "startDate.month": 1,
        "startDate.year": 2023
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    assert "detailedLeadReports" in response.json()

if __name__ == "__main__":
    pytest.main()