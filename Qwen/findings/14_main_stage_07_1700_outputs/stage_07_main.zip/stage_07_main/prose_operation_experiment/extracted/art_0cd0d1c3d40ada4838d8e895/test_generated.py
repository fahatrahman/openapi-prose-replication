import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_domain():
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "YOUR_CREDENTIALS",
        "X-Amz-Date": "DATE",
        "X-Amz-Security-Token": "YOUR_SECURITY_TOKEN",
        "X-Amz-Signature": "SIGNATURE",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-security-token"
    }
    domain_id = "your-domain-id"
    url = f"{BASE_URL}/domains/{domain_id}"
    response = requests.delete(url, headers=headers)
    
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()