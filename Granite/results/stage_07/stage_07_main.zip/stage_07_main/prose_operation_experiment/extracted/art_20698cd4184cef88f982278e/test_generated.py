import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retry strategy
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
session.mount("http://", adapter)
session.mount("https://", adapter)

@pytest.fixture
def product_modules():
    url = f"{BASE_URL}/productmodule"
    response = session.get(url)

    # Check for successful response
    assert response.status_code == 200, f"Request failed with status code {response.status_code}"

    return response.json()

def test_list_product_modules(product_modules):
    assert isinstance(product_modules, list)
    assert all(isinstance(item, dict) for item in product_modules)