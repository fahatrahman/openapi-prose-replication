import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retry logic
session = requests.Session()
retries = Retry(total=3, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
session.mount("http://", adapter)
session.mount("https://", adapter)

@pytest.fixture
def transaction_category():
    company_id = "8a210b68-6988-11ed-a1eb-0242ac120002"
    connection_id = "2e9d2c44-f675-40ba-8049-353bfcb5e171"
    transaction_category_id = "auto-and-transport"

    url = f"{BASE_URL}/companies/{company_id}/connections/{connection_id}/data/banking-transactionCategories/{transaction_category_id}"
    
    response = session.get(url)
    response.raise_for_status()

    return response.json()

def test_transaction_category(transaction_category):
    assert transaction_category["name"] == "Auto & Transport"
    assert transaction_category["status"] == "Active"
    assert isinstance(transaction_category["modifiedDate"], str)