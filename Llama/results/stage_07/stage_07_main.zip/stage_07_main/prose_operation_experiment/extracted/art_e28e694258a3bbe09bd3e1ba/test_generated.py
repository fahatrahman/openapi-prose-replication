# -*- coding: utf-8 -*-
import pytest
import requests
from datetime import datetime, timedelta
import hmac
import hashlib

BASE_URL = "http://openapi.test"

def list_invitations(max_results=10, next_token=None):
    params = {}
    if max_results:
        params["MaxResults"] = max_results
    if next_token:
        params["NextToken"] = next_token
    
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": calculate_content_sha256(),
        "X-Amz-Credential": get_aws_credential(),
        "X-Amz-Date": get_aws_date(),
        "X-Amz-Security-Token": get_security_token(),
        "X-Amz-Signature": calculate_signature(),
        "X-Amz-SignedHeaders": "host;x-amz-date"
    }

    response = requests.get(f"{BASE_URL}/invitations", params=params, headers=headers)
    
    assert response.status_code == 200
    
    return response.json()

def get_aws_credential():
    # Replace with your AWS credential
    return "your_aws_key_id/your_aws_secret_access_key"

def get_aws_date():
    now = datetime.now()
    return now.strftime("%Y%m%dT%H%M%SZ")

def get_security_token():
    # Replace with your security token
    return "your_security_token"

def calculate_content_sha256():
    # Calculate content SHA256 hash
    # This is a placeholder function, you need to implement it according to your needs
    return "your_content_sha256_hash"

def calculate_signature():
    # Calculate signature using HMAC-SHA256 algorithm
    key = get_hmac_key(get_aws_secret_access_key(), get_region())
    message = get_message()
    signature = hmac.new(key, message.encode('utf-8'), hashlib.sha256).hexdigest()
    return signature

def get_hmac_key(secret_access_key, region):
    date_key = hmac.new(b"AWS4Request", get_aws_date().encode('utf-8'), hashlib.sha256).digest()
    date_region_key = hmac.new(date_key, region.encode('utf-8'), hashlib.sha256).digest()
    service_key = hmac.new(date_region_key, b"s3/aws4_request", hashlib.sha256).digest()
    signing_key = hmac.new(service_key, b"aws4_request", hashlib.sha256).digest()
    return signing_key

def get_region():
    # Replace with your region
    return "your_region"

def get_aws_secret_access_key():
    # Replace with your AWS secret access key
    return "your_aws_secret_access_key"

def get_message():
    # Get request message
    return f"GET\n/{BASE_URL}\n/\nx-amz-date:{get_aws_date()}\nx-amz-target:/s3/ListBuckets\nhost:{BASE_URL}"

@pytest.mark.parametrize("max_results,next_token", [(10, None), (None, "token")])
def test_list_invitations(max_results, next_token):
    try:
        list_invitations(max_results, next_token)
    except AssertionError as e:
        pytest.fail(str(e))