# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_mybusiness_accounts_locations_clear_association():
    name = 'your_name'
    url = f"{BASE_URL}/v4/{name}:clearAssociation"
    headers = {
        'Content-Type': 'application/json',
    }
    body = {}
    response = requests.post(url, json=body, headers=headers)
    assert response.status_code == 200