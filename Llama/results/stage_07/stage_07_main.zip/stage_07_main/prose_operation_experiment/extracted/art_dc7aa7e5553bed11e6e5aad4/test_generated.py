# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_get_resolver():
    api_id = "test_api_id"
    type_name = "test_type_name"
    field_name = "test_field_name"

    auth_header = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Date": "20230227T144633Z",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20230227/us-east-1/execute-api/aws4_request",
        "X-Amz-Security-Token": "temporary_credentials",
        "X-Amz-Signature": "UNSIGNED",
        "X-Amz-SignedHeaders": "host"
    }

    headers = {"Authorization": "hmac"}
    params = {}
    url = urljoin(BASE_URL, f"/v1/apis/{api_id}/types/{type_name}/resolvers/{field_name}")

    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200

    # Test error cases
    for status_code in [480, 481, 482]:
        response = requests.get(url, headers=auth_header, params=params)
        assert response.status_code == status_code