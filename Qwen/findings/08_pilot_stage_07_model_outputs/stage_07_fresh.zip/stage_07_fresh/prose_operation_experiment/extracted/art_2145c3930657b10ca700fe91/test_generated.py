import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_client_metadata():
    url = f"{BASE_URL}/v1/projects/clientmetadata"
    params = {
        "parent": "projects/my-project",
        "_xgafv": "1",
        "access_token": "my-access-token",
        "alt": "json",
        "callback": "handleCallback",
        "fields": "properties.ipEnablementState,properties.provisionedRegions",
        "key": "my-api-key",
        "oauth_token": "my-oauth-token",
        "prettyPrint": False,
        "quotaUser": "user123",
        "uploadProtocol": "raw",
        "uploadType": "media"
    }
    headers = {
        "Authorization": "Bearer my-bearer-token"
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    assert "application/json" in response.headers["Content-Type"]
    data = response.json()
    assert "properties" in data
    properties = data["properties"]
    assert "ipEnablementState" in properties
    assert "provisionedRegions" in properties