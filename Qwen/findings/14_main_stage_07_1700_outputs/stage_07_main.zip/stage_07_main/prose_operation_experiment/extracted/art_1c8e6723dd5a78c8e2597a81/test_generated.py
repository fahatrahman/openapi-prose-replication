import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_plugin():
    npm_name = "peertube-plugin-auth-ldap"
    url = f"{BASE_URL}/api/v1/plugins/{npm_name}"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    plugin_data = response.json()
    assert "name" in plugin_data
    assert plugin_data["name"] == npm_name
    assert "description" in plugin_data
    assert "createdAt" in plugin_data
    assert "updatedAt" in plugin_data
    assert "version" in plugin_data
    assert "latestVersion" in plugin_data
    assert "enabled" in plugin_data
    assert "uninstalled" in plugin_data
    assert "peertubeEngine" in plugin_data
    assert "type" in plugin_data
    assert "homepage" in plugin_data
    assert "settings" in plugin_data

if __name__ == "__main__":
    pytest.main()