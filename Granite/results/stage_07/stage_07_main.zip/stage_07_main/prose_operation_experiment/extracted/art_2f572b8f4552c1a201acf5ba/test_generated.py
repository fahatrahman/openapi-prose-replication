import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retry logic for handling transient errors
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

@pytest.fixture
def songlist_for_edit():
    response = session.post(f"{BASE_URL}/api/songLists", json={
        "name": "Test Song List",
        "description": "This is a test song list.",
        "eventDate": "2022-12-31T23:59:59Z",
        "featuredCategory": "Other",
        "songLinks": [
            {
                "songInListId": 1,
                "notes": "A test song",
                "order": 1
            }
        ]
    })

    assert response.status_code == 200
    return response.json()["id"]