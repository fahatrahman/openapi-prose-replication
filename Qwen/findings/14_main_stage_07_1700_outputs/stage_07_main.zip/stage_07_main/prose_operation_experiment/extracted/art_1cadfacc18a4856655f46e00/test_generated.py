import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_insights():
    url = f"{BASE_URL}/v1/projects/-/locations/global/insightTypes/google.compute.instance.MissingInstanceGroups"
    params = {
        "_xgafv": "2",
        "access_token": "YOUR_ACCESS_TOKEN",
        "alt": "json",
        "callback": "onLoadCallback",
        "fields": "insights(name,stateInfo(state),content(grantedPermissionsCount))",
        "key": "YOUR_API_KEY",
        "oauth_token": "YOUR_OAUTH_TOKEN",
        "prettyPrint": True,
        "quotaUser": "user@example.com",
        "uploadType": "media",
        "upload_protocol": "raw",
        "filter": "stateInfo.state = ACTIVE AND severity = CRITICAL",
        "pageSize": 10,
        "pageToken": ""
    }
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()