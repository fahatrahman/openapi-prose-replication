import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_networks():
    url = f"{BASE_URL}/v1/Networks"
    params = {
        "IsoCountry": "US",
        "Mcc": "310",
        "Mnc": "410",
        "PageSize": 50,
        "Page": 0
    }
    response = requests.get(url, params=params, auth=("ACCOUNT_SID", "AUTH_TOKEN"))
    assert response.status_code == 200
    data = response.json()
    assert "networks" in data
    assert isinstance(data["networks"], list)
    assert all(isinstance(network, dict) for network in data["networks"])
    assert "sid" in next(iter(data["networks"]))