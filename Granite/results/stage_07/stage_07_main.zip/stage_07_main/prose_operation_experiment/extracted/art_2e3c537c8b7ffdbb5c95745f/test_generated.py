import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = "path/to/service_account.json"

# Setup Google API client credentials
credentials = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE, scopes=["https://www.googleapis.com/auth/cloud-platform"]
)

def test_purge_artifacts():
    parent = "zynntaco/your_autfnhu/yzvrewumc/your_vmdixebo/uygfpobrVnvmot/your_viuzchcddyfsn"

    payload = {
        "filter": "ieafpp_ykqg <= '2020-11-19T11:30:00-04:00'",
        "force": True
    }

    response = requests.post(
        f"{BASE_URL}/v1/{parent}/artifacts:purge",
        json=payload,
        auth=credentials,
        headers={"Content-Type": "application/json"},
    )

    assert response.status_code == 200

    operation_name = response.json()["name"]
    print(f"Operation started. Monitor its progress using: {BASE_URL}/{operation_name}")