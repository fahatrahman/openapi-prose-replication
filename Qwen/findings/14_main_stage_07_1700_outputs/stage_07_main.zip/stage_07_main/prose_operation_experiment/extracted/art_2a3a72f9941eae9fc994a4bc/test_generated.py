import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_managed_endpoints():
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20230101/us-east-1/emr-containers/aws4_request",
        "X-Amz-Date": "20230101T000000Z",
        "X-Amz-Security-Token": "AQoDYXdzEPT//////////wEaDDiJZ1l0VU1YU1RFR0VNQlVTVFVURUNUTU1UVEVTRVRJVFRURU5FUk9XQU5ERUFSQVRJT04vcGFzc3dvcmQtdG9rZW4=",
        "X-Amz-Signature": "EXAMPLESIGNATURE",
        "X-Amz-SignedHeaders": "host;x-amz-algorithm;x-amz-content-sha256;x-amz-credential;x-amz-date;x-amz-security-token;x-amz-signedheaders"
    }
    params = {
        "virtualClusterId": "example-virtual-cluster-id",
        "createdBefore": "2023-01-01T00:00:00Z",
        "createdAfter": "2022-01-01T00:00:00Z",
        "types": ["TYPE1", "TYPE2"],
        "states": ["ACTIVE", "CREATING"],
        "maxResults": 10,
        "nextToken": "example-next-token"
    }
    response = requests.get(f"{BASE_URL}/virtualclusters/{params['virtualClusterId']}/endpoints", headers=headers, params=params)
    assert response.status_code == 200
    assert "endpoints" in response.json()
    assert "nextToken" in response.json()

if __name__ == "__main__":
    pytest.main()