# -*- coding: utf-8 -*-
"""
Test suite for create_a_new_origin_token_v1_origin_token_new_post endpoint.

This test suite uses pytest and requests libraries to make HTTP requests to the API.
"""

import pytest
import json
import requests

BASE_URL = "http://openapi.test"

def test_create_a_new_origin_token():
    """
    Test creating a new origin token.
    """

    # Prepare the payload
    origin = {"origin": "https://example.com"}

    # Send POST request to /v1/origin_token/new endpoint
    response = requests.post(f"{BASE_URL}/v1/origin_token/new", 
                             headers={"Authorization": f"Bearer {None}"},
                             json=origin)

    # Check if the response is successful (200 OK)
    assert response.status_code == 200

    # Parse the response content as JSON
    response_json = response.json()

    # Check if the response matches the expected schema
    assert response_json["self"]
    assert response_json["region_id"]
    assert response_json["origin"]
    assert response_json["status"]
    assert isinstance(response_json["created_at"], int)
    assert isinstance(response_json["updated_at"], int)

    # Check if the status is either ENABLED or DISABLED
    assert response_json["status"] in ["ENABLED", "DISABLED"]

def test_create_a_new_origin_token_invalid_format():
    """
    Test creating a new origin token with invalid format.
    """

    # Prepare the payload
    origin = {"origin": "invalid"}

    # Send POST request to /v1/origin_token/new endpoint
    response = requests.post(f"{BASE_URL}/v1/origin_token/new", 
                             headers={"Authorization": f"Bearer {None}"},
                             json=origin)

    # Check if the response is unsuccessful (400 Bad Request)
    assert response.status_code == 422

    # Parse the response content as JSON
    response_json = response.json()

    # Check if the response matches the expected schema
    assert isinstance(response_json["detail"][0]["loc"][0], str) or isinstance(response_json["detail"][0]["loc"][0], int)
    assert isinstance(response_json["detail"][0]["msg"], str)
    assert isinstance(response_json["detail"][0]["type"], str)

def test_create_a_new_origin_token_already_exists():
    """
    Test creating a new origin token when it already exists.
    """

    # Prepare the payload
    origin = {"origin": "https://example.com"}

    # Send POST request to /v1/origin_token/new endpoint
    response = requests.post(f"{BASE_URL}/v1/origin_token/new", 
                             headers={"Authorization": f"Bearer {None}"},
                             json=origin)

    # Check if the response is unsuccessful (409 Conflict)
    assert response.status_code == 409