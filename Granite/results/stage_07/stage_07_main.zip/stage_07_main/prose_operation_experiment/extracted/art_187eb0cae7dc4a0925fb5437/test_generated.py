import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

session = requests.Session()
retry_strategy = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)

@pytest.fixture
def oauth2_token():
    return {
        "client_id": "<your_client_id>",
        "client_secret": "<your_client_secret>",
        "grant_type": "client_credentials",
        "scope": "read_shop_script_tags",
    }

def test_get_shop_script_tags(oauth2_token):
    url = f"{BASE_URL}/appstore/v1/script_tags.json"

    headers = {
        "Authorization": f"Bearer {requests.post('https://api.shop-pro.jp/oauth/token', json=oauth2_token).json()['access_token']}",
    }

    response = session.get(url, headers=headers)
    assert response.status_code == 200

    script_tags = response.json()["script_tags"]
    for script in script_tags:
        assert all(key in script for key in ["account_id", "display_scope", "id", "integrity", "make_date", "oauth_application_id", "src", "update_date"])
        assert script["display_scope"] in ["shop", "thanks_page"]
        assert script["src"].startswith("https://")