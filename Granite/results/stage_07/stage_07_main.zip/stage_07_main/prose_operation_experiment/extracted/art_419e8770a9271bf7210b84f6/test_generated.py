import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

# Custom session with retry logic for handling transient errors
class VTEXSession(requests.Session):
    def __init__(self):
        super().__init__()
        self.mount("https://", HTTPAdapter(max_retries=3))

session = VTEXSession()

@pytest.fixture
def create_purchase_information():
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
    }

    # The 'alternativeKey' parameter is optional according to the OpenAPI specification
    alternative_key = None

    profile_id = "70caf394-8534-447e-a0ca-1803c669c771"  # Example value, should be provided or dynamically set based on test context

    endpoint = urljoin(BASE_URL, "/api/storage/profile-system/profiles/{}/purchase-info".format(profile_id))

    response = session.post(endpoint, headers=headers, json={})

    assert response.status_code == 201

    return response.json()