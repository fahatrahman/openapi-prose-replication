import pytest
import requests

BASE_URL = "http://openapi.test"

def test_displayvideo_users_get():
    # Define the API endpoint URL
    url = f"{BASE_URL}/v3/users/{123}"

    # Define the headers and parameters for the request
    headers = {}
    params = {
        "$.xgafv": "1",
        "access_token": None,
        "alt": "json",
        "callback": None,
        "fields": None,
        "key": None,
        "oauth_token": None,
        "prettyPrint": False,
        "quotaUser": None,
        "upload_protocol": None,
        "uploadType": None
    }

    # Make the GET request
    response = requests.get(url, headers=headers, params=params)

    # Check if the request was successful
    assert response.status_code == 200

    # Parse the JSON response
    data = response.json()

    # Assert that the response matches the expected schema
    assert isinstance(data, dict)
    required_fields = ["displayName", "email", "lastLoginTime", "name", "userId"]
    for field in required_fields:
        assert field in data

# Run the tests
pytest.main([__file__, "-vv"])