# Notebook 09 · Cell 02 · Reconcile and score the complete pilot ledger

EVIDENCE = "data/evidence/"


def load_unavailable_review():
    matches = sorted(INPUT.rglob("evaluator_unavailable_review_completed.csv"))
    require(len(matches) == 1,
            "Attach exactly one evaluator_unavailable_review_completed.csv")
    raw = matches[0].read_bytes()
    rows = csv_rows(raw)
    required = {
        "task_id", "op_id", "artifact_id", "collection_status", "baseline_status",
        "request_ids", "reviewed_scenario_id", "baseline_id",
        "spec_evidence_pointer", "oracle_evidence_pointer", "decision",
        "rationale", "recommended_action",
    }
    require(rows and required <= set(rows[0]), "Unavailable review schema differs")
    decisions = Counter(row["decision"] for row in rows)
    require(len(rows) == 16 and decisions == Counter(
        TEST_CONSTRUCTION_DEFECT=15, EVALUATOR_LIMITATION=1),
        "Expected the completed 15 generated-test / 1 evaluator-limitation adjudication")
    require(all(row["task_id"] and row["op_id"] and row["artifact_id"]
                and row["request_ids"] and row["spec_evidence_pointer"]
                and row["oracle_evidence_pointer"] and row["rationale"]
                and row["recommended_action"]
                and row["reviewed_scenario_id"] and row["baseline_id"]
                for row in rows), "Unavailable review contains blank required evidence")
    return keyed(rows, lambda row: row["task_id"], "unavailable adjudication"), raw


def reconcile_review(evaluation, claims):
    require(evaluation.internal.get("checkpoint_c_complete") is True
            and evaluation.external.get("checkpoint_c_complete") is True,
            "Stage 08 has not completed Checkpoint C")
    by_blind = keyed(claims, lambda r: r["blind_claim_id"], "reviewed claims")
    require(all(k and r["review_status"] == "RECONCILED" for k, r in by_blind.items()), "Incomplete assertion review")
    r1, r2, r3 = [keyed(evaluation.csv(f"reviews/completed/reviewer_{i}.csv"),
                        lambda r: r["blind_claim_id"], f"Reviewer {i}") for i in (1, 2, 3)]
    sample = evaluation.json(EVIDENCE + "reviewer_2_frozen_sample.json")
    expected = sorted(random.Random(sample["seed"]).sample(sorted(by_blind), min(len(claims), 300)))
    require(sample["sampled_ids"] == expected and r2.keys() == set(expected)
            and r1.keys() == by_blind.keys(), "Incorrect frozen review coverage")
    disagreements = {k for k in r2 if r1[k]["label"] != r2[k]["label"]}
    require(r3.keys() == disagreements and all(r["adjudication_status"] == "COMPLETED" for r in r3.values()),
            "Incomplete Reviewer 3 decisions")
    labels = {"supported", "contradicted", "undocumented_or_unsupported", "ambiguous_or_unverifiable"}
    for number, decisions in enumerate((r1, r2, r3), 1):
        require(all(row["label"] in labels and row["reviewer_id"] == f"reviewer_{number}"
                    and row["reasoning"].strip() for row in decisions.values()), "Invalid recorded review")
    for k, row in by_blind.items():
        chosen = r3.get(k, r1[k])
        require(row["review_label"] == chosen["label"] and row["requirement_id"] == chosen["requirement_id"]
                and row["review_evidence_pointer"] == chosen["evidence_pointer"],
                "Final claim does not match the reconciled reviewer decision")
    internal = keyed(evaluation.jsonl(EVIDENCE + "assertion_claims_internal.jsonl"),
                     lambda r: r["claim_id"], "frozen assertion extraction")
    require(internal.keys() == {r["claim_id"] for r in claims}
            and all(all(row[k] == v for k, v in internal[row["claim_id"]].items()) for row in claims),
            "Frozen assertion frame differs from reviewed frame")


def expected_oracles(release, selection, partition):
    result = {}
    record_types = {"scenarios": "scenario_id", "baselines": "baseline_id",
                    "requirements": "requirement_id", "response_faults": "fault_id",
                    "legitimate_variations": "variation_id"}
    for op in selection:
        root = f"oracles/frozen/{partition}/{op}"
        records = {kind: release.jsonl(f"{root}/{kind}.jsonl") for kind in record_types}
        for kind, key in record_types.items():
            keyed(records[kind], lambda r: r[key], kind)
        records["faults"] = records["response_faults"]
        result[op] = records
    return result


def qualified_kill(row, fault, baseline, requests):
    if row["status"] != "KILLED_ASSERTION":
        return False
    target = row["replay_target"]
    attempt = requests.get(row.get("target_baseline_request_id"))
    item = target["pytest_item_id"]
    require(baseline["baseline_pass"] is True and row["killed"] is True and row["consumed"] is True
            and row["failure_attribution"] == "assertion" and attempt is not None
            and attempt["status"] == "DELIVERED" and attempt["task_id"] == row["task_id"]
            and attempt["pytest_item_id"] == item and item in row["attributed_assertion_item_ids"]
            and baseline["item_outcomes"].get(item) == "passed"
            and attempt.get("baseline_id") == fault["baseline_id"]
            and any(x.get("replay_mutation_applied") and x.get("fault_id") == fault["fault_id"]
                    and x.get("pytest_item_id") == item for x in row["request_attempts"]),
            "A claimed kill lacks a qualified assertion-linked replay")
    return True


def effective_check(claim, oracle, attempts, fault_rows):
    if claim["review_label"] != "supported" or claim["reachability"] != "REACHED":
        return None
    req = claim["requirement_id"]
    requirement = next((r for r in oracle["requirements"] if r["requirement_id"] == req), None)
    require(requirement is not None and requirement["source_pointer"] == claim["review_evidence_pointer"],
            "Supported claim lacks a corresponding frozen requirement")
    reached = set(claim["reached_item_ids"])
    delivered = [r for r in attempts if r["status"] == "DELIVERED"
                 and r["pytest_item_id"] in reached
                 and r.get("scenario_id") in claim["observed_scenario_ids"]]
    if not delivered:
        return None
    linked_faults = {r["fault_id"] for r in oracle["faults"] if r["requirement_id"] == req
                     and r.get("applicability") == "APPLICABLE"}
    for fault_id in sorted(linked_faults):
        row = fault_rows[fault_id]
        if row["status"] != "KILLED_ASSERTION":
            continue
        target = row["replay_target"]
        if not any(r["request_id"] == row["target_baseline_request_id"] for r in delivered):
            continue
        # Stage 08 names the failed item. Locate the actual failing source line
        # before crediting this particular assertion.
        location = re.compile(r"^work/generated_test\.py:" + str(claim["line"])
                              + r": in " + re.escape(target["pytest_item_id"].split("::")[-1].split("[")[0]) + r"\s*$",
                              re.MULTILINE)
        if location.search(row["stdout"]) and any(
                line.strip() == claim["source_span"].strip()
                for line in row["stdout"].splitlines() if line.strip().startswith("assert ")):
            return {"requirement_id": req, "reached": True, "grounded": True,
                    "linkage_qualified": True, "evidence_type": "assertion_linked_frozen_fault"}
    if linked_faults:
        return None
    # The registered semantic review can substantiate non-fault-linked checks
    # if the assertion has a single unambiguous observed response context.
    if len({(r["scenario_id"], r.get("response_status")) for r in delivered}) == 1:
        return {"requirement_id": req, "reached": True, "grounded": True,
                "linkage_qualified": True, "evidence_type": "reconciled_semantic_review"}
    return None


def apply_oracle_review_scope(unavailable, review, scope):
    affected = {
        "scenario_mapping": scope["mapping_check_scope"],
        "ambiguities_resolved": scope["ambiguity_check_scope"],
        "baseline_validity": ["baseline_pass", "selected_scenario_coverage",
                              "effective_requirement_check_coverage",
                              "unconditional_response_fault_detection"],
        "fault_validity": ["unconditional_response_fault_detection"],
        "traceability": ["baseline_pass", "request_intent_match", "selected_scenario_coverage",
                          "supported_assertion_score", "effective_requirement_check_coverage",
                          "unconditional_response_fault_detection"],
        "denominator_reconciliation": ["selected_scenario_coverage",
                                       "effective_requirement_check_coverage",
                                       "unconditional_response_fault_detection"],
    }
    for check, endpoints in affected.items():
        require(review[check] in {"PASS", "FAIL", "UNAVAILABLE"}, "Invalid oracle check evidence")
        if review[check] != "PASS":
            for endpoint in endpoints:
                unavailable.setdefault(endpoint, f"ORACLE_REVIEW_{check.upper()}_{review[check]}")


def score_partition(sources, selection, partition, scoring_bytes, unavailable_review=None):
    oracle, tasks, generation, evaluation = (sources[s] for s in ("05", "06", "07", "08"))
    for release in (generation, evaluation):
        require(release.read("config/metrics.yaml") == tasks.read("config/metrics.yaml")
                and release.read("config/analysis_registered.yaml") == tasks.read("config/analysis_registered.yaml"),
                "Frozen scoring or analysis contract differs")
    require(scoring_bytes == tasks.read("src/metrics.py") == evaluation.read("src/metrics.py"),
            "Scoring implementation differs from frozen Stage 06")
    metric = load_module("frozen_metrics", scoring_bytes)
    task_rows = keyed(tasks.csv("data/tasks.csv"), lambda r: r["task_id"], "tasks")
    artifact_rows = keyed(generation.csv("data/artifacts.csv"), lambda r: r["task_id"], "raw-generation ledger")
    execution = keyed(evaluation.csv(EVIDENCE + "execution.csv"), lambda r: r["task_id"], "execution")
    baseline = keyed(evaluation.jsonl(EVIDENCE + "baseline_results.jsonl"), lambda r: r["task_id"], "baseline")
    collection = keyed(evaluation.jsonl(EVIDENCE + "collection_results.jsonl"), lambda r: r["task_id"], "collection")
    require(task_rows.keys() == artifact_rows.keys() == execution.keys() == baseline.keys() == collection.keys(),
            "Expected task identities differ across Stages 06–08")
    unavailable_review = {} if unavailable_review is None else unavailable_review
    unavailable_tasks = {task_id for task_id in task_rows
                         if execution[task_id]["collection_status"] == "EVALUATOR_UNAVAILABLE"
                         or execution[task_id]["baseline_status"] == "EVALUATOR_UNAVAILABLE"}
    if unavailable_review:
        require(set(unavailable_review) == unavailable_tasks,
                "Completed adjudication must cover every and only evaluator-unavailable task")
        for task_id, row in unavailable_review.items():
            require(row["op_id"] == task_rows[task_id]["op_id"]
                    and row["artifact_id"] == artifact_rows[task_id]["artifact_id"]
                    and row["collection_status"] == execution[task_id]["collection_status"]
                    and row["baseline_status"] == execution[task_id]["baseline_status"],
                    "Adjudication identity or frozen status differs")
    require(len(task_rows) == 2 * len(selection), "Expected one generation per condition and operation")
    for op, operation_tasks in group(task_rows.values(), lambda r: r["op_id"]).items():
        require(op in selection and len(operation_tasks) == 2
                and {r["condition"] for r in operation_tasks} == {"L0", "L1"}
                and {r["pair_id"] for r in operation_tasks} == {selection[op]["pair_id"]}
                and len({r["seed"] for r in operation_tasks}) == 1, "Invalid task pair or paired seed")
    require({r["op_id"] for r in task_rows.values()} == selection.keys(), "Task and selected-operation frames differ")
    require(all(r["partition"] == partition and str(r["replicate"]) == "1" for r in task_rows.values()),
            "Task partition or replicate differs")
    inventory = keyed(evaluation.jsonl("data/inventory/input_artifact_inventory.jsonl"),
                      lambda r: r["task_id"], "execution input inventory")
    require(inventory.keys() == task_rows.keys(), "Execution inventory differs")
    for k, row in artifact_rows.items():
        require(inventory[k]["raw_sha256"] == (row["raw_hash"] or None)
                and inventory[k]["extracted_sha256"] == (row["extracted_hash"] or None)
                and inventory[k]["extraction_status"] == row["extraction_status"],
                "Evaluation consumed different generation evidence")
    claims = evaluation.jsonl(EVIDENCE + "assertion_claims.jsonl")
    reconcile_review(evaluation, claims)
    by_task_claim = group(claims, lambda r: r["task_id"])
    requests = evaluation.jsonl(EVIDENCE + "request_attempts.jsonl")
    requests_by_id = keyed(requests, lambda r: r["request_id"], "request attempts")
    by_task_requests = group(requests, lambda r: r["task_id"])
    faults = evaluation.jsonl(EVIDENCE + "mutation_results.jsonl")
    variations = evaluation.jsonl(EVIDENCE + "variation_results.jsonl")
    frozen = keyed(evaluation.jsonl(EVIDENCE + "opportunities_frozen.jsonl"),
                   lambda r: r["opportunity_id"], "frozen opportunities")
    outcomes = keyed(evaluation.jsonl(EVIDENCE + "opportunity_outcomes.jsonl"),
                     lambda r: r["opportunity_id"], "opportunity results")
    require(frozen.keys() == outcomes.keys() and all(all(outcomes[k][f] == v for f, v in row.items())
            for k, row in frozen.items()), "Frozen replay ledger differs from its reconciliation")
    for kind, rows, id_key in (("fault", faults, "fault_id"), ("variation", variations, "variation_id")):
        lookup = keyed(rows, lambda r: r["opportunity_id"], f"{kind} results")
        require(lookup.keys() == {k for k, row in frozen.items() if row["kind"] == kind}
                and all(row["task_id"] == frozen[k]["task_id"]
                        and row[id_key] == frozen[k]["oracle_record_id"]
                        and row["status"] == outcomes[k]["final_status"] for k, row in lookup.items()),
                f"{kind} reconciliation mismatch")
    by_task_fault = group(faults, lambda r: r["task_id"])
    by_task_opportunity = group(frozen.values(), lambda r: r["task_id"])
    require(set(by_task_claim) | set(by_task_requests) <= task_rows.keys()
            and by_task_opportunity.keys() == task_rows.keys(), "Evidence contains unknown or missing tasks")
    review_scope = oracle.json("config/exploratory_protocol.json") if partition == "main" else None
    review_dispositions = {}
    if review_scope is not None:
        require(review_scope["protocol_scope"] == "main-seven-endpoint-exploratory-v1"
                and review_scope["confirmatory_endpoints"] == [], "Unexpected Main evidence scope")
        review_dispositions = keyed(oracle.csv("reports/audit/oracle_review_dispositions.csv"),
                                    lambda row: row["op_id"], "oracle review dispositions")
        require(review_dispositions.keys() == selection.keys(), "Oracle review coverage differs")
    oracles = expected_oracles(oracle, selection, partition)
    long, links = [], []
    for task_id, task in sorted(task_rows.items()):
        op = task["op_id"]
        answer = oracles[op]
        expected = {("baseline", r["baseline_id"]) for r in answer["baselines"]}
        expected |= {("scenario", r["scenario_id"]) for r in answer["scenarios"] if r.get("applicability", "APPLICABLE") == "APPLICABLE"}
        expected |= {("fault", r["fault_id"]) for r in answer["faults"] if r.get("applicability", "APPLICABLE") == "APPLICABLE"}
        expected |= {("variation", r["variation_id"]) for r in answer["legitimate_variations"] if r.get("applicability", "APPLICABLE") == "APPLICABLE"}
        actual = [(r["kind"], r["oracle_record_id"]) for r in by_task_opportunity[task_id]]
        require(len(actual) == len(expected) and set(actual) == expected
                and all(r["op_id"] == op for r in by_task_opportunity[task_id]), "Incomplete oracle opportunity frame")
        b, e = baseline[task_id], execution[task_id]
        require(e["baseline_status"] == b["status"] and e["collection_status"] == collection[task_id]["status"],
                "Execution summaries disagree with detailed results")
        require(b["status"] != "EVALUATOR_FAILURE" and e["collection_status"] != "EVALUATOR_FAILURE",
                "Evaluator failure requires a documented rerun")
        require(int(e["collected_item_count"] or 0) == len(collection[task_id]["item_ids"]),
                "Collected item count differs")
        adjudication = unavailable_review.get(task_id)
        generated_output_failure = bool(
            adjudication and adjudication["decision"] == "TEST_CONSTRUCTION_DEFECT")
        effective_collection_status = (
            "GENERATED_OUTPUT_FAILURE"
            if generated_output_failure and e["collection_status"] == "EVALUATOR_UNAVAILABLE"
            else e["collection_status"]
        )
        effective_baseline_status = (
            "GENERATED_OUTPUT_FAILURE"
            if generated_output_failure and b["status"] == "EVALUATOR_UNAVAILABLE"
            else ("COMPLETE" if b["status"] == "PASS" else b["status"])
        )
        seen = by_task_requests[task_id]
        require(all(r["op_id"] == op for r in seen), "Request evidence points to another operation")
        applicable_scenarios = {r["scenario_id"] for r in answer["scenarios"] if r.get("applicability", "APPLICABLE") == "APPLICABLE"}
        baseline_requests = []
        for r in seen:
            cl = r.get("classification") or {}
            scenario = r.get("scenario_id")
            classifiable = cl.get("classifiable") is True or r.get("reason_code") == "REQUEST_OUTSIDE_TARGET_OPERATION"
            baseline_requests.append({"attempt_id": r["request_id"], "classifiable": classifiable,
                                      "matched_intent": classifiable and scenario in applicable_scenarios,
                                      "scenario_id": scenario if classifiable else None})
        reviewed = by_task_claim[task_id]
        require(all(r["op_id"] == op and r["condition"] == task["condition"]
                    and r["artifact_id"] == artifact_rows[task_id]["artifact_id"] for r in reviewed),
                "Reviewed assertion points to another generation")
        listed_faults = {r["fault_id"]: r for r in answer["faults"] if r.get("applicability", "APPLICABLE") == "APPLICABLE"}
        results = keyed(by_task_fault[task_id], lambda r: r["fault_id"], "task fault results")
        effective = [link for claim in reviewed if (link := effective_check(claim, answer, seen, results))]
        links.extend({"task_id": task_id, **link} for link in effective)
        unavailable = {}
        if (not generated_output_failure
                and any(r["status"] == "EVALUATOR_UNAVAILABLE" for r in results.values())):
            unavailable["unconditional_response_fault_detection"] = "FAULT_OR_BASELINE_EVALUATOR_UNAVAILABLE"
        if (not generated_output_failure
                and any(r["reachability"] == "UNVERIFIED" for r in reviewed)
                and e["collection_status"] == "PASS"):
            unavailable["supported_assertion_score"] = "ASSERTION_REACHABILITY_UNVERIFIED"
            unavailable["effective_requirement_check_coverage"] = "ASSERTION_REACHABILITY_UNVERIFIED"
        if op in review_dispositions:
            apply_oracle_review_scope(unavailable, review_dispositions[op], review_scope)
        evidence = {
            "collection_status": effective_collection_status,
            "collected_items": int(e["collected_item_count"] or 0),
            "collection_failure_reason": (None if effective_collection_status == "PASS"
                                           else effective_collection_status),
            "baseline_status": effective_baseline_status,
            "baseline_failure_reason": (None if effective_baseline_status == "COMPLETE"
                                         else effective_baseline_status),
            "item_outcomes": list(b["item_outcomes"].values()),
            "request_attempts": baseline_requests,
            # Semantic judgments are retained for all claims. Unreached source
            # assertions get no credit under the Stage 06 metrics contract.
            "reviewed_claims": [{"reviewed": True, "supported": (r["review_label"] == "supported" and r["reachability"] == "REACHED")} for r in reviewed],
            "effective_checks": effective, "unavailable_endpoints": unavailable,
            "mutation_results": [{"fault_id": f, "consumed": row["consumed"],
                                  "result": "KILLED" if qualified_kill(row, listed_faults[f], b, requests_by_id)
                                  else row["status"]} for f, row in sorted(results.items())],
        }
        scores = metric.score_operation_condition(evidence, answer)
        if b["baseline_pass"] is not None and "baseline_pass" not in unavailable:
            require(scores[1]["score"] == float(b["baseline_pass"]), "Adapter disagrees with frozen baseline result")
        selected = selection[op]
        long.extend({"op_id": op, "pair_id": task["pair_id"], "task_id": task_id,
                     "family_id": selected["family_id"], "stratum": selected["stratum"],
                     "pi": float(selected["inclusion_probability"]), "condition": task["condition"], **s} for s in scores)
    indexed = keyed(long, lambda r: (r["op_id"], r["condition"], r["endpoint"]), "long scores")
    paired = []
    for op, selected in sorted(selection.items()):
        l0 = [indexed[op, "L0", ep] for ep in metric.PRIMARY_ENDPOINTS]
        l1 = [indexed[op, "L1", ep] for ep in metric.PRIMARY_ENDPOINTS]
        differences = metric.paired_metric_differences(l0, l1)
        for a, b in zip(l0, l1):
            ep = a["endpoint"]
            delta = differences[ep]
            paired.append({"op_id": op, "pair_id": selected["pair_id"], "family_id": selected["family_id"],
                           "stratum": selected["stratum"], "pi": float(selected["inclusion_probability"]),
                           "endpoint": ep, "L0": a["score"], "L1": b["score"], "delta": delta,
                           "common_evaluable": delta is not None, "L0_unavailable_reason": a["failure_reason"] if not a["observed"] else "",
                           "L1_unavailable_reason": b["failure_reason"] if not b["observed"] else "",
                           "estimand_type": a["estimand_type"]})
    return {"long": long, "paired": paired, "links": links, "execution": execution, "tasks": task_rows,
            "artifacts": artifact_rows, "requests": requests, "faults": faults, "variations": variations,
            "claims": claims, "baseline": baseline, "endpoints": metric.PRIMARY_ENDPOINTS}
