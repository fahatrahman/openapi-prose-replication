import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Configure session with retry strategy for handling transient network issues
session = requests.Session()
retry_strategy = Retry(
    total=3,
    backoff_factor=0.1,
    status_forcelist=[429, 500, 502, 503, 504],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

# Set up headers
headers = {
    "Authorization": "Auto",
    "Api-Version": "default",
}

@pytest.fixture
def payrun():
    employer_id = "ER001"
    payschedule_id = "SCH001"
    payrun_id = "PR001"

    url = f"{BASE_URL}/Employer/{employer_id}/PaySchedule/{payschedule_id}/PayRun/{payrun_id}"
    
    response = session.get(url, headers=headers)
    response.raise_for_status()

    return response.json()

def test_get_payrun(payrun):
    assert isinstance(payrun, dict)
    assert 'Executed' in payrun
    assert 'IsSupplementary' in payrun
    assert 'PayFrequency' in payrun
    assert 'PaySchedule' in payrun
    assert 'PaymentDate' in payrun
    assert 'PeriodEnd' in payrun
    assert 'PeriodStart' in payrun
    assert 'ProceedingPayRun' in payrun
    assert 'Sequence' in payrun
    assert 'TaxPeriod' in payrun
    assert 'TaxYear' in payrun