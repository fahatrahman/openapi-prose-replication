import pytest
import requests

BASE_URL = "http://openapi.test"

def update_application(id, application, consumer_id, application_id, service_id=None, raw=False):
    url = f"{BASE_URL}/ats/applications/{id}"
    headers = {
        "x-apideck-app-id": application_id,
        "x-apideck-consumer-id": consumer_id,
    }
    if service_id:
        headers["x-apideck-service-id"] = service_id
    params = {"raw": str(raw).lower()}
    response = requests.patch(url, json=application, headers=headers, params=params)
    return response.json()

@pytest.mark.parametrize("id, application, consumer_id, application_id, expected_status", [
    ("test_id", {"applicant_id": "12345"}, "test_consumer_id", "test_app_id", 200),
    ("nonexistent_id", {"applicant_id": "12345"}, "test_consumer_id", "test_app_id", 404),
])
def test_update_application(id, application, consumer_id, application_id, expected_status):
    response = update_application(id, application, consumer_id, application_id)
    assert response.get("status_code") == expected_status

if __name__ == "__main__":
    pytest.main()