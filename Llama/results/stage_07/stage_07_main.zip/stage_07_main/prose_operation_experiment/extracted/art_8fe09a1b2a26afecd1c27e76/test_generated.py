# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_clear_association():
    url = f"{BASE_URL}/v4/{'location_name'}:clearAssociation"
    headers = {}
    params = {
        '$.xgafv': '1',
        'access_token': '',
        'alt': 'json',
        'callback': '',
        'fields': '',
        'key': '',
        'oauth_token': '',
        'prettyPrint': 'false',
        'quotaUser': '',
        'upload_protocol': 'raw',
        'uploadType': 'media'
    }
    json_data = {'@type': 'type.googleapis.com/google.mybusiness.v4.ClearLocationAssociationRequest'}

    response = requests.post(url, headers=headers, params=params, json=json_data)

    assert response.status_code == 200