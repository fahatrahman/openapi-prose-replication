# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_get_tag_languages():
    """Test getting tag languages."""
    
    # Define the path parameters for the request
    params = {"format": "json"}
    
    # Construct the full URL for the request
    url = urljoin(BASE_URL, "/resources/tags/tagLanguages.json")
    
    try:
        # Send a GET request to the defined URL
        response = requests.get(url, params=params)
        
        # Check if the request was successful (status code 200)
        assert response.status_code == 200
        
        # Parse the JSON response
        data = response.json()
        
        # Verify that the response is an array of TagLanguageMarshaller objects
        assert isinstance(data, list)
        for item in data:
            assert isinstance(item, dict)
            assert all(key in item for key in ["id", "isActive", "isoCode", "name"])
        
    except requests.exceptions.RequestException as e:
        # If there's an error during the request, print the exception message
        pytest.fail(f"Request failed: {e}")