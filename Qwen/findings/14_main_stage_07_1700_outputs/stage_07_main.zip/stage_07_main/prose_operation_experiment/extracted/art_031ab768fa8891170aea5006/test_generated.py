import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def access_token():
    return "your_access_token_here"

def test_stop_trial(access_token):
    url = f"{BASE_URL}/v1beta1/zynntaco/autfnhu/yzvrewumc/vmdixebo/qrevxpm/eromb/mimuhg/oaxni:stop"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }
    payload = {}
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert "GoogleCloudAiplatformV1beta1Trial" in response.json()