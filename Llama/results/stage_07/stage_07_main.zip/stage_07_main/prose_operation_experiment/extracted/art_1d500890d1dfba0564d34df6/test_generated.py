import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_partner():
    url = f"{BASE_URL}/v3/partners/partnerId"
    headers = {
        "Content-Type": "application/json",
    }
    params = {
        "$.xgafv": "1",
        "access_token": None,
        "alt": "json",
        "callback": None,
        "fields": "*",
        "key": None,
        "oauth_token": None,
        "prettyPrint": False,
        "quotaUser": None,
        "upload_protocol": None,
        "uploadType": None,
    }

    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)

def test_get_partner_with_api_key():
    url = f"{BASE_URL}/v3/partners/partnerId"
    headers = {
        "Content-Type": "application/json",
    }
    params = {
        "$.xgafv": "1",
        "access_token": None,
        "alt": "json",
        "callback": None,
        "fields": "*",
        "key": "my_api_key",
        "oauth_token": None,
        "prettyPrint": False,
        "quotaUser": None,
        "upload_protocol": None,
        "uploadType": None,
    }

    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)

# Run tests
pytest.main([__file__, "-v"])