import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_operation():
    url = f"{BASE_URL}/v1/projects/locations/operations/example"
    params = {
        "_xgafv": "1",
        "access_token": "example_access_token",
        "alt": "json",
        "callback": "callback_function",
        "fields": "response_fields",
        "key": "example_key",
        "oauth_token": "example_oauth_token",
        "prettyPrint": True,
        "quotaUser": "example_quota_user",
        "uploadType": "media",
        "upload_protocol": "raw"
    }
    headers = {
        "Authorization": "Bearer example_bearer_token"
    }
    response = requests.delete(url, params=params, headers=headers)
    assert response.status_code == 200
    assert response.json() == {}