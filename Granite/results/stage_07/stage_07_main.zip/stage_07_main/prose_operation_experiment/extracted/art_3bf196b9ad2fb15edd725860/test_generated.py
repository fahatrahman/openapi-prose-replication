import os
import pytest
import requests
from google.auth.transport.requests import Request
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_PATH = "path/to/credentials.json"

def get_authenticated_session():
    credentials = service_account.Credentials.from_service_account_file(
        CREDENTIALS_PATH, scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )

    if credentials.expired and credentials.refresh_token:
        credentials.refresh(Request())

    return requests.Session(), credentials

@pytest.mark.parametrize("name", ["your_project_id"])
def test_list_locations(name):
    session, _ = get_authenticated_session()

    url = f"{BASE_URL}/v1alpha/{name}/locations"
    params = {"filter": "", "pageSize": 10, "pageToken": ""}

    response = session.get(url, params=params)

    assert response.status_code == 200

    locations_response = response.json()
    locations = locations_response.get("locations", [])

    assert len(locations) > 0
    for location in locations:
        assert "displayName" in location
        assert "locationId" in location
        assert "metadata" in location