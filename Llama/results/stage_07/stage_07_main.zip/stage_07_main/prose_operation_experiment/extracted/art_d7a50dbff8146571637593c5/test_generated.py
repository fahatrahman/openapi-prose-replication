import pytest
import requests
from urllib.parse import urlencode

BASE_URL = "http://openapi.test"

def test_get_case_type_groups():
    params = {
        "q": "caseTypeGroupId: CTYGSpWaVityBQndsv",
        "pageNumber": 1,
        "order": "asc"
    }
    query_string = urlencode(params)
    
    response = requests.get(f"{BASE_URL}/masterData/caseTypeGroup", params=params)

    assert response.status_code == 200
    response_json = response.json()
    expected_response = {
        "caseTypeGroupArray": [
            {"areaOfLaw": "Tax and Revenue", "areaOfLawId": "AOFLGAd9Ah5qkTRNw9", 
             "caseClass": "Civil", "caseClassId": "CSCLNjbKTN7Yfo2wdb", 
             "caseTypeGroupId": "CTYGSpWaVityBQndsv", "createdDate": "2022-03-28T04:58:28+00:00", 
             "name": "Tax and Revenue", "object": "CaseTypeGroup"}
        ],
        "nextPageAPI": None,
        "object": "CaseTypeGroupResponse",
        "pageNumber": 1,
        "previousPageAPI": None,
        "totalCount": 1,
        "totalPages": 1
    }

    assert response_json["caseTypeGroupArray"] == expected_response["caseTypeGroupArray"]
    assert response_json["nextPageAPI"] == expected_response["nextPageAPI"]
    assert response_json["object"] == expected_response["object"]
    assert response_json["pageNumber"] == expected_response["pageNumber"]
    assert response_json["previousPageAPI"] == expected_response["previousPageAPI"]
    assert response_json["totalCount"] == expected_response["totalCount"]
    assert response_json["totalPages"] == expected_response["totalPages"]

def test_invalid_input_query():
    params = {
        "q": "caseTypeGrouId: CTYGSpWaVityBQndsv",
        "pageNumber": -1,
        "order": "invalid"
    }
    query_string = urlencode(params)
    
    response = requests.get(f"{BASE_URL}/masterData/caseTypeGroup", params=params)

    assert response.status_code == 400
    response_json = response.json()

    expected_response = {
        "code": "UN400",
        "details": "The field passed is invalid.",
        "message": "INVALID_INPUT",
        "object": "Exception"
    }

    assert response_json["code"] == expected_response["code"]
    assert response_json["details"] == expected_response["details"]
    assert response_json["message"] == expected_response["message"]
    assert response_json["object"] == expected_response["object"]

def test_internal_server_error():
    # This test will fail due to the absence of a clear way to trigger an internal server error
    # in the provided OpenAPI specification.
    pass