# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_juniper_switches():
    """Test List Juniper Switch Data Sources"""
    
    # Construct the URL for the operation
    url = f"{BASE_URL}/data-sources/juniper-switches"
    
    # Add authentication headers
    auth_header = {"Authorization": f"Bearer {requests.auth.HTTPBasicAuth('NetworkInsight', 'token').decode()}"}
    
    try:
        response = requests.get(url, headers=auth_header)
        
        assert response.status_code == 200
        
        response.raise_for_status()
        
        data = response.json()
        
        assert isinstance(data['results'], list)
        assert all(isinstance(item, dict) for item in data['results'])
        assert 'entity_id' in data['results'][0]
        assert 'entity_type' in data['results'][0]
        assert data['results'][0]['entity_type'] == 'JuniperSwitchDataSource'
        
    except requests.exceptions.RequestException as e:
        pytest.fail(f"Request failed: {e}")