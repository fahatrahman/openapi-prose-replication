# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_migrationcenter_projects_locations_operations_cancel():
    name = 'example_name'
    headers = {'Content-Type': 'application/json'}
    params = {
        '$.xgafv': '1',
        'access_token': '',
        'alt': 'json',
        'callback': '',
        'fields': '',
        'key': '',
        'oauth_token': '',
        'prettyPrint': 'false',
        'quotaUser': '',
        'upload_protocol': 'jnr',
        'uploadType': 'resumable'
    }
    body = {}

    response = requests.post(
        urljoin(BASE_URL, '/v1alpha1/' + name + ':cancel'),
        headers=headers,
        params=params,
        json=body
    )

    assert response.status_code == 200