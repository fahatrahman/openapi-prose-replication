import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retry strategy for handling transient errors
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["GET", "OPTIONS"],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.mark.parametrize("name", ["example_location"])
def test_get_attributes(name):
    url = f"{BASE_URL}/v1/{name}"

    response = session.get(url)

    if response.status_code == 200:
        attributes = response.json()["attributes"]
        assert isinstance(attributes, list)
        # Add more assertions based on expected structure and content of Attributes schema
    else:
        print(f"Request failed with status {response.status_code}")