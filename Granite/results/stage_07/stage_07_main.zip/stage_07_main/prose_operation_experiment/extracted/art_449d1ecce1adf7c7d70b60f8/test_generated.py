import os
import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"
HEADERS = {"X-API-Token": os.getenv("API_TOKEN")}

@pytest.fixture
def crash_groups():
    endpoint = "/v0.1/apps/OWNER_NAME/APP_NAME/crash_groups"
    params = {
        "last_occurrence_from": None,
        "last_occurrence_to": None,
        "app_version": None,
        "group_type": None,
        "group_status": None,
        "group_text_search": None,
        "$orderby": None,
        "continuation_token": None,
    }

    response = requests.get(BASE_URL + endpoint, headers=HEADERS, params=params)
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Request failed with status code {response.status_code}")