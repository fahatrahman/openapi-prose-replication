import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_all_sub_contractor_tags():
    url = f"{BASE_URL}/Employer/{EMPLOYER_ID}/SubContractors/Tags"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert "application/json" in response.headers["Content-Type"]
    assert isinstance(response.json(), dict)

@pytest.fixture(scope="module")
def EMPLOYER_ID():
    return "ER001"

if __name__ == "__main__":
    pytest.main()