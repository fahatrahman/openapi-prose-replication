import pytest
import requests

BASE_URL = "http://openapi.test"

def test_check_domain_verify_success():
    headers = {
        "Authorization": "Bearer your_access_token"
    }
    url = f"{BASE_URL}/domains/verify/example.com"
    response = requests.post(url, headers=headers)
    
    assert response.status_code == 200
    assert response.json() == {"id": "example.com", "success": True}

def test_check_domain_verify_failure():
    headers = {
        "Authorization": "Bearer your_access_token"
    }
    url = f"{BASE_URL}/domains/verify/nonexistent.com"
    response = requests.post(url, headers=headers)
    
    assert response.status_code in [400, 401, 403, 405]
    assert "error" in response.json()