import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_route_responses():
    api_id = "your_api_id"
    route_id = "your_route_id"
    max_results = "10"
    next_token = None

    headers = {
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Date": "20230401T000000Z",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "your_credential",
        "X-Amz-Security-Token": "your_security_token",
        "X-Amz-Signature": "your_signature",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-algorithm;x-amz-credential;x-amz-security-token"
    }

    params = {}
    if max_results:
        params["maxResults"] = max_results
    if next_token:
        params["nextToken"] = next_token

    url = f"{BASE_URL}/v2/apis/{api_id}/routes/{route_id}/routeresponses"
    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "Items" in response.json()
    assert "NextToken" in response.json()

if __name__ == "__main__":
    pytest.main()