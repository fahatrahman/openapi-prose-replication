# pylint: disable=invalid-name
import pytest
from requests import Response

BASE_URL = "http://openapi.test"

def test_get_statutory_instrument_by_id():
    """Test GetStatutoryInstrumentById"""
    id = "statutory-instrument-id"
    url = f"{BASE_URL}/api/v1/StatutoryInstrument/{id}"
    response: Response = pytest.requests.get(url)

    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    # Add assertions for the StatutoryInstrumentResource schema here