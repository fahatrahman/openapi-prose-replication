import os
import pytest
import requests
from requests_aws_sigv4 import AWSRequestsAuthV4

BASE_URL = "http://openapi.test"

def get_retention_settings(account_id):
    url = f"{BASE_URL}/accounts/{account_id}/retention-settings"

    auth = AWSRequestsAuthV4(
        access_key=os.environ["AWS_ACCESS_KEY_ID"],
        secret_key=os.environ["AWS_SECRET_ACCESS_KEY"],
        service="chime",
        region="us-east-1",
    )

    headers = {
        "Authorization": f"AWS4-HMAC-SHA256 Credential={os.environ['AWS_ACCESS_KEY_ID']}/{os.environ['AWS_DEFAULT_REGION']}:{os.environ['AWS_REQUEST_TIME']}, SignedHeaders=host;x-amz-algorithm;x-amz-credential;x-amz-date;x-amz-signed-headers, Signature={os.environ['AWS_SIGNATURE']}"
    }

    response = requests.get(url, auth=auth, headers=headers)

    if response.status_code == 200:
        return response.json()
    elif response.status_code == 480:
        assert "UnauthorizedClientException" in response.text
    elif response.status_code == 481:
        assert "NotFoundException" in response.text
    elif response.status_code == 482:
        assert "BadRequestException" in response.text
    elif response.status_code == 483:
        assert "ForbiddenException" in response.text
    elif response.status_code == 484:
        assert "ThrottledClientException" in response.text
    elif response.status_code == 485:
        assert "ServiceUnavailableException" in response.text
    elif response.status_code == 486:
        assert "ServiceFailureException" in response.text

@pytest.mark.parametrize("account_id, expected_result", [
    ("example-account-id", {"InitiateDeletionTimestamp": "", "RetentionSettings": {}}),
])
def test_get_retention_settings(account_id, expected_result):
    result = get_retention_settings(account_id)
    assert result == expected_result