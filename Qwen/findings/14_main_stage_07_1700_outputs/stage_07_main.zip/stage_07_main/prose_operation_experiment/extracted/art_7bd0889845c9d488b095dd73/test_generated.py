import pytest
import requests

BASE_URL = "http://openapi.test"

def test_calendar_settings_watch():
    url = f"{BASE_URL}/users/me/settings/watch"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    payload = {
        "address": "http://example.com/callback",
        "expiration": "1672531200000",
        "id": "unique-id",
        "kind": "api#channel",
        "params": {},
        "payload": True,
        "resourceId": "resource-123",
        "resourceUri": "https://www.googleapis.com/calendar/v3/calendars/primary/events",
        "token": "custom-token",
        "type": "web_hook"
    }
    params = {
        "alt": "json",
        "fields": "id,address",
        "key": "YOUR_API_KEY",
        "prettyPrint": False,
        "quotaUser": "user123",
        "userIp": "127.0.0.1",
        "maxResults": 100,
        "pageToken": "",
        "syncToken": ""
    }

    response = requests.post(url, headers=headers, json=payload, params=params)
    
    assert response.status_code == 200
    assert response.json()["kind"] == "api#channel"
    assert response.json()["id"] == "unique-id"
    assert response.json()["address"] == "http://example.com/callback"