import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_edge_config_token():
    edge_config_id = "example_edge_config_id"
    token = "example_token"
    team_id = "example_team_id"
    url = f"{BASE_URL}/v1/edge-config/{edge_config_id}/token/{token}"
    headers = {
        "Authorization": "Bearer example_bearer_token"
    }
    params = {
        "teamId": team_id
    }

    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 200
    assert "token" in response.json()
    assert "label" in response.json()
    assert "id" in response.json()
    assert "edgeConfigId" in response.json()
    assert "createdAt" in response.json()

def test_get_edge_config_token_400():
    edge_config_id = "example_edge_config_id"
    token = "invalid_token"
    team_id = "example_team_id"
    url = f"{BASE_URL}/v1/edge-config/{edge_config_id}/token/{token}"
    headers = {
        "Authorization": "Bearer example_bearer_token"
    }
    params = {
        "teamId": team_id
    }

    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 400

def test_get_edge_config_token_403():
    edge_config_id = "example_edge_config_id"
    token = "example_token"
    team_id = "example_team_id"
    url = f"{BASE_URL}/v1/edge-config/{edge_config_id}/token/{token}"
    headers = {
        "Authorization": "Bearer invalid_bearer_token"
    }
    params = {
        "teamId": team_id
    }

    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 403

def test_get_edge_config_token_404():
    edge_config_id = "nonexistent_edge_config_id"
    token = "example_token"
    team_id = "example_team_id"
    url = f"{BASE_URL}/v1/edge-config/{edge_config_id}/token/{token}"
    headers = {
        "Authorization": "Bearer example_bearer_token"
    }
    params = {
        "teamId": team_id
    }

    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 404