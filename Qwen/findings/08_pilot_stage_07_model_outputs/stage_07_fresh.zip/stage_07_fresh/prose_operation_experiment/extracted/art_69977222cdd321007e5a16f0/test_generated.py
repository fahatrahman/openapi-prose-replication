import pytest
import requests

BASE_URL = "http://openapi.test"

def test_pull_messages():
    url = f"{BASE_URL}/v1/projects/my-project/subscriptions/my-subscription:pull"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "maxMessages": 1,
        "returnImmediately": False
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert "receivedMessages" in response.json()