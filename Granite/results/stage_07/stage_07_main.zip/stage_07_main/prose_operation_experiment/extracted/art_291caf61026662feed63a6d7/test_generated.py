import os
import pytest
import requests
from googleapiclient.errors import HttpError

BASE_URL = "http://openapi.test"

@pytest.fixture
def sample_group_key():
    return "sample_group_key"

def test_get_group(sample_group_key):
    try:
        response = requests.get(
            f"{BASE_URL}/admin/directory/v1/groups/{sample_group_key}",
            headers={"Authorization": "Bearer YOUR_ACCESS_TOKEN"},
        )

        response.raise_for_status()

        group = response.json()["data"]
        assert group["name"] == "Sample Group Name"
        assert group["email"] == "sample_group_email@example.com"

    except HttpError as error:
        print(f"An HTTP error occurred: {error}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")