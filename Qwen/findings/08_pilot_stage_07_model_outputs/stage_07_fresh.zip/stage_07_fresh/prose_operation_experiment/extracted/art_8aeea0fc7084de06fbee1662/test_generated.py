import pytest
import requests

BASE_URL = "http://openapi.test"

def test_cancel_operation():
    url = f"{BASE_URL}/v1/projects/locations/operations/example-operation-name:cancel"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {}
    response = requests.post(url, headers=headers, json=payload)
    
    assert response.status_code == 200
    assert response.json() == {"message": "Operation cancelled successfully"}