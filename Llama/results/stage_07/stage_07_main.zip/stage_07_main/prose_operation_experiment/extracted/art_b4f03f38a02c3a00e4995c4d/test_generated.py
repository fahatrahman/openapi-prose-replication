# -*- coding: utf-8 -*-

import pytest
import requests
from json import JSONDecodeError

BASE_URL = "http://openapi.test"

def test_get_amendment():
    bill_id = 12345
    bill_stage_id = 67890
    amendment_id = 11111

    url = f"{BASE_URL}/api/v1/Bills/{bill_id}/Stages/{bill_stage_id}/Amendments/{amendment_id}"
    headers = {"accept": "application/json"}

    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
    except requests.RequestException as e:
        assert False, f"Request failed: {e}"

    try:
        response.json()
    except JSONDecodeError as e:
        assert False, f"Failed to parse JSON response: {e}"

    # Add assertions based on your expected response content here