import pytest
import requests

BASE_URL = "http://openapi.test"

def get_data_exporter_configs(type=None):
    url = f"{BASE_URL}/api/data-exporter-configs/_template"
    params = {}
    if type:
        params['type'] = type
    response = requests.get(url, params=params)
    return response.json()

@pytest.mark.parametrize("exporter_type", [
    None,
    "elasticsearch",
    "kafka",
    "pulsar",
    "file",
    "mailer",
    "custom"
])
def test_get_data_exporter_configs(exporter_type):
    response = get_data_exporter_configs(exporter_type)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()