import pytest
import requests

BASE_URL = "http://openapi.test"

def test_publish_iteration():
    url = f"{BASE_URL}/projects/{'64b822c5-8082-4b36-a426-27225f4aa18c'}/iterations/{'e31a14ab-5d78-4f7b-a267-3a1e4fd8a758'}/publish"
    headers = {
        "Training-Key": "{API Key}"
    }
    params = {
        "publishName": "Model1",
        "predictionId": "/subscriptions/{subscription}/resourceGroups/{resource group name}/providers/Microsoft.CognitiveServices/accounts/{resource name}"
    }
    response = requests.post(url, headers=headers, params=params)
    
    assert response.status_code == 200
    assert response.json() == True