import pytest
import requests

BASE_URL = "http://openapi.test"

def test_directory_groups_patch():
    url = f"{BASE_URL}/admin/directory/v1/groups/example"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "name": "Updated Group Name"
    }
    params = {
        "_xgafv": "1",
        "access_token": "YOUR_ACCESS_TOKEN",
        "alt": "json",
        "callback": "callback",
        "fields": "id,name,email",
        "key": "YOUR_API_KEY",
        "oauth_token": "YOUR_OAUTH_TOKEN",
        "prettyPrint": False,
        "quotaUser": "quotaUser",
        "uploadType": "media",
        "upload_protocol": "raw"
    }
    response = requests.patch(url, headers=headers, json=payload, params=params)
    assert response.status_code == 200
    assert 'id' in response.json()
    assert 'name' in response.json()
    assert 'email' in response.json()

if __name__ == "__main__":
    pytest.main()