# Main OpenAPI prose experiment · Exploratory report

All 850 selected operation pairs are accounted for.
Results describe pairs with usable evidence for each outcome. The registered confirmatory run was not completed.

## Descriptive paired results

| Endpoint | Available | Missing | L0 | L1 | L1 minus L0 |
|---|---:|---:|---:|---:|---:|
| collection_success | 850 | 0 | 0.5000 | 0.5271 | 0.0271 |
| baseline_pass | 810 | 40 | 0.0519 | 0.0506 | -0.0012 |
| request_intent_match | 63 | 787 | 0.9524 | 0.9524 | 0.0000 |
| selected_scenario_coverage | 750 | 100 | 0.1471 | 0.1542 | 0.0071 |
| supported_assertion_score | 170 | 680 | 0.0014 | 0.0000 | -0.0014 |
| effective_requirement_check_coverage | 170 | 680 | 0.0003 | 0.0000 | -0.0003 |
| unconditional_response_fault_detection | 810 | 40 | 0.0099 | 0.0080 | -0.0020 |

Descriptive values use unweighted means over common-evaluable pairs.
A missing score is retained with its reason. The review dispositions and the technical oracle scope are in the provenance files.
The experiment measures generated tests against documented offline responses.
