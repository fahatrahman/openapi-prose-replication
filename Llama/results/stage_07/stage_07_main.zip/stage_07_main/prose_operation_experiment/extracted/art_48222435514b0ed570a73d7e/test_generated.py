# -*- coding: utf-8 -*-

import pytest
import requests
from requests.auth import HTTPBasicAuth
import json

BASE_URL = "http://openapi.test"

def test_GetAllSubContractorTags():
    employer_id = "GD001"
    headers = {
        'Authorization': 'Auto',
        'Api-Version': 'default'
    }
    response = requests.get(
        f'{BASE_URL}/Employer/{employer_id}/SubContractors/Tags',
        headers=headers,
        auth=HTTPBasicAuth('username', 'password')
    )
    assert response.status_code == 200
    response.raise_for_status()
    data = json.loads(response.content)
    assert isinstance(data, dict)
    assert 'Links' in data
    for link in data['Links']:
        assert '@href' in link
        assert '@rel' in link
        assert '@title' in link

def test_GetAllSubContractorTags_400():
    employer_id = "invalid-id"
    headers = {
        'Authorization': 'Auto',
        'Api-Version': 'default'
    }
    response = requests.get(
        f'{BASE_URL}/Employer/{employer_id}/SubContractors/Tags',
        headers=headers,
        auth=HTTPBasicAuth('username', 'password')
    )
    assert response.status_code == 400

def test_GetAllSubContractorTags_401():
    employer_id = "GD001"
    headers = {
        'Authorization': 'InvalidToken',
        'Api-Version': 'default'
    }
    response = requests.get(
        f'{BASE_URL}/Employer/{employer_id}/SubContractors/Tags',
        headers=headers,
        auth=HTTPBasicAuth('username', 'password')
    )
    assert response.status_code == 401

def test_GetAllSubContractorTags_404():
    employer_id = "non-existent-id"
    headers = {
        'Authorization': 'Auto',
        'Api-Version': 'default'
    }
    response = requests.get(
        f'{BASE_URL}/Employer/{employer_id}/SubContractors/Tags',
        headers=headers,
        auth=HTTPBasicAuth('username', 'password')
    )
    assert response.status_code == 404

def test_GetAllSubContractorTags_500():
    employer_id = "GD001"
    headers = {
        'Authorization': 'Auto',
        'Api-Version': 'default'
    }
    # Introduce a network error to simulate a 500 status code
    response = requests.get(
        f'{BASE_URL}/Employer/{employer_id}/SubContractors/Tags',
        headers=headers,
        auth=HTTPBasicAuth('username', 'password'),
        timeout=0.01
    )
    assert response.status_code == 500