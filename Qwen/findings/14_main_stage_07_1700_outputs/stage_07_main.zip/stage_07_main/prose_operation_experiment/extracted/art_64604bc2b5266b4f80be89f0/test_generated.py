import pytest
import requests

BASE_URL = "http://openapi.test"

def test_start_node():
    url = f"{BASE_URL}/v1alpha1/projects/location/nodes/start"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "resourceName": "projects/location/nodes/node-1"
    }
    params = {
        "$.xgafv": "1",
        "access_token": "YOUR_ACCESS_TOKEN",
        "alt": "json",
        "callback": "cb",
        "fields": "*",
        "key": "YOUR_API_KEY",
        "oauth_token": "YOUR_OAUTH_TOKEN",
        "prettyPrint": "true",
        "quotaUser": "user1",
        "uploadType": "media",
        "upload_protocol": "raw"
    }
    
    response = requests.post(url, headers=headers, json=payload, params=params)
    assert response.status_code == 200
    assert "name" in response.json()
    assert "metadata" in response.json()
    assert "done" in response.json()
    assert "response" in response.json()

if __name__ == "__main__":
    pytest.main()