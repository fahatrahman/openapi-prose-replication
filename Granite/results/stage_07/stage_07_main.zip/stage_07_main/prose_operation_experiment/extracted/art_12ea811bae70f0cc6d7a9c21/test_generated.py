import os
import pytest
import requests
from google.rpc import Status_codes

BASE_URL = "http://openapi.test"

def test_list_operations():
    name = "your_parent_resource"
    params = {
        "_".xgafv: "1",  # V1 error format
        "name": name,
    }

    response = requests.get(f"{BASE_URL}/v1/{name}/operations", params=params)

    if response.status_code == 200:
        operations_data = response.json()
        assert isinstance(operations_data, dict)
        assert "operations" in operations_data
        assert isinstance(operations_data["operations"], list)

        for operation in operations_data["operations"]:
            assert isinstance(operation, dict)
            assert "name" in operation
            assert "done" in operation
            assert "metadata" in operation
            assert "response" in operation

    else:
        print(f"Error: Unable to list operations. Status code: {response.status_code}")
        assert False