import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_user():
    user_id = 123  # Replace with actual user ID
    url = f"{BASE_URL}/api/v2/Users/{user_id}"
    response = requests.get(url)
    
    assert response.status_code == 200
    user_data = response.json()
    assert 'UserID' in user_data
    assert 'Username' in user_data
    assert 'Email' in user_data
    assert 'Name' in user_data
    assert 'Password' in user_data
    assert 'ChangePassword' in user_data