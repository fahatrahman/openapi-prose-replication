import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.exceptions import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.mark.parametrize("artifact_id", ["Topic-1/Inbound"])
def test_list_artifact_versions(artifact_id):
    endpoint = f"{BASE_URL}/artifacts/{artifact_id}/versions"

    response = SESSION.get(endpoint)

    if response.status_code == 200:
        versions = response.json()
        assert isinstance(versions, list)
        assert all(isinstance(ver, int) for ver in versions)
    elif response.status_code == 404:
        assert response.json() == {"error_code": 404, "message": "No artifact with id 'Topic-1/Inbound' could be found."}
    elif response.status_code == 500:
        assert response.json() == {"error_code": 500, "message": "Lost connection to the database."}
    else:
        raise Exception(f"Unexpected status code {response.status_code}")