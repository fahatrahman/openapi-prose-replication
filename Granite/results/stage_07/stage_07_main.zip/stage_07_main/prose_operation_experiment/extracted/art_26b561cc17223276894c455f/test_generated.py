import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_PATH = "path/to/credentials.json"

# Authenticate using Service Accounts
credentials = service_account.Credentials.from_service_account_file(
    CREDENTIALS_PATH)

# Set up the authorization header
headers = {"Authorization": f"Bearer {credentials.token}"}

@pytest.fixture
def api():
    session = requests.Session()
    session.headers.update(headers)

    return session

def test_patch_connector(api):
    name = "your_project_id/your_location_id/your_connector_id"
    update_mask = "optional_field_1,optional_field_2" # replace with actual fields if needed

    connector = {
        "connectedProjects": ["project-1", "project-2"],
        "createTime": "2022-01-01T00:00:00Z",
        "ipCidrRange": "10.132.0.0/28",
        "lastRestartTime": "2022-02-01T00:00:00Z",
        "machineType": "n1-standard-1",
        "maxInstances": 10,
        "maxThroughput": 100,
        "minInstances": 5,
        "minThroughput": 200,
        "name": "my-connector",
        "network": "default",
        "state": "READY",
        "subnet": {
            "name": "subnet-1",
            "projectId": "your-project-id"
        }
    }

    response = api.patch(
        f"{BASE_URL}/v1beta1/{name}",
        json=connector,
        headers=headers,
        params={"updateMask": update_mask}
    )

    assert response.status_code == 200
    print("Test Passed!")


if __name__ == "__main__":
    pytest.main([__file__])