import pytest
import requests
from typing import Dict, List

BASE_URL = "http://openapi.test"

def get_world_template_body(json_data: Dict):
    url = f"{BASE_URL}/getWorldTemplateBody"
    headers = {
        'X-Amz-Algorithm': '',
        'X-Amz-Content-Sha256': '',
        'X-Amz-Credential': '',
        'X-Amz-Date': '',
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': '',
        'X-Amz-SignedHeaders': ''
    }
    response = requests.post(url, json=json_data, headers=headers)
    return response.json()

@pytest.fixture
def valid_request():
    generation_job = "arn:example:generation-job:123456789012:job/1234567890123456789012345678901234567890"
    template = "arn:example:template:123456789012:template/1234567890123456789012345678901234567890"
    return {"generationJob": generation_job, "template": template}

def test_get_world_template_body(valid_request):
    response = get_world_template_body(valid_request)
    assert response['status_code'] == 200
    assert isinstance(response['body'], dict)

def test_get_world_template_body_invalid_parameter():
    invalid_generation_job = "invalid-arn:example:generation-job:123456789012:job/1234567890123456789012345678901234567890"
    invalid_template = "invalid-arn:example:template:123456789012:template/1234567890123456789012345678901234567890"
    response = get_world_template_body({"generationJob": invalid_generation_job, "template": invalid_template})
    assert response['status_code'] == 480

def test_get_world_template_body_resource_not_found():
    invalid_generation_job = "arn:example:generation-job:123456789012:job/1234567890123456789012345678901234567890"
    invalid_template = "invalid-arn:example:template:123456789012:template/1234567890123456789012345678901234567890"
    response = get_world_template_body({"generationJob": invalid_generation_job, "template": invalid_template})
    assert response['status_code'] == 481

def test_get_world_template_body_throttling_exception():
    invalid_generation_job = "arn:example:generation-job:123456789012:job/1234567890123456789012345678901234567890"
    invalid_template = "arn:example:template:123456789012:template/1234567890123456789012345678901234567890"
    response = get_world_template_body({"generationJob": invalid_generation_job, "template": invalid_template})
    assert response['status_code'] == 482

def test_get_world_template_body_internal_server_error():
    invalid_generation_job = "arn:example:generation-job:123456789012:job/1234567890123456789012345678901234567890"
    invalid_template = "arn:example:template:123456789012:template/1234567890123456789012345678901234567890"
    response = get_world_template_body({"generationJob": invalid_generation_job, "template": invalid_template})
    assert response['status_code'] == 483