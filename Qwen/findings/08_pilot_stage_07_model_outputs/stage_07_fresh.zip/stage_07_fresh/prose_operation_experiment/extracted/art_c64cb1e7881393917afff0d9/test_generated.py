import pytest
import requests

BASE_URL = "http://openapi.test"

def test_operations_flightstatus_by_flight_number_and_date_get():
    url = f"{BASE_URL}/operations/flightstatus/AA123/2023-10-01"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Accept": "application/json"
    }
    params = {
        "limit": "10",
        "offset": "0"
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()