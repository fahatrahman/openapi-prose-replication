import pytest
import requests

BASE_URL = "http://openapi.test"

def test_jurisdiction_detail():
    jurisdiction_id = "ocd-jurisdiction/country:us/state:nc/government"
    include = ["organizations", "legislative_sessions"]
    apikey = "your_api_key_here"
    headers = {"x-api-key": apikey}

    response = requests.get(
        f"{BASE_URL}/jurisdictions/{jurisdiction_id}",
        params={"include": include},
        headers=headers,
    )

    assert response.status_code == 200
    jurisdiction_data = response.json()
    assert jurisdiction_data["id"] == jurisdiction_id
    assert all(item in jurisdiction_data for item in include)

def test_jurisdiction_detail_with_invalid_include():
    jurisdiction_id = "ocd-jurisdiction/country:us/state:nc/government"
    include = ["invalid_item"]
    apikey = "your_api_key_here"
    headers = {"x-api-key": apikey}

    response = requests.get(
        f"{BASE_URL}/jurisdictions/{jurisdiction_id}",
        params={"include": include},
        headers=headers,
    )

    assert response.status_code == 422
    validation_error = response.json()
    assert "detail" in validation_error
    assert isinstance(validation_error["detail"], list)