import pytest
import requests
from datetime import datetime
import json

BASE_URL = "http://openapi.test"

def test_list_custom_data_identifiers():
    url = f"{BASE_URL}/custom-data-identifiers/list"
    headers = {
        'Authorization': '',
        'X-Amz-Algorithm': '',
        'X-Amz-Content-Sha256': '',
        'X-Amz-Credential': '',
        'X-Amz-Date': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': '',
        'X-Amz-SignedHeaders': ''
    }
    data = {
        'maxResults': 10,
        'nextToken': None
    }

    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
        assert response.status_code == 200
        result = response.json()
        assert isinstance(result, dict)
        assert 'items' in result
        assert isinstance(result['items'], list)
    except requests.RequestException as e:
        pytest.fail(f"Request failed: {e}")
    except AssertionError as e:
        pytest.fail(f"Assertion failed: {e}")

if __name__ == "__main__":
    pytest.main([__file__])