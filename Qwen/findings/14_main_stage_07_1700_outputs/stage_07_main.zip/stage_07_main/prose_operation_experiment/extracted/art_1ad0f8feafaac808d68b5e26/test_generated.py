import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_resources():
    url = f"{BASE_URL}/api/v1/resources"
    headers = {
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Date": "20230401T000000Z",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20230401/us-east-1/sts/aws4_request",
        "X-Amz-Security-Token": "AQoEXAMPLEH4aoAHFmzLSfNnTRIkdZvdIXFMzLMRGgfyg==",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-algorithm;x-amz-credential;x-amz-security-token"
    }
    params = {
        "userId": "user123",
        "collectionType": "SHARED_WITH_ME",
        "limit": 1,
        "marker": ""
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    assert "Documents" in response.json()
    assert "Folders" in response.json()
    assert "Marker" in response.json()

if __name__ == "__main__":
    pytest.main([__file__])