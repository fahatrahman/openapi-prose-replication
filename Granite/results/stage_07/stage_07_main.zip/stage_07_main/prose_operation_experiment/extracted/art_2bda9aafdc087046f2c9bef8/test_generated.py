import pytest
import requests
BASE_URL = "http://openapi.test"

@pytest.fixture
def test_configuration():
    endpoint = "/v1/{}/configurations"
    configuration = {
        "companyName": "Test Company",
        "configurationId": 123456789,
        "configurationName": "Test Configuration",
        "contactEmail": "test@example.com",
        "contactPhone": "+1234567890",
        "customMessage": "This is a custom message.",
        "dpcExtras": "dpc_extras_value",
        "dpcResourcePath": "dpc_resource_path_value",
        "forcedResetTime": "1.234567",
        "isDefault": True,
        "name": "test_configuration_name"
    }

    response = requests.post(
        f"{BASE_URL}{endpoint}".replace("{}", "'test_customer_id'") ,
        json=configuration,
    )

    assert response.status_code == 200
    return response.json()