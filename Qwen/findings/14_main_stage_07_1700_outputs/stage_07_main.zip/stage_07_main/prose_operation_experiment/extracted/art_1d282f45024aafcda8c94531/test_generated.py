import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_multiple_artists():
    ids = "2CIMQHirSU0MQqyYHq0eOx,57dN52uHvrHOxijzpIgu3E,1vCWHaC5f2uS3yhpwWbIA6"
    url = f"{BASE_URL}/artists"
    params = {"ids": ids}
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }

    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "artists" in data
    assert isinstance(data["artists"], list)
    for artist in data["artists"]:
        assert "id" in artist
        assert "name" in artist
        assert "genres" in artist
        assert "images" in artist
        assert "followers" in artist
        assert "external_urls" in artist
        assert "popularity" in artist
        assert "type" in artist
        assert artist["type"] == "artist"

@pytest.mark.skip(reason="This test requires authentication")
def test_get_multiple_artists_unauthorized():
    ids = "2CIMQHirSU0MQqyYHq0eOx,57dN52uHvrHOxijzpIgu3E,1vCWHaC5f2uS3yhpwWbIA6"
    url = f"{BASE_URL}/artists"
    params = {"ids": ids}
    headers = {
        "Authorization": "Bearer INVALID_ACCESS_TOKEN"
    }

    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 401
    data = response.json()
    assert isinstance(data, dict)
    assert "error" in data
    assert "status" in data["error"]
    assert data["error"]["status"] == 401
    assert "message" in data["error"]
    assert "Unauthorized" in data["error"]["message"]

@pytest.mark.skip(reason="This test requires authentication")
def test_get_multiple_artists_forbidden():
    ids = "2CIMQHirSU0MQqyYHq0eOx,57dN52uHvrHOxijzpIgu3E,1vCWHaC5f2uS3yhpwWbIA6"
    url = f"{BASE_URL}/artists"
    params = {"ids": ids}
    headers = {
        "Authorization": "Bearer FORBIDDEN_ACCESS_TOKEN"
    }

    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 403
    data = response.json()
    assert isinstance(data, dict)
    assert "error" in data
    assert "status" in data["error"]
    assert data["error"]["status"] == 403
    assert "message" in data["error"]
    assert "Forbidden" in data["error"]["message"]

@pytest.mark.skip(reason="This test requires authentication")
def test_get_multiple_artists_too_many_requests():
    ids = "2CIMQHirSU0MQqyYHq0eOx,57dN52uHvrHOxijzpIgu3E,1vCWHaC5f2uS3yhpwWbIA6"
    url = f"{BASE_URL}/artists"
    params = {"ids": ids}
    headers = {
        "Authorization": "Bearer TOO_MANY_REQUESTS_ACCESS_TOKEN"
    }

    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 429
    data = response.json()
    assert isinstance(data, dict)
    assert "error" in data
    assert "status" in data["error"]
    assert data["error"]["status"] == 429
    assert "message" in data["error"]
    assert "Too many requests" in data["error"]["message"]