import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_global_images():
    params = {
        "search": "example",
        "categoryId": "category1",
        "publisher": "publisher1",
        "includeDeleted": False,
        "limit": 10,
        "offset": 0
    }
    response = requests.get(f"{BASE_URL}/api/v2/GlobalImages", params=params)
    
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "Entities" in data
    assert isinstance(data["Entities"], list)
    assert "Metadata" in data
    assert isinstance(data["Metadata"], dict)
    assert "TotalCount" in data["Metadata"]
    assert "Limit" in data["Metadata"]
    assert "Offset" in data["Metadata"]

def test_get_global_images_with_error():
    params = {
        "search": "nonexistent",
        "categoryId": "invalid_category",
        "publisher": "unknown_publisher",
        "includeDeleted": True,
        "limit": -1,
        "offset": -1
    }
    response = requests.get(f"{BASE_URL}/api/v2/GlobalImages", params=params)
    
    assert response.status_code >= 400
    error_data = response.json()
    assert isinstance(error_data, dict)
    assert "DeveloperMessage" in error_data
    assert "ErrorCode" in error_data
    assert "MoreInfo" in error_data
    assert "UserMessage" in error_data