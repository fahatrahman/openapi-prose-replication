import pytest
import requests

BASE_URL = "http://openapi.test"

def test_queries_list():
    url = f"{BASE_URL}/queries"
    params = {
        "$.xgafv": "1",
        "access_token": None,
        "alt": "json",
        "callback": None,
        "fields": None,
        "key": None,
        "oauth_token": None,
        "prettyPrint": False,
        "quotaUser": None,
        "upload_protocol": None,
        "uploadType": None,
        "orderBy": "queryId",
        "pageSize": 10,
        "pageToken": None,
    }
    headers = {"Content-Type": "application/json"}

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 200
    response.raise_for_status()
    response_json = response.json()

    assert isinstance(response_json, dict)
    assert "nextPageToken" not in response_json
    assert isinstance(response_json["queries"], list)

    for query in response_json["queries"]:
        assert isinstance(query, dict)
        assert "queryId" in query
        assert isinstance(query["queryId"], str)
        assert "metadata" in query
        assert isinstance(query["metadata"], dict)
        assert "title" in query["metadata"]
        assert isinstance(query["metadata"]["title"], str)