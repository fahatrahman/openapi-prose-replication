import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_photos():
    short_name = "test_short_name"
    offset = 0
    count = 10

    url = f"{BASE_URL}/v2/tier1/{short_name}/photo/photos"
    params = {
        "offset": offset,
        "count": count
    }

    response = requests.get(url, params=params)

    assert response.status_code == 200
    assert "Content-Type" in response.headers
    assert response.headers["Content-Type"].startswith("application/json")

    try:
        result = response.json()
        assert isinstance(result, dict)
        assert "Count" in result
        assert "Data" in result
        assert isinstance(result["Data"], list)
    except ValueError:
        pytest.fail("Response body is not valid JSON")