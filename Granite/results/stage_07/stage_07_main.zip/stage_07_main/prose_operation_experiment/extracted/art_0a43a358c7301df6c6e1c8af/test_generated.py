import os
import pytest
import requests
from requests.exceptions import HTTPError

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="module")
def auth():
    """Authenticate with Otoroshi using Basic Auth"""
    auth = os.getenv("OTOROSHI_CLIENT_ID"), os.getenv("OTOROSHI_CLIENT_SECRET")
    return auth

def test_reset_snowmonkey_outages(auth):
    """Test resetting Snow Monkey Outages for the day"""
    url = f"{BASE_URL}/api/snowmonkey/outages"

    try:
        response = requests.delete(url, auth=auth, verify=False)  # Disable SSL verification for this example

        # Check if the request was successful (status code 200)
        assert response.status_code == 200

        # Parse the JSON response
        done = response.json()["done"]
        assert isinstance(done, bool), "Response should contain a boolean value under 'done'"
        assert done is True, "Expected 'done' to be true"

    except HTTPError as http_err:
        print(f'HTTP error occurred: {http_err}')
    except Exception as err:
        print(f'An error occurred: {err}')