import pytest
import requests

BASE_URL = "http://openapi.test"

def test_crashGroups_list():
    url = f"{BASE_URL}/v0.1/apps/owner_name/app_name/crash_groups"
    headers = {
        "X-API-Token": "your_api_token_here"
    }
    params = {
        "last_occurrence_from": "2023-01-01T00:00:00Z",
        "last_occurrence_to": "2023-01-31T23:59:59Z",
        "app_version": "1.0.0",
        "group_type": "GroupType1",
        "group_status": "open",
        "group_text_search": "error",
        "$orderby": "last_occurrence desc",
        "continuation_token": ""
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    assert "crash_groups" in response.json()
    assert isinstance(response.json()["crash_groups"], list)

if __name__ == "__main__":
    pytest.main()