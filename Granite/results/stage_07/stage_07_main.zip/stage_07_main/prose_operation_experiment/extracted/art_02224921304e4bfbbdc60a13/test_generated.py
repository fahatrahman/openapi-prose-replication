import os
import pytest
import requests
from xml.etree import ElementTree as ET

BASE_URL = "http://openapi.test"

@pytest.fixture
def pico_loadmanagementgroups():
    response = requests.get(f"{BASE_URL}/api/pico/loadmanagementgroup")
    response.raise_for_status()
    return response.json()

def test_pico_loadmanagementgroups(pico_loadmanagementgroups):
    assert isinstance(pico_loadmanagementgroups, list)
    for group in pico_loadmanagementgroups:
        assert isinstance(group, dict)
        assert "Id" in group
        assert "MaxCurrent" in group
        assert "Name" in group
        assert "NumberOfStations" in group