# -*- coding: utf-8 -*-
"""Tests for the bidders API."""

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_bidders():
    """Test listing bidders."""
    url = f"{BASE_URL}/v1/bidders"
    params = {
        '_.xgafv': '',
        'access_token': '',
        'alt': '',
        'callback': '',
        'fields': '',
        'key': '',
        'oauth_token': '',
        'prettyPrint': False,
        'quotaUser': '',
        'upload_protocol': '',
        'uploadType': '',
        'pageSize': 100,
        'pageToken': ''
    }
    headers = {'Content-Type': 'application/json'}
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200