# -*- coding: utf-8 -*-
"""pytest test suite for MembershipsRecentlyChanged endpoint."""

import pytest
from requests import RequestException

BASE_URL = "http://openapi.test"

def test_MembershipsRecentlyChanged_json_1_day():
    """Test MembershipsRecentlyChanged endpoint with json format and 1 day."""
    url = f"{BASE_URL}/json/RecentlyChangedMemberships/1"
    response = requests.get(url)
    assert response.status_code == 200
    # Add your assertions here to validate the response content

def test_MembershipsRecentlyChanged_xml_2_days():
    """Test MembershipsRecentlyChanged endpoint with xml format and 2 days."""
    url = f"{BASE_URL}/xml/RecentlyChangedMemberships/2"
    response = requests.get(url)
    assert response.status_code == 200
    # Add your assertions here to validate the response content

def test_MembershipsRecentlyChanged_invalid_format():
    """Test MembershipsRecentlyChanged endpoint with invalid format."""
    url = f"{BASE_URL}/invalid/RecentlyChangedMemberships/1"
    with pytest.raises(RequestException):
        requests.get(url)

def test_MembershipsRecentlyChanged_negative_days():
    """Test MembershipsRecentlyChanged endpoint with negative days."""
    url = f"{BASE_URL}/json/RecentlyChangedMemberships/-1"
    with pytest.raises(RequestException):
        requests.get(url)

def test_MembershipsRecentlyChanged_zero_days():
    """Test MembershipsRecentlyChanged endpoint with zero days."""
    url = f"{BASE_URL}/json/RecentlyChangedMemberships/0"
    with pytest.raises(RequestException):
        requests.get(url)

import requests