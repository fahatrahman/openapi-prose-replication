import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_nh_interior():
    headers = {
        "X-API-KEY": "your_api_key_here",
        "Accept-Version": "1.0.0"
    }
    params = {
        "color": ["White", "Colorful"],
        "thumbsize": 100
    }
    response = requests.get(f"{BASE_URL}/nh/interior/Abstract_Wall", headers=headers, params=params)
    
    assert response.status_code == 200
    data = response.json()
    assert "availability" in data
    assert "buy" in data
    assert "category" in data
    assert "colors" in data
    assert "grid_length" in data
    assert "grid_width" in data
    assert "hha_base" in data
    assert "hha_category" in data
    assert "image_url" in data
    assert "item_series" in data
    assert "item_set" in data
    assert "name" in data
    assert "notes" in data
    assert "sell" in data
    assert "tag" in data
    assert "themes" in data
    assert "unlocked" in data
    assert "url" in data
    assert "version_added" in data

def test_get_nh_interior_401():
    headers = {
        "X-API-KEY": "invalid_api_key",
        "Accept-Version": "1.0.0"
    }
    params = {
        "color": ["White", "Colorful"],
        "thumbsize": 100
    }
    response = requests.get(f"{BASE_URL}/nh/interior/Abstract_Wall", headers=headers, params=params)
    
    assert response.status_code == 401
    data = response.json()
    assert "details" in data
    assert "title" in data

def test_get_nh_interior_500():
    headers = {
        "X-API-KEY": "your_api_key_here",
        "Accept-Version": "invalid_version"
    }
    params = {
        "color": ["White", "Colorful"],
        "thumbsize": 100
    }
    response = requests.get(f"{BASE_URL}/nh/interior/Abstract_Wall", headers=headers, params=params)
    
    assert response.status_code == 500
    data = response.json()
    assert "details" in data
    assert "title" in data