import pytest
import requests
from datetime import datetime
import json

BASE_URL = "http://openapi.test"

def test_connections():
    url = f"{BASE_URL}/net/connections"
    headers = {"Content-Type": "application/json"}
    body = {}
    
    response = requests.post(url, headers=headers, data=json.dumps(body))
    assert response.status_code == 200
    
    data = response.json()
    for item in data:
        assert isinstance(item, dict)
        
        assert 'connecting' in item
        assert isinstance(item['connecting'], bool)
        
        assert 'last_handshake' in item
        last_handshake = item['last_handshake']
        assert isinstance(last_handshake, dict)
        
        assert 'agent' in last_handshake
        assert isinstance(last_handshake['agent'], str)
        
        assert 'chain_id' in last_handshake
        assert isinstance(last_handshake['chain_id'], str)
        
        assert 'generation' in last_handshake
        assert isinstance(last_handshake['generation'], int)
        
        assert 'head_id' in last_handshake
        assert isinstance(last_handshake['head_id'], str)
        
        assert 'head_num' in last_handshake
        assert isinstance(last_handshake['head_num'], int)
        
        assert 'key' in last_handshake
        assert isinstance(last_handshake['key'], str)
        
        assert 'last_irreversible_block_id' in last_handshake
        assert isinstance(last_handshake['last_irreversible_block_id'], str)
        
        assert 'last_irreversible_block_num' in last_handshake
        assert isinstance(last_handshake['last_irreversible_block_num'], int)
        
        assert 'network_version' in last_handshake
        assert isinstance(last_handshake['network_version'], int)
        
        assert 'node_id' in last_handshake
        assert isinstance(last_handshake['node_id'], str)
        
        assert 'os' in last_handshake
        assert isinstance(last_handshake['os'], str)
        
        assert 'p2p_address' in last_handshake
        assert isinstance(last_handshake['p2p_address'], str)
        
        assert 'sig' in last_handshake
        assert isinstance(last_handshake['sig'], str)
        
        assert 'time' in last_handshake
        time = last_handshake['time']
        assert isinstance(time, str)
        dt = datetime.strptime(time[:-3], '%Y-%m-%dT%H:%M:%S')
        assert dt.timestamp() <= datetime.now().timestamp()
        
        assert 'token' in last_handshake
        assert isinstance(last_handshake['token'], str)
        
        assert 'peer' in item
        assert isinstance(item['peer'], str)
        
        assert 'syncing' in item
        assert isinstance(item['syncing'], bool)

if __name__ == "__main__":
    pytest.main([__file__])