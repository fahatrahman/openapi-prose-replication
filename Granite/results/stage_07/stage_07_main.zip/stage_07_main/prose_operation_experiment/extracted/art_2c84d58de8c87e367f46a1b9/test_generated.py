import os
import hmac
import hashlib
from datetime import datetime
import requests
import pytest

BASE_URL = "http://openapi.test"

def get_signature(access_key, secret_key, method, path, query_params):
    canonical_uri = "/" + path[len("/invitations"):].lstrip('/')
    canonical_query_string = "&".join([f"{k}={v}" for k, v in sorted(query_params.items())]) if query_params else ""
    canonical_headers = f"x-amz-algorithm:{method}\nx-amz-content-sha256:UNSIGNED-PAYLOAD\nx-amz-credential={access_key},{datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')} /{path}\n"
    payload_hash = hashlib.sha256(b"").hexdigest()

    string_to_sign = (
        f"{method}\n"
        f"{canonical_uri}\n"
        f"{canonical_query_string}\n"
        f"{canonical_headers}\n"
        f"{payload_hash}"
    )

    signing_key = hmac.new(secret_key.encode(), msg=string_to_sign.encode(), digestmod=hashlib.sha256).digest()
    signature = hmac.new(signing_key, msg=string_to_sign.encode(), digestmod=hashlib.sha256).hexdigest()

    return signature

@pytest.fixture
def signed_requests():
    access_key = "YOUR_ACCESS_KEY"
    secret_key = "YOUR_SECRET_KEY"

    headers = {
        'Authorization': f'AWS4-HMAC-SHA256 Credential={access_key},{datetime.utcnow().strftime("%Y%m%d/%N/%n+%fZ")}, SignedHeaders=host;x-amz-algorithm, Signature={get_signature(access_key, secret_key, "GET", "/invitations", {})}'
    }

    def _request(query_params={}):
        url = BASE_URL + "/invitations"
        params = {"MaxResults": 10, "NextToken": None}
        params.update(query_params)

        signature = get_signature(access_key, secret_key, "GET", "/invitations", params)
        headers['Authorization'] = f'AWS4-HMAC-SHA256 Credential={access_key},{datetime.utcnow().strftime("%Y%m%d/%N/%n+%fZ")}, SignedHeaders=host;x-amz-algorithm, Signature={signature}'

        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()

        return response.json()

    yield _request

def test_list_invitations(signed_requests):
    response = signed_requests()
    assert isinstance(response, dict)
    assert "Invitations" in response
    assert "NextToken" in response