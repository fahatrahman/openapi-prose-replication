# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_firestore_projects_databases_documents_begin_transaction():
    url = f"{BASE_URL}/v1/database/documents"
    headers = {
        'Content-Type': 'application/json',
    }
    data = {
        "options": {
            "readOnly": {"readTime": str(datetime.now())},
            "readWrite": {}
        }
    }

    response = requests.post(url, json=data, headers=headers)
    assert response.status_code == 200