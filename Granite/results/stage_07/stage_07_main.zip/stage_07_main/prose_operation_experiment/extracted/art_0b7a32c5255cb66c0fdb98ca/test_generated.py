import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retry logic
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def header():
    return {"access_token": os.getenv("ACCESS_TOKEN")}

def test_list_activity_feeds(header):
    owner = "test_owner"
    repo = "test_repo"
    page = 1
    limit = 10

    url = f"{BASE_URL}/repos/{owner}/{repo}/activities/feeds"
    params = {
        "date": "2022-01-01",
        "page": page,
        "limit": limit,
    }

    response = session.get(url, headers=header, params=params)

    assert response.status_code == 200
    assert isinstance(response.json(), list)