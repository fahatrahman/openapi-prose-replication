import os
import pytest
import requests
from requests.exceptions import HTTPError

BASE_URL = "http://openapi.test"
USERNAME = "Nxvhwzfd-Tpmakj-Lg"
PASSWORD = "Nxvhwzfd-Tpmakj-Krxmdv"

@pytest.fixture(scope="session")
def auth_header():
    """Return basic auth header"""
    return ("Basic", (USERNAME + ":" + PASSWORD).encode("ascii"))


def delete_target(service_id):
    """Delete target for a given service ID"""
    url = f"{BASE_URL}/api/services/{service_id}/targets"

    try:
        response = requests.delete(url, headers=auth_header())

        # Check for expected status code
        response.raise_for_status()

        return response.json()

    except HTTPError as http_err:
        print(f"HTTP error occurred: {http_err}")
    except Exception as err:
        print(f"An error occurred: {err}")
    else:
        print("Request successful.")


def test_delete_target(mocker):
    """Test deletion of a target"""
    # Mock the requests.delete method
    mocker.patch('requests.delete', side_effect=[
        {'status_code': 200, 'json': lambda: [{'host': 'www.google.com', 'scheme': 'https'}]},
        {'status_code': 400, 'json': lambda: {"message": "Bad request"}},
        {'status_code': 401, 'json': lambda: {"message": "Unauthorized"}},
        {'status_code': 404, 'json': lambda: {"message": "Not found"}}
    ])

    assert delete_target("service1") == {'status_code': 200, 'result': [{'host': 'www.google.com', 'scheme': 'https'}]}
    assert delete_target("service2") == {'status_code': 400, 'result': "Bad request"}
    assert delete_target("service3") == {'status_code': 401, 'result': "Unauthorized"}
    assert delete_target("service4") == {'status_code': 404, 'result': "Not found"}