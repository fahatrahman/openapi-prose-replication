import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_billing_group_cost_reports():
    headers = {
        "Authorization": "AWS4-HMAC-SHA256 Credential=your-credential, SignedHeaders=host;x-amz-date,x-amz-security-token, X-Amz-Algorithm=AWS4-HMAC-SHA256, X-Amz-Content-Sha256=UNSIGNED-PAYLOAD, X-Amz-Credential=your-credential, X-Amz-Security-Token=your-token, X-Amz-SignedHeaders=host;x-amz-date,x-amz-security-token",
        "Host": "openapi.test"
    }
    params = {
        "MaxResults": "10",
        "NextToken": ""
    }
    body = {
        "BillingPeriod": "2023-04",
        "Filters": {
            "BillingGroupArns": [
                "arn:aws:billingconductor::123456789012:billinggroup/example"
            ]
        },
        "MaxResults": 10,
        "NextToken": ""
    }
    response = requests.post(f"{BASE_URL}/list-billing-group-cost-reports", headers=headers, json=body, params=params)
    assert response.status_code == 200
    data = response.json()
    assert "BillingGroupCostReports" in data
    assert isinstance(data["BillingGroupCostReports"], list)