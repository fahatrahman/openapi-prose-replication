# -*- coding: utf-8 -*-

import pytest
import json
import requests

BASE_URL = "http://openapi.test"

def test_export_devices():
    url = f"{BASE_URL}/subscriptions/{'subscriptionId'}"
    headers = {'Content-Type': 'application/json'}
    
    payload = {
        "ExportBlobContainerUri": "https://example.blob.core.windows.net",
        "ExcludeKeys": False,
    }
    
    response = requests.post(f"{url}/resourceGroups/{'resourceGroupName'}/providers/Microsoft.Devices/IotHubs/{'resourceName'}/exportDevices", 
                             headers=headers, 
                             params={"api-version": "1.0.0"}, 
                             json=payload)
    
    assert response.status_code == 200
    
    job_response = response.json()
    
    assert isinstance(job_response, dict)
    
    required_fields = ["endTimeUtc", "failureReason", "jobId", "parentJobId", "startTimeUtc", "status", "statusMessage", "type"]
    for field in required_fields:
        assert field in job_response
        
@pytest.fixture(scope="session")
def api_version():
    return "1.0.0"

@pytest.fixture(scope="session")
def subscription_id():
    return "subscriptionId"

@pytest.fixture(scope="session")
def resource_group_name():
    return "resourceGroupName"

@pytest.fixture(scope="session")
def resource_name():
    return "resourceName"