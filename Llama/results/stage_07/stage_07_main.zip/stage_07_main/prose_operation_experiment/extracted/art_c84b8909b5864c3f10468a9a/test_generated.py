# -*- coding: utf-8 -*-
import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_get_organisation_applications():
    url = urljoin(BASE_URL, "/organisations/{id}/applications/{appId}")
    params = {
        "id": "your organisation id",
        "appId": "your application id"
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    assert response.json()["archived"] is False
    assert response.json()["branch"]
    assert response.json()["buildFlavor"]
    assert response.json()["cancelOnPush"] is False
    assert response.json()["commitId"]
    assert response.json()["creationDate"]
    assert response.json()["deployUrl"]
    assert response.json()["deployment"]
    assert response.json()["description"]
    assert response.json()["favourite"] is False
    assert response.json()["homogeneous"] is False
    assert response.json()["id"]
    assert response.json()["instance"]
    assert response.json()["last_deploy"] >= 0
    assert response.json()["name"]
    assert response.json()["ownerId"]
    assert response.json()["separateBuild"] is False
    assert response.json()["state"]
    assert response.json()["stickySessions"] is False
    assert response.json()["vhosts"]
    assert response.json()["webhookSecret"]
    assert response.json()["webhookUrl"]
    assert response.json()["zone"]
