import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_mapping():
    url = f"{BASE_URL}/__admin/mappings"
    payload = {
        "request": {
            "method": "POST",
            "url": "/some/thing",
            "headers": {
                "Content-Type": "application/json"
            },
            "bodyPatterns": [
                {
                    "equalToJson": "{ \"numbers\": [1, 2, 3] }"
                }
            ]
        },
        "response": {
            "status": 200,
            "headers": {
                "Content-Type": "text/plain"
            },
            "body": "Hello world!"
        }
    }
    
    response = requests.post(url, json=payload)
    
    assert response.status_code == 201
    assert response.json()["response"]["status"] == 200
    assert response.json()["response"]["body"] == "Hello world!"