import pytest
import requests
import json

BASE_URL = "http://openapi.test"

def test_get3dsavailability():
    url = f"{BASE_URL}/get3dsAvailability"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Basic Auth",
        "X-API-Key": "Your_API_Key"
    }
    
    data = {
        "cardNumber": "4111111111111111",
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "brands": ["Visa", "Mastercard"],
        "additionalData": {
            "key1": "value1",
            "key2": "value2"
        }
    }

    try:
        response = requests.post(url, headers=headers, data=json.dumps(data))
        response.raise_for_status()
        assert response.status_code == 200
        assert response.json()["threeDS1Supported"] is True
        assert response.json()["threeDS2supported"] is False
    except requests.exceptions.RequestException as e:
        pytest.fail(f"Request failed with exception: {str(e)}")
    except AssertionError as e:
        pytest.fail(f"Assertion failed: {str(e)}")

if __name__ == "__main__":
    pytest.main([__file__])