# -*- coding: utf-8 -*-
import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_locations():
    url = f"{BASE_URL}/v1beta1/{'test-project'}/locations"
    params = {
        'fields': 'locations(displayName),locations(labels)',
        'pageSize': 10,
        'filter': 'displayName=tokyo'
    }
    headers = {'Accept': 'application/json'}
    
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    
    result = response.json()
    assert isinstance(result, dict)
    assert 'locations' in result
    assert len(result['locations']) >= 0
    
@pytest.fixture(autouse=True)
def suppress_requests_warnings():
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)