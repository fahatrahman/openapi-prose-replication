import pytest
import requests

BASE_URL = "http://openapi.test"

def test_add_subnet():
    url = f"{BASE_URL}/networks/{id}/actions/add_subnet"
    payload = {
        "ip_range": "10.0.1.0/24",
        "network_zone": "eu-central",
        "type": "cloud",
        "vswitch_id": 1000
    }
    headers = {
        "Content-Type": "application/json"
    }
    response = requests.post(url, json=payload, headers=headers)
    
    assert response.status_code == 201
    action_response = response.json()
    assert "action" in action_response
    action = action_response["action"]
    assert action["command"] == "add_subnet"
    assert action["status"] in ["success", "running"]

if __name__ == "__main__":
    pytest.main()