import pytest
import requests

BASE_URL = "http://openapi.test"

def test_cancel_execution():
    url = f"{BASE_URL}/v2/projects/{project}/locations/{location}/jobs/{job}/executions/{execution}"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    payload = {
        "etag": "YOUR_ETAG",
        "validateOnly": False
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert "application/json" in response.headers["Content-Type"]
    operation = response.json()
    assert isinstance(operation, dict)
    assert "name" in operation
    assert "done" in operation
    assert "error" in operation
    assert "metadata" in operation
    assert "response" in operation