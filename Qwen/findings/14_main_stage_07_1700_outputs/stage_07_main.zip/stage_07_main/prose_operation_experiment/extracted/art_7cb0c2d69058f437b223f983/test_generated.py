import pytest
import requests

BASE_URL = "http://openapi.test"

def test_adsense_savedadstyles_get():
    saved_ad_style_id = "example_id"
    params = {
        "alt": "json",
        "fields": "adStyle(colors(background,border,text,title,url)),id,name",
        "key": "your_api_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": True,
        "quotaUser": "user@example.com",
        "userIp": "127.0.0.1"
    }
    headers = {
        "Authorization": "Bearer your_access_token"
    }
    response = requests.get(f"{BASE_URL}/savedadstyles/{saved_ad_style_id}", params=params, headers=headers)
    assert response.status_code == 200
    assert response.json()["kind"] == "adsense#savedAdStyle"