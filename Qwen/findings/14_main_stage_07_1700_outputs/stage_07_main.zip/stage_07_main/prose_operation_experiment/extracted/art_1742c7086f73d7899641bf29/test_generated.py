import pytest
import requests

BASE_URL = "http://openapi.test"

def test_teams_listAll():
    headers = {
        "X-API-Token": "your_api_token_here"
    }
    params = {
        "org_name": "your_org_name_here"
    }
    response = requests.get(f"{BASE_URL}/v0.1/orgs/{params['org_name']}/teams", headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    for item in data:
        assert isinstance(item, dict)
        required_keys = {"id", "name", "display_name"}
        assert required_keys <= set(item.keys())
        assert isinstance(item["id"], str)
        assert isinstance(item["name"], str)
        assert isinstance(item["display_name"], str)

if __name__ == "__main__":
    pytest.main()