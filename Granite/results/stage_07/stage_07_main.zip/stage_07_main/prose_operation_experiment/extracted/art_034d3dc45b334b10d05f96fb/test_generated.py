import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retry strategy
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('https://', adapter)
session.mount('http://', adapter)

# Security scheme for Amazon Signature authorization v4
def amazon_sigv4_auth(request):
    request.headers["Authorization"] = "AWS4-HMAC-SHA256 Credential={}, SignedHeaders={}, Signature={}".format(
        os.environ.get("AWS_ACCESS_KEY_ID"),
        ",".join(request.headers.keys()),
        os.environ.get("AWS_SIGNATURE")
    )

session.headers.update({"X-Amz-Algorithm": "AWSv4", "X-Amz-ContentType": "application/json"})
session.headers.update({"Authorization": None})
session.mount("https://", amazon_sigv4_auth)
session.mount("http://", amazon_sigv4_auth)

@pytest.fixture
def delete_live_source():
    def _delete_live_source(source_location_name, live_source_name):
        url = f"{BASE_URL}/sourceLocation/{source_location_name}/liveSource/{live_source_name}"
        response = session.delete(url)
        response.raise_for_status()
        return response.json()

    yield _delete_live_source

def test_delete_live_source(delete_live_source):
    source_location_name = "example_source_location"
    live_source_name = "example_live_source"
    result = delete_live_source(source_location_name, live_source_name)
    assert result == {}