import pytest
import requests
from json.decoder import JSONDecodeError

BASE_URL = "http://openapi.test"

def test_add_video_tags():
    # Prepare the request payload
    payload = [
        {"name": "awesome"},
        {"name": "another-tag"}
    ]

    headers = {
        'Content-Type': 'application/vnd.vimeo.tag+json'
    }

    response = requests.put(
        f"{BASE_URL}/videos/258684937/tags",
        headers=headers,
        json=payload
    )

    assert response.status_code == 200
    try:
        response_json = response.json()
        assert isinstance(response_json, list)
        assert all(isinstance(tag, dict) for tag in response_json)
        assert all('name' in tag for tag in response_json)
    except JSONDecodeError:
        assert False, "Invalid JSON response"