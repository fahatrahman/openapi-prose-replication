import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_photos():
    short_name = "test_short_name"
    offset = 0
    count = 10

    url = f"{BASE_URL}/v2/tier2/{short_name}/photo/photos"
    params = {
        "offset": offset,
        "count": count
    }

    response = requests.get(url, params=params)

    assert response.status_code == 200
    assert response.headers["Content-Type"].startswith("application/json")
    data = response.json()
    assert isinstance(data, dict)
    assert "Count" in data
    assert "Data" in data
    assert isinstance(data["Data"], list)
    for item in data["Data"]:
        assert isinstance(item, dict)
        assert "ETag" in item
        assert "FileName" in item
        assert "InspectionItem" in item
        assert "InterimInspection" in item
        assert "InventoryItem" in item
        assert "Name" in item
        assert "OID" in item
        assert "PhotoNumber" in item
        assert "PhotoType" in item
        assert "Property" in item
        assert "Room" in item