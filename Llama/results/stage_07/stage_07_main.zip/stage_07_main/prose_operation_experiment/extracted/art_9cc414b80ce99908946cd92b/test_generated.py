# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime
import hashlib
import hmac
import json

BASE_URL = "http://openapi.test"

def sign_request(method, path, body=None):
    timestamp = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    credential_scope = "/".join(["", "", timestamp])
    algorithm = "AWS4-HMAC-SHA256"
    credential = "AWS4" + "".join([method.upper(), path[:path.find("/")+1], timestamp[:timestamp.find("T")], credential_scope])

    message = method.upper() + "\n" + path + "\n" + str(len(body)) if body else ""
    hashed_message = hashlib.sha256(message.encode()).hexdigest()
    signature = hmac.new(
        key="your_secret_key_here",
        msg=hashed_message.encode(),
        digestmod=hashlib.sha256,
    ).hexdigest()

    return {
        "X-Amz-Algorithm": algorithm,
        "X-Amz-Credential": credential,
        "X-Amz-Date": timestamp,
        "X-Amz-SignedHeaders": "host",
        "X-Amz-Signature": signature,
        "X-Amz-Security-Token": "your_security_token_here",
    }

def create_findings_filter(name, finding_criteria, action, client_token, description="", position=100):
    url = f"{BASE_URL}/findingsfilters"
    headers = sign_request("POST", url)
    body = {
        "action": action,
        "clientToken": client_token,
        "description": description,
        "findingCriteria": {"criterion": [finding_criteria]},
        "name": name,
        "position": position,
    }
    response = requests.post(url, headers=headers, data=json.dumps(body))
    assert response.status_code == 200
    response.raise_for_status()

@pytest.mark.parametrize("name, finding_criteria, action, client_token, description, position", [
    ("test_filter", {"criterion": [{"eq": ["key", "value"]}]}, "ARCHIVE", "1234567890", "Test filter", 99),
])
def test_create_findings_filter(name, finding_criteria, action, client_token, description, position):
    try:
        create_findings_filter(name, finding_criteria, action, client_token, description, position)
    except requests.exceptions.RequestException as err:
        pytest.fail(err)
