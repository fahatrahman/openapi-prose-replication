import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_resolver():
    api_id = "test_api_id"
    type_name = "test_type_name"
    field_name = "test_field_name"
    headers = {
        "X-Amz-Content-Sha256": "example",
        "X-Amz-Date": "example",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "example",
        "X-Amz-Security-Token": "example",
        "X-Amz-Signature": "example",
        "X-Amz-SignedHeaders": "example"
    }
    url = f"{BASE_URL}/v1/apis/{api_id}/types/{type_name}/resolvers/{field_name}"
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()