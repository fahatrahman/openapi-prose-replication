import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def auth():
    return HTTPBasicAuth("username", "password")

def test_create_webproperty(auth):
    endpoint = "/management/accounts/123456/webproperties"
    headers = {"Content-Type": "application/json"}

    webproperty = {
        "name": "Test Web Property",
        "websiteUrl": "http://example.com",
        "accountId": "123456",
    }

    response = requests.post(
        BASE_URL + endpoint,
        json=webproperty,
        headers=headers,
        auth=auth,
    )

    assert response.status_code == 200

    created_webproperty = response.json()

    # Additional assertions can be added here to validate the created webproperty

    print("Test passed: Created webproperty successfully.")