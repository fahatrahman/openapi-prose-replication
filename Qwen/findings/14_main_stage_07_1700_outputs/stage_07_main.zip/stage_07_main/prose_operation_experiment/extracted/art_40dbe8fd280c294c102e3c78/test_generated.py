import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def access_token():
    return "your_access_token_here"

@pytest.fixture
def parent():
    return "projects/your_project_id/submissions"

@pytest.mark.parametrize("params", [
    {
        "_xgafv": "1",
        "alt": "json"
    },
    {
        "_xgafv": "2",
        "prettyPrint": True,
        "quotaUser": "user@example.com"
    }
])
def test_webrisk_projects_submissions_create(access_token, parent, params):
    url = f"{BASE_URL}/v1/{parent}"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }
    payload = {
        "uri": "http://example.com/test-uri"
    }
    response = requests.post(url, headers=headers, json=payload, params=params)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "uri" in response.json()