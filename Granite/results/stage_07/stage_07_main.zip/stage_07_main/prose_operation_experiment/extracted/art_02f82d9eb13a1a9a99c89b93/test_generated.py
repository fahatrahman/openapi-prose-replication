import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = "path/to/your/service_account.json"

@pytest.fixture
def auth():
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )
    return credentials

def test_evaluate_processor_version(auth):
    processor_version = "your_processor_version"
    path = f"/v1/{processor_version}:evaluateProcessorVersion"

    request_body = {
        "evaluationDocuments": {
            "gcsDocuments": {
                "documents": [
                    {"gcsUri": "gs://your_bucket/your_document.pdf", "mimeType": "application/pdf"}
                ],
                "gcsPrefix": "your_gcs_prefix/"
            }
        }
    }

    headers = {
        "Content-Type": "application/json"
    }

    response = requests.post(
        f"{BASE_URL}{path}", json=request_body, headers=headers, verify=False, auth=auth
    )

    assert response.status_code == 200
    operation_name = response.json()["name"]

    # Add more assertions or checks here based on expected behavior
