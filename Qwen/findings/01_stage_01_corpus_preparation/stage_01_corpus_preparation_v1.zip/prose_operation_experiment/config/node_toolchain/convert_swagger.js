"use strict";

const fs = require("fs");
const converter = require("swagger2openapi");

const [
    inputPath,
    outputPath,
    metadataPath
] = process.argv.slice(2);

if (!inputPath || !outputPath || !metadataPath) {
    console.error(
        "Expected input, output, and metadata paths."
    );
    process.exit(2);
}

const source = JSON.parse(
    fs.readFileSync(inputPath, "utf8")
);

const options = {
    patch: false,
    warnOnly: false,
    resolve: false,
    targetVersion: "3.0.3",
    rbname: "x-original-body-parameter-name"
};

converter.convertObj(
    source,
    options,
    (error, result) => {
        if (error) {
            console.error(
                error.stack || String(error)
            );
            process.exitCode = 1;
            return;
        }

        const openapi = result.openapi;

        if (!openapi || typeof openapi !== "object") {
            console.error(
                "Converter returned no OpenAPI document."
            );
            process.exitCode = 1;
            return;
        }

        const metadata = {
            converterVersion:
                require(
                    "swagger2openapi/package.json"
                ).version,
            targetVersion: options.targetVersion,
            outputOpenapiVersion:
                openapi.openapi || null,
            warnings: result.warnings || [],
            warningCount:
                (result.warnings || []).length,
            patches: Number(result.patches || 0),
            patchingEnabled: options.patch,
            warnOnlyEnabled: options.warnOnly,
            referenceResolutionEnabled:
                options.resolve
        };

        fs.writeFileSync(
            outputPath,
            JSON.stringify(openapi, null, 2) + "\n",
            "utf8"
        );

        fs.writeFileSync(
            metadataPath,
            JSON.stringify(metadata, null, 2) + "\n",
            "utf8"
        );
    }
);
