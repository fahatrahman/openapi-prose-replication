import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
SESSION.mount("https://", HTTPAdapter(max_retries=10))
SESSION.mount("http://", HTTPAdapter(max_retries=10))

@pytest.fixture
def server():
    server_id = "your_base64_encoded_server_id"  # Replace with actual server ID
    response = SESSION.get(urljoin(BASE_URL, f"/servers/{server_id}"))
    response.raise_for_status()
    return response.json()

def test_server_config(server):
    assert isinstance(server, dict)
    required_keys = [
        "accountCount",
        "appandroid",
        "appios",
        "appname",
        "appurl",
        "lastLogin",
        "logo",
        "owner",
        "pinTimeout",
        "pinTransTimeout",
        "pingTime",
        "serverFlags",
        "serverName",
        "serverid",
        "serverpk",
    ]

    for key in required_keys:
        assert key in server

    # Add more assertions based on expected values if needed