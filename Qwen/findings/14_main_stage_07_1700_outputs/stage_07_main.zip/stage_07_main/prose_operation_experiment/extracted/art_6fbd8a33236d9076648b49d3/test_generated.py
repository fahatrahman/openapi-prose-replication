import pytest
import requests

BASE_URL = "http://openapi.test"

def test_youtube_tests_insert():
    url = f"{BASE_URL}/youtube/v3/tests"
    headers = {
        "Content-Type": "application/json",
    }
    payload = {
        "part": ["snippet"],
        "externalChannelId": "test_channel_id",
        "body": {
            "snippet": {}
        }
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert "id" in response.json()