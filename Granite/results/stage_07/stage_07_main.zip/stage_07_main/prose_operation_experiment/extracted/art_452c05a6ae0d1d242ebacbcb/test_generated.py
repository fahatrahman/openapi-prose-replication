import os
import requests
import pytest
BASE_URL = "http://openapi.test"

def get_cis_transactions(employer_id, authorization, api_version):
    url = f"{BASE_URL}/Employer/{employer_id}/CisTransactions"
    headers = {"Authorization": authorization, "Api-Version": api_version}

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        return response.json()
    elif response.status_code == 400:
        return {"error": response.json()}
    elif response.status_code == 401:
        return {"error": response.json()}
    elif response.status_code == 404:
        return {"error": response.json()}
    elif response.status_code == 500:
        return {"error": response.json()}
    else:
        return {"error": f"Unexpected status code: {response.status_code}"}

@pytest.mark.parametrize("authorization,api_version,expected", [
    ("Auto", "default", {"Links": [{"@href": "...", "@rel": "...", "@title": "..."}]}),
    # Add more test cases here...
])
def test_get_cis_transactions(authorization, api_version, expected):
    result = get_cis_transactions("test_employer_id", authorization, api_version)
    assert result == expected