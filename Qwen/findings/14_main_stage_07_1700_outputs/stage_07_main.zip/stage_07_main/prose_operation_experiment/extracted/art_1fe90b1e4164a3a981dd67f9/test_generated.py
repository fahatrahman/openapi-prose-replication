import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_wifi_config():
    response = requests.get(f"{BASE_URL}/api/v1/config/wifi")
    assert response.status_code == 200
    wifi_config = response.json()
    assert isinstance(wifi_config, dict)
    assert 'mode' in wifi_config
    assert 'password' in wifi_config
    assert 'ssid' in wifi_config
    assert wifi_config['mode'] in ['ap', 'client']
    assert isinstance(wifi_config['password'], str)
    assert isinstance(wifi_config['ssid'], str)

if __name__ == "__main__":
    pytest.main()