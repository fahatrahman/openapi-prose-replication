import os
import pytest
import requests
from requests.exceptions import HTTPError

BASE_URL = "http://openapi.test"

@pytest.fixture
def http_client():
    session = requests.Session()
    return session

def test_get_offerings(http_client):
    url = f"{BASE_URL}/offerings"
    headers = {"Authorization": "your_api_key"}  # Replace 'your_api_key' with actual key

    try:
        response = http_client.get(url, headers=headers)
        response.raise_for_status()

        offerings = response.json()["items"]
        assert isinstance(offerings, list)
        for offering in offerings:
            assert offering["id"].strip()
            assert offering["name"].strip()
            assert offering["start"].strip()
            assert offering["end"].strip()
            assert offering["price"] > 0
            assert offering["description"].strip()
            assert offering["overview"].strip()
            assert offering["tags"] if "tags" in offering else True
            assert offering["trailerVideoUrl"].strip()
            assert offering["coverImageUrl"].strip()

            # Additional assertions based on specific requirements can be added here

        print("Test passed successfully.")

    except HTTPError as http_err:
        print(f'HTTP error occurred: {http_err}')
    except Exception as err:
        print(f'An error occurred: {err}')