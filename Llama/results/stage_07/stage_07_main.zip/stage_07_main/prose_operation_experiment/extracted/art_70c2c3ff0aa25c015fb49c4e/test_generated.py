# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_texttospeech_projects_locations_operations_get():
    response = requests.get(
        f"{BASE_URL}/v1beta1/{'name'}",
        params={
            "$.xgafv": "1",
            "access_token": None,
            "alt": "json",
            "callback": None,
            "fields": None,
            "key": None,
            "oauth_token": None,
            "prettyPrint": False,
            "quotaUser": None,
            "upload_protocol": None,
            "uploadType": None
        }
    )
    assert response.status_code == 200