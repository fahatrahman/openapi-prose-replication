import pytest
import requests
from typing import Dict, List

BASE_URL = "http://openapi.test"

class TestOpenApi:
    def test_get_dicom_stores(self):
        url = f"{BASE_URL}/v1beta1/{self.parent}/dicomStores"
        
        params: Dict[str, str] = {
            "filter": "",
            "pageSize": "100",
            "pageToken": ""
        }
        
        response = requests.get(url, params=params)
        
        assert response.status_code == 200
        
        data = response.json()
        
        assert isinstance(data, dict)
        assert 'dicomStores' in data.keys()
        assert isinstance(data['dicomStores'], list)

    def test_get_dicom_stores_with_filter(self):
        url = f"{BASE_URL}/v1beta1/{self.parent}/dicomStores"
        
        filter_value = "your_filter_value"
        params: Dict[str, str] = {
            "filter": f"your_filter_value",
            "pageSize": "100",
            "pageToken": ""
        }
        
        response = requests.get(url, params=params)
        
        assert response.status_code == 200
        
        data = response.json()
        
        assert isinstance(data, dict)
        assert 'dicomStores' in data.keys()
        assert isinstance(data['dicomStores'], list)

    @pytest.fixture(autouse=True)
    def setup(self):
        self.parent = "your_parent_path"

@pytest.mark.parametrize("filter_value", ["your_filter_value"])
def test_get_dicom_stores_with_filter_parametrize(test_open_api, filter_value):
    test_open_api.test_get_dicom_stores_with_filter(filter_value)
