# pylint: disable=redefined-outer-name
import pytest
from pytest_cases import parametrize_with_cases
import requests

BASE_URL = "http://openapi.test"

def test_read_float_table():
    url = f"{BASE_URL}/device/strategy/tables/floats/ftable"
    response = requests.get(url)
    assert response.status_code == 200
    assert response.json() == []

def test_read_float_table_start_index():
    url = f"{BASE_URL}/device/strategy/tables/floats/ftable?startIndex=5"
    response = requests.get(url)
    assert response.status_code == 200
    assert response.json() == []

def test_read_float_table_num_elements():
    url = f"{BASE_URL}/device/strategy/tables/floats/ftable?startIndex=10&numElements=3"
    response = requests.get(url)
    assert response.status_code == 200
    assert response.json() == []

def test_read_float_table_invalid_admin_or_value():
    url = f"{BASE_URL}/device/strategy/tables/floats/ftable?startIndex=-1&numElements=3"
    response = requests.get(url)
    assert response.status_code == 400
    error_response = response.json()
    assert isinstance(error_response["errorCode"], int)
    assert isinstance(error_response["message"], str)

def test_read_float_table_unauthorized():
    url = f"{BASE_URL}/device/strategy/tables/floats/ftable"
    response = requests.get(url, auth=("invalid", "invalid"))
    assert response.status_code == 401
    error_response = response.json()
    assert isinstance(error_response["errorCode"], int)
    assert isinstance(error_response["message"], str)

def test_read_float_table_not_found():
    url = f"{BASE_URL}/device/strategy/tables/nonexistent"
    response = requests.get(url)
    assert response.status_code == 404
    error_response = response.json()
    assert isinstance(error_response["errorCode"], int)
    assert isinstance(error_response["message"], str)