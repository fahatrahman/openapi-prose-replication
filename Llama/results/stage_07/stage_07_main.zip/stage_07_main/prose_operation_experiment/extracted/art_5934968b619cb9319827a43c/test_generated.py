import pytest
import requests
from urllib.parse import urljoin
from json import dumps

BASE_URL = "http://openapi.test"

def test_dialogflow_projects_locations_agents_restore():
    api_url = urljoin(BASE_URL, "/v3beta1/{name}:restore")
    headers = {
        'Content-Type': 'application/json',
    }
    payload = {
        "agentContent": b'your_agent_content_here',
        "agentUri": "gs://your_bucket_name/your_agent_file",
        "gitSource": {"trackingBranch": "your_tracking_branch"},
        "restoreOption": "KEEP"
    }

    response = requests.post(api_url, headers=headers, json=payload)

    assert response.status_code == 200
    assert isinstance(response.json(), dict)