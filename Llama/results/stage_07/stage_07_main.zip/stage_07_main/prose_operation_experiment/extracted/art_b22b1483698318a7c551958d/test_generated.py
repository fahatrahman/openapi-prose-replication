# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_import_dockerfiles():
    """Test list_import_dockerfiles endpoint"""
    response = requests.get(f"{BASE_URL}/imports/images/{pytest.param}/dockerfile", 
                            params={"operation_id": pytest.param})
    
    assert response.status_code == 200
    
    try:
        json_response = response.json()
        assert isinstance(json_response, list)
        for item in json_response:
            assert isinstance(item, str)
    except ValueError:
        assert False, "Invalid JSON"
        
    # Test 500 error case (no assertions here since we don't know what should be returned)
    response = requests.get(f"{BASE_URL}/imports/images/{pytest.param}/dockerfile")
    assert response.status_code == 500

if __name__ == "__main__":
    pytest.main([__file__, "-v"])