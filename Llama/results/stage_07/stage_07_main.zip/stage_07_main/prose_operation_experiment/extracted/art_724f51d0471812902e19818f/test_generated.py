# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_stats():
    """Test getStatsUsingPOST"""
    url = f"{BASE_URL}/getStats"
    headers = {"Content-Type": "application/json"}
    params = {"apikey": "your_api_key"}  # Replace 'your_api_key' with your actual API key
    response = requests.post(url, headers=headers, params=params)
    
    assert response.status_code == 200
    response_json = response.json()
    assert isinstance(response_json["code"], int)
    assert isinstance(response_json["data"], dict)
    assert isinstance(response_json["message"], str)

def test_get_stats_400():
    """Test getStatsUsingPOST returns 400"""
    url = f"{BASE_URL}/getStats"
    headers = {"Content-Type": "application/json"}
    params = {"apikey": "wrong_api_key"}  # Replace 'wrong_api_key' with your incorrect API key
    response = requests.post(url, headers=headers, params=params)
    
    assert response.status_code == 400
    response_json = response.json()
    assert isinstance(response_json["code"], int)
    assert isinstance(response_json["data"], dict)
    assert isinstance(response_json["message"], str)

def test_get_stats_401():
    """Test getStatsUsingPOST returns 401"""
    url = f"{BASE_URL}/getStats"
    headers = {"Content-Type": "application/json"}
    params = {}  # No API key provided
    response = requests.post(url, headers=headers, params=params)
    
    assert response.status_code == 401
    response_json = response.json()
    assert isinstance(response_json["code"], int)
    assert isinstance(response_json["data"], dict)
    assert isinstance(response_json["message"], str)

def test_get_stats_500():
    """Test getStatsUsingPOST returns 500"""
    url = f"{BASE_URL}/getStats"
    headers = {"Content-Type": "application/json"}
    params = {"apikey": "your_api_key"}  # Replace 'your_api_key' with your actual API key
    response = requests.post(url, headers=headers, params=params)
    response.raise_for_status()  # Raise an exception for bad status codes
    
    assert False, "Should have raised an exception"

if __name__ == "__main__":
    pytest.main([__file__])