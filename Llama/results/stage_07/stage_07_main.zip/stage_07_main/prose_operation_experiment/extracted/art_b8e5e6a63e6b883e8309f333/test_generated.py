# -*- coding: utf-8 -*-

import pytest
import json
import requests
from typing import Dict

BASE_URL = "http://openapi.test"

def load_json(path: str) -> Dict:
    """Load JSON file."""
    with open(path, 'r') as f:
        return json.load(f)

def get_available_rights() -> Dict:
    """Get available rights using GET /oauth/rights request."""
    response = requests.get(f"{BASE_URL}/oauth/rights")
    assert response.status_code == 200, f"Expected status code 200, got {response.status_code}"
    return response.json()

def test_get_available_rights():
    """Test getting available rights."""
    rights = get_available_rights()
    # Add your assertions here for example:
    assert isinstance(rights, dict), "Expected dictionary"
    assert 'description' in rights, "Missing description key"
    assert 'name' in rights, "Missing name key"

if __name__ == "__main__":
    pytest.main([__file__])