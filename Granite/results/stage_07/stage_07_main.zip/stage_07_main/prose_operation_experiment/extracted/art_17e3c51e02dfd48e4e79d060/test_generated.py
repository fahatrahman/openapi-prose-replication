import os
import pytest
import requests
BASE_URL = "http://openapi.test"

@pytest.fixture
def forwarding_addresses():
    url = f"{BASE_URL}/gmail/v1/users/me/settings/forwardingAddresses"
    headers = {
        "Alt": "json",
    }
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    return response.json()["forwardingAddresses"]

def test_forwarding_addresses(forwarding_addresses):
    assert isinstance(forwarding_addresses, list)
    for address in forwarding_addresses:
        assert "forwardingEmail" in address
        assert "verificationStatus" in address