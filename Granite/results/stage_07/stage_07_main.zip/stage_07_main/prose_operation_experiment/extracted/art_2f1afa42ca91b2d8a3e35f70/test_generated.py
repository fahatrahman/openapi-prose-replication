import os
import pytest
import requests
from googleapiclient.discovery import build

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def dfa_service():
    """Create a DFA service object."""
    api_service_name = "dfareporting"
    api_version = "v3"

    # Build the service object for DFA.
    service = build(api_service_name, api_version, developerKey="YOUR_DEVELOPER_KEY")

    return service

def test_get_operating_system(dfa_service):
    """Test getting an operating system by DART ID."""
    profile_id = "YOUR_PROFILE_ID"
    dart_id = "YOUR_DART_ID"

    try:
        response = dfa_service.operatingSystems().get(
            profileId=profile_id, dartId=dart_id
        ).execute()

        assert response["kind"] == "dfareporting#operatingSystem"
        assert isinstance(response["dartId"], str)
        assert isinstance(response["name"], str)
        assert isinstance(response["desktop"], bool)
        assert isinstance(response["mobile"], bool)

    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")
        assert False