# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_artifact_versions():
    """Test listArtifactVersions"""
    
    # Get all versions of artifact Topic-1/Inbound
    response = requests.get(f"{BASE_URL}/artifacts/Topic-1/Inbound/versions")
    
    assert response.status_code == 200
    
    # Check if response is JSON
    assert response.headers["Content-Type"] == "application/json"
    
    # Check if response body is correct
    expected_response_body = [5, 6, 10, 103]
    assert response.json() == expected_response_body

def test_list_artifact_versions_not_found():
    """Test listArtifactVersions when artifact does not exist"""
    
    # Try to get all versions of non-existent artifact
    response = requests.get(f"{BASE_URL}/artifacts/NonExistentArtifact/versions")
    
    assert response.status_code == 404
    
    # Check if response is JSON
    assert response.headers["Content-Type"] == "application/json"
    
    # Check if response body is correct
    expected_response_body = {"error_code": 404, "message": "No artifact with id 'NonExistentArtifact/versions' could be found."}
    assert response.json() == expected_response_body

def test_list_artifact_versions_server_error():
    """Test listArtifactVersions when server encounters an error"""
    
    # Introduce a temporary server error by mocking the request
    def mock_get(*args, **kwargs):
        return requests.Response()
    
    requests.get = mock_get
    
    # Try to get all versions of existing artifact
    try:
        response = requests.get(f"{BASE_URL}/artifacts/Topic-1/Inbound/versions")
        assert False, "Expected ServerError"
    except requests.RequestException as e:
        assert isinstance(e.response, requests.Response)
        assert e.response.status_code == 500
        
        # Check if response is JSON
        assert e.response.headers["Content-Type"] == "application/json"
        
        # Check if response body is correct
        expected_response_body = {"error_code": 500, "message": "Lost connection to the database."}
        assert e.response.json() == expected_response_body