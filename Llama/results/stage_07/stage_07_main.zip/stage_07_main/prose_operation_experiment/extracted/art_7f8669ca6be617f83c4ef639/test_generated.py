# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime
from urllib.parse import quote_plus

BASE_URL = "http://openapi.test"

def get_timestamp():
    return int(datetime.now().timestamp() * 1000)

def calculate_amz_date(timestamp):
    return datetime.fromtimestamp(timestamp / 1000).strftime('%Y%m%dT%H%M%SZ')

def calculate_signed_headers(headers):
    return ','.join([key for key in headers.keys()])

def sign_request(method, path, body, headers, timestamp, secret_key):
    amz_date = calculate_amz_date(timestamp)
    signed_headers = calculate_signed_headers(headers)
    
    payload = {
        'Action': method,
        'Version': '2017-01-11',
        'X-Amz-Algorithm': 'AWS4-HMAC-SHA256',
        'X-Amz-Date': amz_date,
        'X-Amz-SignedHeaders': signed_headers,
    }
    
    if body:
        payload['X-Amz-Signature'] = ''
        
    canonical_request = '\n'.join([
        method + ' ' + path + ' ' + '\n'.join([f'{key}: {value}' for key, value in headers.items()]),
        '',
        '',
        '',
        '',
        '\n'.join([f'{key}: {quote_plus(str(value))}' for key, value in sorted(payload.items())])
    ])
    
    algorithm = 'AWS4-HMAC-SHA256'
    credential_scope = '/'.join(['20170111', region, service, 'aws4_request'])
    string_to_sign = '\n'.join([
        algorithm,
        timestamp,
        amz_date,
        credential_scope,
    ])
    
    hashed_canonical_request = hashlib.sha256(canonical_request.encode('utf-8')).hexdigest()
    signature = hmac.new(
        (secret_key + '&').encode('utf-8'),
        (algorithm + '\n' + str(timestamp) + '\n' + amz_date + '\n' + credential_scope + '\n' +
         hashed_canonical_request).encode('utf-8'), 
        digestmod=hashlib.sha256
    ).hexdigest()
    
    if body:
        payload['X-Amz-Signature'] = signature
    
    return payload

class TestListAppliedSchemaArns:

    def setup_method(self, method):
        self.timestamp = get_timestamp()
        self.secret_key = 'your_secret_key_here'
        self.region = 'your_region_here'
        self.service = 'cloud-directory'
        
        self.headers = {
            'X-Amz-Algorithm': 'AWS4-HMAC-SHA256',
            'X-Amz-Credential': f'{self.secret_key}/20170111/{self.region}/{self.service}/aws4_request',
            'X-Amz-Date': calculate_amz_date(self.timestamp),
            'X-Amz-Security-Token': '',
            'X-Amz-Signature': '',
            'X-Amz-SignedHeaders': 'host;x-amz-date',
        }
        
        self.body = {
            'DirectoryArn': 'arn:aws:clouddirectory:region-id:account-id:directory/directory-id',
            'MaxResults': 10,
            'NextToken': None,
            'SchemaArn': 'arn:aws:clouddirectory:region-id:account-id:schema/schema-id',
        }

    @pytest.mark.parametrize("method, status_code", [
        ('POST', 200),
        # Add more cases here...
    ])
    def test_list_applied_schema_arns(self, method, status_code):
        url = f'{BASE_URL}/amazonclouddirectory/2017-01-11/schema/applied'
        response = requests.request(method, url, json=self.body, headers=self.headers)
        assert response.status_code == status_code
        
        if status_code != 200:
            return
        
        payload = sign_request(method, url, response.json(), self.headers, self.timestamp, self.secret_key)
        
        assert response.json()['NextToken']
        
        self.headers['X-Amz-SignedHeaders'] += ',next-token'
        self.headers['X-Amz-Signature'] = ''
        payload = sign_request(method, url, response.json(), self.headers, self.timestamp, self.secret_key)
        
        response = requests.request(method, url, json=response.json(), headers=self.headers)
        assert response.status_code == status_code
        
        payload = sign_request(method, url, response.json(), self.headers, self.timestamp, self.secret_key)
        
        assert response.json()['SchemaArns']
