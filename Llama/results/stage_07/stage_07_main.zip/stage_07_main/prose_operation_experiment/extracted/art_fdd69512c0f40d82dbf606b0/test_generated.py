# -*- coding: utf-8 -*-

import pytest
import requests
from jsonschema import validate
import base64
import hashlib
import hmac
import datetime
import time

BASE_URL = "http://openapi.test"

def get_timestamp():
    return str(int(time.time()))

def sign_request(method, path, headers, payload):
    algorithm = 'AWS4-HMAC-SHA256'
    credential = headers['X-Amz-Credential']
    date = headers['X-Amz-Date']
    signed_headers = headers['X-Amz-SignedHeaders']

    canonical_request = method + "\n" + path + "\n" + get_canonical_request_payload(payload) + "\n" + get_string_to_sign(algorithm, date, credential, signed_headers)
    signature = get_signature(canonical_request, algorithm, credential, date)

    return signature

def get_canonical_request_payload(payload):
    return str(len(payload)).encode('utf-8') + b'\n' + payload

def get_string_to_sign(algorithm, date, credential, signed_headers):
    return algorithm + '\n' + date + '\n' + credential + '\n' + signed_headers

def get_signature(canonical_request, algorithm, credential, date):
    key_date = hmac.new(('AWS4' + credential.split('.')[3]).encode('utf-8'), date.encode('utf-8'), hashlib.sha256).digest()
    key_region = hmac.new(key_date, '20141010'.encode('utf-8'), hashlib.sha256).digest()
    key_service = hmac.new(key_region, 'execute-api'.encode('utf-8'), hashlib.sha256).digest()
    keySigning = hmac.new(key_service, canonical_request.encode('utf-8'), hashlib.sha256).digest()

    return base64.b64encode(hmac.new(keySigning, b'', hashlib.sha256).digest()).decode('utf-8')

def create_auth_header(credential, date, algorithm, signed_headers, signature):
    auth_string = 'Credential=' + credential + ', SignedHeaders=' + signed_headers + ', Signature=' + signature
    return 'AWS4-HMAC-SHA256 Credential=' + credential + ', SignedHeaders=' + signed_headers + ', Signature=' + signature

def get_canonical_request(headers, payload):
    return str(headers.get('Host')).encode('utf-8') + b'\n' + get_sorted_headers(headers) + b'\n' + get_canonical_request_payload(payload)

def get_sorted_headers(headers):
    sorted_keys = sorted(headers.keys())
    return '\n'.join([key + ':' + value for key, value in [ (key, headers[key]) for key in sorted_keys ]])

def test_DeleteInvitations():
    url = BASE_URL + '/invitations/delete'

    account_ids = ["account_id_1", "account_id_2"]
    headers = {
        'X-Amz-Algorithm': 'AWS4-HMAC-SHA256',
        'X-Amz-Content-Sha256': get_content_sha256(),
        'X-Amz-Credential': 'AWS_ACCESS_KEY_ID/20141010/us-east-1/execute-api/aws4_request',
        'X-Amz-Date': get_timestamp(),
        'X-Amz-Security-Token': '',
        'X-Amz-SignedHeaders': 'host;x-amz-date',
        'X-Amz-Signature': sign_request('POST', url, headers, bytes(json.dumps({"AccountIds": account_ids}), encoding="utf-8")),
        'Host': 'openapi.test',
        'Authorization': ''
    }

    response = requests.post(url, headers=headers, data=json.dumps({"AccountIds": account_ids}))

    assert response.status_code == 200
    assert validate(instance=response.json(), schema={"$ref": "#/components/schemas/DeleteInvitationsResponse"}) is None

import json