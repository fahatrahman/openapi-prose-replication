import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_operations():
    params = {
        "name": "example-operation",
        "filter": "",
        "pageSize": 10,
        "pageToken": ""
    }
    headers = {"Content-Type": "application/json"}

    try:
        response = requests.get(f"{BASE_URL}/v1/{params['name']}/operations", 
                                params=params, 
                                headers=headers)
        assert response.status_code == 200
        response.raise_for_status()
    except requests.RequestException as e:
        pytest.fail(f"Request failed: {e}")