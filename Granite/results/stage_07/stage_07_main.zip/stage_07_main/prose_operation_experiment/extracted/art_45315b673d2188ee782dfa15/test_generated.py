import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)
headers = {"xero-tenant-id": os.environ["XERO_TENANT_ID"]}

@pytest.fixture
def association_data():
    return [
        {
            "FileId": "6beccb4a-0d7d-4518-93f3-e0cd1dccb254",
            "ObjectId": "1270bf7c-5d18-473a-9231-1e36c4bd33ed",
            "ObjectType": "Business",
            "ObjectGroup": "Contact"
        }
    ]

def test_file_associations(association_data):
    file_id = "4ff1e5cc-9835-40d5-bb18-09fdb118db9c"
    url = f"{BASE_URL}/Files/{file_id}/Associations"

    response = session.get(url, headers=headers)
    assert response.status_code == 200
    assert response.json() == association_data