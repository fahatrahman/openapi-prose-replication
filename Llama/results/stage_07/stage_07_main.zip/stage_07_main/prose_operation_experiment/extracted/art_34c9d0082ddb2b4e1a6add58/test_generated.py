# -*- coding: utf-8 -*-

import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

def test_Application_DeleteAttributesV2():
    application_id = "your_application_id"
    attribute_name = "your_attribute_name"
    
    url = f"{BASE_URL}/api/v2/application/{application_id}/attributes?name={attribute_name}"
    
    response = requests.delete(url)
    
    assert response.status_code == 200
    
    # Note: The schema type is string in this example, so we can't validate the content directly.
    # In a real-world scenario, you would need to know the actual structure of the response.
    # For demonstration purposes, we'll just check if the content is not empty.
    assert response.text.strip() != ""