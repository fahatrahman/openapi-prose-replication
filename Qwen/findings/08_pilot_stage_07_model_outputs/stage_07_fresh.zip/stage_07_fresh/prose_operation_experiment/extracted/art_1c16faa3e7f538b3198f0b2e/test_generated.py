import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_tokens():
    url = f"{BASE_URL}/v1/tokens"
    params = {
        "paginate_limit": 20,
        "paginate_page": "1",
        "paginate_enabled": True,
        "sort_by": "createdAt",
        "sort_order": "desc",
        "createdAt[$gte]": "2023-01-01T00:00:00Z",
        "createdAt[$lte]": "2023-12-31T23:59:59Z",
        "updatedAt[$gte]": "2023-01-01T00:00:00Z",
        "updatedAt[$lte]": "2023-12-31T23:59:59Z",
        "include_driver": False,
        "include_organization": False
    }
    headers = {
        "Authorization": "Bearer <your_access_token>"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    assert response.json()["ok"]
    assert isinstance(response.json()["result"]["items"], list)

if __name__ == "__main__":
    pytest.main()