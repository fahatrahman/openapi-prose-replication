import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS = service_account.Credentials.from_service_account_file("path/to/credentials.json")

@pytest.fixture
def cloudfunctions():
    url = f"{BASE_URL}/v2/{os.getenv('PROJECT')}/locations"
    headers = {"Authorization": f"Bearer {CREDENTIALS.token}"}

    def _get():
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        return response.json()

    yield _get

def test_list_locations(cloudfunctions):
    response = cloudfunctions()
    assert response["locations"]
    assert "nextPageToken" in response