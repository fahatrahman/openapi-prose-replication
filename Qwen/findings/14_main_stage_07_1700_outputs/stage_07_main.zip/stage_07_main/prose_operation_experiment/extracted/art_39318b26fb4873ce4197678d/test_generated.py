import pytest
import requests

BASE_URL = "http://openapi.test"

def test_analyze_move():
    url = f"{BASE_URL}/v1/projects/my-project-id:analyzeMove"
    params = {
        "destinationParent": "folders/123",
        "view": "FULL"
    }
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    response = requests.get(url, params=params, headers=headers)
    
    assert response.status_code == 200
    assert "moveAnalysis" in response.json()

if __name__ == "__main__":
    pytest.main()