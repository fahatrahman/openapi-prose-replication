import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS = service_account.Credentials.from_service_account_file("path/to/credentials.json")

@pytest.fixture
def http_client():
    session = requests.Session()
    session.mount("https://", requests.adapters.HTTPAdapter(max_retries=10))
    auth = CREDENTIALS.authorize(http_client=session)
    session.headers.update({"Authorization": f"Bearer {auth}"})
    return session

def test_cancel_operation(http_client):
    path = "/v1alpha1/operations/example_operation:cancel"
    response = http_client.post(BASE_URL + path, json={"displayName": "example"})

    assert response.status_code == 200
    assert response.json() == {"empty": {}}