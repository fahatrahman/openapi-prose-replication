import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS = service_account.Credentials.from_service_account_file(
    "path/to/your/service_account_file.json"
)

@pytest.fixture
def authenticated_session():
    auth_http = requests.AuthBase()

    def request_callback(r):
        r.headers["Authorization"] = f"Bearer {CREDENTIALS.token}"
        return r

    auth_http.request_callback = request_callback
    return requests.Session()


def test_list_user_workload_secrets(authenticated_session):
    parent = "projects/<PROJECT_ID>/locations/<LOCATION_ID>/environments/<ENVIRONMENT_ID>"
    params = {
        "parent": parent,
        "pageSize": 10,
        "pageToken": "<PAGE_TOKEN>"
    }

    response = authenticated_session.get(
        f"{BASE_URL}/v1beta1/{parent}/userWorkloadsSecrets",
        params=params,
        headers={"x-goog-api-client": "gl-python"},
    )

    assert response.status_code == 200

    data = response.json()
    secrets = data["userWorkloadsSecrets"]
    assert len(secrets) == params.get("pageSize")
    assert data.get("nextPageToken") is not None