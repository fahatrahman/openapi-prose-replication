import pytest
import requests

BASE_URL = "http://openapi.test"

def test_update_connector_registration():
    url = f"{BASE_URL}/update-connector-registration"
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20230414/us-east-1/execute-api/aws4_request",
        "X-Amz-Date": "20230414T000000Z",
        "X-Amz-Security-Token": "EXAMPLETOKEN",
        "X-Amz-Signature": "EXAMPLESIGNATURE",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-algorithm;x-amz-credential;x-amz-security-token",
        "Authorization": "AWS4-HMAC-SHA256 Credential=AKIAIOSFODNN7EXAMPLE/20230414/us-east-1/execute-api/aws4_request,SignedHeaders=host;x-amz-content-sha256;x-amz-date;x-amz-algorithm;x-amz-credential;x-amz-security-token,Signature=EXAMPLESIGNATURE"
    }
    payload = {
        "clientToken": "example-client-token",
        "connectorLabel": "example-label",
        "connectorProvisioningConfig": {
            "lambda": {
                "lambdaArn": "arn:aws:lambda:us-east-1:123456789012:function:example-lambda"
            }
        },
        "description": "Example description"
    }
    response = requests.post(url, json=payload, headers=headers)
    assert response.status_code == 200
    assert "connectorArn" in response.json()