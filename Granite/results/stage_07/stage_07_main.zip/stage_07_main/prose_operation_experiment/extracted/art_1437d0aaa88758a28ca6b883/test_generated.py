import os
import pytest
import requests
from requests_aws_sigv4 import AWSSignaturesV4Auth

BASE_URL = "http://openapi.test"

@pytest.fixture()
def setup_recipe():
    name = "sample_recipe"

    def teardown():
        try:
            requests.delete(f"{BASE_URL}/recipes/{name}/publishRecipe")
        except Exception as e:
            print(f"Error during cleanup: {e}")

    return name, teardown

def test_publish_recipe():
    name, teardown = setup_recipe()

    payload = {"Description": "Sample description for publishing recipe."}
    headers = {
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Date": "20220101T000000Z",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "aki.us-east-1.eksctl.io%2Faccess-key%2F20220101%2Fus-east-1%2Fs3%2Faws4_request",
        "X-Amz-Security-Token": "",
        "X-Amz-Signature": "EXAMPLESIGNATURE",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-algorithm",
    }

    auth = AWSSignaturesV4Auth(
        access_key="YOUR_ACCESS_KEY", secret_key="YOUR_SECRET_KEY"
    )

    response = requests.post(
        f"{BASE_URL}/recipes/{name}/publishRecipe",
        json=payload,
        headers=headers,
        auth=auth,
    )

    assert response.status_code == 200

    teardown()