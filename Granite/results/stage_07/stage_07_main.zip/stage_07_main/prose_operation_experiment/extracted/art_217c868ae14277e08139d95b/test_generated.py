import os
import pytest
import requests
from requests_toolbelt import MultipartEncoder

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def setup():
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "TEST_CREDENTIALS",
        "X-Amz-Date": "20220901T000000Z",
        "X-Amz-Exponent": "64",
        "X-Amz-SignedHeaders": "host;x-amz-algorithm;x-amz-credential;x-amz-date;x-amz-exponent",
        "X-Amz-Signature": "TEST_SIGNATURE",
    }

    return headers

def test_search_associated_transcripts(setup):
    url = f"{BASE_URL}/bots/botid/botversions/draft/botlocales/localeid/botrecommendations/botrecommendationid/associatedtranscripts"

    payload = {
        "filters": [
            {
                "name": "IntentId",
                "values": ["intent_value"]
            }
        ],
        "maxResults": 100,
        "nextIndex": 0,
        "searchOrder": "Ascending"
    }

    multipart = MultipartEncoder(
        fields={
            "body": requests.Request("POST", url, headers=setup, json=payload).body
        }
    )

    response = requests.post(url, headers=setup, data=multipart)

    assert response.status_code == 200
    # Add more assertions as needed based on the expected response schema