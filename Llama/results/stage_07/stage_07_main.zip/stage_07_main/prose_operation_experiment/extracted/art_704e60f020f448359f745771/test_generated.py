# -*- coding: utf-8 -*-

import pytest
import json
import requests

BASE_URL = "http://openapi.test"

def test_post_cis_instruction_into_sub_contractor():
    employer_id = "ER001"
    sub_contractor_id = "SUB001"
    auth_header = "Auto"
    api_version = "default"

    headers = {
        "Authorization": auth_header,
        "Api-Version": api_version
    }

    body = {
        "CisInstruction": {
            "CisLineTag": "test_tag",
            "CisLineType": "test_type",
            "Description": "test_description",
            "PayFrequency": "Monthly",
            "PeriodEnd": 12345,
            "PeriodStart": 67890,
            "TaxYearEnd": 11111,
            "TaxYearStart": 22222,
            "UOM": "NotSet",
            "Units": 100.5,
            "VAT": 20.5,
            "Value": 50.99
        }
    }

    response = requests.post(
        f"{BASE_URL}/Employer/{employer_id}/SubContractor/{sub_contractor_id}/CisInstructions",
        headers=headers,
        json=body
    )

    assert response.status_code == 201
    assert response.json()["Link"]["@href"]