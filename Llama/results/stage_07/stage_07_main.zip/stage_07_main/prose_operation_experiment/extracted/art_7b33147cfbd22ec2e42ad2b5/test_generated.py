import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def create_recipe(name, description, steps, tags):
    headers = {
        'X-Amz-Algorithm': '',
        'X-Amz-Content-Sha256': '',
        'X-Amz-Credential': '',
        'X-Amz-Date': get_amz_date(),
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': '',
        'X-Amz-SignedHeaders': ''
    }

    body = {
        'Description': description,
        'Name': name,
        'Steps': steps,
        'Tags': tags
    }

    response = requests.post(
        f"{BASE_URL}/recipes",
        headers=headers,
        json=body
    )

    return response.json()

def get_amz_date():
    now = datetime.now()
    return now.strftime('%Y%m%dT%H%M%SZ')

@pytest.mark.asyncio
async def test_create_recipe():
    recipe_name = "Test Recipe"
    recipe_description = "This is a test recipe."
    recipe_steps = [
        {"Action": "Test Action", "ConditionExpressions": []},
        {"Action": "Another Test Action", "ConditionExpressions": []}
    ]
    recipe_tags = {
        "Tag1": "Value1",
        "Tag2": "Value2"
    }

    response = create_recipe(recipe_name, recipe_description, recipe_steps, recipe_tags)

    assert response['Name'] == recipe_name
    assert response['Description'] == recipe_description

@pytest.fixture
def recipe_response():
    return create_recipe("Test Recipe", "This is a test recipe.", [{"Action": "Test Action", "ConditionExpressions": []}], {"Tag1": "Value1"})

def test_recipe_response(recipe_response):
    assert recipe_response['Name'] == "Test Recipe"
    assert recipe_response['Description'] == "This is a test recipe."

if __name__ == "__main__":
    pytest.main([__file__, '-v'])