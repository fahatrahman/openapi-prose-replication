import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_images_from_files():
    api_key = "{API Key}"
    project_id = "64b822c5-8082-4b36-a426-27225f4aa18c"
    headers = {
        "Training-Key": api_key,
        "Content-Type": "application/json"
    }
    payload = {
        "images": [
            {
                "contents": open("hemlock_10.jpg", "rb").read(),
                "name": "hemlock_10.jpg",
                "regions": [],
                "tagIds": []
            }
        ],
        "tagIds": []
    }

    response = requests.post(f"{BASE_URL}/projects/{project_id}/images/files", headers=headers, json=payload)

    assert response.status_code == 200
    assert response.json()["isBatchSuccessful"]