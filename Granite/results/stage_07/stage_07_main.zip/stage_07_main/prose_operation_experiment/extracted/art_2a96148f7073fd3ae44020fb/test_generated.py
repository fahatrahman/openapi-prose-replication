import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.fixture
def api_token():
    return os.environ.get("API_TOKEN")

def test_errors_group_model_counts(api_token):
    url = f"{BASE_URL}/v0.1/apps/test_owner/test_app/errors/errorGroups/test_errorGroupId/models"
    headers = {"X-API-Token": api_token}

    response = SESSION.get(url, headers=headers)

    if response.status_code == 200:
        expected_result = {
            "errorCount": 123,
            "models": [
                {
                    "errorCount": 45,
                    "modelCode": "model1",
                    "modelName": "Model One",
                },
                {
                    "errorCount": 34,
                    "modelCode": "model2",
                    "modelName": "Model Two",
                },
            ],
        }

        assert response.json() == expected_result
    else:
        error_response = response.json()
        assert error_response["error"]["code"] == "InternalServerError"
        assert error_response["error"]["message"] == "Internal Server Error"