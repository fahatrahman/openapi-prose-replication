import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retry strategy
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def globalpageload():
    for param in [
        {"name": "license", "value": "your_license"},
        {"name": "origin", "value": "your_origin"},
        {"name": "url", "value": "your_url"},
    ]:
        response = session.get(
            f"{BASE_URL}/globalpageload", params={param["name"]: param["value"]}
        )
        response.raise_for_status()
        return response.json()

def test_globalpageload(globalpageload):
    assert "Code" in globalpageload
    assert "Contents" in globalpageload
    assert "Credits" in globalpageload
    assert "Origin" in globalpageload
    assert "PageResponseStatus" in globalpageload
    assert "Seconds" in globalpageload