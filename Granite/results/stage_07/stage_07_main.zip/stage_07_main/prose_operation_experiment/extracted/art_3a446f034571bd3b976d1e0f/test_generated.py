import os
import pytest
import requests
from googleapiclient.discovery import build
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = 'path/to/service_account.json'
SCOPES = ['https://www.googleapis.com/auth/drive.labels']

def test_batch_update_label_permissions():
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    service = build('drivelabels', 'v2beta', credentials=credentials)

    parent = 'ytspfo/your_parent_value'
    request_body = {
        "requests": [
            {
                "labelPermission": {
                    "audience": "audience_value",
                    "email": "email_value",
                    "group": "group_value",
                    "name": "name_value",
                    "person": "person_value",
                    "role": "role_value"
                },
                "parent": parent,
                "useAdminAccess": True
            }
        ]
    }

    response = service.labels().revisions().permissions().batchUpdate(
        parent=parent, body=request_body).execute()

    assert response['permissions'][0]['audience'] == 'audience_value'
    assert response['permissions'][0]['email'] == 'email_value'
    assert response['permissions'][0]['group'] == 'group_value'
    assert response['permissions'][0]['name'] == 'name_value'
    assert response['permissions'][0]['person'] == 'person_value'
    assert response['permissions'][0]['role'] == 'role_value'