# -*- coding: utf-8 -*-
"""
pytest module for OpenAPI operations.

BASE_URL should be set to the base URL of your API before running tests.
"""

import pytest
import requests
from datetime import datetime, timedelta

def test_issue_token():
    # Set base URL
    BASE_URL = "http://openapi.test"

    # Define valid request body
    new_token_request = {
        "entityToken": "00000000-0000-0000-0000-000000000000",
        "expirationDate": (datetime.utcnow() + timedelta(minutes=5)).isoformat(),
        "userToken": "00000000-0000-0000-0000-000000000000"
    }

    # Send POST request to issue token
    headers = {"Token": "User Authentication Token"}
    response = requests.post(
        f"{BASE_URL}/administration/token",
        headers=headers,
        json=new_token_request,
        content_type="application/json"
    )

    # Check if response was successful
    assert response.status_code == 200

    # Extract token from response
    token = response.text.strip()

    # Verify token format
    assert len(token) == 36  # UUID length in hexadecimal notation

if __name__ == "__main__":
    pytest.main([__file__])