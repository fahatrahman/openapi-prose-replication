import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_api_key():
    target_id = "some_target_id"
    id = "some_id"
    headers = {
        "Authorization": "Bearer some_jwt_token"
    }
    url = f"{BASE_URL}/targets/{target_id}/keys/{id}"
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert 'id' in response.json()
    assert 'key' in response.json()
    assert 'name' in response.json()

def test_forbidden_error():
    target_id = "some_target_id"
    id = "some_id"
    headers = {
        "Authorization": "Bearer invalid_jwt_token"
    }
    url = f"{BASE_URL}/targets/{target_id}/keys/{id}"
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 403
    assert 'detail' in response.json()
    assert response.json()['detail'] == "Phbnl qquvejv."

def test_not_found_error():
    target_id = "nonexistent_target_id"
    id = "nonexistent_id"
    headers = {
        "Authorization": "Bearer some_jwt_token"
    }
    url = f"{BASE_URL}/targets/{target_id}/keys/{id}"
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 404
    assert 'detail' in response.json()
    assert response.json()['detail'] == "Hwy aqprs."