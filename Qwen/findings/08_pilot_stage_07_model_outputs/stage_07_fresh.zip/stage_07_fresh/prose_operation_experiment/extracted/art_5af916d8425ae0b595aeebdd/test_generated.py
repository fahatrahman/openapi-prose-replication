import pytest
import requests

BASE_URL = "http://openapi.test"

def test_test_iam_permissions():
    url = f"{BASE_URL}/v1/projects/locations/restorePlans/restores/volumeRestores:testIamPermissions"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "permissions": ["storage.objects.get"]
    }
    params = {
        "_xgafv": "1",
        "access_token": "YOUR_ACCESS_TOKEN",
        "alt": "json",
        "callback": "callback",
        "fields": "permissions",
        "key": "YOUR_API_KEY",
        "oauth_token": "YOUR_OAUTH_TOKEN",
        "prettyPrint": True,
        "quotaUser": "user",
        "uploadType": "media",
        "upload_protocol": "raw"
    }

    response = requests.post(url, headers=headers, json=payload, params=params)

    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "permissions" in response.json()