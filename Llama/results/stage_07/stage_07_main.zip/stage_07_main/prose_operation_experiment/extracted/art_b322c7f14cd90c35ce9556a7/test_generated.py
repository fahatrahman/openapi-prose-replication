import pytest
import requests

BASE_URL = "http://openapi.test"

def test_scim_create_user():
    url = f"{BASE_URL}/v2/scim/2.0/Users"
    headers = {"Content-Type": "application/scim+json"}
    
    user_data = {
        "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
        "userName": "test.user@example.com",
        "name": {
            "familyName": "Test",
            "givenName": "User"
        },
        "emails": [{"value": "test.user@example.com", "primary": True}]
    }
    
    response = requests.post(url, json=user_data, headers=headers)
    assert response.status_code == 201
    assert response.json()["schemas"][0] == "urn:ietf:params:scim:schemas:core:2.0:User"
    assert response.json()["userName"] == "test.user@example.com"
    assert response.json()["name"]["familyName"] == "Test"
    assert response.json()["name"]["givenName"] == "User"
    assert len(response.json()["emails"]) == 1
    assert response.json()["emails"][0]["value"] == "test.user@example.com"
    assert response.json()["emails"][0].get("primary") is True
    
def test_scim_create_user_bad_request():
    url = f"{BASE_URL}/v2/scim/2.0/Users"
    headers = {"Content-Type": "application/scim+json"}
    
    user_data = {
        "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"]
    }
    
    response = requests.post(url, json=user_data, headers=headers)
    assert response.status_code == 400
    
def test_scim_create_user_conflict():
    url = f"{BASE_URL}/v2/scim/2.0/Users"
    headers = {"Content-Type": "application/scim+json"}
    
    user_data = {
        "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
        "userName": "test.user@example.com",
        "name": {
            "familyName": "Test",
            "givenName": "User"
        },
        "emails": [{"value": "test.user@example.com", "primary": True}]
    }
    
    # Simulate conflict by sending same user data again
    response = requests.post(url, json=user_data, headers=headers)
    assert response.status_code == 409
    
def test_scim_create_user_forbidden():
    url = f"{BASE_URL}/v2/scim/2.0/Users"
    headers = {"Content-Type": "application/scim+json"}
    
    user_data = {
        "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
        "userName": "test.user@example.com",
        "name": {
            "familyName": "Test",
            "givenName": "User"
        },
        "emails": [{"value": "test.user@example.com", "primary": True}]
    }
    
    # Simulate forbidden by setting invalid headers
    headers["Authorization"] = "InvalidToken"
    response = requests.post(url, json=user_data, headers=headers)
    assert response.status_code == 403
    
def test_scim_create_user_not_found():
    url = f"{BASE_URL}/v2/scim/2.0/Users"
    headers = {"Content-Type": "application/scim+json"}
    
    user_data = {
        "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
        "userName": "non.existent.user@example.com",
        "name": {
            "familyName": "Non Existent",
            "givenName": "User"
        },
        "emails": [{"value": "non.existent.user@example.com", "primary": True}]
    }
    
    response = requests.post(url, json=user_data, headers=headers)
    assert response.status_code == 404
    
def test_scim_create_user_unauthorized():
    url = f"{BASE_URL}/v2/scim/2.0/Users"
    headers = {"Content-Type": "application/scim+json"}
    
    user_data = {
        "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
        "userName": "test.user@example.com",
        "name": {
            "familyName": "Test",
            "givenName": "User"
        },
        "emails": [{"value": "test.user@example.com", "primary": True}]
    }
    
    # Simulate unauthorized by removing Authorization header
    del headers["Authorization"]
    response = requests.post(url, json=user_data, headers=headers)
    assert response.status_code == 401
    
def test_scim_create_user_internal_error():
    url = f"{BASE_URL}/v2/scim/2.0/Users"
    headers = {"Content-Type": "application/scim+json"}
    
    user_data = {
        "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
        "userName": "test.user@example.com",
        "name": {
            "familyName": "Test",
            "givenName": "User"
        },
        "emails": [{"value": "test.user@example.com", "primary": True}]
    }
    
    # Simulate internal error by setting invalid JSON
    user_data = "Invalid JSON"
    response = requests.post(url, json=user_data, headers=headers)
    assert response.status_code == 500