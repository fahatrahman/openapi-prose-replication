import pytest
import requests

BASE_URL = "http://openapi.test"

def test_failover_instance():
    url = f"{BASE_URL}/v1/projects/location/clusters/instance:failover"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "requestId": "unique-request-id",
        "validateOnly": False
    }
    params = {
        "_xgafv": "2",
        "access_token": "YOUR_ACCESS_TOKEN",
        "alt": "json",
        "callback": "",
        "fields": "*",
        "key": "YOUR_API_KEY",
        "oauth_token": "",
        "prettyPrint": True,
        "quotaUser": "",
        "uploadType": "",
        "upload_protocol": ""
    }
    response = requests.post(url, headers=headers, json=payload, params=params)
    assert response.status_code == 200
    assert response.json()["done"] is True