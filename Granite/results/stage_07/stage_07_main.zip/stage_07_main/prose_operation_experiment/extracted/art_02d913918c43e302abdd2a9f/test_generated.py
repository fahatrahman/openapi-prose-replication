import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Configure session with retry strategy
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

# Constants for authorization headers
AUTH_HEADER_KEY = "Authorization"
VERSION_HEADER_KEY = "Api-Version"
DEFAULT_AUTH_VALUE = "Auto"
DEFAULT_VERSION_VALUE = "default"

@pytest.fixture
def payrun_response():
    employer_id = "GD001"
    pay_schedule_id = "KFM001"
    pay_run_id = "DB001"

    url = f"{BASE_URL}/Employer/{employer_id}/PaySchedule/{pay_schedule_id}/PayRun/{pay_run_id}"
    
    headers = {
        AUTH_HEADER_KEY: DEFAULT_AUTH_VALUE,
        VERSION_HEADER_KEY: DEFAULT_VERSION_VALUE
    }

    response = session.get(url, headers=headers)
    response.raise_for_status()

    return response.json()

def test_get_payrun(payrun_response):
    assert isinstance(payrun_response, dict)
    assert "PayRun" in payrun_response
    # Add more assertions based on expected structure and content of PayRun object