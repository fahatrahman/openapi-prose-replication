import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def headers():
    return {
        "Ocp-Apim-Subscription-Key": "your_subscription_key"
    }

@pytest.fixture
def params():
    return {
        "key": "your_api_key"
    }

def test_competitions_leagues(headers, params):
    url = f"{BASE_URL}/json/Competitions"
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 200
    assert isinstance(response.json(), list)

if __name__ == "__main__":
    pytest.main()