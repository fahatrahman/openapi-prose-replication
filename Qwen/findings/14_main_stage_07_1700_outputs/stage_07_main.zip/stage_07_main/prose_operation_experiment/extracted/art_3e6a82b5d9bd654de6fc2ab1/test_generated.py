import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_collectors():
    url = f"{BASE_URL}/list-collectors"
    headers = {
        "Authorization": "hmac your_access_key",
        "X-Amz-Algorithm": "your_algorithm",
        "X-Amz-Content-Sha256": "your_content_sha256",
        "X-Amz-Credential": "your_credential",
        "X-Amz-Date": "your_date",
        "X-Amz-Security-Token": "your_security_token",
        "X-Amz-Signature": "your_signature",
        "X-Amz-SignedHeaders": "your_signed_headers"
    }
    params = {
        "maxResults": 10,
        "nextToken": ""
    }
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "Collectors" in response.json()
    assert isinstance(response.json()["Collectors"], list)

if __name__ == "__main__":
    pytest.main()