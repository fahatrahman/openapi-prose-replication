import os
import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def client():
    return requests.Session()

def get_normalized_skills(client, skill_name):
    url = f"{BASE_URL}/skills/normalize?skill_name={skill_name}"
    response = client.get(url)
    response.raise_for_status()
    return response.json()["results"]

def test_get_normalized_skills(client):
    skill_name = "example_skill"
    normalized_skills = get_normalized_skills(client, skill_name)
    assert isinstance(normalized_skills, list)
    for skill in normalized_skills:
        assert "skill_name" in skill
        assert "uuid" in skill