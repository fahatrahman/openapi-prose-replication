import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

requests.packages.urllib3.disable_warnings()
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=None,
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("http://", adapter)
session.mount("https://", adapter)

@pytest.fixture
def orders_setlineitemmetadata():
    merchant_id = os.getenv("MERCHANT_ID")
    order_id = os.getenv("ORDER_ID")
    if not merchant_id or not order_id:
        pytest.skip("MERCHANT_ID and ORDER_ID environment variables are not set.")

    request_body = {
        "lineItemId": order_id,
        "annotations": [
            {"key": "annotation_key", "value": "annotation_value"},
        ],
    }

    url = f"{BASE_URL}/{{merchantId}}/orders/{{orderId}}/setLineItemMetadata".format(
        merchantId=merchant_id, orderId=order_id
    )

    response = session.post(url, json=request_body)
    response.raise_for_status()

    return response.json()