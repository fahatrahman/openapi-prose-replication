import os
import pytest
import requests
from google.rpc.status_pb2 import Status
from google.cloud.aiplatform_v1beta1.types import (
    BatchDeletePipelineJobsRequest,
    GoogleLongrunningOperation,
)

BASE_URL = "http://openapi.test"

@pytest.fixture
def get_request():
    def _get(method, path, json=None):
        url = f"{BASE_URL}{path}"
        headers = {"Content-Type": "application/json"}
        response = requests.request(method, url, headers=headers, json=json)
        return response

    yield _get

def test_batch_delete_pipeline_jobs(get_request):
    parent = "projects/<PROJECT>/locations/<LOCATION>"
    request_body = {
        "names": [
            "projects/<PROJECT>/locations/<LOCATION>/pipelineJobs/<PIPELINE_JOB1>",
            "projects/<PROJECT>/locations/<LOCATION>/pipelineJobs/<PIPELINE_JOB2>",
        ]
    }
    response = get_request("POST", f"/v1beta1/{parent}/pipelineJobs:batchDelete", json=request_body)

    assert response.status_code == 200

    operation_response = response.json()
    assert isinstance(operation_response, GoogleLongrunningOperation)
    assert operation_response.done