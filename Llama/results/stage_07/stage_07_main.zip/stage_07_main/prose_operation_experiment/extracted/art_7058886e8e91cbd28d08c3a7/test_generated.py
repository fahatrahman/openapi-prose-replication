# -*- coding: utf-8 -*-
"""Tests for distributionGroups_listAllTestersForOrg endpoint."""

import pytest
from requests import Response

BASE_URL = "http://openapi.test"

def test_distribution_groups_list_all_testers_for_org():
    """Tests for distributionGroups_listAllTestersForOrg endpoint."""
    
    # Arrange
    org_name = "example_org"
    headers = {"X-API-Token": "your_api_token"}
    url = f"{BASE_URL}/v0.1/orgs/{org_name}/testers"
    
    # Act
    response: Response = requests.get(url, headers=headers)
    
    # Assert
    assert response.status_code == 200
    
    # Parse JSON response
    json_response = response.json()
    
    # Check if the 'results' key exists in the response
    assert 'results' in json_response
    
    # Iterate over each item in the 'results'
    for item in json_response['results']:
        # Check required fields exist and are strings
        assert isinstance(item['name'], str)
        assert isinstance(item['email'], str)
        
        # Check optional field exists (if present) and is string
        if 'display_name' in item:
            assert isinstance(item['display_name'], str)

def test_distribution_groups_list_all_testers_for_org_error():
    """Tests error responses for distributionGroups_listAllTestersForOrg endpoint."""
    
    # Arrange
    org_name = "non_existent_org"
    headers = {"X-API-Token": "your_api_token"}
    url = f"{BASE_URL}/v0.1/orgs/{org_name}/testers"
    
    # Act
    response: Response = requests.get(url, headers=headers)
    
    # Assert
    assert response.status_code != 200
    
    # Parse JSON response
    json_response = response.json()
    
    # Check if the 'error' key exists in the response
    assert 'error' in json_response
    
    # Check required fields exist in the 'error' object
    error = json_response['error']
    assert 'code' in error
    assert 'message' in error

import requests