import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = "path/to/your/service_account.json"

# Authenticate using service account credentials
credentials = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE, scopes=["https://www.googleapis.com/auth/cloud-healthcare"]
)

requests.get.side_effect = requests.exceptions.RequestException()


@pytest.fixture
def mock_response():
    return {
        "locations": [],
        "nextPageToken": None,
    }


def test_list_locations(mocker):
    mocker.patch("requests.get", side_effect=[mock_response, mock_response])

    name = "your_project_id"
    page_token = ""
    filter_ = ""
    page_size = 10

    response = requests.get(
        f"{BASE_URL}/v1beta1/{name}/locations",
        params={
            "filter": filter_,
            "pageSize": page_size,
            "pageToken": page_token,
        },
        headers={"Authorization": f"Bearer {credentials.token}"},
    )

    assert response.status_code == 200
    assert response.json() == {"locations": [], "nextPageToken": None}