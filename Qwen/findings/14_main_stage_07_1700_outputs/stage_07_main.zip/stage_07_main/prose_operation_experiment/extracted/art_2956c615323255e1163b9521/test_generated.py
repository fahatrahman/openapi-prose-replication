import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_domain():
    domain_id = "b30a91ae-e3c1-4f73-a81e-c270bff27c39"
    headers = {
        "Training-Key": "your_training_key_here"
    }
    response = requests.get(f"{BASE_URL}/domains/{domain_id}", headers=headers)
    
    assert response.status_code == 200
    assert response.headers["Content-Type"].startswith("application/json")
    domain_data = response.json()
    assert isinstance(domain_data, dict)
    assert "enabled" in domain_data
    assert "exportable" in domain_data
    assert "id" in domain_data
    assert "name" in domain_data
    assert "type" in domain_data
    assert domain_data["id"] == domain_id
    assert domain_data["type"] == "Classification"