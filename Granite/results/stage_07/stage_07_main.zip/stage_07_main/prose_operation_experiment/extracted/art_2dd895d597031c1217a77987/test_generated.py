import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.fixture
def headers():
    return {"Authorization": "Bearer YOUR_BASKET_TOKEN"}

def test_get_response_settings(headers):
    response_name = "GET"
    basket_name = "YOUR_BASKET_NAME"

    url = f"{BASE_URL}/api/baskets/{basket_name}/responses/{response_name}"
    response = SESSION.get(url, headers=headers)

    assert response.status_code == 200, f"Unexpected status code: {response.status_code}"

    response_data = response.json()
    assert "body" in response_data, "Expected 'body' in response"
    assert "headers" in response_data, "Expected 'headers' in response"
    assert isinstance(response_data["headers"], dict), "Expected 'headers' to be a dictionary"
    assert "is_template" in response_data, "Expected 'is_template' in response"
    assert "status" in response_data, "Expected 'status' in response"
    assert isinstance(response_data["status"], int), "Expected 'status' to be an integer"