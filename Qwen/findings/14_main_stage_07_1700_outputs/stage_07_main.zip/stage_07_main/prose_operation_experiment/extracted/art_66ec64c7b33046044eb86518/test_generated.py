import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_amendment():
    bill_id = 123
    bill_stage_id = 456
    amendment_id = 789

    url = f"{BASE_URL}/api/v1/Bills/{bill_id}/Stages/{bill_stage_id}/Amendments/{amendment_id}"
    
    response = requests.get(url)
    
    assert response.status_code == 200
    assert 'application/json' in response.headers['Content-Type']
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()