# -*- coding: utf-8 -*-

import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

def test_list_templates():
    response = requests.get(
        f"{BASE_URL}/templates",
        auth=HTTPBasicAuth("api_token", "xyvylscj:gna_yiuso_lg,lcknolcj:gna_yiuso_krxmdv"),
        params={
            "query": "2",
            "parent_folder_id": "fld_000000000000000001",
            "page": 2,
            "per_page": 1
        }
    )
    assert response.status_code == 200
    assert len(response.json()) > 0

def test_unauthorized():
    response = requests.get(
        f"{BASE_URL}/templates",
        auth=HTTPBasicAuth("invalid_api_token", "")
    )
    assert response.status_code == 401
    error = response.json()
    assert isinstance(error, dict)
    assert error["error"] == "Unauthorized"

def test_not_found():
    response = requests.get(f"{BASE_URL}/nonexistent")
    assert response.status_code == 404
    error = response.json()
    assert isinstance(error, dict)

if __name__ == "__main__":
    pytest.main([__file__, "-sv"])