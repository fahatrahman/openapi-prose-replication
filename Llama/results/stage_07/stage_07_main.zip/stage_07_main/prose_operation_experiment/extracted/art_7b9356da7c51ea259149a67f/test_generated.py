# Generated using openapi-generator-cli
import pytest
import requests

BASE_URL = "http://openapi.test"

def test_ListDevices():
    url = f"{BASE_URL}/devices"
    params = {
        "maxResults": 100,
    }
    headers = {
        "Authorization": "hmac",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "1234567890abcdef",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20161215/us-east-1/iotanalytics/aws4_request",
        "X-Amz-Date": "20201214T000000Z",
        "X-Amz-Security-Token": "AQoDYXdzEPT//////////wEa6jQWV9Yp/8fng2C9L2F/FDy+8tBkG4mM=",
        "X-Amz-SignedHeaders": "host",
        "X-Amz-Signature": "1234567890abcdef",
    }

    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    assert response.json()["Devices"] != []