import pytest
import requests

BASE_URL = "http://openapi.test"

def test_cancel_operation():
    url = f"{BASE_URL}/v1/{'example-name'}:cancel"
    headers = {"Content-Type": "application/json"}
    data = {
        "name": "example-operation",
    }
    response = requests.post(url, headers=headers, json=data)
    assert response.status_code == 200