import os
import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def get_streams():
    url = f"{BASE_URL}/v1alpha1/{parent}/streams"
    headers = {
        "_._xgafv": "1",
    }
    params = {
        "filter": "all",
        "orderBy": "name",
        "pageSize": 100,
        "pageToken": None,
    }

    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200

    return response.json()

def test_get_streams(get_streams):
    assert isinstance(get_streams, dict)
    assert "streams" in get_streams
    assert len(get_streams["streams"]) > 0