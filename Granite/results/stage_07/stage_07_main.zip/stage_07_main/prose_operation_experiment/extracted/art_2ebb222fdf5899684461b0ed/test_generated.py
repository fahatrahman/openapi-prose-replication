import os
import pytest
import requests
from requests_aws_sigv4 import AWSRequestsAuthV4

BASE_URL = "http://openapi.test"

@pytest.mark.parametrize(
    "identifier", ["any_identifier"]
)
def test_delete_data_integration(identifier):
    url = f"{BASE_URL}/dataIntegrations/{identifier}"

    auth = AWSRequestsAuthV4(
        access_key="ANY_ACCESS_KEY",
        secret_key="ANY_SECRET_KEY",
        security_token="ANY_SECURITY_TOKEN" if "ANY_SECURITY_TOKEN" else None,
    )

    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "ANY_CONTENT_SHA256",
        "X-Amz-Date": "ANY_DATE",
        "X-Amz-Credential": "ANY_CREDENTIAL",
        "X-Amz-Security-Token": "ANY_SECURITY_TOKEN" if "ANY_SECURITY_TOKEN" else None,
        "X-Amz-Signature": "ANY_SIGNATURE",
        "X-Amz-SignedHeaders": "ANY_SIGNED_HEADERS",
    }

    response = requests.delete(url, auth=auth, headers=headers)

    assert response.status_code == 200, f"Expected status code 200, got {response.status_code}"