import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Retry mechanism for requests
retries = Retry(
    total=5,  # number of retries
    backoff_factor=1,  # factor to apply between retries in seconds
    status_forcelist=[429, 500, 502, 503, 504],  # HTTP status codes to force a retry
)
adapter = HTTPAdapter(max_retries=retries)
http = requests.Session()
http.mount("https://", adapter)
http.mount("http://", adapter)
requests.adapters.HTTPAdapter.max_retries = retries

@pytest.fixture
def beta_build_localizations():
    build_id = os.getenv("BUILD_ID")
    if not build_id:
        pytest.skip("BUILD_ID environment variable not set")

    url = f"{BASE_URL}/v1/builds/{build_id}/betaBuildLocalizations"

    response = http.get(url, params={"fields[betaBuildLocalizations]": ["build", "locale", "whatsNew"], "limit": 10})
    response.raise_for_status()

    return response.json()

def test_beta_build_localizations(beta_build_localizations):
    assert isinstance(beta_build_localizations, dict)
    assert "data" in beta_build_localizations
    assert "included" not in beta_build_localizations or not beta_build_localizations["included"]
    assert "links" in beta_build_localizations
    assert "meta" in beta_build_localizations
    assert all(isinstance(item, str) for item in beta_build_localizations["data"]["items"])