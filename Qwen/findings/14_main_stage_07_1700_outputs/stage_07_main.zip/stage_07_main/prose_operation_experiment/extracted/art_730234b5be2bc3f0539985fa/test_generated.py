import pytest
import requests

BASE_URL = "http://openapi.test"

def test_autocomplete_ingredient_search():
    url = f"{BASE_URL}/food/ingredients/autocomplete"
    params = {
        "query": "burger",
        "number": 10,
        "language": "en"
    }
    headers = {
        "x-api-key": "your_api_key_here"
    }
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    for item in data:
        assert "aisle" in item
        assert "id" in item
        assert "image" in item
        assert "name" in item
        assert "possibleUnits" in item
        assert isinstance(item["possibleUnits"], list)

if __name__ == "__main__":
    pytest.main()