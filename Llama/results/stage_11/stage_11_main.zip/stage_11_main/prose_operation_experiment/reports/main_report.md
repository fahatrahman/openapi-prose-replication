# Main OpenAPI prose experiment · Exploratory report

All 850 selected operation pairs are accounted for.
Results describe pairs with usable evidence for each outcome. The registered confirmatory run was not completed.

## Descriptive paired results

| Endpoint | Available | Missing | L0 | L1 | L1 minus L0 |
|---|---:|---:|---:|---:|---:|
| collection_success | 848 | 2 | 0.2512 | 0.2311 | -0.0200 |
| baseline_pass | 782 | 68 | 0.0371 | 0.0435 | 0.0064 |
| request_intent_match | 35 | 815 | 0.8571 | 0.8214 | -0.0357 |
| selected_scenario_coverage | 726 | 124 | 0.1374 | 0.1391 | 0.0017 |
| supported_assertion_score | 205 | 645 | 0.0077 | 0.0035 | -0.0042 |
| effective_requirement_check_coverage | 205 | 645 | 0.0004 | 0.0002 | -0.0001 |
| unconditional_response_fault_detection | 782 | 68 | 0.0038 | 0.0027 | -0.0011 |

Descriptive values use unweighted means over common-evaluable pairs.
A missing score is retained with its reason. The review dispositions and the technical oracle scope are in the provenance files.
The experiment measures generated tests against documented offline responses.
