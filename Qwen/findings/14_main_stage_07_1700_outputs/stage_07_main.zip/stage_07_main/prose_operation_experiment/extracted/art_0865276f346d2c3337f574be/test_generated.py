import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_service_lb_policies():
    url = f"{BASE_URL}/v1/zynntaco/project1/yzvrewumc/location1/serviceLbPolicies"
    params = {
        "pageSize": 10,
        "pageToken": None,
        "_xgafv": "1",
        "access_token": "your_access_token_here",
        "alt": "json",
        "callback": None,
        "fields": None,
        "key": "your_api_key_here",
        "oauth_token": "your_oauth_token_here",
        "prettyPrint": True,
        "quotaUser": None,
        "uploadProtocol": None,
        "uploadType": None
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    data = response.json()
    assert "serviceLbPolicies" in data
    assert isinstance(data["serviceLbPolicies"], list)

if __name__ == "__main__":
    pytest.main()