# -*- coding: utf-8 -*-
"""Tests for Servers."""

import pytest
import requests

BASE_URL = "http://openapi.test"


def test_get_metrics_for_server():
    """Test Get Metrics for Server."""
    url = f"{BASE_URL}/servers/123/metrics"
    params = {
        "type": "cpu",
        "start": "2022-01-01T00:00:00+00:00",
        "end": "2022-01-02T00:00:00+00:00",
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    response.raise_for_status()
    data = response.json()
    assert data["metrics"]["start"]
    assert data["metrics"]["end"]
    assert data["metrics"]["step"]
    assert isinstance(data["metrics"]["time_series"], dict)


def test_get_metrics_for_server_with_disk_and_network_types():
    """Test Get Metrics for Server with Disk and Network types."""
    url = f"{BASE_URL}/servers/123/metrics"
    params = {
        "type": "cpu,disk,network",
        "start": "2022-01-01T00:00:00+00:00",
        "end": "2022-01-02T00:00:00+00:00",
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    response.raise_for_status()
    data = response.json()
    assert data["metrics"]["start"]
    assert data["metrics"]["end"]
    assert data["metrics"]["step"]
    assert isinstance(data["metrics"]["time_series"], dict)


def test_get_metrics_for_server_with_custom_step():
    """Test Get Metrics for Server with custom step."""
    url = f"{BASE_URL}/servers/123/metrics"
    params = {
        "type": "cpu",
        "start": "2022-01-01T00:00:00+00:00",
        "end": "2022-01-02T00:00:00+00:00",
        "step": "3600",  # 1 hour
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    response.raise_for_status()
    data = response.json()
    assert data["metrics"]["start"]
    assert data["metrics"]["end"]
    assert data["metrics"]["step"] == 3600
    assert isinstance(data["metrics"]["time_series"], dict)


if __name__ == "__main__":
    pytest.main([__file__])