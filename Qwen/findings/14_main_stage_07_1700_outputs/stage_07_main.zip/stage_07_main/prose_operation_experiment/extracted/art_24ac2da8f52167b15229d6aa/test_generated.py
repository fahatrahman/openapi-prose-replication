import pytest
import requests

BASE_URL = "http://openapi.test"

def test_migrationcenter_projects_locations_sources_delete():
    url = f"{BASE_URL}/v1/projects/location/sources/source"
    params = {
        "_xgafv": "2",
        "access_token": "example_access_token",
        "alt": "json",
        "callback": "callback_function",
        "fields": "name",
        "key": "example_key",
        "oauth_token": "example_oauth_token",
        "prettyPrint": False,
        "quotaUser": "example_quota_user",
        "uploadType": "media",
        "upload_protocol": "raw",
        "name": "projects/location/sources/source",
        "requestId": "unique_request_id"
    }
    response = requests.delete(url, params=params)
    assert response.status_code == 200
    assert response.json().get("name") == "projects/location/sources/source"