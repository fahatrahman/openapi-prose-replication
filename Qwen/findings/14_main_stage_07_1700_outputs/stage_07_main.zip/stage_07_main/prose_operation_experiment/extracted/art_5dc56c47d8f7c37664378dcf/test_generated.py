import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_applied_schema_arns():
    headers = {
        "X-Amz-Algorithm": "HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "access-key-id/20230401/us-east-1/aws4_request",
        "X-Amz-Date": "20230401T123456Z",
        "X-Amz-Security-Token": "session-token",
        "X-Amz-Signature": "signature",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-security-token;x-amz-signal"
    }
    params = {
        "MaxResults": "10",
        "NextToken": ""
    }
    body = {
        "DirectoryArn": "arn:aws:clouddirectory:us-west-2:123456789012:directory/default",
        "MaxResults": 10,
        "NextToken": "",
        "SchemaArn": ""
    }
    response = requests.post(f"{BASE_URL}/amazonclouddirectory/2017-01-11/schema/applied", headers=headers, params=params, json=body)
    
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "NextToken" in response.json()
    assert "SchemaArns" in response.json()

if __name__ == "__main__":
    pytest.main()