import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_order_return(mocker):
    mock_response = {
        "creationDate": "2023-04-01T12:00:00Z",
        "merchantOrderId": "M12345",
        "orderId": "O67890",
        "orderReturnId": "R11111",
        "returnItems": [],
        "returnShipments": []
    }
    mocker.patch('requests.get', return_value=mock_response)
    
    url = f"{BASE_URL}/merchantId/orderreturns/returnId"
    params = {
        "_xgafv": "1",
        "access_token": "fake_access_token",
        "alt": "json",
        "callback": "",
        "fields": "*",
        "key": "fake_key",
        "oauth_token": "fake_oauth_token",
        "prettyPrint": True,
        "quotaUser": "user123",
        "uploadType": "media",
        "upload_protocol": "raw"
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 200
    assert response.json() == mock_response