import os
import pytest
import requests
BASE_URL = "http://openapi.test"

def test_send_sms():
    url = f"{BASE_URL}/sms"
    headers = {"X-API-Key": "your_api_key"}
    data = {
        "text": "Test message",
        "to": "+1234567890",
        "from": "YourName",
        "foreign_id": "123456",
        "label": "Test Label",
        "udh": "Custom UDH",
        "delay": "2022-12-31T23:59:59Z",
        "debug": 0,
        "no_reload": 0,
        "unicode": 0,
        "flash": 0,
        "utf8": 0,
        "details": 0,
        "return_msg_id": 0,
        "json": 0,
        "performance_tracking": 0,
    }

    response = requests.post(url, headers=headers, json=data)
    assert response.status_code == 200

    response_data = response.json()
    # Add your assertions based on expected response structure here
    assert isinstance(response_data, dict)
    assert "balance" in response_data
    assert "debug" in response_data
    assert "messages" in response_data
    assert "sms_type" in response_data
    assert "success" in response_data
    assert "total_price" in response_data