import pytest
import requests
BASE_URL = "http://openapi.test"

def test_fleet_get():
    fleet_name = "blue.fleet"
    url = f"{BASE_URL}/fleet/{fleet_name}"

    response = requests.get(url)
    assert response.status_code == 200

    expected_data = {
        "@id": "https://phantauth.net/fleet/blue.fleet",
        "logo": "https://www.gravatar.com/avatar/60757eca81bdd6768421ed3b669b651d?s=256&d=identicon",
        "logo_email": "blue.fleet.6JBLL7Y@mailinator.com",
        "members": [
            {
                "@id": "https://phantauth.net/client/zamit%7Eueyonuvxhz0",
                "client_id": "zamit~ueyonuvxhz0",
                "client_name": "Zamit",
                "client_secret": "o0Ie0Ph4",
                "client_uri": "https://phantauth.net/client/zamit%7Eueyonuvxhz0/profile",
                "logo_email": "zamit.6UTF3FA@mailinator.com",
                "logo_uri": "https://www.gravatar.com/avatar/849f9934a6aec97935cb40eadbf06d60?s=256&d=https%3A%2F%2Favatars.phantauth.net%2Ficon%2Fpnelv7bK.png",
                "policy_uri": "https://phantauth.net/client/zamit%7Eueyonuvxhz0/policy",
                "software_id": "tzpm4afosVpE65jyw55ZLA",
                "software_version": "8.0.8",
                "tos_uri": "https://phantauth.net/client/zamit%7Eueyonuvxhz0/tos"
            },
            # Add other members here...
        ],
        "name": "Blue Fleet",
        "profile": "https://phantauth.net/fleet/blue.fleet/profile",
        "sub": "blue.fleet"
    }

    assert response.json() == expected_data