# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_cancel_operation():
    url = f"{BASE_URL}/v1/{'example_name'}:cancel"
    headers = {"Content-Type": "application/json"}
    data = {
        "name": "example_name",
        "cancelled": True,
    }
    response = requests.post(url, headers=headers, json=data)
    assert response.status_code == 200
    assert response.json() is None