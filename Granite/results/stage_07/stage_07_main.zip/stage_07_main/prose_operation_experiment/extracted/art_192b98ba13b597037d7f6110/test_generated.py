import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = 'path/to/service_account.json'
SCOPES = ['https://www.googleapis.com/auth/cloud-platform']

def test_disable_database_instance():
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=SCOPES)

    url = f"{BASE_URL}/v1beta/{os.environ['NAME']}:disable"

    headers = {
        'Content-Type': 'application/json',
    }

    disable_database_instance_request = {}

    response = requests.post(url, headers=headers, json=disable_database_instance_request, verify=False, cert=(credentials.private_key().public_key(), credentials.private_key()))

    assert response.status_code == 200