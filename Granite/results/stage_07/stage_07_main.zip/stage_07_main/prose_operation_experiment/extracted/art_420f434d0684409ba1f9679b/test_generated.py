import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

# Custom session with retry logic
class UnicornRetrySession(requests.Session):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.mount("http://", HTTPAdapter(max_retries=3))

@pytest.fixture
def client():
    return UnicornRetrySession()

def test_search_normalized_judges_by_id(client):
    norm_judge_search_id = "JSRCNUSK3pLGe48QcU"
    path = urljoin(BASE_URL, f"/normJudgeSearch/{norm_judge_search_id}")

    response = client.get(path, params={"pageNumber": 1})

    assert response.status_code == 200, response.text

    expected_data = {
        "nextPageAPI": None,
        "normJudgeSearchId": norm_judge_search_id,
        "normJudgeSearchResultArray": [
            {
                "firstFetchDate": "2023-02-16T12:56:17+00:00",
                "lastFetchDate": "2023-02-16T12:56:17+00:00",
                "matchedObjectArray": [
                    {
                        "highlightSnippet": "<b>NJUD5STmDbUZGukfQm</b>",
                        "matchedObjectAPI": "https://enterpriseapi.unicourt.com/normJudge/NJUD5STmDbUZGukfQm",
                        "matchedObjectAttribute": "normJudgeId",
                        "matchedObjectId": "NJUD5STmDbUZGukfQm",
                        "matchedObjectName": "NormJudge",
                        "object": "MatchedObject",
                    }
                ],
                "name": "JOHN ACOSTA",
                "normJudgeDetailsAPI": "https://enterpriseapi.unicourt.com/normJudge/NJUD5STmDbUZGukfQm",
                "normJudgeId": "NJUD5STmDbUZGukfQm",
                "object": "NormJudgeSearchResult",
            }
        ],
        "object": "NormJudgeSearchResponse",
        "pageNumber": 1,
        "previousPageAPI": None,
        "q": f"normJudgeId%3A%22{norm_judge_search_id}%22",
        "totalCount": 1,
        "totalPages": 1,
    }

    response_data = response.json()

    # Check if the response structure matches the expected one
    assert set(expected_data.keys()) == set(response_data.keys())

    # Compare specific values for validation
    for key in expected_data:
        if isinstance(expected_data[key], str):
            assert expected_data[key] == response_data[key]
        elif isinstance(expected_data[key], list):
            assert len(expected_data[key]) == len(response_data[key])
            for item1, item2 in zip(expected_data[key], response_data[key]):
                assert set(item1.keys()) == set(item2.keys())
                for sub_key in item1:
                    if isinstance(item1[sub_key], str):
                        assert item1[sub_key] == item2[sub_key]
                    else:
                        raise ValueError(
                            f"Unexpected type found while comparing MatchedObject details."
                        )