# -*- coding: utf-8 -*-
"""
Test bigquery.tabledata.list endpoint.

"""
import pytest
import requests


BASE_URL = "http://openapi.test"


def test_bigquery_tabledata_list():
    """Test bigquery.tabledata.list endpoint."""
    url = f"{BASE_URL}/projects/{'project_id'}/datasets/{'dataset_id'}/tables/{'table_id'}/data"
    headers = {}
    params = {
        "$.xgafv": "1",
        "access_token": "",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "",
        "oauth_token": "",
        "prettyPrint": "false",
        "quotaUser": "",
        "upload_protocol": "upload_type",
        "uploadType": "media",
        "formatOptions.useInt64Timestamp": "true",
        "maxResults": 10,
        "pageToken": "",
        "selectedFields": "",
        "startIndex": ""
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    # assert response.json()  # Uncomment this line if you want to parse the JSON response