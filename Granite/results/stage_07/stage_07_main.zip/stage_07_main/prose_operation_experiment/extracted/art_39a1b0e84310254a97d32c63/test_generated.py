import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def brand():
    return {
        "activeDisplayNames": [],
        "activeIcon": "",
        "activeIconUri": "",
        "displayNameDisapprovalReason": [],
        "displayNameState": "REVIEW_STATE_NEW",
        "displayNames": [],
        "icon": "",
        "iconDisapprovalReasons": [],
        "iconState": "REVIEW_STATE_NEW",
        "name": "",
        "propertyCount": "0",
        "submittedDisplayNames": [],
        "submittedIcon": ""
    }

def create_brand(parent, brand_id):
    url = f"{BASE_URL}/v3/{parent}/brands"
    headers = {"Content-Type": "application/json"}

    response = session.post(url, json=brand(), headers=headers)
    assert response.status_code == 200

    return response.json()

def test_create_brand(brand_id):
    parent = "your_parent_value"
    created_brand = create_brand(parent, brand_id)
    
    # Add assertions here based on your requirements
    assert created_brand["displayNameState"] == "REVIEW_STATE_NEW"