import pytest
import requests

BASE_URL = "http://openapi.test"

def test_update_account():
    url = f"{BASE_URL}/userprofiles/profileId/accounts"
    
    headers = {
        'Content-Type': 'application/json'
    }
    
    data = {
        "accountPermissionIds": ["1", "2"],
        "accountProfile": "ACCOUNT_PROFILE_BASIC",
        "active": True,
        "activeAdsLimitTier": "ACTIVE_ADS_TIER_40K",
        "activeViewOptOut": False,
        "availablePermissionIds": ["1", "2"],
        "countryId": "1",
        "currencyId": "1",
        "defaultCreativeSizeId": "1",
        "description": "Test Account",
        "id": "1",
        "kind": "dfareporting#account",
        "locale": "en",
        "maximumImageSize": "1",
        "name": "Test Account",
        "nielsenOcrEnabled": False,
        "reportsConfiguration": {
            "exposureToConversionEnabled": True,
            "lookbackConfiguration": {
                "clickDuration": 0,
                "postImpressionActivitiesDuration": 0
            },
            "reportGenerationTimeZoneId": "1"
        },
        "shareReportsWithTwitter": False,
        "teaserSizeLimit": "1"
    }
    
    response = requests.put(url, json=data, headers=headers)
    
    assert response.status_code == 200
    
    # Parse JSON response
    json_response = response.json()
    
    # Check if the updated account has the expected properties
    assert json_response["accountPermissionIds"] == ["1", "2"]
    assert json_response["accountProfile"] == "ACCOUNT_PROFILE_BASIC"
    assert json_response["active"] == True
    assert json_response["activeAdsLimitTier"] == "ACTIVE_ADS_TIER_40K"
    assert json_response["activeViewOptOut"] == False
    assert json_response["availablePermissionIds"] == ["1", "2"]
    assert json_response["countryId"] == "1"
    assert json_response["currencyId"] == "1"
    assert json_response["defaultCreativeSizeId"] == "1"
    assert json_response["description"] == "Test Account"
    assert json_response["id"] == "1"
    assert json_response["kind"] == "dfareporting#account"
    assert json_response["locale"] == "en"
    assert json_response["maximumImageSize"] == "1"
    assert json_response["name"] == "Test Account"
    assert json_response["nielsenOcrEnabled"] == False
    assert json_response["reportsConfiguration"]["exposureToConversionEnabled"] == True
    assert json_response["reportsConfiguration"]["lookbackConfiguration"]["clickDuration"] == 0
    assert json_response["reportsConfiguration"]["lookbackConfiguration"]["postImpressionActivitiesDuration"] == 0
    assert json_response["reportsConfiguration"]["reportGenerationTimeZoneId"] == "1"
    assert json_response["shareReportsWithTwitter"] == False
    assert json_response["teaserSizeLimit"] == "1"
