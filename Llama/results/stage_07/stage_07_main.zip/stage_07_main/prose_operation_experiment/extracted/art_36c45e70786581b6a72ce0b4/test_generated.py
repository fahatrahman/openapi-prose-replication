# -*- coding: utf-8 -*-

import pytest
import requests
from jsonschema import validate

BASE_URL = "http://openapi.test"

def test_globalpageload():
    url = f"{BASE_URL}/globalpageload"
    params = {
        "license": "GNA",
        "origin": "Ghirl",
        "url": "https://example.com"
    }
    
    response = requests.get(url, params=params)
    
    assert response.status_code == 200
    
    try:
        validate(instance=response.json(), schema={
            "type": "object",
            "properties": {
                "Code": {"type": "string"},
                "Contents": {"type": "string"},
                "Credits": {"type": "string"},
                "Origin": {"type": "string"},
                "PageResponseStatus": {"type": "string"},
                "Seconds": {"type": "string"}
            },
            "required": ["Code", "Contents", "Credits", "Origin", "PageResponseStatus", "Seconds"]
        })
    except Exception as e:
        pytest.fail(f"Invalid JSON response: {str(e)}")
        
    assert response.json()["Code"] != ""
    assert response.json()["Contents"] != ""
    assert response.json()["Credits"] != ""
    assert response.json()["Origin"] == params["origin"]
    assert response.json()["PageResponseStatus"] != ""
    assert response.json()["Seconds"] != ""

def test_globalpageload_400():
    url = f"{BASE_URL}/globalpageload"
    params = {
        "license": "",
        "origin": "Ghirl",
        "url": "https://example.com"
    }
    
    response = requests.get(url, params=params)
    
    assert response.status_code == 400

def test_globalpageload_403():
    url = f"{BASE_URL}/globalpageload"
    params = {
        "license": "GNA",
        "origin": "",
        "url": "https://example.com"
    }
    
    response = requests.get(url, params=params)
    
    assert response.status_code == 403

def test_globalpageload_404():
    url = f"{BASE_URL}/globalpageload2"
    
    response = requests.get(url)
    
    assert response.status_code == 404

def test_globalpageload_405():
    url = f"{BASE_URL}/globalpageload"
    
    response = requests.post(url)
    
    assert response.status_code == 405

def test_globalpageload_500():
    url = f"{BASE_URL}/globalpageload"
    params = {
        "license": "GNA",
        "origin": "Ghirl",
        "url": ""
    }
    
    response = requests.get(url, params=params)
    
    assert response.status_code == 500

def test_globalpageload_402():
    # This endpoint is not tested in the original specification,
    # so we will skip this test for now.
    pass