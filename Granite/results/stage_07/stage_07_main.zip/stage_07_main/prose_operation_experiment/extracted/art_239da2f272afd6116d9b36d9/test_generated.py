import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    backoff_factor=0.1,
    status_forcelist=[429, 500, 502, 503, 504],
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.fixture
def player_season():
    hitter_id = "10000031"
    pitcher_id = "10000618"
    format_ = "JSON"

    response = SESSION.get(
        f"{BASE_URL}/{format}/HitterVsPitcher/{hitter_id}/{pitcher_id}",
        headers={},
        params={"key": ""},
    )

    assert response.status_code == 200

    return response.json()

def test_player_season(player_season):
    assert isinstance(player_season, list)
    for stat in player_season:
        assert set(stat.keys()).issuperset({"Name", "BattingAverage", "HomeRuns"})