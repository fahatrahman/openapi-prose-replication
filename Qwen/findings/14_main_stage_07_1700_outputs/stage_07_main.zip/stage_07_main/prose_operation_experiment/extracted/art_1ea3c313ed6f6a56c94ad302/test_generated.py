import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="module")
def api_key_header():
    return {"Ocp-Apim-Subscription-Key": "your_api_key_here"}

@pytest.fixture(scope="module")
def api_key_query():
    return {"key": "your_api_key_here"}

def test_AreGamesInProgress(api_key_header, api_key_query):
    url = f"{BASE_URL}/XML/AreAnyGamesInProgress"
    headers = {**api_key_header}
    params = {**api_key_query}
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 200
    assert isinstance(response.json(), bool)

if __name__ == "__main__":
    pytest.main()