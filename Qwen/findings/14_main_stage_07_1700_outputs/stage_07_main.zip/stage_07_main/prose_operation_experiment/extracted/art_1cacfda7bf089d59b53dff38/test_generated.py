import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_integrations():
    headers = {
        "Authorization": "hmac example"
    }
    params = {
        "DomainName": "example-domain",
        "next-token": "",
        "max-results": 10,
        "include-hidden": False
    }
    response = requests.get(f"{BASE_URL}/domains/{params['DomainName']}/integrations", headers=headers, params=params)
    assert response.status_code == 200
    assert "Items" in response.json()
    assert "NextToken" in response.json()

if __name__ == "__main__":
    pytest.main([__file__])