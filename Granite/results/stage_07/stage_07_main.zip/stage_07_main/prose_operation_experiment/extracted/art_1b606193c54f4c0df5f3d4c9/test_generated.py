import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = "path/to/service_account.json"

@pytest.fixture
def authenticated_session():
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )
    return requests.Session(), credentials

def test_tensorboard_timeseries_update(authenticated_session):
    session, credentials = authenticated_session

    url = f"{BASE_URL}/v1/{'run_id'}/{time_series_id}"

    payload = {
        "description": "Updated description",
        "displayName": "Updated display_name",
        "valueType": "SCALAR",
    }

    headers = {"Content-Type": "application/json"}

    response = session.patch(url, json=payload, headers=headers)
    response.raise_for_status()

    updated_timeseries = response.json()
    assert updated_timeseries["description"] == "Updated description"
    assert updated_timeseries["displayName"] == "Updated display_name"
    assert updated_timeseries["valueType"] == "SCALAR"