import pytest
import requests

BASE_URL = "http://openapi.test"

def test_scim_create_user():
    url = f"{BASE_URL}/v2/scim/2.0/Users"
    headers = {"Content-Type": "application/scim+json"}
    
    user_data = {
        "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
        "userName": "test.user@example.com",
        "name": {"familyName": "Doe", "givenName": "John"},
        "emails": [{"value": "test.user@example.com", "primary": True}],
        "groups": [{"value": "group1"}, {"value": "group2"}]
    }
    
    response = requests.post(url, json=user_data, headers=headers)
    assert response.status_code == 201
    
    # Verify that the created user has the expected attributes
    user_response = response.json()
    assert user_response["schemas"][0] == "urn:ietf:params:scim:schemas:core:2.0:User"
    assert user_response["userName"] == "test.user@example.com"
    assert user_response["name"]["familyName"] == "Doe"
    assert user_response["name"]["givenName"] == "John"
    assert len(user_response["emails"]) == 1
    assert user_response["emails"][0]["value"] == "test.user@example.com"
    assert len(user_response["groups"]) == 2
    
def test_scim_create_user_invalid_schema():
    url = f"{BASE_URL}/v2/scim/2.0/Users"
    headers = {"Content-Type": "application/scim+json"}
    
    user_data = {
        "schemas": ["invalid-schema"],
        "userName": "test.user@example.com",
        "name": {"familyName": "Doe", "givenName": "John"},
        "emails": [{"value": "test.user@example.com", "primary": True}],
        "groups": [{"value": "group1"}, {"value": "group2"}]
    }
    
    response = requests.post(url, json=user_data, headers=headers)
    assert response.status_code == 400
    
def test_scim_create_user_missing_required_fields():
    url = f"{BASE_URL}/v2/scim/2.0/Users"
    headers = {"Content-Type": "application/scim+json"}
    
    user_data = {
        "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"]
    }
    
    response = requests.post(url, json=user_data, headers=headers)
    assert response.status_code == 400

def test_scim_create_user_unauthorized():
    url = f"{BASE_URL}/v2/scim/2.0/Users"
    headers = {"Content-Type": "application/scim+json"}
    
    user_data = {
        "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
        "userName": "test.user@example.com",
        "name": {"familyName": "Doe", "givenName": "John"},
        "emails": [{"value": "test.user@example.com", "primary": True}],
        "groups": [{"value": "group1"}, {"value": "group2"}]
    }
    
    response = requests.post(url, json=user_data, headers=headers)
    assert response.status_code == 401

def test_scim_create_user_forbidden():
    url = f"{BASE_URL}/v2/scim/2.0/Users"
    headers = {"Content-Type": "application/scim+json"}
    
    user_data = {
        "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
        "userName": "test.user@example.com",
        "name": {"familyName": "Doe", "givenName": "John"},
        "emails": [{"value": "test.user@example.com", "primary": True}],
        "groups": [{"value": "group1"}, {"value": "group2"}]
    }
    
    response = requests.post(url, json=user_data, headers=headers)
    assert response.status_code == 403

def test_scim_create_user_not_found():
    url = f"{BASE_URL}/v2/scim/2.0/Users"
    headers = {"Content-Type": "application/scim+json"}
    
    user_data = {
        "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
        "userName": "test.user@example.com",
        "name": {"familyName": "Doe", "givenName": "John"},
        "emails": [{"value": "test.user@example.com", "primary": True}],
        "groups": [{"value": "group1"}, {"value": "group2"}]
    }
    
    response = requests.post(url, json=user_data, headers=headers)
    assert response.status_code == 404

def test_scim_create_user_conflict():
    url = f"{BASE_URL}/v2/scim/2.0/Users"
    headers = {"Content-Type": "application/scim+json"}
    
    user_data = {
        "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
        "userName": "test.user@example.com",
        "name": {"familyName": "Doe", "givenName": "John"},
        "emails": [{"value": "test.user@example.com", "primary": True}],
        "groups": [{"value": "group1"}, {"value": "group2"}]
    }
    
    response = requests.post(url, json=user_data, headers=headers)
    assert response.status_code == 409

def test_scim_create_user_internal_server_error():
    url = f"{BASE_URL}/v2/scim/2.0/Users"
    headers = {"Content-Type": "application/scim+json"}
    
    user_data = {
        "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
        "userName": "test.user@example.com",
        "name": {"familyName": "Doe", "givenName": "John"},
        "emails": [{"value": "test.user@example.com", "primary": True}],
        "groups": [{"value": "group1"}, {"value": "group2"}]
    }
    
    response = requests.post(url, json=user_data, headers=headers)
    assert response.status_code == 500