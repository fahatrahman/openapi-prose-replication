# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_serviceusage_services_consumerquotametrics_limits_consumeroverrides_patch():
    url = f"{BASE_URL}/v1beta1/{name}"
    headers = {
        "$.xgafv": "1",
        "Content-Type": "application/json"
    }
    params = {
        "prettyPrint": True,
        "quotaUser": "",
        "upload_protocol": "raw",
        "uploadType": "multipart"
    }
    json = {
        "adminOverrideAncestor": "",
        "dimensions": {},
        "metric": "",
        "name": "",
        "overrideValue": "-1",
        "unit": ""
    }

    response = requests.request(
        "PATCH",
        url,
        headers=headers,
        params=params,
        json=json
    )

    assert response.status_code == 200