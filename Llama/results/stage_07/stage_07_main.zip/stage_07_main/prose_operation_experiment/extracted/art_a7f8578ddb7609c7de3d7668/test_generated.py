import pytest
import requests

BASE_URL = "http://openapi.test"

def test_operating_systems_list():
    url = f"{BASE_URL}/userprofiles/profileId/operatingSystems"
    params = {
        "$.xgafv": "1",
        "access_token": None,
        "alt": "json",
        "callback": None,
        "fields": None,
        "key": None,
        "oauth_token": None,
        "prettyPrint": "false",
        "quotaUser": None,
        "upload_protocol": "raw",
        "uploadType": "media",
        "profileId": "profileId"
    }
    
    try:
        response = requests.get(url, params=params)
        assert response.status_code == 200
    except requests.RequestException as e:
        pytest.fail(f"Request failed: {e}")