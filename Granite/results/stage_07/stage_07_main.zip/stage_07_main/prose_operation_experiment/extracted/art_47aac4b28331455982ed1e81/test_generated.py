import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retry strategy for handling transient errors
session = requests.Session()
retries = Retry(total=3, backoff_factor=0.1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
session.mount("http://", adapter)
session.mount("https://", adapter)

# OAuth2 credentials setup (replace with actual credentials)
ACCESS_TOKEN = os.environ["ACCESS_TOKEN"] if "ACCESS_TOKEN" in os.environ else None

@pytest.fixture
def headers():
    return {
        "Accept": "application/json",
        "Authorization": f"Bearer {ACCESS_TOKEN}" if ACCESS_TOKEN else "",
    }

def test_get_client(headers):
    account_id = "example_account_id"
    client_account_id = "example_client_account_id"

    url = f"{BASE_URL}/v2beta1/accounts/{account_id}/clients/{client_account_id}"
    
    response = session.get(url, headers=headers)
    
    # Check for successful response
    assert response.status_code == 200

    client_data = response.json()
    assert isinstance(client_data, dict)
    assert "clientAccountId" in client_data
    assert "clientName" in client_data
    assert "entityId" in client_data
    assert "entityName" in client_data
    assert "entityType" in client_data
    assert "partnerClientId" in client_data
    assert "role" in client_data
    assert "status" in client_data
    assert "visibleToSeller" in client_data