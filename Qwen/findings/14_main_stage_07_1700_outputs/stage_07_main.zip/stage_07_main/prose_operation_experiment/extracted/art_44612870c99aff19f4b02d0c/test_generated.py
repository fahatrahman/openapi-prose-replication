import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_app():
    headers = {
        "Authorization": "Bearer your_access_token_here",
        "Content-Type": "application/json"
    }
    payload = {
        "name": "test_app",
        "apnsCertificate": None,
        "apnsPrivateKey": None,
        "apnsUseSandboxEndpoint": False,
        "fcmKey": None,
        "status": None,
        "tlsOnly": False
    }
    response = requests.post(f"{BASE_URL}/accounts/your_account_id/apps", headers=headers, json=payload)
    assert response.status_code == 201
    response_json = response.json()
    assert "id" in response_json
    assert "name" in response_json and response_json["name"] == "test_app"

if __name__ == "__main__":
    pytest.main(["-v", __file__])