import os
import pytest
import requests
from google.rpc import Status

BASE_URL = "http://openapi.test"

def test_evict_lun():
    path = "/v2/projects/-/volumes/my-volume/luns/my-lun:evict"
    headers = {
        "_.xgafv": "1",
    }
    request_body = {

    }
    response = requests.post(BASE_URL + path, headers=headers, json=request_body)
    response.raise_for_status()
    assert response.status_code == 200

    operation = response.json()
    assert isinstance(operation, dict)
    assert operation["@type"] == "type.googleapis.com/google.longrunning.Operation"
    assert operation["metadata"]["@type"] == "type.googleapis.com/google.longrunning.OperationMetadata"
    assert operation["name"].startswith("operations/")
    assert operation["done"] is False  # Operation is not yet complete

if __name__ == "__main__":
    pytest.main([__file__, "-v"])