import pytest
import requests

BASE_URL = "http://openapi.test"

def test_collection_ticket_comments_update():
    headers = {
        "x-apideck-app-id": "dSBdXd2H6Mqwfg0atXHXYcysLJE9qyn1VwBtXHX",
        "x-apideck-consumer-id": "12345",
        "x-apideck-service-id": "service_id_example"
    }
    url = f"{BASE_URL}/issue-tracking/collections/collection_id_example/tickets/ticket_id_example/comments/id_example"
    payload = {
        "body": "What internet provider do you use?",
        "custom_mappings": {}
    }
    response = requests.patch(url, json=payload, headers=headers)
    
    assert response.status_code == 200
    assert response.json()["status"] == "OK"
    assert response.json()["status_code"] == 200
    assert response.json()["resource"] == "Tickets"
    assert response.json()["operation"] == "update"
    assert response.json()["service"] == "github"
    assert response.json()["data"]["id"] == "id_example"