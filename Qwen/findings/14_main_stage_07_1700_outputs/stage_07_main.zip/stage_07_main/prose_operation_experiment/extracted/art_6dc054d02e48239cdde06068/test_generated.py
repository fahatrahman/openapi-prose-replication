import pytest
import requests

BASE_URL = "http://openapi.test"

def test_books_promooffer_get():
    url = f"{BASE_URL}/books/v1/promooffer/get"
    params = {
        "_xgafv": "1",
        "access_token": "example_access_token",
        "alt": "json",
        "callback": "cb=gapi._callbacks.api1_0.callback",
        "fields": "items(id,title)",
        "key": "AIzaSyDQw4w9WgXcQGADSDQw4w9WgXcQGADSDQ",
        "oauth_token": "ya29.a0ARrdaM7ZoJ7RiF5tKJ7RiF5tKJ7RiF5tKJ7RiF5tKJ7RiF5tKJ7RiF5tKJ7RiF5tKJ7RiF",
        "prettyPrint": True,
        "quotaUser": "user@example.com",
        "uploadType": "media",
        "upload_protocol": "raw",
        "androidId": "1234567890",
        "device": "pixel",
        "manufacturer": "google",
        "model": "Pixel 3",
        "product": "phone",
        "serial": "ABCDEF123456"
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    assert 'offers' in response.json()