import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_PATH = "path/to/credentials.json"

@pytest.fixture
def auth():
    credentials = service_account.Credentials.from_service_account_file(
        CREDENTIALS_PATH, scopes=["https://www.googleapis.com/auth/analytics.edit"]
    )
    return credentials

def test_create_connected_site_tag(auth):
    url = f"{BASE_URL}/v1alpha/properties:createConnectedSiteTag"

    request_body = {
        "connectedSiteTag": {
            "displayName": "Test Connected Site Tag",
            "tagId": "test-tag-id"
        },
        "property": "properties/testProperty"
    }

    headers = {"Content-Type": "application/json"}

    response = requests.post(url, json=request_body, headers=headers, auth=auth)

    assert response.status_code == 200