import pytest
import requests

BASE_URL = "http://openapi.test"

def test_approve_wire_transfer():
    wire_transfer_id = "wire_transfer_5akynk7dqsq25qwk9q2u"
    url = f"{BASE_URL}/wire_transfers/{wire_transfer_id}/approve"
    headers = {
        "Authorization": "Bearer YOUR_API_KEY",
        "Content-Type": "application/json"
    }
    
    response = requests.post(url, headers=headers)
    
    assert response.status_code == 200
    assert response.json()["type"] == "wire_transfer"
    assert response.json()["status"] == "pending_approval"

def test_approve_nonexistent_wire_transfer():
    wire_transfer_id = "nonexistent_wire_transfer_id"
    url = f"{BASE_URL}/wire_transfers/{wire_transfer_id}/approve"
    headers = {
        "Authorization": "Bearer YOUR_API_KEY",
        "Content-Type": "application/json"
    }
    
    response = requests.post(url, headers=headers)
    
    assert response.status_code == 404
    assert response.json()["type"] == "object_not_found_error"
    assert response.json()["status"] == 404
    assert response.json()["title"] == "Object Not Found Error"
    assert response.json()["detail"] == f"The requested wire transfer {wire_transfer_id} does not exist."

if __name__ == "__main__":
    pytest.main()