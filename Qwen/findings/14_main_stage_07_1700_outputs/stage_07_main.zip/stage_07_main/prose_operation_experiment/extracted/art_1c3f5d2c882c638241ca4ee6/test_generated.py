import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_tensorflow_versions():
    url = f"{BASE_URL}/v1/projects/location/tensorflowVersions"
    params = {
        "_xgafv": "2",
        "access_token": "your_access_token_here",
        "alt": "json",
        "callback": None,
        "fields": None,
        "key": "your_api_key_here",
        "oauth_token": None,
        "prettyPrint": True,
        "quotaUser": None,
        "uploadType": None,
        "upload_protocol": None,
        "filter": None,
        "orderBy": None,
        "pageSize": None,
        "pageToken": None
    }
    headers = {
        "Authorization": "Bearer your_oauth_token_here"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert "tensorflowVersions" in data
    assert isinstance(data["tensorflowVersions"], list)

if __name__ == "__main__":
    pytest.main([__file__])