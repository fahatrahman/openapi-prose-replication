import os
import pytest
import requests

BASE_URL = "http://openapi.test"
HEADERS = {"Accept": "application/json"}
AUTH_FLOW = {
    "authorizationUrl": "https://api.lufthansa.com/v1/oauth/token",
    "tokenUrl": "https://api.lufthansa.com/v1/oauth/token",
    "scopes": {"read:LH Open API": "read access"},
}

@pytest.fixture
def auth():
    return requests.RequestAuth(AUTH_FLOW["authorizationUrl"], AUTH_FLOW["tokenUrl"], scopes=AUTH_FLOW["scopes"])

def test_get_cargo_route():
    origin = "FRA"
    destination = "HKG"
    from_date = "2017-07-15"
    product_code = "YNZ"

    url = f"{BASE_URL}/cargo/getRoute/{origin}-{destination}/{from_date}/{product_code}"
    response = requests.get(url, headers=HEADERS, auth=auth)

    assert response.status_code == 200
    assert isinstance(response.json(), dict)