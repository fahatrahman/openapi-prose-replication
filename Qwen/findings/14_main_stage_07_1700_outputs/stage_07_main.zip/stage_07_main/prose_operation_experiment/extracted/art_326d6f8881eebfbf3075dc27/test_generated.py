import pytest
import requests

BASE_URL = "http://openapi.test"

def patch_pay_instruction(employer_id, employee_id, pay_instruction_id, authorization, api_version, pay_instruction):
    url = f"{BASE_URL}/Employer/{employer_id}/Employee/{employee_id}/PayInstruction/{pay_instruction_id}"
    headers = {
        "Authorization": authorization,
        "Api-Version": api_version
    }
    response = requests.patch(url, json=pay_instruction, headers=headers)
    return response

@pytest.mark.parametrize("employer_id, employee_id, pay_instruction_id, authorization, api_version, pay_instruction, expected_status_code", [
    ("GD001", "CT001", "LSH001", "Bearer token", "default", {"Description": "Updated description"}, 200),
    ("GD001", "CT001", "LSH001", "Bearer invalid_token", "default", {"Description": "Updated description"}, 401),
    ("GD001", "CT001", "nonexistent", "Bearer token", "default", {"Description": "Updated description"}, 404),
])
def test_patch_pay_instruction(employer_id, employee_id, pay_instruction_id, authorization, api_version, pay_instruction, expected_status_code):
    response = patch_pay_instruction(employer_id, employee_id, pay_instruction_id, authorization, api_version, pay_instruction)
    assert response.status_code == expected_status_code