import pytest
import requests

BASE_URL = "http://openapi.test"

def test_cancel_line_item():
    url = f"{BASE_URL}/123/orders/456/cancelLineItem"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "lineItemId": "line-item-id",
        "operationId": "operation-id",
        "productId": "product-id",
        "quantity": 1,
        "reason": "customerInitiatedCancel",
        "reasonText": "Customer initiated cancel"
    }
    params = {
        "_xgafv": "2",
        "access_token": "YOUR_ACCESS_TOKEN",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "YOUR_API_KEY",
        "oauth_token": "",
        "prettyPrint": True,
        "quotaUser": "",
        "uploadType": "",
        "upload_protocol": ""
    }
    response = requests.post(url, headers=headers, json=payload, params=params)
    assert response.status_code == 200
    assert response.json()["kind"] == "content#ordersCancelLineItemResponse"
    assert response.json()["executionStatus"] == "executed"