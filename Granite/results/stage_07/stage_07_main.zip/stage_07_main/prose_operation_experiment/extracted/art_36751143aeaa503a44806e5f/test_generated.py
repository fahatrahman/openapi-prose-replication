import os
import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

@pytest.fixture
def auth():
    username = os.getenv("BASIC_AUTH_USERNAME")
    password = os.getenv("BASIC_AUTH_PASSWORD")
    return HTTPBasicAuth(username, password)

def test_get_call_broadcast_batches(auth):
    id = 123  # Replace with actual ID
    limit = 10  # Replace with desired limit
    offset = 0  # Replace with desired offset

    url = f"{BASE_URL}/calls/broadcasts/{id}/batches"
    params = {
        "fields": "id, name",  # Replace with desired fields
        "limit": limit,
        "offset": offset
    }

    response = requests.get(url, auth=auth, params=params)

    assert response.status_code == 200
    data = response.json()
    assert "items" in data
    assert "totalCount" in data
    assert len(data["items"]) <= limit
