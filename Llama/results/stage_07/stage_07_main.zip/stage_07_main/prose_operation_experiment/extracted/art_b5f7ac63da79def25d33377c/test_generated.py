import pytest
import requests
from jsonschema import validate

BASE_URL = "http://openapi.test"

def test_issue_add_label():
    url = f"{BASE_URL}/repos/{'owner'}/{'repo'}/issues/{100}/labels"
    
    headers = {
        'Authorization': 'Bearer token',
        # Other security scheme headers...
    }
    
    body = {
        'labels': [123]
    }

    response = requests.post(url, headers=headers, json=body)
    
    assert response.status_code == 200
    
    try:
        schema = {
            "type": "array",
            "items": {
                "$ref": "#/components/schemas/Label"
            }
        }
        
        validate(instance=response.json(), schema=schema)
    except Exception as e:
        print(f"Validation failed: {str(e)}")
    
    # Test for forbidden status code
    response_forbidden = requests.post(url, headers={'Authorization': 'Invalid token'})
    assert response_forbidden.status_code == 403
    
    try:
        schema = {
            "type": "object",
            "properties": {
                "message": {"type": "string"},
                "url": {"type": "string"}
            },
            "required": ["message", "url"]
        }
        
        validate(instance=response_forbidden.json(), schema=schema)
    except Exception as e:
        print(f"Validation failed: {str(e)}")

if __name__ == "__main__":
    pytest.main([__file__, "-v"])