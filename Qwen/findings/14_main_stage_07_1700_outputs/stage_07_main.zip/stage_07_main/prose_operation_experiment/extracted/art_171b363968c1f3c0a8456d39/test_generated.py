import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_metrics_pageviews_top_by_country():
    url = f"{BASE_URL}/metrics/pageviews/top-by-country/project/access/year/month"
    response = requests.get(url)
    assert response.status_code == 200
    assert response.json().get("items") is not None

if __name__ == "__main__":
    pytest.main()