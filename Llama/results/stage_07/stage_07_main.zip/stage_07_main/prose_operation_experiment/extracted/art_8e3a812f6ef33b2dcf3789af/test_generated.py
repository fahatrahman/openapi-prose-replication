import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_repositories():
    url = f"{BASE_URL}/v1beta1/{'projects/locations/repositories'}"
    headers = {}
    params = {
        'filter': '',
        'orderBy': '',
        'pageSize': 10,
        'pageToken': ''
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    response.raise_for_status()
    data = response.json()
    assert isinstance(data, dict)
    assert 'repositories' in data
    assert isinstance(data['repositories'], list)

def test_list_repositories_with_parent_path():
    parent_path = 'projects/locations'
    url = f"{BASE_URL}/v1beta1/{parent_path}/repositories"
    headers = {}
    params = {
        'filter': '',
        'orderBy': '',
        'pageSize': 10,
        'pageToken': ''
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    response.raise_for_status()
    data = response.json()
    assert isinstance(data, dict)
    assert 'repositories' in data
    assert isinstance(data['repositories'], list)