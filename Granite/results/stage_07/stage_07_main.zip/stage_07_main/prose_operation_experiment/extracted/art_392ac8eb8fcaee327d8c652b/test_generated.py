import os
import requests
import pytest

BASE_URL = "http://openapi.test"

@pytest.fixture
def client():
    return requests.Session()

def test_last_quote(client):
    symbol = "AAPL"
    url = f"{BASE_URL}/v1/last_quote/stocks/{symbol}"

    response = client.get(url)

    if response.status_code == 200:
        assert response.json()["status"] == "success"
        assert isinstance(response.json()["last"], dict)
        assert response.json()["symbol"] == symbol
    else:
        assert response.json["code"] == response.status_code
        assert response.json["message"] == f"Unexpected error {response.status_code}"