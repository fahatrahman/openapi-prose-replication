import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_similar_images():
    params = {
        "id": "465011609",
        "language": "es",
        "page": 1,
        "per_page": 20,
        "view": "minimal"
    }
    response = requests.get(f"{BASE_URL}/v2/images/{params['id']}/similar", params=params)
    
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "data" in data
    assert isinstance(data["data"], list)

if __name__ == "__main__":
    pytest.main()