import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS = service_account.Credentials.from_service_account_file(
    "path/to/credentials.json"
)

@pytest.fixture
def api_client():
    if CREDENTIALS is None:
        raise Exception("Credentials not provided")

    def _api_request(method, path, **kwargs):
        url = BASE_URL + path
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {CREDENTIALS.token}",
        }

        if method == "GET":
            response = requests.get(url, headers=headers, params=kwargs)
        elif method == "POST":
            response = requests.post(url, headers=headers, json=kwargs)
        else:
            raise ValueError("Unsupported HTTP method")

        response.raise_for_status()
        return response.json()

    return _api_request

def test_list_projects(api_client):
    method = "GET"
    path = "/v1/projects"
    kwargs = {"filter": "lifecycleState:ACTIVE"}

    response = api_client(method, path, **kwargs)
    assert len(response["projects"]) > 0