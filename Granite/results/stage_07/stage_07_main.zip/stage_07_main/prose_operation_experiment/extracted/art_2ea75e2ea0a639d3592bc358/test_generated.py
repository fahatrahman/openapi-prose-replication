import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Configure session for retries
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["HEAD", "GET", "OPTIONS"],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("http://", adapter)
session.mount("https://", adapter)

# Security credentials for OAuth2
OAUTH2_CREDENTIALS = {
    "client_id": "YOUR_CLIENT_ID",
    "client_secret": "YOUR_CLIENT_SECRET",
    "refresh_token": "YOUR_REFRESH_TOKEN",
}

@pytest.fixture
def enterprises_set_store_layout():
    """
    Test fixture for setting store layout of an enterprise.
    """

    def _test(
        enterprise_id,
        store_layout,
    ):
        url = f"{BASE_URL}/androidenterprise/v1/enterprises/{enterprise_id}/storeLayout"

        headers = {}
        if "access_token" in OAUTH2_CREDENTIALS:
            headers["Authorization"] = f"Bearer {OAUTH2_CREDENTIALS['access_token']}"

        response = session.put(url, json={"storeLayout": store_layout}, headers=headers)

        response.raise_for_status()

        return response.json()

    yield _test