# Generated using openapi-generator v6.2.1
import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_payees_invitation_status_v4():
    url = f"{BASE_URL}/v4/payees/payors/{pytest.fixture('payor_id')}/invitationStatus"
    params = {
        "payeeId": pytest.fixture("payee_id"),
        "invitationStatus": pytest.fixture("invitation_status"),
        "page": pytest.fixture("page_number", default=1),
        "pageSize": pytest.fixture("page_size", default=25)
    }
    
    response = requests.get(url, params=params)

    assert response.status_code == 200
    
    # Check JSON response
    response_json = response.json()
    assert isinstance(response_json, dict)
    assert "content" in response_json
    assert len(response_json["content"]) > 0
    assert all(isinstance(item, dict) for item in response_json["content"])
    assert all(key in item for key in ["gracePeriodEndDate", "invitationStatus", "payeeId"] for item in response_json["content"])

def test_get_payees_invitation_status_v4_invalid_request():
    url = f"{BASE_URL}/v4/payees/payors/{pytest.fixture('payor_id')}/invitationStatus"
    params = {"invalid_param": "invalid_value"}
    
    response = requests.get(url, params=params)

    assert response.status_code == 400
    
    # Check JSON response
    response_json = response.json()
    assert isinstance(response_json, dict)
    assert "correlationId" in response_json
    assert "errors" in response_json
    assert isinstance(response_json["errors"], list)
    assert all(isinstance(error, dict) for error in response_json["errors"])
    assert all(key in error for key in ["errorCode", "errorData", "errorMessage", "localisationDetails", "location", "reasonCode"] for error in response_json["errors"])

@pytest.fixture
def payor_id():
    return "9ac75325-5dcd-42d5-b992-175d7e0a035e"

@pytest.fixture
def payee_id():
    return "2aa5d7e0-2ecb-403f-8494-1865ed0454e9"

@pytest.fixture
def invitation_status():
    return "invitationStatus"

@pytest.fixture
def page_number():
    return 1

@pytest.fixture
def page_size():
    return 25