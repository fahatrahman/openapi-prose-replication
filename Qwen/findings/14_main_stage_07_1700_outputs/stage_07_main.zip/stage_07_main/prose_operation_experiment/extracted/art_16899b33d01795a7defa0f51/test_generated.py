import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_outbound_message_dump():
    headers = {
        "X-Postmark-Server-Token": "your_server_token_here",
        "Content-Type": "application/json"
    }
    params = {
        "messageid": "your_message_id_here"
    }
    url = f"{BASE_URL}/messages/outbound/{params['messageid']}/dump"
    
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 200
    assert 'Body' in response.json()
    assert isinstance(response.json()['Body'], str)

def test_get_outbound_message_dump_422():
    headers = {
        "X-Postmark-Server-Token": "your_server_token_here",
        "Content-Type": "application/json"
    }
    params = {
        "messageid": "invalid_message_id"
    }
    url = f"{BASE_URL}/messages/outbound/{params['messageid']}/dump"
    
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 422
    assert 'ErrorCode' in response.json()
    assert 'Message' in response.json()

def test_get_outbound_message_dump_500():
    headers = {
        "X-Postmark-Server-Token": "your_server_token_here",
        "Content-Type": "application/json"
    }
    params = {
        "messageid": "internal_error_message_id"
    }
    url = f"{BASE_URL}/messages/outbound/{params['messageid']}/dump"
    
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 500