import pytest
import requests

BASE_URL = "http://openapi.test"

def test_operating_systems_list():
    profile_id = "test_profile"
    params = {
        "$.xgafv": "1",
        "access_token": "",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "",
        "oauth_token": "",
        "prettyPrint": "false",
        "quotaUser": "",
        "upload_protocol": "upload",
        "uploadType": "media",
        "profileId": profile_id,
    }
    headers = {}
    
    response = requests.get(
        f"{BASE_URL}/userprofiles/{profile_id}/operatingSystems", 
        params=params, 
        headers=headers)
        
    assert response.status_code == 200
    
    response_json = response.json()
    assert isinstance(response_json, dict)
    assert 'kind' in response_json.keys()
    assert isinstance(response_json['operatingSystems'], list)

if __name__ == "__main__":
    pytest.main([__file__])