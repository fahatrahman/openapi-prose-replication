import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_sources():
    params = {
        "max": 10,
        "offset": 0,
        "sort": "name"
    }
    response = requests.get(f"{BASE_URL}/resources/sources.json", params=params)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    for item in data:
        assert "meta" in item
        assert "results" in item
        meta = item["meta"]
        results = item["results"]
        assert isinstance(meta, dict)
        assert isinstance(results, list)
        for result in results:
            assert isinstance(result, dict)
            assert "acronym" in result
            assert "contactEmail" in result
            assert "id" in result
            assert "largeLogoUrl" in result
            assert "name" in result
            assert "smallLogoUrl" in result
            assert "websiteUrl" in result