# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_topic_sentiment():
    # Prepare the request body
    post_request = [
        {"id": "", "language": "en", "text": "This is a sample text"},
        {"id": "", "language": "fr", "text": "Ceci est un texte d'exemple"}
    ]

    # Send the POST request
    response = requests.post(
        urljoin(BASE_URL, "/topic-sentiment"),
        headers={"x-api-key": "your_api_key"},  # Replace 'your_api_key' with your actual API key
        json=post_request,
        params={"domain": "Ecom"}
    )

    # Check if the response was successful
    assert response.status_code == 200

    # Parse the JSON response
    topic_sentiment_response = response.json()

    # Check if the response matches the expected schema
    assert isinstance(topic_sentiment_response, list)
    for topic_sentiment_output in topic_sentiment_response:
        assert isinstance(topic_sentiment_output, dict)
        assert "id" in topic_sentiment_output
        assert "language" in topic_sentiment_output
        assert "sentiments" in topic_sentiment_output
        assert "text" in topic_sentiment_output
        assert "topicSentiments" in topic_sentiment_output
        assert "topics" in topic_sentiment_output

        for sentiment in topic_sentiment_output["sentiments"]:
            assert isinstance(sentiment, dict)
            assert "category" in sentiment
            assert "end" in sentiment
            assert "negationTerm" in sentiment
            assert "parentCategory" in sentiment
            assert "positive" in sentiment
            assert "scale" in sentiment
            assert "start" in sentiment
            assert "text" in sentiment

        for topic_sentiment in topic_sentiment_output["topicSentiments"]:
            assert isinstance(topic_sentiment, dict)
            assert "sentence" in topic_sentiment
            assert "sentiment" in topic_sentiment
            assert "topic" in topic_sentiment

        for topic in topic_sentiment_output["topics"]:
            assert isinstance(topic, dict)
            assert "category" in topic
            assert "end" in topic
            assert "polarity" in topic
            assert "start" in topic
            assert "text" in topic
            assert "topic" in topic