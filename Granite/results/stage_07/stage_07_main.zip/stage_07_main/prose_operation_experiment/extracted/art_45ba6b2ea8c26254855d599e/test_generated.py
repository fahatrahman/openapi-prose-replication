import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = "path/to/your/service_account.json"

def test_validate_flow():
    # Load credentials from service account file
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=["https://www.googleapis.com/auth/cloud-platform", "https://www.googleapis.com/auth/dialogflow"]
    )

    # Define the path for the flow to validate
    flow_path = "/v3/projects/-/locations/-/agents/-/flows/YOUR_FLOW_NAME:validate"

    # Create a session using the loaded credentials
    session = requests.Session()
    session.auth = (credentials.service_account_email, credentials.id_token)

    # Prepare the request payload
    payload = {
        "languageCode": "en"
    }

    # Send the POST request
    response = session.post(BASE_URL + flow_path, json=payload)

    # Check if the request was successful (status code 200)
    assert response.status_code == 200

    # Parse the response JSON
    validation_result = response.json()

    # Perform further assertions based on the validation_result if needed