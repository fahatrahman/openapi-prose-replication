import pytest
import requests

BASE_URL = "http://openapi.test"

def test_card_details_basic():
    url = f"{BASE_URL}/cardDetails"
    headers = {
        "Content-Type": "application/json",
        "Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed"
    }
    payload = {
        "cardNumber": "411111",
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT"
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert response.json() == {
        "brands": [
            {"supported": True, "type": "visa"},
            {"supported": True, "type": "cartebancaire"}
        ]
    }

def test_card_details_supported_brands():
    url = f"{BASE_URL}/cardDetails"
    headers = {
        "Content-Type": "application/json",
        "Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed"
    }
    payload = {
        "cardNumber": "411111",
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "supportedBrands": ["visa", "mc", "amex"]
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert response.json() == {
        "brands": [
            {"supported": True, "type": "visa"},
            {"supported": False, "type": "cartebancaire"}
        ]
    }