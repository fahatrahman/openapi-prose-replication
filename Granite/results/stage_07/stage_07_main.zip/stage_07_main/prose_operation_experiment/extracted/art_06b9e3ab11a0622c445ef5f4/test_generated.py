import pytest
import requests
BASE_URL = "http://openapi.test"

@pytest.fixture
def apps():
    response = requests.get(f"{BASE_URL}/vendor/apps", params={"offset": 5})
    response.raise_for_status()
    return response.json()["items"]

def test_get_vendor_apps(apps):
    assert isinstance(apps, list)
    for app in apps:
        assert all(key in app for key in ("archived", "branch", "buildFlavor", "cancelOnPush", "commitId", "creationDate", "deployUrl", "deployment", "description", "favourite", "homogeneous", "id", "instance", "last_deploy", "name", "ownerId", "separateBuild", "state", "stickySessions", "vhosts", "webhookSecret", "webhookUrl", "zone"))