import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_menu_deal_groups():
    url = f"{BASE_URL}/restaurants/uk/95224345321/catalogue/items/534685/dealgroups"
    params = {
        "limit": 10
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 200
    assert "dealGroups" in response.json()
    assert "paging" in response.json()

def test_get_menu_deal_groups_with_cursor():
    url = f"{BASE_URL}/restaurants/uk/95224345321/catalogue/items/534685/dealgroups"
    params = {
        "limit": 10,
        "after": "NDMyNzQyODI3OTQw"
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 200
    assert "dealGroups" in response.json()
    assert "paging" in response.json()

def test_get_menu_deal_groups_invalid_limit():
    url = f"{BASE_URL}/restaurants/uk/95224345321/catalogue/items/534685/dealgroups"
    params = {
        "limit": 0
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 400
    assert "errors" in response.json()
    assert "description" in response.json()["errors"][0]
    assert response.json()["errors"][0]["description"] == "Invalid value 0 for parameter limit."

def test_get_menu_deal_groups_not_found():
    url = f"{BASE_URL}/restaurants/uk/95224345321/catalogue/items/999999999999/dealgroups"
    params = {
        "limit": 10
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 404
    assert "errors" in response.json()
    assert "description" in response.json()["errors"][0]
    assert response.json()["errors"][0]["description"] == "Resource with identifier restaurantId:999999999999 for tenant:uk and itemId:999999999999 not found."