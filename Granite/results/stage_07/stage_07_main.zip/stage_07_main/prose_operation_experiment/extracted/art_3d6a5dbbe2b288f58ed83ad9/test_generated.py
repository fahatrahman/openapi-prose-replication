import os
import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

@pytest.fixture
def test_data():
    return {
        "manager_customer_id": "123",
        "startDate": {"year": 2022, "month": 1, "day": 1},
        "endDate": {"year": 2022, "month": 12, "day": 31}
    }

def search_detailed_lead_reports(manager_customer_id, start_date, end_date):
    url = f"{BASE_URL}/v1/detailedLeadReports:search"
    params = {
        "query": f"manager_customer_id:{manager_customer_id}",
        "startDate.year": start_date["year"], "startDate.month": start_date["month"], "startDate.day": start_date["day"],
        "endDate.year": end_date["year"], "endDate.month": end_date["month"], "endDate.day": end_date["day"]
    }

    headers = {}
    if 'access_token' in os.environ:
        headers['Authorization'] = f"Bearer {os.environ['access_token']}"

    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 200, f"Request failed with status code {response.status_code}"
    
    return response.json()

def test_search_detailed_lead_reports(test_data):
    result = search_detailed_lead_reports(**test_data)
    assert isinstance(result, dict), "Response should be a dictionary"
    assert "detailedLeadReports" in result, "Response should contain 'detailedLeadReports'"
    print("Test passed successfully.")