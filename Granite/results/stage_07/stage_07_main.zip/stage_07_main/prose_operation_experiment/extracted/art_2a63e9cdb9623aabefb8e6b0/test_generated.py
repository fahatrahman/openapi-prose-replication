import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = "path/to/service_account.json"

def get_authenticated_session():
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )
    return requests.Session(), credentials

@pytest.fixture
def backup_schedule_data():
    return {
        "createTime": "2022-01-01T00:00:00Z",
        "dailyRecurrence": {},
        "name": "projects/my-project/databases/(default)/backupSchedules/my-backup-schedule",
        "retention": "30d",
        "updateTime": "2022-01-01T00:00:00Z",
        "weeklyRecurrence": {"day": "MONDAY"},
    }

def test_create_backup_schedule(get_authenticated_session):
    session, credentials = get_authenticated_session()

    path_params = {"parent": "projects/my-project/databases/(default)"}
    payload = backup_schedule_data

    response = session.post(
        f"{BASE_URL}/v1/{path_params['parent']}/backupSchedules", json=payload, auth=credentials
    )

    assert response.status_code == 200
    created_schedule = response.json()

    # Add more assertions based on the expected output here