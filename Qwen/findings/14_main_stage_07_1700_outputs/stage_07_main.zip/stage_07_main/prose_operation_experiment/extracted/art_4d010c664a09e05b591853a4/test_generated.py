import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_question():
    url = f"{BASE_URL}/v4/example_name"
    params = {
        "_xgafv": "1",
        "access_token": "example_access_token",
        "alt": "json",
        "callback": "example_callback",
        "fields": "example_fields",
        "key": "example_key",
        "oauth_token": "example_oauth_token",
        "prettyPrint": False,
        "quotaUser": "example_quota_user",
        "uploadType": "example_upload_type",
        "upload_protocol": "example_upload_protocol"
    }
    response = requests.delete(url, params=params)
    assert response.status_code == 200
    assert response.json() == {}