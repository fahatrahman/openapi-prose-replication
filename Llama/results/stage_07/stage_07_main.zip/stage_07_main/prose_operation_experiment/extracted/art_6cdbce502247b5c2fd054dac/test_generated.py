import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_refund_or_cancel_payment():
    # Define the path parameters
    payment_psp_reference = "your_payment_psp_reference"

    # Define the payload
    payload = {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "reference": "YOUR_UNIQUE_REFERENCE"
    }

    # Set the headers
    headers = {
        "Content-Type": "application/json",
        "Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed"
    }

    # Send the POST request
    response = requests.post(
        urljoin(BASE_URL, f"/payments/{payment_psp_reference}/reversals"),
        json=payload,
        headers=headers
    )

    # Check the status code
    assert response.status_code == 201

    # Parse the JSON response
    response_json = response.json()

    # Check the response content
    assert response_json["merchantAccount"] == "YOUR_MERCHANT_ACCOUNT"
    assert response_json["paymentPspReference"] != ""
    assert response_json["pspReference"] != ""
    assert response_json["reference"] == "YOUR_UNIQUE_REFERENCE"
    assert response_json["status"] == "received"

def test_refund_or_cancel_payment_bad_request():
    # Define the path parameters
    payment_psp_reference = "your_payment_psp_reference"

    # Define the payload
    payload = {}

    # Set the headers
    headers = {
        "Content-Type": "application/json",
        "Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed"
    }

    # Send the POST request
    response = requests.post(
        urljoin(BASE_URL, f"/payments/{payment_psp_reference}/reversals"),
        json=payload,
        headers=headers
    )

    # Check the status code
    assert response.status_code == 400

def test_refund_or_cancel_payment_unauthorized():
    # Define the path parameters
    payment_psp_reference = "your_payment_psp_reference"

    # Define the payload
    payload = {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "reference": "YOUR_UNIQUE_REFERENCE"
    }

    # Set the headers
    headers = {
        "Content-Type": "application/json"
    }

    # Send the POST request
    response = requests.post(
        urljoin(BASE_URL, f"/payments/{payment_psp_reference}/reversals"),
        json=payload,
        headers=headers
    )

    # Check the status code
    assert response.status_code == 401

def test_refund_or_cancel_payment_forbidden():
    # Define the path parameters
    payment_psp_reference = "your_payment_psp_reference"

    # Define the payload
    payload = {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "reference": "YOUR_UNIQUE_REFERENCE"
    }

    # Set the headers
    headers = {
        "Content-Type": "application/json",
        "Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed"
    }

    # Send the POST request
    response = requests.post(
        urljoin(BASE_URL, f"/payments/{payment_psp_reference}/reversals"),
        json=payload,
        headers=headers
    )

    # Check the status code
    assert response.status_code == 403

def test_refund_or_cancel_payment_unprocessable_entity():
    # Define the path parameters
    payment_psp_reference = "your_payment_psp_reference"

    # Define the payload
    payload = {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT"
    }

    # Set the headers
    headers = {
        "Content-Type": "application/json",
        "Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed"
    }

    # Send the POST request
    response = requests.post(
        urljoin(BASE_URL, f"/payments/{payment_psp_reference}/reversals"),
        json=payload,
        headers=headers
    )

    # Check the status code
    assert response.status_code == 422

def test_refund_or_cancel_payment_internal_server_error():
    # Define the path parameters
    payment_psp_reference = "your_payment_psp_reference"

    # Define the payload
    payload = {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "reference": "YOUR_UNIQUE_REFERENCE"
    }

    # Set the headers
    headers = {
        "Content-Type": "application/json",
        "Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed"
    }

    # Send the POST request
    response = requests.post(
        urljoin(BASE_URL, f"/payments/{payment_psp_reference}/reversals"),
        json=payload,
        headers=headers
    )

    # Check the status code
    assert response.status_code == 500