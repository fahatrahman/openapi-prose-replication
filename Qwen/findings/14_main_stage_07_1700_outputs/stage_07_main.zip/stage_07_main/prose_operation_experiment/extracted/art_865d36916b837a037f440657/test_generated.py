import pytest
import requests

BASE_URL = "http://openapi.test"

def test_update_beta_group():
    headers = {
        "Authorization": "Bearer YOUR_BEARER_TOKEN",
        "Content-Type": "application/json"
    }
    beta_group_id = "YOUR_BETA_GROUP_ID"
    update_data = {
        "data": {
            "id": beta_group_id,
            "type": "betaGroups",
            "attributes": {
                "name": "Updated Beta Group Name",
                "publicLinkEnabled": False
            }
        }
    }
    response = requests.patch(f"{BASE_URL}/v1/betaGroups/{beta_group_id}", json=update_data, headers=headers)
    
    assert response.status_code == 200
    assert response.json()["data"]["id"] == beta_group_id
    assert response.json()["data"]["attributes"]["name"] == "Updated Beta Group Name"
    assert response.json()["data"]["attributes"]["publicLinkEnabled"] is False

if __name__ == "__main__":
    pytest.main()