import os
import pytest
import requests
from google.rpc import status_pb2

BASE_URL = "http://openapi.test"

@pytest.fixture
def get_operation():
    def _get_operation(apps_id, operations_id):
        url = f"{BASE_URL}/v1beta/apps/{apps_id}/operations/{operations_id}"
        headers = {"accept": "application/json"}

        response = requests.get(url, headers=headers)
        response.raise_for_status()

        return response.json()

    return _get_operation

def test_get_operation(get_operation):
    apps_id = "your_apps_id"
    operations_id = "your_operations_id"

    operation = get_operation(apps_id, operations_id)
    assert operation["done"] is False or operation["done"] is True
    assert isinstance(operation["error"], status_pb2.Status)
    assert isinstance(operation["metadata"], dict)
    assert isinstance(operation["name"], str)
    assert isinstance(operation["response"], dict)