# -*- coding: utf-8 -*-

import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

def test_create_nfs_share():
    # Create an NFS share
    url = f"{BASE_URL}/v2/{parent}/nfsShares"
    headers = {"Content-Type": "application/json"}
    auth = None  # Oauth2/Oauth2c not implemented

    body = {
        "allowedClients": [],
        "id": "",
        "labels": {},
        "name": "",
        "nfsShareId": "",
        "pod": "",
        "requestedSizeGib": "0",
        "state": "STATE_UNSPECIFIED",
        "storageType": "STORAGE_TYPE_UNSPECIFIED",
        "volume": ""
    }

    response = requests.post(url, headers=headers, json=body, auth=auth)

    assert response.status_code == 200
    response_json = response.json()
    assert isinstance(response_json, dict)
    assert "name" in response_json
    assert "done" in response_json["name"]
    assert response_json["done"]

if __name__ == "__main__":
    pytest.main([__file__])