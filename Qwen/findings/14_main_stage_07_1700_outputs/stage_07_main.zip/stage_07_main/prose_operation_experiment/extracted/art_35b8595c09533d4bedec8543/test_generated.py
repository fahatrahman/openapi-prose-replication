import pytest
import requests

BASE_URL = "http://openapi.test"

def test_restore_volume_snapshot():
    url = f"{BASE_URL}/v2/volumeSnapshot:restoreVolumeSnapshot"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    payload = {
        "volumeSnapshot": "example-volume-snapshot"
    }
    params = {
        "_xgafv": "1",
        "access_token": "YOUR_ACCESS_TOKEN",
        "alt": "json",
        "prettyPrint": True,
        "quotaUser": "user@example.com"
    }

    response = requests.post(url, headers=headers, json=payload, params=params)

    assert response.status_code == 200
    assert response.json()["name"]
    assert response.json()["response"]

pytest.main()