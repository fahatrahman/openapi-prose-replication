import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_FILE = "path/to/your/credentials.json"

@pytest.fixture
def authenticated_session():
    credentials = service_account.Credentials.from_service_account_file(
        CREDENTIALS_FILE, scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )

    session = requests.Session()
    session.auth = (credentials.service_account_email, credentials.id_token)
    return session

def test_list_service_lb_policies(authenticated_session):
    parent = f"{BASE_URL}/projects/your_project/locations/your_location"
    params = {"pageSize": 10, "pageToken": "your_page_token"}
    
    response = authenticated_session.get(f"{BASE_URL}/v1/{parent}/serviceLbPolicies", params=params)
    response.raise_for_status()
    
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "serviceLbPolicies" in response.json()
    assert "nextPageToken" in response.json()