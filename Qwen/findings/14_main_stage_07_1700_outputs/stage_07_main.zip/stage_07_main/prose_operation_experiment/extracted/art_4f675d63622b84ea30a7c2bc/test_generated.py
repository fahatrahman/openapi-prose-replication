import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_global_config():
    url = f"{BASE_URL}/api/globalconfig"
    response = requests.get(url)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()