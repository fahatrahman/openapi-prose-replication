import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retry mechanism
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("http://", adapter)
session.mount("https://", adapter)

@pytest.fixture
def dialogflow_project_locations_delete_agent():
    """Test deleting an agent in Dialogflow."""

    def _test(parent):
        url = f"{BASE_URL}/v2/{parent}/agent"

        headers = {}

        response = session.delete(url, headers=headers)

        assert response.status_code == 200

        return {"response status code": response.status_code}

    yield _test