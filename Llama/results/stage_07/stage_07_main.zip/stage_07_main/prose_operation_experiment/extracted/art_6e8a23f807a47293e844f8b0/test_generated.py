# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urlencode

BASE_URL = "http://openapi.test"

def test_get_sources():
    url = f"{BASE_URL}/resources/sources.json"
    params = {
        'max': None,
        'offset': None,
        'sort': None
    }

    response = requests.get(url, params=urlencode(params))
    assert response.status_code == 200
    response.raise_for_status()

    data = response.json()
    assert isinstance(data, list)
    for item in data:
        assert isinstance(item, dict)
        assert 'callback' in item
        assert 'meta' in item
        assert isinstance(item['meta'], dict)
        assert 'messages' in item['meta']
        assert isinstance(item['meta']['messages'], list)
        for message in item['meta']['messages']:
            assert isinstance(message, dict)
            assert 'errorCode' in message
            assert 'errorDetail' in message
            assert 'errorMessage' in message
            assert 'userMessage' in message
        assert 'results' in item
        assert isinstance(item['results'], list)
        for result in item['results']:
            assert isinstance(result, dict)
            assert 'acronym' in result
            assert 'contactEmail' in result
            assert 'id' in result
            assert 'largeLogoUrl' in result
            assert 'name' in result
            assert 'smallLogoUrl' in result
            assert 'websiteUrl' in result

def test_get_sources_with_max():
    max_value = 10
    url = f"{BASE_URL}/resources/sources.json?{urlencode({'max': max_value})}"
    response = requests.get(url)
    assert response.status_code == 200
    response.raise_for_status()

    data = response.json()
    assert isinstance(data, list)

def test_get_sources_with_offset():
    offset_value = 20
    url = f"{BASE_URL}/resources/sources.json?{urlencode({'offset': offset_value})}"
    response = requests.get(url)
    assert response.status_code == 200
    response.raise_for_status()

    data = response.json()
    assert isinstance(data, list)

def test_get_sources_with_sort():
    sort_value = 'asc'
    url = f"{BASE_URL}/resources/sources.json?{urlencode({'sort': sort_value})}"
    response = requests.get(url)
    assert response.status_code == 200
    response.raise_for_status()

    data = response.json()
    assert isinstance(data, list)

def test_get_sources_invalid_max():
    invalid_max_value = 'not_an_integer'
    url = f"{BASE_URL}/resources/sources.json?{urlencode({'max': invalid_max_value})}"
    response = requests.get(url)
    assert response.status_code == 400

def test_get_sources_invalid_offset():
    invalid_offset_value = 'not_an_integer'
    url = f"{BASE_URL}/resources/sources.json?{urlencode({'offset': invalid_offset_value})}"
    response = requests.get(url)
    assert response.status_code == 400

def test_get_sources_invalid_sort():
    invalid_sort_value = 123
    url = f"{BASE_URL}/resources/sources.json?{urlencode({'sort': str(invalid_sort_value)})}"
    response = requests.get(url)
    assert response.status_code == 400

def test_get_sources_server_error():
    # Simulate a server error by adding an extra query parameter
    url = f"{BASE_URL}/resources/sources.json?{urlencode({'extra': 'parameter'})}"
    response = requests.get(url)
    assert response.status_code == 500