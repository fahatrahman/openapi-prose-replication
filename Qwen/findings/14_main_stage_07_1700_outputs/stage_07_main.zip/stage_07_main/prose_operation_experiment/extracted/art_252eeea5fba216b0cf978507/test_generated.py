import pytest
import requests

BASE_URL = "http://openapi.test"

def get_ship_nav(ship_symbol, access_token):
    headers = {
        "Authorization": f"Bearer {access_token}"
    }
    url = f"{BASE_URL}/my/ships/{ship_symbol}/nav"
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    return response.json()

@pytest.fixture
def access_token():
    # Mock function to simulate obtaining an access token
    return "mock_access_token"

def test_get_ship_nav(access_token):
    ship_symbol = "test_ship_symbol"
    try:
        result = get_ship_nav(ship_symbol, access_token)
        assert "data" in result
        assert "status" in result["data"]
        assert result["data"]["status"] in ["IN_TRANSIT", "IN_ORBIT", "DOCKED"]
    except requests.exceptions.RequestException as e:
        pytest.fail(f"Request failed: {e}")