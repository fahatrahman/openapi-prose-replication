import os
import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"
HEADERS = {"Content-Type": "application/json"}

def get_team_members(team_id, limit=None, since=None, until=None, search=None, role=None, exclude_project=None):
    url = f"{BASE_URL}/v2/teams/{team_id}/members"
    params = {}

    if limit:
        params["limit"] = limit
    if since:
        params["since"] = since
    if until:
        params["until"] = until
    if search:
        params["search"] = search
    if role:
        params["role"] = role
    if exclude_project:
        params["excludeProject"] = exclude_project

    response = requests.get(url, headers=HEADERS, params=params, auth=HTTPBasicAuth("token", ""))
    
    assert response.status_code == 200, f"Request failed with status code {response.status_code}"
    
    return response.json()

@pytest.mark.parametrize(
    "team_id, limit, since, until, search, role, exclude_project",
    [
        (
            "team_id",
            None,
            None,
            None,
            None,
            None,
            None,
        ),
        (
            "team_id",
            10,
            None,
            None,
            None,
            None,
            None,
        ),
        (
            "team_id",
            None,
            1540095775951,
            None,
            None,
            None,
            None,
        ),
        (
            "team_id",
            None,
            None,
            1540095775951,
            None,
            None,
            None,
        ),
        (
            "team_id",
            None,
            None,
            None,
            "John Doe",
            None,
            None,
        ),
        (
            "team_id",
            None,
            None,
            None,
            None,
            "OWNER",
            None,
        ),
        (
            "team_id",
            None,
            None,
            None,
            None,
            None,
            "project_id",
        ),
    ],
)
def test_get_team_members(team_id, limit, since, until, search, role, exclude_project):
    result = get_team_members(team_id, limit, since, until, search, role, exclude_project)
    assert isinstance(result, dict), "Response format is incorrect"
    assert "emailInviteCodes" not in result or not result["emailInviteCodes"], "Unexpected 'emailInviteCodes' key present in the response"
    assert "members" in result, "'members' key is missing from the response"
    assert isinstance(result["members"], list), "'members' value is not a list"