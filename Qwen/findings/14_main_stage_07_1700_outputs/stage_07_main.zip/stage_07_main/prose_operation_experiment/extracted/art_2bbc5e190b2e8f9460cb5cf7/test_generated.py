import pytest
import requests

BASE_URL = "http://openapi.test"

def test_load_stored_value():
    url = f"{BASE_URL}/load"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer YOUR_API_KEY"  # Replace with actual API key if needed
    }
    payload = {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",  # Replace with actual merchant account
        "reference": "TEST_REF_123",  # Replace with actual reference
        "paymentMethod": {},
        "amount": {
            "currency": "USD",
            "value": 100
        },
        "loadType": "load",
        "shopperReference": "SHopper_REF_123",  # Replace with actual shopper reference
        "shopperInteraction": "Ecommerce",
        "store": "STORE_123"  # Replace with actual store ID
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 200
    assert "authCode" in response.json()
    assert "currentBalance" in response.json()
    assert "pspReference" in response.json()
    assert "resultCode" in response.json() and response.json()["resultCode"] == "Success"

def test_load_stored_value_with_error():
    url = f"{BASE_URL}/load"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer YOUR_API_KEY"  # Replace with actual API key if needed
    }
    payload = {
        "merchantAccount": "INVALID_MERCHANT_ACCOUNT",  # Intentionally invalid merchant account for error testing
        "reference": "TEST_REF_456",  # Replace with actual reference
        "paymentMethod": {},
        "amount": {
            "currency": "USD",
            "value": 100
        },
        "loadType": "load",
        "shopperReference": "SHopper_REF_456",  # Replace with actual shopper reference
        "shopperInteraction": "Ecommerce",
        "store": "STORE_456"  # Replace with actual store ID
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 400
    assert "errorCode" in response.json()
    assert "errorType" in response.json()
    assert "message" in response.json()

if __name__ == "__main__":
    pytest.main()