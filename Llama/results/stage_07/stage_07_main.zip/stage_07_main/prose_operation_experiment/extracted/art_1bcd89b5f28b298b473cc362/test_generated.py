# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime
from typing import List

BASE_URL = "http://openapi.test"

def get_bank_feeds(company_id: str, connection_id: str) -> List[dict]:
    """Get bank feeds for a company."""
    
    url = f"{BASE_URL}/companies/{company_id}/connections/{connection_id}/connectionInfo/bankFeedAccounts"
    headers = {"Authorization": "Bearer <your_token>"}
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    
    return response.json()

def test_get_bank_feeds():
    """Test getting bank feeds for a company."""
    
    company_id = "8a210b68-6988-11ed-a1eb-0242ac120002"
    connection_id = "2e9d2c44-f675-40ba-8049-353bfcb5e171"
    
    try:
        bank_feeds = get_bank_feeds(company_id, connection_id)
        assert isinstance(bank_feeds, list)
        
        # Example usage:
        account_name = bank_feeds[0].get("accountName")
        assert account_name == "account-081"
        
    except AssertionError as e:
        pytest.fail(f"Failed to retrieve bank feeds: {str(e)}")

if __name__ == "__main__":
    pytest.main([__file__, "-s"])