import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_create_service_binding():
    url = f"{BASE_URL}/v1beta1/{'projects/123/locations/abc'}"
    headers = {
        'Content-Type': 'application/json'
    }
    body = {
        "name": "example-service-binding",
        "description": "Example service binding",
        "labels": {"label-key": "label-value"},
        "service": "example-service",
        "serviceId": "example-service-id"
    }

    response = requests.post(url, headers=headers, json=body)
    assert response.status_code == 200
    result = response.json()
    assert isinstance(result['name'], str)
    assert isinstance(result['description'], str)
    assert isinstance(result['labels'], dict)
    assert isinstance(result['service'], str)
    assert isinstance(result['serviceId'], str)

    # Validate metadata
    metadata = result.get('metadata')
    if metadata:
        assert isinstance(metadata, dict)
        for key, value in metadata.items():
            assert isinstance(key, str)
            assert isinstance(value, str)

    # Validate response
    response_schema = {
        "name": {"type": "string"},
        "description": {"type": "string"},
        "labels": {"type": "object"},
        "service": {"type": "string"},
        "serviceId": {"type": "string"}
    }
    for field, schema in response_schema.items():
        assert field in result
        assert isinstance(result[field], type(schema["type"]))