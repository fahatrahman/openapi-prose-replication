import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.fixture
def globalpageload():
    license = os.environ.get("LICENSE")
    origin = os.environ.get("ORIGIN")
    url = os.environ.get("URL")

    if not all([license, origin, url]):
        pytest.skip("Missing required environment variables.")

    params = {
        "license": license,
        "origin": origin,
        "url": url,
    }

    response = SESSION.get(f"{BASE_URL}/globalpageload", params=params)
    response.raise_for_status()

    return response.json()