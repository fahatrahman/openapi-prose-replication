import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_nft_uri():
    contract = "0x9db475371b5cc2913d3219f72e16a3f101339a05"
    token_id = "374"
    url = f"{BASE_URL}/v2/ethereum/nfts/{contract}/uri/{token_id}"
    
    response = requests.get(url)
    
    assert response.status_code == 200
    assert response.json()["ok"] is True
    assert response.json()["status"] == 200
    assert "uri" in response.json()["data"]
    assert response.json()["data"]["uri"] == "https://gateway.pinata.cloud/ipfs/Qma651vJiey2Kec22exdQ5qrZkQ3dDCzitpJLdjqDxnXRk"

if __name__ == "__main__":
    pytest.main()