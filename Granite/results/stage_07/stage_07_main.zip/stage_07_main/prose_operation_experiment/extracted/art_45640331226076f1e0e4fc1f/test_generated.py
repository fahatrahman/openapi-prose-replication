import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_PATH = "path/to/credentials.json"

@pytest.fixture
def dialogflow_client():
    credentials = service_account.Credentials.from_service_account_file(
        CREDENTIALS_PATH
    )
    return requests.Client(auth=credentials)

def test_batch_create_messages(dialogflow_client):
    parent = os.environ["PARENT"]
    messages_request = {
        "requests": [
            {
                "message": {
                    "content": "Hello, world!",
                    "participant": "end-user",
                },
                "parent": parent,
            }
        ]
    }

    response = dialogflow_client.post(
        f"{BASE_URL}/v2beta1/{parent}/messages:batchCreate", json=messages_request
    )
    assert response.status_code == 200
    messages = response.json()["messages"]
    assert len(messages) == 1
    assert messages[0]["content"] == "Hello, world!"