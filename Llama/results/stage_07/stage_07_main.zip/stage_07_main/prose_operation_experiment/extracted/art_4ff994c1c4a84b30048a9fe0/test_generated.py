# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_nearest_place():
    # Test case for nearest place endpoint
    url = f"{BASE_URL}/nearest_place"
    
    params = {
        'lat': '12.3',
        'lon': '12.3'
    }
    
    response = requests.get(url, params=params)
    
    assert response.status_code == 200
    
    data = response.json()
    
    # Validate response schema
    expected_schema = {
        'adm_area1': 'England',
        'adm_area2': 'Greater London',
        'country': 'United Kingdom',
        'lat': '23.2N',
        'lon': '15.3E',
        'name': 'London',
        'place_id': 'london',
        'timezone': 'Europe/London',
        'type': 'settlement'
    }
    
    for key in expected_schema:
        assert key in data
        assert data[key] == expected_schema[key]

def test_nearest_place_invalid_lat():
    # Test case for invalid latitude
    url = f"{BASE_URL}/nearest_place"
    
    params = {
        'lat': 'abc',
        'lon': '12.3'
    }
    
    response = requests.get(url, params=params)
    
    assert response.status_code == 422
    
    data = response.json()
    
    # Validate response schema
    expected_schema = [
        {'loc': ['path.lat'], 'msg': 'value is not a valid number', 'type': 'type_error.number'}
    ]
    
    assert len(data['detail']) == 1
    assert data['detail'][0]['loc'] == ['path.lat']
    assert data['detail'][0]['msg'] == 'value is not a valid number'
    assert data['detail'][0]['type'] == 'type_error.number'

def test_nearest_place_missing_key():
    # Test case for missing API key
    url = f"{BASE_URL}/nearest_place"
    
    params = {
        'lat': '12.3',
        'lon': '12.3'
    }
    
    response = requests.get(url, params=params)
    
    assert response.status_code == 403
    
    data = response.json()
    
    # Validate response schema
    expected_schema = {
        'detail': 'Missing API key'
    }
    
    assert data == expected_schema

def test_nearest_place_invalid_key():
    # Test case for invalid API key
    url = f"{BASE_URL}/nearest_place"
    
    params = {
        'lat': '12.3',
        'lon': '12.3',
        'key': 'invalid_key'
    }
    
    response = requests.get(url, params=params)
    
    assert response.status_code == 401
    
    data = response.json()
    
    # Validate response schema
    expected_schema = {
        'detail': 'Invalid API key'
    }
    
    assert data == expected_schema