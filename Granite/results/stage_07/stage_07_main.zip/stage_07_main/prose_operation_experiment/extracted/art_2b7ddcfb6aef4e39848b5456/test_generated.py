import os
import pytest
import requests
from requests_aws_sigv4 import AWSRequestsAuth43

BASE_URL = "http://openapi.test"

@pytest.fixture
def auth():
    return AWSRequestsAuth43(
        access_key=os.environ["AWS_ACCESS_KEY"],
        secret_key=os.environ["AWS_SECRET_KEY"],
        service="execute-api",
        region="us-east-1"
    )

def test_get_retention_settings(auth):
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "STRING_VALUE",
        "X-Amz-Date": "STRING_VALUE",
        "X-Amz-Credential": "STRING_VALUE",
        "X-Amz-Security-Token": "STRING_VALUE",
        "X-Amz-Signature": "STRING_VALUE",
        "X-Amz-SignedHeaders": "STRING_VALUE",
    }

    response = requests.get(
        f"{BASE_URL}/accounts/{{accountId}}/retention-settings",
        headers=headers,
        auth=auth
    )

    assert response.status_code == 200
    assert response.json()["InitiateDeletionTimestamp"]
    assert response.json()["RetentionSettings"]["ConversationRetentionSettings"]
    assert response.json()["RetentionSettings"]["RoomRetentionSettings"]["RetentionDays"] >= 1
