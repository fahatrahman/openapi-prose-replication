import pytest
import requests

BASE_URL = "http://openapi.test"

def get_api_key(target_id, id, access_token):
    url = f"{BASE_URL}/targets/{target_id}/keys/{id}"
    headers = {
        "Authorization": f"Bearer {access_token}"
    }
    response = requests.get(url, headers=headers)
    return response.json()

def test_get_api_key_success():
    # Assuming 'valid_access_token' is a valid JWT token with appropriate permissions
    response = get_api_key("target123", "key456", "valid_access_token")
    assert response['status_code'] == 200
    assert 'id' in response['data']
    assert 'key' in response['data']
    assert 'name' in response['data']

def test_get_api_key_forbidden():
    # Assuming 'invalid_access_token' is a JWT token without permission to access this endpoint
    response = get_api_key("target123", "key456", "invalid_access_token")
    assert response['status_code'] == 403
    assert 'error' in response['data']
    assert response['data']['error'] == "Not allowed to perform operation"

def test_get_api_key_not_found():
    # Assuming 'nonexistent_target_id' and 'nonexistent_id' do not exist in the system
    response = get_api_key("nonexistent_target_id", "nonexistent_id", "valid_access_token")
    assert response['status_code'] == 404
    assert 'error' in response['data']
    assert response['data']['error'] == "Not found"