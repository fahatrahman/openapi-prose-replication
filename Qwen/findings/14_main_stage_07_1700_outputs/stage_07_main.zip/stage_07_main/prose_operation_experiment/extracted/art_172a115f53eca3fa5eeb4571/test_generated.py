import pytest
import requests

BASE_URL = "http://openapi.test"

def test_key_retrieve():
    pk = "example-pk-43chars"
    url = f"{BASE_URL}/key/{pk}"
    
    response = requests.get(url)
    
    assert response.status_code == 200
    assert 'Content-Type' in response.headers and response.headers['Content-Type'].startswith('application/json')
    assert isinstance(response.json(), dict)
    assert 'since' in response.json() and isinstance(response.json()['since'], str)
    assert 'status' in response.json() and isinstance(response.json()['status'], str)
    assert 'sub' in response.json() and isinstance(response.json()['sub'], str)

def test_key_retrieve_404():
    pk = "unknown-key"
    url = f"{BASE_URL}/key/{pk}"
    
    response = requests.get(url)
    
    assert response.status_code == 404
    assert 'Content-Type' in response.headers and response.headers['Content-Type'].startswith('application/json')
    assert isinstance(response.json(), dict)
    assert 'error' in response.json() and isinstance(response.json()['error'], int)

def test_key_retrieve_410():
    pk = "revoked-key"
    url = f"{BASE_URL}/key/{pk}"
    
    response = requests.get(url)
    
    assert response.status_code == 410
    assert 'Content-Type' in response.headers and response.headers['Content-Type'].startswith('application/json')
    assert isinstance(response.json(), dict)
    assert 'error' in response.json() and isinstance(response.json()['error'], int)