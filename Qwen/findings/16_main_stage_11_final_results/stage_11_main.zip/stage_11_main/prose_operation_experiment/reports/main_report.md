# Main OpenAPI prose experiment · Exploratory report

All 850 selected operation pairs are accounted for.
Results describe pairs with usable evidence for each outcome. The registered confirmatory run was not completed.

## Descriptive paired results

| Endpoint | Available | Missing | L0 | L1 | L1 minus L0 |
|---|---:|---:|---:|---:|---:|
| collection_success | 849 | 1 | 0.5300 | 0.5748 | 0.0448 |
| baseline_pass | 725 | 125 | 0.0828 | 0.0717 | -0.0110 |
| request_intent_match | 205 | 645 | 0.8527 | 0.8486 | -0.0041 |
| selected_scenario_coverage | 677 | 173 | 0.3323 | 0.3642 | 0.0319 |
| supported_assertion_score | 202 | 648 | 0.0067 | 0.0033 | -0.0034 |
| effective_requirement_check_coverage | 202 | 648 | 0.0004 | 0.0013 | 0.0009 |
| unconditional_response_fault_detection | 725 | 125 | 0.0451 | 0.0454 | 0.0003 |

Descriptive values use unweighted means over common-evaluable pairs.
A missing score is retained with its reason. The review dispositions and the technical oracle scope are in the provenance files.
The experiment measures generated tests against documented offline responses.
