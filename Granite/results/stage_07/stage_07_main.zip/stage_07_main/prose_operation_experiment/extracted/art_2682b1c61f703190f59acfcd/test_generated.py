import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

# Custom session with retry logic
class UnicornSession(requests.Session):
    def __init__(self):
        super().__init__()
        self.mount("http://", HTTPAdapter(max_retries=3))

session = UnicornSession()

@pytest.fixture
def norm_judge_search_id():
    return "JSRCNUSK3pLGe48QcU"

@pytest.mark.parametrize(
    "norm_judge_search_id, expected_status_code, expected_response",
    [
        (
            norm_judge_search_id(),
            200,
            {
                "nextPageAPI": None,
                "normJudgeSearchId": norm_judge_search_id(),
                "normJudgeSearchResultArray": [
                    {
                        "firstFetchDate": "2023-02-16T12:56:17+00:00",
                        "lastFetchDate": "2023-02-16T12:56:17+00:00",
                        "matchedObjectArray": [
                            {
                                "highlightSnippet": "<b>NJUD5STmDbUZGukfQm</b>",
                                "matchedObjectAPI": "https://enterpriseapi.unicourt.com/normJudge/NJUD5STmDbUZGukfQm",
                                "matchedObjectAttribute": "normJudgeId",
                                "matchedObjectId": "NJUD5STmDbUZGukfQm",
                                "matchedObjectName": "NormJudge",
                                "object": "MatchedObject",
                            }
                        ],
                        "name": "JOHN ACOSTA",
                        "normJudgeDetailsAPI": "https://enterpriseapi.unicourt.com/normJudge/NJUD5STmDbUZGukfQm",
                        "normJudgeId": "NJUD5STmDbUZGukfQm",
                        "object": "NormJudgeSearchResult",
                    }
                ],
                "object": "NormJudgeSearchResponse",
                "pageNumber": 1,
                "previousPageAPI": None,
                "q": "normJudgeId%3A%22NJUD5STmDbUZGukfQm%22",
                "totalCount": 1,
                "totalPages": 1,
            },
        ),
        # Add more test cases here...
    ],
)
def test_normalized_judge_search_by_id(
    norm_judge_search_id, expected_status_code, expected_response
):
    url = urljoin(BASE_URL, f"/normJudgeSearch/{norm_judge_search_id}")

    response = session.get(url, params={"pageNumber": 1})

    assert response.status_code == expected_status_code
    assert response.json() == expected_response