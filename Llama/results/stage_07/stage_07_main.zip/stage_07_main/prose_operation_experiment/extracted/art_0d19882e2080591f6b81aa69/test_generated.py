# -*- coding: utf-8 -*-
import pytest
import requests
from uuid import UUID

BASE_URL = "http://openapi.test"

def test_get_asset():
    # Test getting asset by ID
    asset_id = UUID("e77602e0-3fb8-4734-aef9-fbc6fdcb0fa8").hex
    response = requests.get(f"{BASE_URL}/org/assets/{asset_id}", headers={"Authorization": f"Bearer {''}"})
    
    assert response.status_code == 200
    
    try:
        response.raise_for_status()
    except requests.RequestException as e:
        pytest.fail(str(e))
        
    assert response.json()["id"] == asset_id
    
    # Test getting non-existent asset
    non_existent_asset_id = UUID("12345678-1234-1234-1234-123456789012").hex
    response = requests.get(f"{BASE_URL}/org/assets/{non_existent_asset_id}")
    
    assert response.status_code == 404
    
    try:
        response.raise_for_status()
    except requests.RequestException as e:
        pytest.fail(str(e))
        
    assert response.json()["description"] == "Resource not found"