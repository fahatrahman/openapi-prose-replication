import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Define retry strategy for requests
session = requests.Session()
retries = Retry(total=3, backoff_factor=0.1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

@pytest.fixture
def create_comment():
    def inner(topic_id, comment):
        url = f"{BASE_URL}/api/discussions/topics/{topic_id}/comments"
        response = session.post(url, json=comment)
        response.raise_for_status()
        return response.json()

    return inner

def test_create_comment(create_comment):
    topic_id = 123  # Replace with actual topic ID
    comment = {
        "author": {"name": "Test User"},
        "authorName": "test_user",
        "created": "2022-01-01T00:00:00Z",
        "entry": {"name": "Test Entry"},
        "id": 1,
        "message": "This is a test comment."
    }

    response = create_comment(topic_id, comment)
    assert response["id"] > 0
    assert response["author"]["name"] == "Test User"
    assert response["message"] == "This is a test comment."