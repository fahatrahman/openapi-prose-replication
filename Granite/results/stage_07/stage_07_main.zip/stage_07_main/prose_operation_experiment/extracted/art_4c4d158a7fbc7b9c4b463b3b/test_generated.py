import os
import pytest
import requests
from googleapiclient.discovery import build

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def dns_service():
    """Create a service object for interacting with the Cloud DNS API."""
    api_service_name = "dns"
    api_version = "v1"
    credentials = None  # Replace this with your actual credentials if needed

    service = build(api_service_name, api_version, developerKey=credentials)
    return service

def test_list_policies(dns_service):
    """Test listing policies for a project."""
    project_id = "your_project_id"  # Replace with your actual project ID

    request = dns_service.projects().policies().list(
        project=project_id,
        maxResults=None,
        pageToken=None
    )

    response = request.execute()

    assert isinstance(response, dict)
    assert "header" in response
    assert "kind" in response
    assert "nextPageToken" in response["nextPageToken"] is None or isinstance(response["nextPageToken"], str)
    assert "policies" in response
    assert all(isinstance(policy, dict) for policy in response["policies"])