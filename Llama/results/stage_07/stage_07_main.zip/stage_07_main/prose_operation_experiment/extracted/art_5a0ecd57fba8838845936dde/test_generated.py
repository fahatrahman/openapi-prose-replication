# -*- coding: utf-8 -*-

import pytest
import requests
from requests.auth import HTTPBasicAuth
from datetime import datetime
import hashlib
import hmac
import base64

BASE_URL = "http://openapi.test"

def sign_request(method, path, query_string=""):
    timestamp = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    credential_scope = "/wireless-devices/{Identifier}/deregister"
    canonical_request = f"{method}\n{path}\n{query_string}\nhost:{BASE_URL}\nx-amz-date:{timestamp}"
    hashed_request = hashlib.sha256(canonical_request.encode()).hexdigest()
    string_to_sign = (
        f"{timestamp}\n{credential_scope}\n{hashed_request}\naws4_request"
    )
    signing_key = (
        "AWS4{KEY_ID}{DATE}\n"
        "20150925/aws4_request"
        .format(KEY_ID="YOUR_KEY_ID", DATE=datetime(2015, 9, 25).strftime("%Y%m%d"))
    )
    signature = hmac.new(
        signing_key.encode(),
        string_to_sign.encode(),
        hashlib.sha256,
    ).digest()
    return base64.b64encode(signature).decode()

def deregister_wireless_device(identifier, wireless_device_type=None):
    url = f"{BASE_URL}/wireless-devices/{identifier}/deregister"
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": hashlib.sha256("").hexdigest(),
        "X-Amz-Date": datetime.utcnow().strftime("%Y%m%dT%H%M%SZ"),
        "X-Amz-Credential": "YOUR_KEY_ID/20150925/wireless-devices/%2F/deregister/aws4_request",
        "X-Amz-Security-Token": "",
        "X-Amz-SignedHeaders": "host;x-amz-date",
        "Authorization": f"hmac {sign_request('PATCH', url)}",
    }
    if wireless_device_type:
        params = {"WirelessDeviceType": wireless_device_type}
    else:
        params = {}
    response = requests.patch(url, headers=headers, params=params)
    assert response.status_code == 200
    response.raise_for_status()

@pytest.mark.parametrize("identifier,wireless_device_type", [
    ("test_identifier", None),
    ("another_test_identifier", "Sidewalk"),
])
def test_deregister_wireless_device(identifier, wireless_device_type):
    deregister_wireless_device(identifier, wireless_device_type)

# Replace 'YOUR_KEY_ID' with your actual AWS key ID.
# Replace 'YOUR_KEY_ID' in the line below with your actual AWS key ID.
deregister_wireless_device("test_identifier", None)