import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

@pytest.fixture
def create_comment():
    def inner(id, comment):
        url = f"{BASE_URL}/api/songs/{id}/comments"
        response = session.post(url, json=comment)
        return response.json()

    return inner

def test_create_comment(create_comment):
    id = 123  # Replace with actual song ID
    comment = {
        "author": {"id": 1},
        "authorName": "Test User",
        "created": "2022-01-01T00:00:00Z",
        "entry": {"id": id},
        "id": 1,
        "message": "This is a test comment."
    }

    response = create_comment(id, comment)
    assert response["id"] == 1
    assert response["author"]["id"] == 1
    assert response["authorName"] == "Test User"
    assert response["created"] == "2022-01-01T00:00:00Z"
    assert response["entry"]["id"] == id
    assert response["message"] == "This is a test comment."