# -*- coding: utf-8 -*-

import pytest
import requests
from json import JSONDecodeError
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_get_photos():
    """Test getting photos."""
    
    # Construct full path
    path = "/v2/tier2/{shortName}/photo/photos"
    
    # Define parameters
    params = {
        "offset": 0,
        "count": 10
    }
    
    # Send GET request
    response = requests.get(urljoin(BASE_URL, path), params=params)
    
    # Check status code
    assert response.status_code == 200
    
    try:
        # Parse JSON response
        response_json = response.json()
        
        # Check schema compliance
        assert isinstance(response_json['Count'], int)
        assert isinstance(response_json['Data'], list)
        
        # Check each item in Data array
        for item in response_json['Data']:
            assert isinstance(item['ETag'], str)
            assert isinstance(item['FileName'], str)
            assert isinstance(item['InspectionItem'], str) or item['InspectionItem'] is None
            assert isinstance(item['InterimInspection'], str) or item['InterimInspection'] is None
            assert isinstance(item['InventoryItem'], str) or item['InventoryItem'] is None
            assert isinstance(item['Name'], str)
            assert isinstance(item['OID'], str)
            assert isinstance(item['PhotoNumber'], int)
            assert item['PhotoType'] in ["Photo", "Map", "FloorPlan", "SiteMap", "AerialPhoto"]
            assert isinstance(item['Property'], str)
            assert isinstance(item['Room'], str) or item['Room'] is None
        
    except JSONDecodeError:
        # If JSON decoding fails, print error message
        print(f"Failed to parse JSON response: {response.text}")
        assert False