# -*- coding: utf-8 -*-

"""Test module for /skills/{id}/related_jobs endpoint."""

import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_related_jobs():
    """Tests retrieving a collection of jobs associated with a specified skill."""
    
    # Define the path parameter id
    id = "example_skill_uuid"
    
    # Construct the full URL by joining the base URL and path
    url = urljoin(BASE_URL, f"/skills/{id}/related_jobs")
    
    # Send a GET request to the constructed URL
    response = requests.get(url)
    
    # Check if the request was successful (status code 200)
    assert response.status_code == 200
    
    # Parse the JSON response content
    data = response.json()
    
    # Assert that the response conforms to the expected schema
    assert isinstance(data["skill_name"], str)
    assert isinstance(data["skill_uuid"], str)
    assert isinstance(data["normalized_job_title"], str)
    assert all(isinstance(job, dict) for job in data["jobs"])
    assert all(all(key in job for key in ["importance", "job_title", "job_uuid", "level", "normalized_job_title"]) 
               for job in data["jobs"])

def test_unexpected_error():
    """Tests unexpected error scenario."""
    
    # Define a non-existent path parameter id
    id = "non_existent_skill_uuid"
    
    # Construct the full URL by joining the base URL and path
    url = urljoin(BASE_URL, f"/skills/{id}/related_jobs")
    
    # Send a GET request to the constructed URL
    response = requests.get(url)
    
    # Check if the request was unsuccessful (status code other than 200)
    assert response.status_code != 200
    
    # Parse the JSON response content
    data = response.json()
    
    # Assert that the response conforms to the expected Error schema
    assert isinstance(data["code"], int)
    assert isinstance(data["message"], str)

if __name__ == "__main__":
    pytest.main([__file__])