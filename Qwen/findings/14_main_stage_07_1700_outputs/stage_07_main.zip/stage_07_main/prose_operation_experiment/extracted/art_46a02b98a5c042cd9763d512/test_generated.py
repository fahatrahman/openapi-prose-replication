import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_gateway():
    headers = {
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Date": "20230401T123456Z",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20230401/us-east-1/execute-api/aws4_request",
        "X-Amz-Security-Token": "EXAMPLEKEY",
        "X-Amz-Signature": "EXAMPLESIGNATURE",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-algorithm;x-amz-credential;x-amz-security-token"
    }
    url = f"{BASE_URL}/v1/gateways/example-gateway-arn"
    response = requests.delete(url, headers=headers)
    
    assert response.status_code == 200
    assert "gatewayArn" in response.json()
    assert response.json()["gatewayArn"] == "example-gateway-arn"