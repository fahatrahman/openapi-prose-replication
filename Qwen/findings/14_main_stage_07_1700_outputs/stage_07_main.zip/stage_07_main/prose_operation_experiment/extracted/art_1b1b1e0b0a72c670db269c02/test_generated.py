import pytest
import requests

BASE_URL = "http://openapi.test"

def get_integration_branding(platform_key):
    url = f"{BASE_URL}/config/integrations/{platform_key}/branding"
    headers = {
        "Authorization": "Basic <your_api_key>"
    }
    response = requests.get(url, headers=headers)
    return response.json()

def test_get_integration_branding():
    platform_key = "<example_platform_key>"
    branding = get_integration_branding(platform_key)
    assert isinstance(branding, dict)
    assert "logo" in branding
    assert "full" in branding["logo"]
    assert "image" in branding["logo"]["full"]
    assert "alt" in branding["logo"]["full"]["image"]
    assert "src" in branding["logo"]["full"]["image"]

if __name__ == "__main__":
    pytest.main()