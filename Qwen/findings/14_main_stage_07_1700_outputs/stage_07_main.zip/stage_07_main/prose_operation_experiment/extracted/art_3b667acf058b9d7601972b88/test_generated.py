import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_instance_size_success():
    slug = "basic-xxs"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer $DIGITALOCEAN_TOKEN"
    }
    response = requests.get(f"{BASE_URL}/v2/apps/tiers/instance_sizes/{slug}", headers=headers)
    assert response.status_code == 200
    assert response.json()["instance_size"]["slug"] == slug

def test_get_instance_size_not_found():
    slug = "nonexistent-slug"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer $DIGITALOCEAN_TOKEN"
    }
    response = requests.get(f"{BASE_URL}/v2/apps/tiers/instance_sizes/{slug}", headers=headers)
    assert response.status_code == 404
    assert response.json()["id"] == "not_found"

def test_get_instance_size_unauthorized():
    slug = "basic-xxs"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer invalid_token"
    }
    response = requests.get(f"{BASE_URL}/v2/apps/tiers/instance_sizes/{slug}", headers=headers)
    assert response.status_code == 401
    assert response.json()["id"] == "unauthorized"

def test_get_instance_size_rate_limit_exceeded():
    slug = "basic-xxs"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer $DIGITALOCEAN_TOKEN"
    }
    for _ in range(10):
        response = requests.get(f"{BASE_URL}/v2/apps/tiers/instance_sizes/{slug}", headers=headers)
        assert response.status_code == 429
        assert response.json()["id"] == "too_many_requests"