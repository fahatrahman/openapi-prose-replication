import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_trials():
    url = f"{BASE_URL}/v1beta1/zynntaco/autfnhu/yzvrewumc/vmdixebo/qrevxpm/eromb/trials"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token_here",
        "alt": "json",
        "fields": "*",
        "key": "your_api_key_here",
        "oauth_token": "your_oauth_token_here",
        "prettyPrint": False,
        "quotaUser": "your_quota_user_here",
        "uploadType": "multipart/form-data",
        "upload_protocol": "raw",
        "pageSize": 10,
        "pageToken": ""
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "nextPageToken" in data
    assert "trials" in data
    trials = data["trials"]
    assert isinstance(trials, list)
    if trials:
        trial = trials[0]
        assert "clientId" in trial
        assert "customJob" in trial
        assert "endTime" in trial
        assert "finalMeasurement" in trial
        assert "id" in trial
        assert "infeasibleReason" in trial
        assert "measurements" in trial
        assert "name" in trial
        assert "parameters" in trial
        assert "startTime" in trial
        assert "state" in trial
        assert "webAccessUris" in trial
        measurement = trial["finalMeasurement"]
        assert "elapsedDuration" in measurement
        assert "metrics" in measurement
        assert "stepCount" in measurement
        metrics = measurement["metrics"]
        assert isinstance(metrics, list)
        if metrics:
            metric = metrics[0]
            assert "metricId" in metric
            assert "value" in metric
        parameters = trial["parameters"]
        assert isinstance(parameters, list)
        if parameters:
            parameter = parameters[0]
            assert "parameterId" in parameter
            assert "value" in parameter