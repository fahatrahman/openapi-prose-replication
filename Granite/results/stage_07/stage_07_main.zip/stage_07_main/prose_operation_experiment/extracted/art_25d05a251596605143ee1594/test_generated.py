import os
import pytest
import requests
from googleapiclient.discovery import build

BASE_URL = "http://openapi.test"

@pytest.fixture
def directory_service():
    credentials = ('YOUR_CREDENTIALS') # Replace with your actual credentials
    api_service_name = 'admin'
    api_version = 'directory_v1'
    service = build(api_service_name, api_version, credentials=credentials)
    return service

def test_update_group(directory_service):
    group_key = 'your_group_key'  # Replace with your actual group key
    group_data = {
        'name': 'Updated Group Name',
        'description': 'This is an updated group.'
    }

    try:
        updated_group = directory_service.groups().patch(groupKey=group_key, body=group_data).execute()
        assert updated_group['name'] == group_data['name']
        assert updated_group['description'] == group_data['description']
        print("Test passed: Group updated successfully.")
    except requests.exceptions.HTTPError as e:
        print(f"Test failed: HTTP Error - {e}")
    except Exception as e:
        print(f"Test failed: An unexpected error occurred - {e}")