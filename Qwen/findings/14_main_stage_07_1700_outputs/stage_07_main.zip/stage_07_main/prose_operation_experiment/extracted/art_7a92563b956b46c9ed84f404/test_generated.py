import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_certs():
    url = f"{BASE_URL}/api/v2/AftermarketServices/Certificates"
    response = requests.get(url)
    
    if response.status_code == 200:
        assert isinstance(response.json(), dict), "Response should be JSON object"
    else:
        api_error = response.json()
        assert isinstance(api_error, dict) and 'ErrorCode' in api_error, "API error response should contain ErrorCode"
        assert isinstance(api_error['ErrorCode'], int), "ErrorCode should be an integer"
        assert 'UserMessage' in api_error, "API error response should contain UserMessage"
        assert isinstance(api_error['UserMessage'], str), "UserMessage should be a string"

if __name__ == "__main__":
    pytest.main()