import pytest
import requests

BASE_URL = "http://openapi.test"

def test_update_transfer_instrument():
    url = f"{BASE_URL}/transferInstruments/LE00000000000000000000001"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Basic Auth Credentials",  # Replace with actual credentials
        "X-API-Key": "Your API Key",  # Replace with actual key
        "x-requested-verification-code": "0_0001"
    }
    payload = {
        "bankAccount": {
            "currencyCode": "EUR",
            "iban": "NL02ABNA0123456789"
        },
        "legalEntityId": "LE00000000000000000000001",
        "type": "bankAccount"
    }

    response = requests.patch(url, headers=headers, json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["bankAccount"]["countryCode"] == "NL"
    assert data["bankAccount"]["currencyCode"] == "EUR"
    assert data["bankAccount"]["iban"] == "NL02ABNA0123456789"
    assert data["id"] == "SE576BH223222F5GJVKHH6BDT"
    assert data["legalEntityId"] == "LE00000000000000000000001"
    assert data["type"] == "bankAccount"

def test_update_transfer_instrument_bad_request():
    url = f"{BASE_URL}/transferInstruments/LE00000000000000000000001"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Basic Auth Credentials",  # Replace with actual credentials
        "X-API-Key": "Your API Key",  # Replace with actual key
        "x-requested-verification-code": "0_0001"
    }
    payload = {
        "bankAccount": {
            "currencyCode": "USD"
        },
        "legalEntityId": "Invalid ID",
        "type": "invalid-type"
    }

    response = requests.patch(url, headers=headers, json=payload)
    assert response.status_code == 422
    data = response.json()
    assert isinstance(data, dict)
    assert "errorCode" in data
    assert "errorType" in data
    assert "message" in data
    assert "pspReference" in data
    assert "status" in data

def test_update_transfer_instrument_unauthorized():
    url = f"{BASE_URL}/transferInstruments/LE00000000000000000000001"
    headers = {
        "Content-Type": "application/json",
        "X-API-Key": "Invalid API Key"
    }
    payload = {
        "bankAccount": {
            "currencyCode": "EUR",
            "iban": "NL02ABNA0123456789"
        },
        "legalEntityId": "LE00000000000000000000001",
        "type": "bankAccount"
    }

    response = requests.patch(url, headers=headers, json=payload)
    assert response.status_code == 401
    data = response.json()
    assert isinstance(data, dict)
    assert "errorCode" in data
    assert "errorType" in data
    assert "message" in data
    assert "pspReference" in data
    assert "status" in data

def test_update_transfer_instrument_forbidden():
    url = f"{BASE_URL}/transferInstruments/LE00000000000000000000001"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Basic Auth Credentials",  # Replace with actual credentials
        "X-API-Key": "Your API Key",  # Replace with actual key
        "x-requested-verification-code": ""
    }
    payload = {
        "bankAccount": {
            "currencyCode": "EUR",
            "iban": "NL02ABNA0123456789"
        },
        "legalEntityId": "LE00000000000000000000001",
        "type": "bankAccount"
    }

    response = requests.patch(url, headers=headers, json=payload)
    assert response.status_code == 403
    data = response.json()
    assert isinstance(data, dict)
    assert "errorCode" in data
    assert "errorType" in data
    assert "message" in data
    assert "pspReference" in data
    assert "status" in data

def test_update_transfer_instrument_internal_server_error():
    url = f"{BASE_URL}/transferInstruments/LE00000000000000000000001"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Basic Auth Credentials",  # Replace with actual credentials
        "X-API-Key": "Your API Key",  # Replace with actual key
        "x-requested-verification-code": "0_0001"
    }
    payload = {
        "bankAccount": {
            "currencyCode": "EUR",
            "iban": "Invalid IBAN"
        },
        "legalEntityId": "LE00000000000000000000001",
        "type": "bankAccount"
    }

    response = requests.patch(url, headers=headers, json=payload)
    assert response.status_code == 500
    data = response.json()
    assert isinstance(data, dict)
    assert "errorCode" in data
    assert "errorType" in data
    assert "message" in data
    assert "pspReference" in data
    assert "status" in data