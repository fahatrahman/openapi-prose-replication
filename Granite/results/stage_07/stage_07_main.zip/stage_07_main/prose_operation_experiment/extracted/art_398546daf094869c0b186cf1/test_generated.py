import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["GET", "OPTIONS"],
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

def test_get_employee_secrets():
    employer_id = "GD001"
    employee_id = "CT001"
    authorization = "Auto"
    api_version = "default"

    url = f"{BASE_URL}/Employer/{employer_id}/Employee/{employee_id}/Secrets"

    headers = {
        "Authorization": authorization,
        "Api-Version": api_version,
    }

    response = SESSION.get(url, headers=headers)

    assert response.status_code == 200, response.text

    response_data = response.json()
    # Add assertions based on the expected LinkCollection schema here.
    assert isinstance(response_data, dict) and "Links" in response_data

    if response.status_code != 200:
        error_model = response.json()
        assert isinstance(error_model, dict), "Invalid error model format"
        assert "Description" in error_model
        assert "ErrorCategory" in error_model["Errors"][0]