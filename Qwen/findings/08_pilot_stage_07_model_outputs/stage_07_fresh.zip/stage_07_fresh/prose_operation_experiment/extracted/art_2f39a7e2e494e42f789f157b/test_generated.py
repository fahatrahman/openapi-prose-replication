import pytest
import requests

BASE_URL = "http://openapi.test"

def test_update_domain_mapping():
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    url = f"{BASE_URL}/v1beta/apps/your-app-id/domainMappings/your-domain.com"
    payload = {
        "sslSettings": {
            "sslManagementType": "MANUAL",
            "certificateId": "your-certificate-id"
        },
        "updateMask": "sslSettings.certificateId"
    }
    response = requests.patch(url, json=payload, headers=headers)
    assert response.status_code == 200
    assert response.json().get("name")
    assert response.json().get("done") is False