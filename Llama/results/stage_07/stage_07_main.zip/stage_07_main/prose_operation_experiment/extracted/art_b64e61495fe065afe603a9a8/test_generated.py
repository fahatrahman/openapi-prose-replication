# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_transaction_category():
    url = f"{BASE_URL}/companies/{'8a210b68-6988-11ed-a1eb-0242ac120002'}/connections/{'2e9d2c44-f675-40ba-8049-353bfcb5e171'}"
    headers = {"Authorization": "Basic YOUR_API_KEY_BASE64_ENCODED"}
    
    response = requests.get(f"{url}/banking-transactionCategories/auto-and-transport", headers=headers)
    assert response.status_code == 200
    
    data = response.json()
    assert data["hasChildren"]
    assert data["id"] == "auto-and-transport"
    assert data["name"] == "Auto & Transport"
    assert data["modifiedDate"] == "2022-05-23T16:32:50"
    assert data["sourceModifiedDate"] == "2021-04-24T07:59:10"
    assert data["status"] == "Active"