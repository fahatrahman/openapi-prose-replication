import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.error import HTTPError

BASE_URL = "http://openapi.test"

# Create session with retry functionality
session = requests.Session()
retry = True
while retry:
    try:
        session.mount("https://", HTTPAdapter(max_retries=5))
        retry = False
    except (HTTPError, ConnectionError):
        pass

@pytest.fixture
def header():
    """Get the access token."""
    auth = input("Enter your access token: ")
    headers = {"Authorization": f"Bearer {auth}"}
    return headers

def test_ship_scan(header):
    """Test ship scanning endpoint."""
    ship_symbol = "example_ship_symbol"
    url = f"{BASE_URL}/my/ships/{ship_symbol}/scan/ships"

    response = session.post(url, json={}, headers=header)

    assert response.status_code == 201
    data = response.json()["data"]
    assert "ships" in data
    assert "cooldown" in data