import pytest
import requests

BASE_URL = "http://openapi.test"

def test_analyze_move():
    url = f"{BASE_URL}/v1/resource:analyzeMove"
    params = {
        "resource": "resource",
        "view": "FULL",
        "destinationParent": "destinationParent"
    }
    headers = {}
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    response_json = response.json()
    assert isinstance(response_json, dict)
    assert 'moveAnalysis' in response_json.keys()

def test_analyze_move_with_security():
    # Oauth2 token is required for this test
    url = f"{BASE_URL}/v1/resource:analyzeMove"
    params = {
        "resource": "resource",
        "view": "FULL",
        "destinationParent": "destinationParent"
    }
    headers = {
        "Authorization": "Bearer YOUR_OAUTH_TOKEN"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    response_json = response.json()
    assert isinstance(response_json, dict)
    assert 'moveAnalysis' in response_json.keys()

# To run tests with security, you need to replace YOUR_OAUTH_TOKEN with actual OAuth token
# You can get OAuth token using Google OAuth client library or other methods
# For example, you can use google-auth library to get OAuth token
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request

def get_oauth_token():
    creds = None
    if creds and creds.valid:
        return creds.token
    if creds and creds.expired and creds.refresh_token:
        creds.refresh(Request())
    return creds.token

test_analyze_move_with_security = test_analyze_move_with_security
test_analyze_move_with_security.__name__ = "test_analyze_move_with_security"
test_analyze_move_with_security.get_oauth_token = get_oauth_token