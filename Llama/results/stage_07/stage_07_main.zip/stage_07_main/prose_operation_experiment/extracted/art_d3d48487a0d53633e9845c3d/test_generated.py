import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_list_user_workloads_secrets():
    parent = "projects/my-project/locations/my-location/environments/my-environment"
    params = {
        "key": "my-api-key",
        "page_size": 10,
        "page_token": None,
        "$.xgafv": "1"
    }
    headers = {"Content-Type": "application/json"}

    response = requests.get(
        urljoin(BASE_URL, f"/v1beta1/{parent}/userWorkloadsSecrets"),
        params=params,
        headers=headers
    )

    assert response.status_code == 200
    assert isinstance(response.json(), dict)