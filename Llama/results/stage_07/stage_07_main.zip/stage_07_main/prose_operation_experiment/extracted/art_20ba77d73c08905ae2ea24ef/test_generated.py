# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_category():
    """Test GET /providernetworks/{providernetworkUID}/categories/{categoryUID}"""
    
    # Define the path parameters
    providernetwork_uid = "example_providernetwork_UID"
    category_uid = "example_category_UID"
    
    # Construct the full URL
    url = f"{BASE_URL}/providernetworks/{providernetwork_uid}/categories/{category_uid}"
    
    # Define the query parameter (if present)
    params = {}
    if True:
        expand = "example_expand"
        params["expand"] = expand
    
    # Send the GET request
    response = requests.get(url, params=params)
    
    # Check the status code
    assert response.status_code == 200
    
    # Check the content type
    assert response.headers["Content-Type"] == "application/json"
    
    # Parse the JSON response
    json_response = response.json()
    
    # Check that the response conforms to the expected schema
    assert json_response["_links"]
    assert json_response["attributes"]
    assert json_response["description"]
    assert json_response["expand"]
    assert json_response["href"]
    assert json_response["name"]
    assert json_response["price"]
    assert json_response["uid"]

def test_get_category_invalid_providernetwork_uid():
    """Test GET /providernetworks/{providernetworkUID}/categories/{categoryUID} with invalid providernetwork_uid"""
    
    # Define the path parameters
    providernetwork_uid = ""
    category_uid = "example_category_UID"
    
    # Construct the full URL
    url = f"{BASE_URL}/providernetworks/{providernetwork_uid}/categories/{category_uid}"
    
    # Send the GET request
    response = requests.get(url)
    
    # Check the status code
    assert response.status_code == 400
    
    # Check the content type
    assert response.headers["Content-Type"] == "application/json"
    
    # Parse the JSON response
    json_response = response.json()
    
    # Check that the response conforms to the expected schema
    assert json_response["name"]
    assert json_response["level"] in ["INFO", "WARNING", "ERROR"]
    assert json_response["message"]
    assert json_response["code"] >= 0

def test_get_category_forbidden():
    """Test GET /providernetworks/{providernetworkUID}/categories/{categoryUID} with forbidden access"""
    
    # Define the path parameters
    providernetwork_uid = "example_providernetwork_UID"
    category_uid = "example_category_UID"
    
    # Construct the full URL
    url = f"{BASE_URL}/providernetworks/{providernetwork_uid}/categories/{category_uid}"
    
    # Simulate forbidden access by setting a random user agent
    headers = {"User-Agent": "random_user_agent"}
    
    # Send the GET request
    response = requests.get(url, headers=headers)
    
    # Check the status code
    assert response.status_code == 403
    
    # Check the content type
    assert response.headers["Content-Type"] == "application/json"
    
    # Parse the JSON response
    json_response = response.json()
    
    # Check that the response conforms to the expected schema
    assert json_response["name"]
    assert json_response["level"] in ["INFO", "WARNING", "ERROR"]
    assert json_response["message"]
    assert json_response["code"] >= 0