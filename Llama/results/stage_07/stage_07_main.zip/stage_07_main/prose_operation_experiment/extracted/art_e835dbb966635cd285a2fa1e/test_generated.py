# -*- coding: utf-8 -*-
"""
pytest module for testing Heartbeat API endpoint.

This module is generated based on the provided OpenAPI specification and
provides test cases for the GET /v0.5/heartbeat endpoint.
"""

import pytest
import requests
from datetime import datetime
from xml.etree import ElementTree as ET

BASE_URL = "http://openapi.test"

def get_heartbeat():
    """
    Send GET request to /v0.5/heartbeat endpoint.

    :return: Response object
    """
    return requests.get(f"{BASE_URL}/v0.5/heartbeat")

def parse_xml_response(response):
    """
    Parse XML response into a dictionary.

    :param response: Response object
    :return: Dictionary representation of the XML response
    """
    root = ET.fromstring(response.content)
    error = {}
    if root.find("error") is not None:
        error["code"] = int(root.find("error").find("code").text)
        error["message"] = root.find("error").find("message").text
    status = root.find("status").text
    timestamp = root.find("timestamp").text
    heartbeat_response = {
        "error": error,
        "status": status,
        "timestamp": timestamp
    }
    return heartbeat_response

class TestHeartbeatEndpoint:
    def test_get_heartbeat(self):
        """
        Test successful GET request to /v0.5/heartbeat endpoint.
        """
        response = get_heartbeat()
        assert response.status_code == 200
        if response.headers["Content-Type"] == "application/json":
            heartbeat_response = response.json()
            assert heartbeat_response["status"] in ["UP", "DOWN"]
            assert isinstance(heartbeat_response["timestamp"], str)
            assert heartbeat_response["timestamp"].startswith(datetime.now().strftime("%Y-%m-%dT%H:%M:%S"))
        elif response.headers["Content-Type"] == "application/xml":
            heartbeat_response = parse_xml_response(response)
            assert heartbeat_response["status"] in ["UP", "DOWN"]
            assert isinstance(heartbeat_response["timestamp"], str)
            assert heartbeat_response["timestamp"].startswith(datetime.now().strftime("%Y-%m-%dT%H:%M:%S"))

def test_invalid_request():
    """
    Test sending an invalid request to the /v0.5/heartbeat endpoint.
    """
    try:
        requests.post(BASE_URL + "/v0.5/heartbeat")
        pytest.fail("Expected POST request to fail")
    except requests.RequestException as e:
        assert True

if __name__ == "__main__":
    pytest.main([__file__])