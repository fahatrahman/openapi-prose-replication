import pytest
import requests

BASE_URL = "http://openapi.test"

def test_streetviewpublish_photo_sequence_get():
    sequence_id = "example_sequence_id"
    filter_param = "example_filter"
    view_param = "BASIC"
    
    url = f"{BASE_URL}/v1/photoSequence/{sequence_id}"
    params = {
        "_xgafv": "1",
        "access_token": "example_access_token",
        "alt": "json",
        "callback": "example_callback",
        "fields": "example_fields",
        "key": "example_key",
        "oauth_token": "example_oauth_token",
        "prettyPrint": True,
        "quotaUser": "example_quota_user",
        "uploadType": "multipart",
        "upload_protocol": "raw",
        "filter": filter_param,
        "view": view_param
    }
    
    headers = {
        "Authorization": "Bearer example_access_token"
    }
    
    response = requests.get(url, params=params, headers=headers)
    
    assert response.status_code == 200
    assert response.json()["kind"] == "streetViewPublish#photoSequence"