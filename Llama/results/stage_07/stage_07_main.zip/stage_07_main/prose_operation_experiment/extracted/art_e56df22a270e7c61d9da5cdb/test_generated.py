# -*- coding: utf-8 -*-
import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_global_images():
    url = f"{BASE_URL}/api/v2/GlobalImages"
    params = {
        "limit": 10,
        "offset": 0
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "Entities" in data
    assert "Metadata" in data
    assert "Limit" in data["Metadata"]
    assert "Offset" in data["Metadata"]
    assert "TotalCount" in data["Metadata"]

def test_get_global_images_with_search():
    url = f"{BASE_URL}/api/v2/GlobalImages"
    params = {
        "search": "test",
        "limit": 10,
        "offset": 0
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "Entities" in data
    assert "Metadata" in data
    assert "Limit" in data["Metadata"]
    assert "Offset" in data["Metadata"]
    assert "TotalCount" in data["Metadata"]

def test_get_global_images_with_category_id():
    url = f"{BASE_URL}/api/v2/GlobalImages"
    params = {
        "categoryId": "test",
        "limit": 10,
        "offset": 0
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "Entities" in data
    assert "Metadata" in data
    assert "Limit" in data["Metadata"]
    assert "Offset" in data["Metadata"]
    assert "TotalCount" in data["Metadata"]

def test_get_global_images_with_publisher():
    url = f"{BASE_URL}/api/v2/GlobalImages"
    params = {
        "publisher": "test",
        "limit": 10,
        "offset": 0
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "Entities" in data
    assert "Metadata" in data
    assert "Limit" in data["Metadata"]
    assert "Offset" in data["Metadata"]
    assert "TotalCount" in data["Metadata"]

def test_get_global_images_with_include_deleted():
    url = f"{BASE_URL}/api/v2/GlobalImages"
    params = {
        "includeDeleted": True,
        "limit": 10,
        "offset": 0
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "Entities" in data
    assert "Metadata" in data
    assert "Limit" in data["Metadata"]
    assert "Offset" in data["Metadata"]
    assert "TotalCount" in data["Metadata"]

def test_get_global_images_invalid_limit():
    url = f"{BASE_URL}/api/v2/GlobalImages"
    params = {
        "limit": -10,
        "offset": 0
    }
    response = requests.get(url, params=params)
    assert response.status_code != 200
    data = response.json()
    assert isinstance(data, dict)
    assert "ErrorCode" in data
    assert "UserMessage" in data

def test_get_global_images_invalid_offset():
    url = f"{BASE_URL}/api/v2/GlobalImages"
    params = {
        "limit": 10,
        "offset": -10
    }
    response = requests.get(url, params=params)
    assert response.status_code != 200
    data = response.json()
    assert isinstance(data, dict)
    assert "ErrorCode" in data
    assert "UserMessage" in data

def test_get_global_images_missing_limit():
    url = f"{BASE_URL}/api/v2/GlobalImages"
    params = {}
    response = requests.get(url, params=params)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "Entities" in data
    assert "Metadata" in data
    assert "Limit" in data["Metadata"]
    assert "Offset" in data["Metadata"]
    assert "TotalCount" in data["Metadata"]

def test_get_global_images_missing_offset():
    url = f"{BASE_URL}/api/v2/GlobalImages"
    params = {
        "limit": 10
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "Entities" in data
    assert "Metadata" in data
    assert "Limit" in data["Metadata"]
    assert "Offset" in data["Metadata"]
    assert "TotalCount" in data["Metadata"]