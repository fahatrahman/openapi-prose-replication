import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

def get_templates(query=None, parent_folder_id=None, page=1, per_page=50):
    url = f"{BASE_URL}/templates"
    params = {"query": query, "parent_folder_id": parent_folder_id, "page": page, "per_page": per_page}

    response = requests.get(url, auth=HTTPBasicAuth("Xyvylscj", "GNA Yiuso LR"), verify=False)

    if response.status_code == 200:
        return response.json()["templates"]
    elif response.status_code == 401:
        return {"error": "Unauthorized"}
    elif response.status_code == 404:
        return {"error": "Not Found"}
    else:
        return {"error": "Unexpected status code", "status": str(response.status_code)}

@pytest.mark.parametrize(
    "query, parent_folder_id, page, per_page, expected",
    [
        (
            None,
            None,
            1,
            50,
            [
                {
                    "allow_additional_properties": False,
                    "description": None,
                    "document_url": "/uploads/test/store/templates/test/test-document.pdf",
                    "editable_submissions": False,
                    "expiration_interval": "days",
                    "expire_after": 7,
                    "expire_submissions": True,
                    "id": "tpl_000000000000000011",
                    "locked": False,
                    "name": "Sub Template 1",
                    "page_count": 3,
                    "page_dimensions": [[612, 792], [792, 612], [612, 792]],
                    "parent_folder_id": "fld_000000000000000001",
                    "path": "/Folder",
                    "permanent_document_url": "http://app.docspring.local/templates/tpl_000000000000000011/original_pdf?token=123456789abcdef",
                    "public_submissions": False,
                    "public_web_form": False,
                    "redirect_url": None,
                    "slack_webhook_url": None,
                    "template_type": "pdf",
                    "webhook_url": None,
                },
                # Add other templates here...
            ],
        ),
    ],
)
def test_get_templates(query, parent_folder_id, page, per_page, expected):
    result = get_templates(query, parent_folder_id, page, per_page)
    assert result == expected