# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime
from typing import Dict, List

BASE_URL = "http://openapi.test"

def get_crash_groups(owner_name: str, app_name: str,
                     last_occurrence_from: str = None,
                     last_occurrence_to: str = None,
                     app_version: str = None,
                     group_type: str = None,
                     group_status: str = None,
                     group_text_search: str = None,
                     orderby: str = "last_occurrence desc",
                     continuation_token: str = None) -> Dict:
    params = {
        "owner_name": owner_name,
        "app_name": app_name,
        "last_occurrence_from": last_occurrence_from,
        "last_occurrence_to": last_occurrence_to,
        "app_version": app_version,
        "group_type": group_type,
        "group_status": group_status,
        "group_text_search": group_text_search,
        "orderby": orderby,
        "continuation_token": continuation_token
    }

    headers = {"X-API-Token": "your_api_key"}

    response = requests.get(f"{BASE_URL}/v0.1/apps/{owner_name}/{app_name}/crash_groups", params=params, headers=headers)

    assert response.status_code == 200, f"Unexpected status code: {response.status_code}"

    return response.json()

def test_get_crash_groups():
    # Test successful response
    response = get_crash_groups("test_owner", "test_app")
    assert isinstance(response["crash_groups"], list), f"Expected crash_groups to be a list, got {type(response['crash_groups'])}"
    assert response["limited_result_set"] is False, f"Expected limited_result_set to be false, got {response['limited_result_set']}"

    # Test error handling
    with pytest.raises(AssertionError):
        get_crash_groups("invalid_owner")

if __name__ == "__main__":
    pytest.main([__file__, "-vv"])