import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def maintenance_issue():
    return {
        "Documents": [
            {
                "MimeType": "image/png",
                "URL": "http://example.com/document.png"
            }
        ],
        "ExternalID": "12345",
        "IssueFault": "Some fault",
        "IssueNotes": "Some notes",
        "IssuePriority": "Medium",
        "IssueTitle": "Maintenance Issue",
        "PropertyAddress1": "123 Main St",
        "PropertyAddress2": "",
        "PropertyAddress3": "",
        "PropertyAddress4": "",
        "PropertyCountry": "US",
        "PropertyPostcode": "12345",
        "ReportedAt": "2023-04-01T12:00:00Z",
        "TenantEMailAddress": "tenant@example.com",
        "TenantForename": "John",
        "TenantPhonePrimary": "123-456-7890",
        "TenantPhoneSecondary": "",
        "TenantPresenceRequested": False,
        "TenantSurname": "Doe",
        "TenantTitle": ""
    }

def test_create_maintenance_job(maintenance_issue):
    url = f"{BASE_URL}/v3/maintenance/shortName/maintenance/branchID/createmaintenancejob"
    response = requests.post(url, json=maintenance_issue)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()