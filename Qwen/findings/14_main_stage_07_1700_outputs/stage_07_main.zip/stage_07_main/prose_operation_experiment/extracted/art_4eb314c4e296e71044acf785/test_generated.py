import pytest
import requests

BASE_URL = "http://openapi.test"

def get_deployments_for_all_apps(org_id):
    url = f"{BASE_URL}/organisations/{org_id}/deployments"
    response = requests.get(url)
    response.raise_for_status()
    return response.json()

@pytest.mark.parametrize("org_id", ["test_org_1", "test_org_2"])
def test_get_deployments_for_all_apps(org_id):
    deployments = get_deployments_for_all_apps(org_id)
    assert isinstance(deployments, dict)
    assert "app_id" in deployments
    assert isinstance(deployments["app_id"], list)
    for deployment_view in deployments["app_id"]:
        assert isinstance(deployment_view, dict)
        required_fields = [
            "action",
            "author",
            "cause",
            "commit",
            "date",
            "id",
            "instances",
            "state",
            "uuid"
        ]
        for field in required_fields:
            assert field in deployment_view
        assert isinstance(deployment_view["author"], dict)
        author_required_fields = ["id", "name"]
        for field in author_required_fields:
            assert field in deployment_view["author"]
        assert isinstance(deployment_view["date"], str)
        assert isinstance(deployment_view["id"], int)
        assert isinstance(deployment_view["instances"], int)
        assert isinstance(deployment_view["uuid"], str)

if __name__ == "__main__":
    pytest.main()