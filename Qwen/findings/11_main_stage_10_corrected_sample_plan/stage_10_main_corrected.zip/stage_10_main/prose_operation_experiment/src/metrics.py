from __future__ import annotations


PRIMARY_ENDPOINTS = (
    "collection_success",
    "baseline_pass",
    "request_intent_match",
    "selected_scenario_coverage",
    "supported_assertion_score",
    "effective_requirement_check_coverage",
    "unconditional_response_fault_detection",
)


def metric_record(
    endpoint,
    numerator,
    denominator,
    failure_reason=None,
    zero_credit=False,
):
    observed = (
        denominator > 0
        or zero_credit
    )

    if denominator > 0:
        score = numerator / denominator
    elif zero_credit:
        score = 0.0
    else:
        score = None

    return {
        "endpoint": endpoint,
        "numerator": numerator,
        "denominator": denominator,
        "score": score,
        "observed": observed,
        "literal_denominator_observed": (
            denominator > 0
        ),
        "failure_reason": failure_reason,
        "estimand_type": (
            "common_evaluable_pairs"
            if endpoint == "request_intent_match"
            else "full_population"
        ),
    }


def score_operation_condition(
    evidence,
    oracle,
):
    """
    Calculate scores using execution evidence and frozen oracles.

    The evaluator must not inspect the generated task's
    L0/L1 condition when judging correctness.
    """

    if evidence.get("evaluator_error"):
        raise RuntimeError(
            "Evaluator failure cannot be scored "
            "as a generated-model failure."
        )

    scenario_ids = {
        row["scenario_id"]
        for row in oracle["scenarios"]
        if row.get("applicability")
        == "APPLICABLE"
    }

    requirement_ids = {
        row["requirement_id"]
        for row in oracle["requirements"]
        if row.get("applicability")
        == "APPLICABLE"
    }

    fault_ids = {
        row["fault_id"]
        for row in oracle["faults"]
        if (
            row.get("applicable", True)
            and row.get(
                "applicability",
                "APPLICABLE",
            ) == "APPLICABLE"
        )
    }

    if not (
        scenario_ids
        and requirement_ids
        and fault_ids
        and oracle.get("baselines")
    ):
        raise ValueError(
            "Zero frozen oracle denominator."
        )

    collection_success = (
        evidence.get("collection_status")
        == "PASS"
        and int(
            evidence.get("collected_items")
            or 0
        ) > 0
    )

    item_outcomes = evidence.get(
        "item_outcomes",
        [],
    )

    has_normal_pass = (
        "passed" in item_outcomes
    )

    no_unexpected_outcomes = (
        bool(item_outcomes)
        and all(
            outcome in (
                "passed",
                "skipped",
                "xfailed",
            )
            for outcome in item_outcomes
        )
    )

    baseline_pass = (
        collection_success
        and evidence.get("baseline_status")
        == "COMPLETE"
        and has_normal_pass
        and no_unexpected_outcomes
    )

    requests = evidence.get(
        "request_attempts",
        [],
    )

    distinct_attempts = {
        row["attempt_id"]: row
        for row in requests
        if row.get("attempt_id")
    }

    classifiable = [
        row
        for row in distinct_attempts.values()
        if row.get("classifiable") is True
    ]

    matching = [
        row
        for row in classifiable
        if row.get("matched_intent") is True
    ]

    exercised_scenarios = {
        row["scenario_id"]
        for row in distinct_attempts.values()
        if row.get("scenario_id")
        in scenario_ids
    }

    reviewed_claims = [
        row
        for row in evidence.get(
            "reviewed_claims",
            [],
        )
        if row.get("reviewed") is True
    ]

    supported_claims = [
        row
        for row in reviewed_claims
        if row.get("supported") is True
    ]

    checked_requirements = {
        row["requirement_id"]
        for row in evidence.get(
            "effective_checks",
            [],
        )
        if (
            row.get("requirement_id")
            in requirement_ids
            and row.get("reached") is True
            and row.get("grounded") is True
            and row.get("linkage_qualified")
            is True
        )
    }

    killed_faults = {
        row["fault_id"]
        for row in evidence.get(
            "mutation_results",
            [],
        )
        if (
            row.get("fault_id") in fault_ids
            and row.get("result") == "KILLED"
            and row.get("consumed") is True
            and baseline_pass
        )
    }

    results = [
        metric_record(
            "collection_success",
            int(collection_success),
            1,
            evidence.get(
                "collection_failure_reason"
            ),
        ),
        metric_record(
            "baseline_pass",
            int(baseline_pass),
            1,
            evidence.get(
                "baseline_failure_reason"
            ),
        ),
        metric_record(
            "request_intent_match",
            len(matching),
            len(classifiable),
            (
                "NO_CLASSIFIABLE_REQUESTS"
                if not classifiable
                else None
            ),
        ),
        metric_record(
            "selected_scenario_coverage",
            len(exercised_scenarios),
            len(scenario_ids),
        ),
        metric_record(
            "supported_assertion_score",
            len(supported_claims),
            len(reviewed_claims),
            (
                "NO_USABLE_CLAIMS"
                if not reviewed_claims
                else None
            ),
            zero_credit=True,
        ),
        metric_record(
            "effective_requirement_check_coverage",
            len(checked_requirements),
            len(requirement_ids),
        ),
        metric_record(
            "unconditional_response_fault_detection",
            len(killed_faults),
            len(fault_ids),
        ),
    ]

    unavailable = dict(evidence.get("unavailable_endpoints") or {})
    if evidence.get("collection_status") == "EVALUATOR_UNAVAILABLE":
        unavailable.update({name: "COLLECTION_EVALUATOR_UNAVAILABLE"
                            for name in PRIMARY_ENDPOINTS if name not in unavailable})
    elif evidence.get("baseline_status") == "EVALUATOR_UNAVAILABLE":
        for name in PRIMARY_ENDPOINTS:
            if name != "collection_success":
                unavailable.setdefault(name, "BASELINE_EVALUATOR_UNAVAILABLE")
    if any(not reason or name not in PRIMARY_ENDPOINTS
           for name, reason in unavailable.items()):
        raise ValueError("Invalid endpoint unavailability evidence")
    for row in results:
        if row["endpoint"] in unavailable:
            row.update(numerator=None, score=None, observed=False,
                       literal_denominator_observed=False,
                       failure_reason=unavailable[row["endpoint"]])
    return results


def paired_metric_differences(
    l0_scores,
    l1_scores,
):
    l0 = {
        row["endpoint"]: row
        for row in l0_scores
    }

    l1 = {
        row["endpoint"]: row
        for row in l1_scores
    }

    if (
        set(l0) != set(PRIMARY_ENDPOINTS)
        or set(l1) != set(PRIMARY_ENDPOINTS)
    ):
        raise ValueError(
            "Incomplete seven-endpoint score vectors."
        )

    differences = {}

    for endpoint in PRIMARY_ENDPOINTS:
        left = l0[endpoint]["score"]
        right = l1[endpoint]["score"]

        differences[endpoint] = (
            None
            if left is None or right is None
            else right - left
        )

    return differences
