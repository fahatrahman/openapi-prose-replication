import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_txs():
    params = {
        "address": "your_address_here",
        "block": "your_block_hash_here",
        "pageNum": 1
    }
    response = requests.get(f"{BASE_URL}/ins/txs", params=params)
    assert response.status_code == 200
    data = response.json()
    assert "pagesTotal" in data
    assert "txs" in data
    assert isinstance(data["pagesTotal"], int)
    assert isinstance(data["txs"], list)
    for tx in data["txs"]:
        assert "blockhash" in tx
        assert "blockheight" in tx
        assert "blocktime" in tx
        assert "confirmations" in tx
        assert "fee" in tx
        assert "fees" in tx
        assert "locktime" in tx
        assert "size" in tx
        assert "time" in tx
        assert "totalsent" in tx
        assert "txid" in tx
        assert "valueIn" in tx
        assert "valueOut" in tx
        assert "version" in tx
        assert "vin" in tx
        assert "vout" in tx

if __name__ == "__main__":
    pytest.main()