import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_server():
    server_id = 42  # Example server ID
    url = f"{BASE_URL}/servers/{server_id}"
    
    response = requests.delete(url)
    
    assert response.status_code == 200
    assert 'action' in response.json()
    action = response.json()['action']
    assert 'command' in action
    assert action['command'] == 'start_server'
    assert 'status' in action
    assert action['status'] in ['success', 'running', 'error']
    assert 'progress' in action
    assert isinstance(action['progress'], float) or action['progress'] is None
    assert 'started' in action
    assert 'finished' in action
    assert 'resources' in action
    assert isinstance(action['resources'], list)
    for resource in action['resources']:
        assert 'id' in resource
        assert 'type' in resource
    assert 'error' in action
    if action['error']:
        error = action['error']
        assert 'code' in error
        assert 'message' in error

if __name__ == "__main__":
    pytest.main()