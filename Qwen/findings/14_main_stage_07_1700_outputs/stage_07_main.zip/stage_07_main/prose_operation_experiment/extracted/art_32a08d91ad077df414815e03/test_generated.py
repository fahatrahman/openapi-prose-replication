import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_operations():
    url = f"{BASE_URL}/v1/projects/locations/vmwareClusters/vmwareNodePools/operations"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token",
        "alt": "json",
        "fields": "nextPageToken,operations(name,status(done,response))",
        "key": "your_api_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": False,
        "quotaUser": "user@example.com",
        "uploadProtocol": "raw",
        "uploadType": "multipart/form-data",
        "name": "projects/locations/vmwareClusters/vmwareNodePools/operations",
        "filter": "status=RUNNING",
        "pageSize": 10,
        "pageToken": None
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    assert 'nextPageToken' in response.json()
    assert 'operations' in response.json()

if __name__ == "__main__":
    pytest.main()