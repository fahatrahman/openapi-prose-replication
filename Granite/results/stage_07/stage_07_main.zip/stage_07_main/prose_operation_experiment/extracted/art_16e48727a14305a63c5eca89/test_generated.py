import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Define custom session with retry strategy
session = requests.Session()
retry_strategy = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def get_deployments():
    def _get_deployments(org_id):
        url = f"{BASE_URL}/organisations/{org_id}/deployments"
        response = session.get(url)
        response.raise_for_status()
        return response.json()

    return _get_deployments

def test_get_deployments(get_deployments):
    org_id = "your_organization_id"  # Replace this with actual organization ID
    deployments = get_deployments(org_id)

    assert isinstance(deployments, dict), "Response should be in JSON format"
    assert all(key == app_id for app_id, deployments_view in deployments.items()), \
        "Response should contain 'app_id' as key"

    for deployments_view in deployments.values():
        assert set(deployments_view.keys()) == {"instances", "state", "uuid", "date", "action", "author", "commit", "id"}, \
            "DeploymentView schema mismatch"

        assert isinstance(deployments_view["instances"], int), "Instances should be an integer"
        assert isinstance(deployments_view["state"], str), "State should be a string"
        assert isinstance(deployments_view["uuid"], str), "UUID should be a string"
        assert isinstance(deployments_view["date"], str), "Date should be a string in ISO format"

        author = deployments_view["author"]
        assert isinstance(author, dict), "Author should be a dictionary"
        assert "id" in author and "name" in author, "Author should have 'id' and 'name'"
        assert isinstance(author["id"], str), "'id' in author should be a string"
        assert isinstance(author["name"], str), "'name' in author should be a string"

        assert isinstance(deployments_view["action"], str), "Action should be a string"
        assert isinstance(deployments_view["cause"], str), "Cause should be a string"
        assert isinstance(deployments_view["commit"], str), "Commit should be a string"
        assert isinstance(deployments_view["id"], int), "ID should be an integer"