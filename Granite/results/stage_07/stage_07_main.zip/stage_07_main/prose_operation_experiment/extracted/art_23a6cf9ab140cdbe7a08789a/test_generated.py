import os
import json
import pytest
from requests import Request, Session
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="function")
def setup():
    headers = {
        "Content-Type": "application/json",
    }

    # Define the request body
    export_devices_request = {
        "ExportBlobContainerUri": "<your_export_blob_container_uri>",
        "ExcludeKeys": True,
    }

    # Create a session to persist certain parameters across requests
    session = Session()

    # Prepare the request
    url = urljoin(BASE_URL, "/subscriptions/<subscription_id>/resourceGroups/<resource_group_name>/providers/Microsoft.Devices/IotHubs/<iot_hub_name>/exportDevices")
    req = Request("POST", url, headers=headers, json=export_devices_request)
    prepared_request = session.prepare_request(req)

    return session, prepared_request

def test_export_devices(setup):
    session, prepared_request = setup

    try:
        response = session.send(prepared_request)

        response.raise_for_status()

        result = response.json()
        
        assert response.status_code == 200
        assert isinstance(result, dict)
        assert 'jobId' in result
        assert 'status' in result and result['status'] == 'completed'
        
    except Session.HTTPError as e:
        assert e.response.status_code != 200
    except Exception as e:
        pytest.fail(f"Unexpected error: {str(e)}")