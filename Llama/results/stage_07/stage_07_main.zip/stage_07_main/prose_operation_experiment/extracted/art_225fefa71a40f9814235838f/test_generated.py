# pytest_openapi.py

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_ServicePrincipals_ListKeyCredentials():
    url = f"{BASE_URL}/{tenantID}/servicePrincipals/{objectId}/keyCredentials"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "api-version": "1.0",
    }
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    assert response.json()["@odata.context"] is None
    assert isinstance(response.json()["value"], list)

@pytest.fixture
def tenantID():
    return "some_tenant_id"

@pytest.fixture
def objectId():
    return "some_object_id"

@pytest.fixture
def access_token():
    # This would typically be obtained through authentication flow
    # For simplicity, we're just returning a hardcoded token
    return "some_access_token"