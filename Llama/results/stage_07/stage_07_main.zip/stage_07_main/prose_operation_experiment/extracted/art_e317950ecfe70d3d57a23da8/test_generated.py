import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_queues():
    url = f"{BASE_URL}/apps/my_app_id/queues"
    headers = {"Authorization": "Bearer my_token"}
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    for item in data:
        assert isinstance(item, dict)
        assert "id" in item
        assert "name" in item
        assert "state" in item
        assert "stats" in item
        stats = item["stats"]
        assert isinstance(stats, dict)
        assert "acknowledgementRate" not in stats or stats["acknowledgementRate"] is None
        assert "deliveryRate" not in stats or stats["deliveryRate"] is None
        assert "publishRate" not in stats or stats["publishRate"] is None

def test_list_queues_unauthorized():
    url = f"{BASE_URL}/apps/my_app_id/queues"
    response = requests.get(url)
    assert response.status_code == 401

def test_list_queues_not_found():
    url = f"{BASE_URL}/apps/non_existent_app_id/queues"
    headers = {"Authorization": "Bearer my_token"}
    response = requests.get(url, headers=headers)
    assert response.status_code == 404

def test_list_queues_internal_server_error():
    url = f"{BASE_URL}/apps/my_app_id/queues"
    headers = {"Authorization": "Bearer my_token", "X-Test-Header": "test-value"}
    response = requests.get(url, headers=headers)
    assert response.status_code == 500

def test_list_queues_service_unavailable():
    url = f"{BASE_URL}/apps/my_app_id/queues"
    headers = {"Authorization": "Bearer my_token"}
    response = requests.get(url, headers=headers, proxies={"http": "http://localhost:8000"})
    assert response.status_code == 503

def test_list_queues_gateway_timeout():
    url = f"{BASE_URL}/apps/my_app_id/queues"
    headers = {"Authorization": "Bearer my_token"}
    response = requests.get(url, headers=headers, timeout=0.01)
    assert response.status_code == 504