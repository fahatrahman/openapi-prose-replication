import pytest
import requests

BASE_URL = "http://openapi.test"

def test_write_tensorboard_run_data():
    url = f"{BASE_URL}/v1/zynntaco/{autfnhu}/yzvrewumc/{vmdixebo}/kpulllhsgiar/{hlrldkizwyp}/utxxqkwjmut/{cbmjguzrhu}/oqan/{pbb}:write"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "tensorboardRun": "zynntaco/{autfnhu}/yzvrewumc/{vmdixebo}/kpulllhsgiar/{hlrldkizwyp}/utxxqkwjmut/{cbmjguzrhu}/oqan/{pbb}",
        "timeSeriesData": [
            {
                "tensorboardTimeSeriesId": "example_time_series_id",
                "valueType": "SCALAR",
                "values": [
                    {
                        "scalar": {
                            "value": 1.0
                        },
                        "step": 1,
                        "wallTime": "2023-04-01T00:00:00Z"
                    }
                ]
            }
        ]
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 200
    assert "application/json" in response.headers["Content-Type"]
    assert isinstance(response.json(), dict)