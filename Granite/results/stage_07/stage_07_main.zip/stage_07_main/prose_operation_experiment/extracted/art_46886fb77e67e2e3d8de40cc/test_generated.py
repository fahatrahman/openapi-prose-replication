import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.exceptions import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    status_forcelist=[429],
    backoff_factor=1,
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

def test_crawl():
    query = "google+search+api"
    url = f"{BASE_URL}/v1/crawl/{query}"

    response = SESSION.get(url)
    assert response.status_code == 200

    expected_response = {
        "answer": None,
        "results": [
            "<!doctype html><html itemscope=\"\" itemtype=\"http://schema.org/SearchResultsPage\" lang=\"en\"><head> ..."
        ],
        "total": None,
    }
    assert response.json() == expected_response