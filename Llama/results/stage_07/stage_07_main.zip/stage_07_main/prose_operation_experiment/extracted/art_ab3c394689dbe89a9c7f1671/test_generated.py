import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_get_sdk_type():
    sdktype_id = "test_sdktype_id"
    headers = {
        'X-Amz-Algorithm': '',
        'X-Amz-Content-Sha256': '',
        'X-Amz-Credential': '',
        'X-Amz-Date': datetime.now().strftime("%Y%m%dT%H%M%SZ"),
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': '',
        'X-Amz-SignedHeaders': '',
        'Authorization': ''
    }
    
    response = requests.get(f"{BASE_URL}/sdktypes/{sdktype_id}", headers=headers)
    
    assert response.status_code == 200
    assert response.json()['configurationProperties'] is not None
    assert response.json()['description'] is not None
    assert response.json()['friendlyName'] is not None
    assert response.json()['id'] is not None
    
@pytest.mark.parametrize("status_code", [480, 481, 482, 483])
def test_error_responses(status_code):
    sdktype_id = "test_sdktype_id"
    headers = {
        'X-Amz-Algorithm': '',
        'X-Amz-Content-Sha256': '',
        'X-Amz-Credential': '',
        'X-Amz-Date': datetime.now().strftime("%Y%m%dT%H%M%SZ"),
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': '',
        'X-Amz-SignedHeaders': '',
        'Authorization': ''
    }
    
    response = requests.get(f"{BASE_URL}/sdktypes/{sdktype_id}", headers=headers)
    
    assert response.status_code == status_code
    