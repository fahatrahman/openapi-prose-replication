import pytest
import requests

BASE_URL = "http://openapi.test"

def test_find_place():
    params = {
        "api_key": "ak_test",
        "query": "london"
    }
    response = requests.get(f"{BASE_URL}/places", params=params)
    assert response.status_code == 200
    data = response.json()
    assert data["code"] == 2000
    assert data["message"] == "Success"
    assert "hits" in data["result"]
    assert isinstance(data["result"]["hits"], list)

def test_find_place_bad_request():
    params = {
        "api_key": "invalid_api_key",
        "query": "london"
    }
    response = requests.get(f"{BASE_URL}/places", params=params)
    assert response.status_code == 400
    data = response.json()
    assert data["code"] == 400
    assert "errors" in data
    assert isinstance(data["errors"], list)
    for error in data["errors"]:
        assert "errorCode" in error
        assert "message" in error
        assert "path" in error