import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def access_token():
    # Implement token retrieval logic here
    return "your_access_token_here"

def test_get_shop_script_tags(access_token):
    url = f"{BASE_URL}/appstore/v1/script_tags.json"
    headers = {
        "Authorization": f"Bearer {access_token}"
    }
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert "script_tags" in data
    script_tags = data["script_tags"]
    for tag in script_tags:
        assert "id" in tag
        assert "display_scope" in tag
        assert "account_id" in tag
        assert "integrity" in tag
        assert "make_date" in tag
        assert "oauth_application_id" in tag
        assert "src" in tag
        assert "update_date" in tag