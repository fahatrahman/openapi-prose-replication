import pytest
import requests
from jsonschema import ValidationError

BASE_URL = "http://openapi.test"

def test_get_authentication_result():
    url = f"{BASE_URL}/getAuthenticationResult"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Basic your_basic_auth_credentials_here"
    }
    data = {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "pspReference": "9935272408535455"
    }

    response = requests.post(url, headers=headers, json=data)

    assert response.status_code == 200
    try:
        response.json()
    except ValidationError as e:
        print(e)
        pytest.fail("Invalid JSON in response")

def test_get_authentication_result_unauthorized():
    url = f"{BASE_URL}/getAuthenticationResult"
    headers = {}
    data = {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "pspReference": "9935272408535455"
    }

    response = requests.post(url, headers=headers, json=data)

    assert response.status_code == 401

def test_get_authentication_result_bad_request():
    url = f"{BASE_URL}/getAuthenticationResult"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Basic your_basic_auth_credentials_here"
    }
    data = {
        "pspReference": "9935272408535455"
    }

    response = requests.post(url, headers=headers, json=data)

    assert response.status_code == 400

def test_get_authentication_result_internal_server_error():
    url = f"{BASE_URL}/getAuthenticationResult"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Basic your_basic_auth_credentials_here"
    }
    data = {
        "merchantAccount": "INVALID_MERCHANT_ACCOUNT",
        "pspReference": "9935272408535455"
    }

    response = requests.post(url, headers=headers, json=data)

    assert response.status_code == 500