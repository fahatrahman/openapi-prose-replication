import pytest
import requests

BASE_URL = "http://openapi.test"

def test_update_policy():
    url = f"{BASE_URL}/dns/v1/projects/example-project/policies/example-policy"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "policy": {
            "kind": "dns#policy",
            "name": "example-policy",
            "description": "Updated policy description",
            "enableInboundForwarding": True,
            "enableLogging": False,
            "networks": [
                {"kind": "dns#policyNetwork", "networkUrl": "https://www.example.com/network"}
            ],
            "alternativeNameServerConfig": {
                "kind": "dns#policyAlternativeNameServerConfig",
                "targetNameServers": [
                    {
                        "kind": "dns#policyAlternativeNameServerConfigTargetNameServer",
                        "ipv4Address": "1.2.3.4",
                        "forwardingPath": "default"
                    }
                ]
            }
        }
    }
    response = requests.put(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert "responseHeader" in response.json()
    assert "policy" in response.json()