import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["GET", "OPTIONS"],
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

def test_get_tags_from_cis_instruction():
    employer_id = "your_employer_id"
    subcontractor_id = "your_subcontractor_id"
    cis_instruction_id = "your_cis_instruction_id"
    authorization = "Auto"
    api_version = "default"

    url = f"{BASE_URL}/Employer/{employer_id}/SubContractor/{subcontractor_id}/CisInstruction/{cis_instruction_id}/Tags"

    headers = {
        "Authorization": authorization,
        "Api-Version": api_version,
    }

    response = SESSION.get(url, headers=headers)

    assert response.status_code == 200, f"Expected status code 200, got {response.status_code}"

    # Assuming LinkCollection schema has 'Links' array, we'll check if it's present in the response
    assert "Links" in response.json(), "Response missing 'Links' array"

if __name__ == "__main__":
    pytest.main([__file__, "-v"])