# -*- coding: utf-8 -*-
import pytest
import requests
from typing import Dict, Any

BASE_URL = "http://openapi.test"

def test_files_get_file() -> None:
    """
    Test Files Get File operation.

    :return: None
    """

    # Construct full path
    url: str = f"{BASE_URL}/api/v2/Files/{'file-id'}"
    
    # Define expected response schema
    expected_schema: Dict[str, Any] = {
        "type": "object",
        "properties": {
            "CRC": {"type": "string"},
            "ContentType": {"type": "string"},
            "Description": {"type": "string"},
            "Id": {"type": "string"},
            "IsPublic": {"type": "boolean"},
            "Name": {"type": "string"},
            "Path": {"type": "string"},
            "Size": {"type": "integer", "format": "int64"},
            "State": {"type": "string", "enum": ["Created", "Available", "Removed"]}
        },
        "required": ["Name", "Description", "ContentType", "State", "IsPublic", "CRC", "Path"]
    }

    # Send GET request
    try:
        response: requests.Response = requests.get(url)
        response.raise_for_status()
        
        # Validate response against expected schema
        assert response.json() == expected_schema
    
    except requests.RequestException as e:
        # Handle API errors
        print(f"Request failed with status {e.response.status_code}")
        assert False

if __name__ == "__main__":
    pytest.main([__file__])