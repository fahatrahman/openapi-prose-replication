import pytest
import requests
BASE_URL = "http://openapi.test"

# Define security schemes
SECURITY_SCHEMES = {
    'Oauth2': ['https://www.googleapis.com/auth/appengine.admin',
               'https://www.googleapis.com/auth/cloud-platform',
               'https://www.googleapis.com/auth/cloud-platform.read-only'],
    'Oauth2c': ['https://www.googleapis.com/auth/appengine.admin',
                'https://www.googleapis.com/auth/cloud-platform',
                'https://www.googleapis.com/auth/cloud-platform.read-only']
}

def get_instance(apps_id, services_id, versions_id, instances_id):
    url = f"{BASE_URL}/v1/apps/{apps_id}/services/{services_id}/versions/{versions_id}/instances/{instances_id}"
    
    @pytest.mark.parametrize("security", SECURITY_SCHEMES.values())
    def test_get_instance(security):
        response = requests.get(url, verify=False, headers={"Authorization": f"Bearer {security[0]}", "Content-Type": "application/json"})
        
        assert response.status_code == 200
        assert isinstance(response.json(), dict)
        assert "appEngineRelease" in response.json()
        assert "availability" in response.json()
        assert "averageLatency" in response.json()

    return test_get_instance