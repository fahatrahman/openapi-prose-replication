import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_all_risk_factors():
    params = {
        "age.value": 18,
        "age.unit": "year",
        "enable_triage_5": False
    }
    response = requests.get(f"{BASE_URL}/risk_factors", params=params)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    for item in data:
        assert "id" in item
        assert "name" in item
        assert "sex_filter" in item
        assert item["sex_filter"] in ["both", "male", "female"]