import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_track_collection_list():
    params = {
        "page": 1,
        "per_page": 100,
        "embed": ["share_code"]
    }
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    response = requests.get(f"{BASE_URL}/v2/audio/collections", params=params, headers=headers)
    
    assert response.status_code == 200
    data = response.json()
    assert "data" in data
    assert isinstance(data["data"], list)
    for collection in data["data"]:
        assert "id" in collection
        assert "name" in collection
        assert "total_item_count" in collection
        if "embed" in params and "share_code" in params["embed"]:
            assert "share_code" in collection