import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

def test_update_transfer_instrument():
    id = "SE576BH223222F5GJVKHH6BDT"
    verification_code = 1

    headers = {"x-requested-verification-code": str(verification_code)}
    response = SESSION.patch(
        f"{BASE_URL}/transferInstruments/{id}", json={"bankAccount": {"currencyCode": "EUR", "iban": "NL02ABNA0123456789"}}
    )

    assert response.status_code == 200
    assert response.json()["bankAccount"]["currencyCode"] == "EUR"
    assert response.json()["bankAccount"]["iban"] == "NL02ABNA0123456789"
    assert response.json()["id"] == id