# -*- coding: utf-8 -*-
"""Tests for artifactregistry projects locations repositories packages list."""

import pytest
from requests import HTTPError

BASE_URL = "http://openapi.test"

def test_artifactregistry_projects_locations_repositories_packages_list():
    """Test artifactregistry projects locations repositories packages list."""
    url = f"{BASE_URL}/v1beta1/{'parent'}"
    params = {
        'pageSize': 1,
        'pageToken': ''
    }
    headers = {}
    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 200, f"Unexpected status code {response.status_code}"
    try:
        response.raise_for_status()
    except HTTPError as http_err:
        print(f"HTTP error occurred: {http_err}")
        assert False