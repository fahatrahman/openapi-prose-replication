import os
import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def delete_server(api_client):
    server_id = 123  # Replace with actual server ID

    response = api_client.delete(
        f"{BASE_URL}/servers/{server_id}",
    )

    assert response.status_code == 200

    action = response.json()["action"]
    assert isinstance(action, dict)
    assert "command" in action
    assert "status" in action
    assert action["status"] == "success"