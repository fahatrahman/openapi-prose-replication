import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retry mechanism
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
session.mount("http://", adapter)
session.mount("https://", adapter)

# Set access token for authentication
os.environ["ACCESS_TOKEN"] = "your_access_token"

@pytest.fixture
def headers():
    return {
        "Authorization": f"Bearer {os.getenv('ACCESS_TOKEN')}",
        "Content-Type": "application/json",
    }

@pytest.mark.parametrize("url, expected_status", [(f"{BASE_URL}/data/v1/dimensions", 200)])
def test_list_dimensions(url, expected_status):
    response = session.get(url, headers=headers())
    assert response.status_code == expected_status

    if response.status_code == 200:
        data = response.json()
        # Add more assertions here if needed
        print(data)