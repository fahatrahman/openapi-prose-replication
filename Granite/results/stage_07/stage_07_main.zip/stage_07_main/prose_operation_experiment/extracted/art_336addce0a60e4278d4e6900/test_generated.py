import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retry logic for handling transient errors
session = requests.Session()
retry_strategy = Retry(
    total=3,
    backoff_factor=0.1,
    status_forcelist=[429, 500, 502, 503, 504],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def player_season_projection_stats():
    format_ = "JSON"
    season = "2017"

    url = f"{BASE_URL}/{format.lower()}/PlayerSeasonProjectionStats/{season}"

    response = session.get(url)
    response.raise_for_status()

    return response.json()

def test_player_season_projection_stats(player_season_projection_stats):
    assert isinstance(player_season_projection_stats, list)
    for stat in player_season_projection_stats:
        assert set(stat.keys()).issuperset({"Name", "Runs", "Hits", "HomeRuns"})