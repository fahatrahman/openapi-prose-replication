import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_list_label_permissions():
    url = urljoin(BASE_URL, "/v2beta/{parent}/permissions")
    params = {
        "parent": "labels/my-label",
        "pageSize": 10,
        "pageToken": "",
        "useAdminAccess": True
    }
    
    response = requests.get(url, params=params)
    assert response.status_code == 200
    
    data = response.json()
    assert isinstance(data, dict)
    assert 'labelPermissions' in data
    assert isinstance(data['labelPermissions'], list)

def test_list_label_permissions_with_oauth2():
    # This test requires valid OAUTH2_TOKEN environment variable
    url = urljoin(BASE_URL, "/v2beta/{parent}/permissions")
    headers = {'Authorization': f'Bearer {os.environ["OAUTH2_TOKEN"]}'}
    params = {
        "parent": "labels/my-label",
        "pageSize": 10,
        "pageToken": ""
    }
    
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    
    data = response.json()
    assert isinstance(data, dict)
    assert 'labelPermissions' in data
    assert isinstance(data['labelPermissions'], list)

import os
# Run tests only if OAUTH2_TOKEN env var is set
pytestmark = pytest.mark.skipif(os.getenv('OAUTH2_TOKEN') is None, reason="OAUTH2_TOKEN env var is required")
