import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Define retry strategy for handling transient errors
retries = Retry(total=3, backoff_factor=0.1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
http = requests.Session()
http.mount("https://", adapter)
http.mount("http://", adapter)

requests.adapters.HTTPAdapter.MAX_RETRIES = retries.total
requests.packages.urllib3.util.Retry.BACKOFF_FACTOR = retries.backoff_factor

# Security credentials for OAuth2
OAUTH2_CLIENT_ID = "<your_client_id>"
OAUTH2_CLIENT_SECRET = "<your_client_secret>"
OAUTH2_REFRESH_TOKEN = "<your_refresh_token>"

def test_delete_entity():
    name = "zynntaco/your_autfnhu/yzvrewumc/your_vmdixebo/dkjrcljplpt/your_yrbrlgnwgg/socmqsZvoyc/your_qvlt/rjwjgnsj/your_lg"

    url = f"{BASE_URL}/v2/{name}"
    
    headers = {
        "Authorization": f"Bearer {OAUTH2_REFRESH_TOKEN}",
    }

    response = http.delete(url, headers=headers)
    assert response.status_code == 200
    assert response.json() == {"message": "Entity deleted successfully"}