import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_aliases():
    url = f"{BASE_URL}/v4/aliases"
    headers = {
        "Authorization": "Bearer YOUR_BEARER_TOKEN"
    }
    params = {
        "domain": "my-test-domain.com",
        "limit": 10,
        "projectId": "prj_12HKQaOmR5t5Uy6vdcQsNIiZgHGB"
    }
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 200
    data = response.json()
    assert "aliases" in data
    assert "pagination" in data
    aliases = data["aliases"]
    pagination = data["pagination"]
    
    assert isinstance(aliases, list)
    for alias in aliases:
        assert "alias" in alias
        assert "created" in alias
        assert "createdAt" in alias
        assert "creator" in alias
        assert "deletedAt" in alias
        assert "deployment" in alias
        assert "deploymentId" in alias
        assert "projectId" in alias
        assert "protectionBypass" in alias
        assert "redirect" in alias
        assert "redirectStatusCode" in alias
        assert "uid" in alias
        assert "updatedAt" in alias
    
    assert isinstance(pagination, dict)
    assert "count" in pagination
    assert "next" in pagination
    assert "prev" in pagination