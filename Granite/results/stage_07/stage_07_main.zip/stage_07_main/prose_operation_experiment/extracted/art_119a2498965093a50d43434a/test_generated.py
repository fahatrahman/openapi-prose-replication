import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_PATH = os.environ.get("CREDENTIALS_PATH")

# Load credentials from JSON file if CREDENTIALS_PATH is set
if CREDENTIALS_PATH:
    credentials = service_account.Credentials.from_service_account_file(
        CREDENTIALS_PATH
    )
else:
    credentials = None

SERVICE_ACCOUNT_EMAIL = credentials.to_dict()["client_email"] if credentials else None

def test_update_container():
    # Define parameters for the update request
    path_params = {
        "accountId": "your_account_id",
        "containerId": "your_container_id",
    }

    query_params = {
        "fingerprint": "your_fingerprint",
    }

    body = {
        "accountId": "your_account_id",
        "containerId": "your_container_id",
        # Add other properties required by Container schema here if needed
    }

    # Construct the full URL for the API call
    url = f"{BASE_URL}/tagmanager/v1/accounts/{path_params['accountId']}/containers/{path_params['containerId']}"

    headers = {}
    if credentials:
        headers["Authorization"] = f"Bearer {credentials.token}"

    response = requests.put(
        url, json=body, headers=headers, params=query_params
    )

    assert response.status_code == 200
    updated_container = response.json()
    # Perform additional assertions or checks on the 'updated_container' object if necessary