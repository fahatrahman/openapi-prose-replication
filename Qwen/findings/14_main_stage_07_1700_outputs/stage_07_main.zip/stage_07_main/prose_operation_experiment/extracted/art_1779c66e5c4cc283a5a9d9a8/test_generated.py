import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_sip_rules():
    headers = {
        "X-Amz-Content-Sha256": "",
        "X-Amz-Date": "",
        "X-Amz-Algorithm": "",
        "X-Amz-Credential": "",
        "X-Amz-Security-Token": "",
        "X-Amz-Signature": "",
        "X-Amz-SignedHeaders": ""
    }
    params = {
        "sip-media-application": "example-sip-media-application",
        "max-results": 10,
        "next-token": "",
        "MaxResults": "",
        "NextToken": ""
    }
    response = requests.get(f"{BASE_URL}/sip-rules", headers=headers, params=params)
    
    assert response.status_code == 200
    assert "ListSipRulesResponse" in response.json()

def test_unauthorized_client_exception():
    headers = {
        "X-Amz-Content-Sha256": "",
        "X-Amz-Date": "",
        "X-Amz-Algorithm": "",
        "X-Amz-Credential": "",
        "X-Amz-Security-Token": "",
        "X-Amz-Signature": "",
        "X-Amz-SignedHeaders": ""
    }
    params = {}
    response = requests.get(f"{BASE_URL}/sip-rules", headers=headers, params=params)
    
    assert response.status_code == 480
    assert "UnauthorizedClientException" in response.json()

def test_forbidden_exception():
    headers = {
        "X-Amz-Content-Sha256": "",
        "X-Amz-Date": "",
        "X-Amz-Algorithm": "",
        "X-Amz-Credential": "",
        "X-Amz-Security-Token": "",
        "X-Amz-Signature": "",
        "X-Amz-SignedHeaders": ""
    }
    params = {}
    response = requests.get(f"{BASE_URL}/sip-rules", headers=headers, params=params)
    
    assert response.status_code == 481
    assert "ForbiddenException" in response.json()

def test_bad_request_exception():
    headers = {
        "X-Amz-Content-Sha256": "",
        "X-Amz-Date": "",
        "X-Amz-Algorithm": "",
        "X-Amz-Credential": "",
        "X-Amz-Security-Token": "",
        "X-Amz-Signature": "",
        "X-Amz-SignedHeaders": ""
    }
    params = {}
    response = requests.get(f"{BASE_URL}/sip-rules", headers=headers, params=params)
    
    assert response.status_code == 482
    assert "BadRequestException" in response.json()

def test_throttled_client_exception():
    headers = {
        "X-Amz-Content-Sha256": "",
        "X-Amz-Date": "",
        "X-Amz-Algorithm": "",
        "X-Amz-Credential": "",
        "X-Amz-Security-Token": "",
        "X-Amz-Signature": "",
        "X-Amz-SignedHeaders": ""
    }
    params = {}
    response = requests.get(f"{BASE_URL}/sip-rules", headers=headers, params=params)
    
    assert response.status_code == 483
    assert "ThrottledClientException" in response.json()

def test_service_unavailable_exception():
    headers = {
        "X-Amz-Content-Sha256": "",
        "X-Amz-Date": "",
        "X-Amz-Algorithm": "",
        "X-Amz-Credential": "",
        "X-Amz-Security-Token": "",
        "X-Amz-Signature": "",
        "X-Amz-SignedHeaders": ""
    }
    params = {}
    response = requests.get(f"{BASE_URL}/sip-rules", headers=headers, params=params)
    
    assert response.status_code == 484
    assert "ServiceUnavailableException" in response.json()

def test_service_failure_exception():
    headers = {
        "X-Amz-Content-Sha256": "",
        "X-Amz-Date": "",
        "X-Amz-Algorithm": "",
        "X-Amz-Credential": "",
        "X-Amz-Security-Token": "",
        "X-Amz-Signature": "",
        "X-Amz-SignedHeaders": ""
    }
    params = {}
    response = requests.get(f"{BASE_URL}/sip-rules", headers=headers, params=params)
    
    assert response.status_code == 485
    assert "ServiceFailureException" in response.json()