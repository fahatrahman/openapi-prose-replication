# -*- coding: utf-8 -*-
import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_sentences():
    url = f"{BASE_URL}/sentences"
    params = {"limit": 1}
    response = requests.get(url, params=params)
    assert response.status_code == 200
    data = response.json()["data"]
    for sentence in data:
        assert isinstance(sentence["id"], str)
        assert isinstance(sentence["sentence"], str)
        book_ref = sentence["book"]
        book_url = f"{url}?limit=1&offset=0"
        book_response = requests.get(book_url)
        book_data = book_response.json()["data"][0]
        assert book_data["id"] == book_ref["id"]

def test_get_sentences_invalid_limit():
    url = f"{BASE_URL}/sentences"
    params = {"limit": 101}  # Invalid limit value
    response = requests.get(url, params=params)
    assert response.status_code == 200
    data = response.json()["data"]
    assert len(data) <= 100  # Limit should be capped at 100

if __name__ == "__main__":
    pytest.main([__file__])