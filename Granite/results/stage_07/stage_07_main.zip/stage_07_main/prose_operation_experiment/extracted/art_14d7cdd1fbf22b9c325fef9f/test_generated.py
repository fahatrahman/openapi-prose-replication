import os
import json
import pytest
from requests import Session

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def session():
    session = Session()
    headers = {"Authorization": f"Bearer {os.environ['AGENT_TOKEN']}"}
    session.headers.update(headers)
    return session

def get_ship_nav(ship_symbol):
    url = f"{BASE_URL}/my/ships/{ship_symbol}/nav"
    response = session.get(url)
    assert response.status_code == 200
    return response.json()["data"]

def test_get_ship_nav(session):
    ship_symbol = "TEST_SHIP"
    nav_status = get_ship_nav(ship_symbol)

    # Add more assertions based on expected structure of 'nav_status'
    assert isinstance(nav_status, dict)
    assert nav_status["systemSymbol"] is not None
    assert nav_status["waypointSymbol"] is not None
    assert nav_status["route"]["destination"]["symbol"] is not None
    assert nav_status["route"]["departure"] is not None
    assert nav_status["route"]["departureTime"] is not None
    assert nav_status["route"]["arrival"] is not None
    assert nav_status["status"] in ["IN_TRANSIT", "IN_ORBIT", "DOCKED"]
    assert nav_status["flightMode"] in ["DRIFT", "STEALTH", "CRUISE", "BURN"]