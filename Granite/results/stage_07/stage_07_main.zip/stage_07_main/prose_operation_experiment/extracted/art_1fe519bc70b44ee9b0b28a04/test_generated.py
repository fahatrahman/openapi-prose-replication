import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.fixture
def game_by_date():
    def _game_by_date(format, date):
        url = f"{BASE_URL}/{format}/GamesByDate/{date}"
        response = SESSION.get(url)
        response.raise_for_status()
        return response.json()["response"]

    yield _game_by_date

def test_game_by_date(game_by_date):
    games = game_by_date("JSON", "2017-ZQD-31")
    assert isinstance(games, list)
    for game in games:
        assert isinstance(game, dict)
        # Add more assertions based on the expected structure of 'Game' object
    games = game_by_date("XML", "2017-CIM-01")
    assert isinstance(games, list)
    for game in games:
        assert isinstance(game, dict)
        # Add more assertions based on the expected structure of 'Game' object