import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_package_types():
    params = {
        'limit': 10,
        'offset': 0,
        'userID': None
    }
    response = requests.get(f"{BASE_URL}/api/v2/PackageTypes", params=params)
    
    assert response.status_code == 200
    data = response.json()
    
    assert 'Entities' in data
    assert isinstance(data['Entities'], list)
    assert 'Metadata' in data
    assert isinstance(data['Metadata'], dict)
    assert 'Limit' in data['Metadata']
    assert 'Offset' in data['Metadata']
    assert 'TotalCount' in data['Metadata']

if __name__ == "__main__":
    pytest.main(['-v', __file__])