import pytest
import requests

BASE_URL = "http://openapi.test"

def get_ticket_messages(ticket_id, authorization, offset=0, limit=10):
    url = f"{BASE_URL}/ticket/{ticket_id}/messages"
    params = {
        "offset": offset,
        "limit": limit
    }
    headers = {
        "Authorization": authorization
    }
    response = requests.get(url, headers=headers, params=params)
    return response.json()

@pytest.mark.parametrize("ticket_id, authorization, expected_status", [
    ("123", "Bearer token123", 200),
    ("456", "Bearer invalidtoken", 401),
    ("789", "Bearer expiredtoken", 403),
    ("101", "Bearer validtoken", 400)
])
def test_get_ticket_messages(ticket_id, authorization, expected_status):
    response = get_ticket_messages(ticket_id, authorization)
    assert response.status_code == expected_status