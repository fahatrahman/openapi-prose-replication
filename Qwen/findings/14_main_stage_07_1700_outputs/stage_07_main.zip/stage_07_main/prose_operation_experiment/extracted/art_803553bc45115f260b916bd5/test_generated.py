import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_locations():
    url = f"{BASE_URL}/v1beta1/projects/locations"
    params = {
        "_xgafv": "1",
        "access_token": "test_access_token",
        "alt": "json",
        "callback": "test_callback",
        "fields": "locations(nextPageToken)",
        "key": "test_key",
        "oauth_token": "test_oauth_token",
        "prettyPrint": False,
        "quotaUser": "test_quota_user",
        "uploadType": "test_upload_type",
        "upload_protocol": "test_upload_protocol",
        "name": "projects/test_project",
        "filter": "status=ACTIVE",
        "pageSize": 10,
        "pageToken": ""
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    data = response.json()
    assert "locations" in data
    assert "nextPageToken" in data