import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def api_client():
    def client(operation_id, **kwargs):
        url = f"{BASE_URL}/designer/templates"
        if operation_id == "list_templates_designer_templates_get":
            params = {key: kwargs[key] for key in ("limit", "offset") if key in kwargs}
            response = requests.get(url, headers={"x-api-key": "your_api_key"}, params=params)
            return response.json()
        else:
            raise ValueError(f"Unsupported operation ID: {operation_id}")
    return client

def test_list_templates(api_client):
    response = api_client("list_templates_designer_templates_get")
    assert response["status"] == 200
    assert isinstance(response["data"]["results"], list)

if __name__ == "__main__":
    pytest.main(["-v", "-s"])