import pytest
import requests

BASE_URL = "http://openapi.test"

def test_post_files_v3_folders_update_async():
    url = f"{BASE_URL}/files/v3/folders/update/async"
    headers = {
        "private-app-legacy": "your_private_app_token",
        "Authorization": "Bearer your_oauth_token"
    }
    payload = {
        "id": "folder_id_to_update",
        "name": "New Folder Name",
        "parentFolderId": 123456789
    }
    
    response = requests.post(url, headers=headers, json=payload)
    
    assert response.status_code == 202
    assert 'id' in response.json()
    assert 'links' in response.json()

if __name__ == "__main__":
    pytest.main()