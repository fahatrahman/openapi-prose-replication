import pytest
import requests

BASE_URL = "http://openapi.test"

def test_grant_flow_entitlements():
    headers = {
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Date": "20230401T123456Z",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20230401/us-east-1/mediaconnect/aws4_request",
        "X-Amz-Security-Token": "AQoEXAMPLEHIGNE+NCOrRtjCWyJ60LRUYQwYBamgVZRqc7tgWq8Z0uQRbOpKnOry2NiRHnG9Kcbgq9PGvdvoAMrxd1lCY9D5Fo3z5nZfUdksk3pQ0Fe0nxUGIwem53sf8ulsw6RW5MGLY7L7uzqK8XR9zdAsZetMOZHXOPozfHC2/wr74TKFTpgTLokkjfxdi4wgiCOSUR3ldP7ZhCGPYELQTSCQCAmDz8z3DMPLCTGNhK9z4YyKpzFE4w6XT8E69MZqN28XyFwukyufcVhg0n80qR2p5lVYbvxXqy2UfM05i4CZ20jkDiOQr3PQ13jyPP90Uxo0vV06wXw50nZmDnKlG5W3PpSjbw==",
        "X-Amz-Signature": "f45ac34ed6548fe32f6cd56f4ecedd012c6de9e9ee9c1a2b917172c069dd10f5",
        "X-Amz-SignedHeaders": "host;x-amz-algorithm;x-amz-content-sha256;x-amz-credential;x-amz-date;x-amz-security-token"
    }
    url = f"{BASE_URL}/v1/flows/arn:aws:mediaconnect:us-west-2:123456789012:flow/1-abcdefgh-ijkl-mnop-qrst-uvwxyz123456/entitlements"
    payload = {
        "entitlements": [
            {
                "Subscribers": ["123456789012"],
                "Name": "test-entitlement",
                "Description": "Test entitlement",
                "Encryption": {
                    "RoleArn": "arn:aws:iam::123456789012:role/MediaConnectRole",
                    "KeyType": "static-key",
                    "SecretArn": "arn:aws:secretsmanager:us-west-2:123456789012:secret:MediaConnectKey"
                },
                "EntitlementStatus": "ENABLED"
            }
        ]
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert "Entitlements" in response.json()
    assert "FlowArn" in response.json()

if __name__ == "__main__":
    pytest.main()