import pytest
import requests
from jsonschema import validate
from urllib.parse import urlencode

BASE_URL = "http://openapi.test"

def get_multiple_artists(ids):
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
    }
    params = {'ids': ids}

    try:
        response = requests.get(f'{BASE_URL}/artists', headers=headers, params=urlencode(params))
        response.raise_for_status()
    except requests.exceptions.RequestException as err:
        raise Exception('Request failed', err)

    return response.json()

def test_get_multiple_artists():
    ids = "2CIMQHirSU0MQqyYHq0eOx,57dN52uHvirSU0MQqyYHq0eOx,1vCWHaC5f2uS3yhpwWbIA6"
    response_data = get_multiple_artists(ids)
    
    # Validate JSON schema
    schema = {
        "type": "object",
        "properties": {
            "artists": {"type": "array", "items": {"$ref": "#/components/schemas/ArtistObject"}}
        },
        "required": ["artists"]
    }
    validate(instance=response_data, schema=schema)

    assert len(response_data['artists']) > 0
    assert isinstance(response_data, dict)
    assert 'artists' in response_data.keys()

def test_get_multiple_artists_unauthorized():
    ids = "2CIMQHirSU0MQqyYHq0eOx,57dN52uHvirSU0MQqyYHq0eOx,1vCWHaC5f2uS3yhpwWbIA6"
    response_data = get_multiple_artists(ids)

    # Validate JSON schema
    schema = {
        "type": "object",
        "properties": {
            "error": {"$ref": "#/components/schemas/ErrorObject"}
        },
        "required": ["error"]
    }
    validate(instance=response_data, schema=schema)

    assert isinstance(response_data, dict)
    assert 'error' in response_data.keys()

def test_get_multiple_artists_forbidden():
    ids = "2CIMQHirSU0MQqyYHq0eOx,57dN52uHvirSU0MQqyYHq0eOx,1vCWHaC5f2uS3yhpwWbIA6"
    response_data = get_multiple_artists(ids)

    # Validate JSON schema
    schema = {
        "type": "object",
        "properties": {
            "error": {"$ref": "#/components/schemas/ErrorObject"}
        },
        "required": ["error"]
    }
    validate(instance=response_data, schema=schema)

    assert isinstance(response_data, dict)
    assert 'error' in response_data.keys()

def test_get_multiple_artists_too_many_requests():
    ids = "2CIMQHirSU0MQqyYHq0eOx,57dN52uHvirSU0MQqyYHq0eOx,1vCWHaC5f2uS3yhpwWbIA6"
    response_data = get_multiple_artists(ids)

    # Validate JSON schema
    schema = {
        "type": "object",
        "properties": {
            "error": {"$ref": "#/components/schemas/ErrorObject"}
        },
        "required": ["error"]
    }
    validate(instance=response_data, schema=schema)

    assert isinstance(response_data, dict)
    assert 'error' in response_data.keys()

if __name__ == '__main__':
    pytest.main([__file__, '-vv'])