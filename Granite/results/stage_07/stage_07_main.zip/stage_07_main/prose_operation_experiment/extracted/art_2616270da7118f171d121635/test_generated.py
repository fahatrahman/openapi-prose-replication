import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retry mechanism for handling transient network issues
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["HEAD", "GET", "OPTIONS"],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def get_word_senses():
    def _get_word_senses(language, word):
        headers = {"Ocp-Apim-Subscription-Key": os.environ["API_KEY"]}
        url = f"{BASE_URL}/senses?language={language}&word={word}"
        response = session.get(url, headers=headers)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Request failed with status code {response.status_code}")

    yield _get_word_senses

def test_word_senses(get_word_senses):
    language = "en"
    word = "couscous"

    senses = get_word_senses(language, word)

    assert len(senses["items"]) > 0
    assert all(
        [
            families[0]["lemma"] == "couscous"
            and families[0]["lexemeId"] == 28041
            for families in senses["items"][0]["families"]
        ]
    )