# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_competitions_leagues():
    url = f"{BASE_URL}/{'json'}"
    headers = {"Ocp-Apim-Subscription-Key": "your_api_key"}
    params = {}
    
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    
    json_response = response.json()
    assert isinstance(json_response, list)
    for competition in json_response:
        assert isinstance(competition, dict)
        required_keys = ["AreaId", "CompetitionId", "Seasons"]
        for key in required_keys:
            assert key in competition
        
@pytest.fixture
def api_key():
    return "your_api_key"

def test_competitions_leagues_with_api_key(api_key):
    url = f"{BASE_URL}/{'json'}"
    headers = {"Ocp-Apim-Subscription-Key": api_key}
    params = {}
    
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    
    json_response = response.json()
    assert isinstance(json_response, list)
    for competition in json_response:
        assert isinstance(competition, dict)
        required_keys = ["AreaId", "CompetitionId", "Seasons"]
        for key in required_keys:
            assert key in competition