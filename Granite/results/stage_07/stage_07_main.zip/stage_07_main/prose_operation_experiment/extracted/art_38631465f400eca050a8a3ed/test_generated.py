import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

headers = {
    "Authorization": "AWS4-HMAC-SHA256 Credential={access_key}/20220901/us-east-1/s3/aws4_request, SignedHeaders=host;x-amz-content-sha256;x-amz-date, Signature={signature}"
}

@pytest.fixture
def client():
    return session

def test_disassociate_user(client):
    endpoint = "/user/DisassociateUser"
    data = {
        "Domain": "example.com",
        "IdentityProvider": {
            "ActiveDirectoryIdentityProvider": {
                "DirectoryId": "ad-directory-id"
            }
        },
        "InstanceId": "i-0123456789abcdef0",
        "Username": "johndoe"
    }

    response = client.post(BASE_URL + endpoint, json=data, headers=headers)

    assert response.status_code == 200
    disassociate_response = response.json()
    # Further assertions can be added based on the expected DisassociateUserResponse structure
