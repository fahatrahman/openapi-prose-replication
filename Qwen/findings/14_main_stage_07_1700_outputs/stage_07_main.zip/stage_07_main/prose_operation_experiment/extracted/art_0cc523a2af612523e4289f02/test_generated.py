import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_service():
    url = f"{BASE_URL}/v1/Services"
    response = requests.get(url)
    assert response.status_code == 200
    data = response.json()
    assert "meta" in data
    assert "services" in data
    services = data["services"]
    assert isinstance(services, list)
    if services:
        assert "sid" in services[0]
        assert "friendly_name" in services[0]
        assert "date_created" in services[0]

if __name__ == "__main__":
    pytest.main([__file__])