import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

@pytest.fixture
def client():
    return session

def test_create_asset(client):
    headers = {
        'X-Amz-Algorithm': 'AWS4-HMAC-SHA256',
        'X-Amz-Credential': 'TEST_CREDENTIALS',
        'X-Amz-Date': '20210930T123600Z',
        'X-Amz-ExponentialBackoff': '0',
        'X-Amz-ExponentialBackoffPolicy': 'default',
        'X-Amz-SignedHeaders': 'host;x-amz-content-sha256;x-amz-date',
        'X-Amz-Security-Token': 'TEST_SECURITY_TOKEN'
    }

    payload = {
        "id": "example_id",
        "packagingGroupId": "example_packaging_group_id",
        "sourceArn": "arn:aws:iam::123456789012:role/ExampleRole",
        "sourceRoleArn": "arn:aws:iam::123456789012:role/ExampleRole",
        "tags": {
            "example-tag": "example-value"
        }
    }

    response = client.post(
        f"{BASE_URL}/assets",
        json=payload,
        headers=headers
    )

    assert response.status_code == 200
    assert response.json()["Id"] == "example_id"
    assert response.json()["PackagingGroupId"] == "example_packaging_group_id"
    assert response.json()["SourceArn"] == "arn:aws:iam::123456789012:role/ExampleRole"
    assert response.json()["SourceRoleArn"] == "arn:aws:iam::123456789012:role/ExampleRole"
    assert response.json()["Tags"]["example-tag"] == "example-value"