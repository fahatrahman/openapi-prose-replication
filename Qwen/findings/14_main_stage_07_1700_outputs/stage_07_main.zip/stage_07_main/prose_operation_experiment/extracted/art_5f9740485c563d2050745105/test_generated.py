import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_word_senses():
    params = {
        "language": "en",
        "word": "couscous"
    }
    headers = {
        "Ocp-Apim-Subscription-Key": "your_api_key_here"
    }
    response = requests.get(f"{BASE_URL}/senses", params=params, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    for item in data:
        assert "families" in item
        assert "features" in item
        assert "frequency" in item
        assert "isLemma" in item
        assert "legacyMapId" in item
        assert "lemma" in item
        assert "lexemeId" in item