import pytest
import requests

BASE_URL = "http://openapi.test"

def test_link_application():
    headers = {
        "Authorization": "Bearer your_access_token"
    }
    payload = {
        "application": "applicationId"
    }
    url = f"{BASE_URL}/messenger/12345678/applications"
    
    response = requests.post(url, json=payload, headers=headers)
    
    assert response.status_code == 200
    assert "access_token" in response.json()
    assert "api_key" in response.json()
    assert "applications" in response.json()
    assert "external_id" in response.json()
    assert "name" in response.json()
    assert "provider" in response.json()

def test_link_application_unauthorized():
    headers = {}
    payload = {
        "application": "applicationId"
    }
    url = f"{BASE_URL}/messenger/12345678/applications"
    
    response = requests.post(url, json=payload, headers=headers)
    
    assert response.status_code == 401
    assert "detail" in response.json()
    assert "title" in response.json()

def test_link_application_forbidden():
    headers = {
        "Authorization": "Bearer your_access_token"
    }
    payload = {
        "application": "invalid_applicationId"
    }
    url = f"{BASE_URL}/messenger/12345678/applications"
    
    response = requests.post(url, json=payload, headers=headers)
    
    assert response.status_code == 403
    assert "detail" in response.json()
    assert "title" in response.json()

def test_link_application_conflict():
    headers = {
        "Authorization": "Bearer your_access_token"
    }
    payload = {
        "application": "another_applicationId"
    }
    url = f"{BASE_URL}/messenger/12345678/applications"
    
    response = requests.post(url, json=payload, headers=headers)
    
    assert response.status_code == 409
    assert "detail" in response.json()
    assert "title" in response.json()