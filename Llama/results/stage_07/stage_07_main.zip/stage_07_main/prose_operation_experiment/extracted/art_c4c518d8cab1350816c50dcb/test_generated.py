# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime
from pydantic import BaseModel
from typing import Optional

class ErrorModel(BaseModel):
    Description: str
    ErrorCategory: str
    Errors: list[str]

class Tag(BaseModel):
    Created: str
    TaggedItem: dict[str, str]
    Text: str

BASE_URL = "http://openapi.test"

def test_get_tag_from_employee():
    employer_id = "GD001"
    employee_id = "CT001"
    tag_id = "DpFoa"
    auth_header = "Bearer Auto"
    api_version_header = "default"

    url = f"{BASE_URL}/Employer/{employer_id}/Employee/{employee_id}/Tag/{tag_id}"
    headers = {
        "Authorization": auth_header,
        "Api-Version": api_version_header
    }

    response = requests.get(url, headers=headers)

    assert response.status_code == 200
    assert response.json()["Created"]
    assert response.json()["TaggedItem"]["@href"]
    assert response.json()["TaggedItem"]["@rel"]
    assert response.json()["TaggedItem"]["@title"]
    assert response.json()["Text"]

def test_get_tag_from_employee_unauthorized():
    employer_id = "GD001"
    employee_id = "CT001"
    tag_id = "DpFoa"
    auth_header = ""
    api_version_header = "default"

    url = f"{BASE_URL}/Employer/{employer_id}/Employee/{employee_id}/Tag/{tag_id}"
    headers = {
        "Authorization": auth_header,
        "Api-Version": api_version_header
    }

    response = requests.get(url, headers=headers)

    assert response.status_code == 401
    error_model = ErrorModel.parse_obj(response.json())
    assert error_model.ErrorCategory in ["General", "NotFound", "NotAuthorised", "ValidationFailure"]

def test_get_tag_from_employee_not_found():
    employer_id = "GD001"
    employee_id = "CT001"
    tag_id = "DpFoa"
    auth_header = "Bearer Auto"
    api_version_header = "default"

    url = f"{BASE_URL}/Employer/{employer_id}/Employee/{employee_id}/Tag/not-found-tag-id"
    headers = {
        "Authorization": auth_header,
        "Api-Version": api_version_header
    }

    response = requests.get(url, headers=headers)

    assert response.status_code == 404
    error_model = ErrorModel.parse_obj(response.json())
    assert error_model.ErrorCategory in ["General", "NotFound", "NotAuthorised", "ValidationFailure"]

def test_get_tag_from_employee_internal_server_error():
    employer_id = "GD001"
    employee_id = "CT001"
    tag_id = "DpFoa"
    auth_header = "Bearer Auto"
    api_version_header = "default"

    url = f"{BASE_URL}/Employer/{employer_id}/Employee/{employee_id}/Tag/{tag_id}"
    headers = {
        "Authorization": auth_header,
        "Api-Version": api_version_header
    }
    # Simulate internal server error by adding an invalid header
    headers["Invalid-Header"] = "invalid-value"

    response = requests.get(url, headers=headers)

    assert response.status_code == 500
    error_model = ErrorModel.parse_obj(response.json())
    assert error_model.ErrorCategory in ["General", "NotFound", "NotAuthorised", "ValidationFailure"]