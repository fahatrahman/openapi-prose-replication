import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from typing import Dict

BASE_URL = "http://openapi.test"

# Create a session with a custom adapter for handling retries
session = requests.Session()
adapter = HTTPAdapter(max_retries=3)
session.mount("http://", adapter)
session.mount("https://", adapter)

@pytest.fixture
def google_apps_script_api():
    def _google_apps_script_api(script_id: str):
        url = f"{BASE_URL}/v1/projects/{script_id}"
        headers: Dict[str, str] = {
            "x-goog-api-client": "gl-python",
            "x-goog-api-version": "1",
        }

        response = session.get(url, headers=headers)
        response.raise_for_status()

        return response.json()

    return _google_apps_script_api

def test_project_details(google_apps_script_api):
    script_id = "your_script_id"
    project_data = google_apps_script_api(script_id)

    assert isinstance(project_data, dict)
    assert "createTime" in project_data
    assert "creator" in project_data
    assert "lastModifyUser" in project_data
    assert "parentId" in project_data
    assert "scriptId" in project_data
    assert "title" in project_data
    assert "updateTime" in project_data