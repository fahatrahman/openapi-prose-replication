import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def get_bep20_balance(contract, token_id):
    endpoint = "/v2/bsc/balances/{}/{}/bep20/{}".format(contract, token_id, contract)
    response = requests.get(urljoin(BASE_URL, endpoint), verify=False)

    if response.status_code == 200:
        assert response.headers["Cache-Control"] == "max-age=0, must-revalidate, private"
        assert response.headers["Connection"] == "keep-alive"
        assert response.headers["Date"] != ""
        assert response.headers["Expires"] != ""
        assert response.headers["Server"] != ""
        assert response.headers["Set-Cookie"] != ""
        assert response.headers["Transfer-Encoding"] == "chunked"
        assert response.headers["X-Debug-Token"] != ""
        assert response.headers["X-Debug-Token-Link"] is not None
        assert response.headers["X-Robots-Tag"] == "noindex"

        data = response.json()
        assert "data" in data
        assert "balance" in data["data"]
        assert data["message"] == "Token Balance has been successfully parsed."
        assert data["ok"] is True
        assert data["status"] == 200

        return data["data"]["balance"]
    else:
        raise Exception("Unexpected status code: {}".format(response.status_code))


@pytest.mark.parametrize(
    "contract, token_id",
    [
        ("0x1dDB2C0897daF18632662E71fdD2dbDC0eB3a9Ec", "0x9dB475371B5cC2913D3219f72e16a3F101339a05"),
    ],
)
def test_get_bep20_balance(contract, token_id):
    balance = get_bep20_balance(contract, token_id)
    print(f"Test passed for contract {contract} and token_id {token_id}. Balance: {balance}")