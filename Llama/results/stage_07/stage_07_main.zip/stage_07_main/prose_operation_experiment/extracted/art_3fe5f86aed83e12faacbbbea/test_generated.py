# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_UpcomingScheduleByPlayer():
    player_id = "90026231"
    formats = ["json", "xml"]
    
    for fmt in formats:
        url = f"{BASE_URL}/{fmt}/UpcomingScheduleByPlayer/{player_id}"
        
        headers = {}
        params = {}
        
        try:
            response = requests.get(url, headers=headers, params=params)
            assert response.status_code == 200
        except requests.RequestException as e:
            pytest.fail(f"Request failed: {e}")
            
def test_UpcomingScheduleByPlayer_invalid_format():
    player_id = "90026231"
    invalid_formats = ["invalid", "csv"]
    
    for fmt in invalid_formats:
        url = f"{BASE_URL}/{fmt}/UpcomingScheduleByPlayer/{player_id}"
        
        headers = {}
        params = {}
        
        try:
            response = requests.get(url, headers=headers, params=params)
            assert response.status_code != 200
        except requests.RequestException as e:
            pytest.fail(f"Request failed: {e}")

if __name__ == "__main__":
    pytest.main([__file__])