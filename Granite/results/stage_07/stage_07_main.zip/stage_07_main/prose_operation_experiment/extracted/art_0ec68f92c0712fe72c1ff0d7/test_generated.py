import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retry strategy
session = requests.Session()
retry_strategy = Retry(
    total=3,
    backoff_factor=0.1,
    status_forcelist=[429, 500, 502, 503, 504],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

# Security keys
KEY_HEADER = "Ocp-Apim-Subscription-Key"
KEY_QUERY = "key"

@pytest.fixture
def headers():
    return {KEY_HEADER: os.environ["SUBSCRIPTION_KEY"]}

@pytest.fixture
def query_params():
    return {KEY_QUERY: os.environ["SUBSCRIPTION_KEY"]}

@pytest.mark.parametrize("format_", ["XML", "JSON"])
def test_are_games_in_progress(format_, headers, query_params):
    url = f"{BASE_URL}/{format}/AreAnyGamesInProgress"

    # Send GET request
    response = session.get(url, headers=headers, params=query_params)

    # Assert response status code
    assert response.status_code == 200

    # Assert response content type
    assert response.headers["Content-Type"] in ["application/json", "application/xml"]

    # Parse and validate response
    games_in_progress = response.json() if "application/json" in response.headers["Content-Type"] else response.text
    assert isinstance(games_in_progress, bool), "Response should be a boolean"