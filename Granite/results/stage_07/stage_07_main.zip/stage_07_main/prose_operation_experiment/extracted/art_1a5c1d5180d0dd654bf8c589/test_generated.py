import os
import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def get_project():
    def _get_project(script_id):
        url = f"{BASE_URL}/v1/projects/{script_id}"
        headers = {
            "x-goog-api-client": "gl-python",
            "x-goog-api-version": "v1",
        }

        response = requests.get(url, headers=headers)
        response.raise_for_status()

        return response.json()

    return _get_project

def test_get_project(get_project):
    script_id = "your_script_id_here"
    project = get_project(script_id)

    assert isinstance(project, dict)
    assert "createTime" in project
    assert "creator" in project
    assert "lastModifyUser" in project
    assert "parentId" in project
    assert "scriptId" in project
    assert "title" in project
    assert "updateTime" in project