# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_supported_languages():
    url = f"{BASE_URL}/v3beta1/{'projects/123456789012'}{/supportedLanguages}"
    headers = {"Content-Type": "application/json"}
    params = {
        "$.xgafv": "1",
        "access_token": "",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "",
        "oauth_token": "",
        "prettyPrint": "false",
        "quotaUser": "",
        "upload_protocol": "raw",
        "uploadType": "multipart"
    }
    params["displayLanguageCode"] = "en"
    params["model"] = ""

    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 200
    assert response.json()["languages"]