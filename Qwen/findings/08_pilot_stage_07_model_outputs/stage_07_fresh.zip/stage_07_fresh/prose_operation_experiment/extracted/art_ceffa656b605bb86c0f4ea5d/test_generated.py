import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_operations():
    url = f"{BASE_URL}/v1alpha1/projects/locations/operations"
    params = {
        "filter": "some_filter",
        "pageSize": 10,
        "pageToken": "some_page_token"
    }
    headers = {
        "Authorization": "Bearer some_access_token"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert "nextPageToken" in data
    assert isinstance(data["operations"], list)

if __name__ == "__main__":
    pytest.main()