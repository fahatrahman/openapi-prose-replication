import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_video_playlist_videos():
    playlist_id = "some_playlist_id"
    start = 0
    count = 15
    
    url = f"{BASE_URL}/api/v1/video-playlists/{playlist_id}/videos"
    params = {
        "start": start,
        "count": count
    }
    
    response = requests.get(url, params=params)
    
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "data" in response.json()
    assert "total" in response.json()

pytest.main(["-v", __file__])