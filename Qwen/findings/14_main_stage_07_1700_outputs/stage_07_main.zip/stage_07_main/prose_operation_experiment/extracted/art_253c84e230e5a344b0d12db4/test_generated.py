import pytest
import requests

BASE_URL = "http://openapi.test"

def get_server(serverid, api_key):
    headers = {
        "X-apikey": api_key,
        "X-su": api_key
    }
    url = f"{BASE_URL}/servers/{serverid}"
    response = requests.get(url, headers=headers)
    return response.json()

@pytest.mark.parametrize("serverid, expected_keys", [
    ("example-server-id-1", ["logo", "pinTimeout", "pinTransTimeout", "pingTime", "serverFlags", "serverName", "serverid", "serverpk"]),
    ("example-server-id-2", ["logo", "pinTimeout", "pinTransTimeout", "pingTime", "serverFlags", "serverName", "serverid", "serverpk"])
])
def test_get_server(serverid, expected_keys, api_key):
    server_data = get_server(serverid, api_key)
    assert all(key in server_data for key in expected_keys)

if __name__ == "__main__":
    pytest.main()