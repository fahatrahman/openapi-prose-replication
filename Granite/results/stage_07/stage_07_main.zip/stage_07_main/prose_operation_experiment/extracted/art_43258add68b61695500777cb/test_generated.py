import os
import json
import pytest
import requests

BASE_URL = "http://openapi.test"
HEADERS = {"Authorization": "Bearer <your_jwt_token>"}  # Replace with your JWT token


def get_app_category_parent(category_id, fields=None):
    url = f"{BASE_URL}/v1/appCategories/{category_id}/parent"

    params = {}
    if fields:
        params["fields[appCategories]"] = ",".join(fields)

    response = requests.get(url, headers=HEADERS, params=params)

    if response.status_code == 200:
        return response.json()
    elif response.status_code == 400 or response.status_code == 403 or response.status_code == 404:
        raise Exception(response.json())
    else:
        raise Exception(f"Unexpected status code: {response.status_code}")


@pytest.mark.parametrize(
    "category_id, fields",
    [
        ("example_id", ["parent", "platforms"]),
        ("another_example_id", ["subcategories"]),
    ],
)
def test_get_app_category_parent(category_id, fields):
    result = get_app_category_parent(category_id, fields)
    assert isinstance(result, dict)
    assert "data" in result
    assert "included" in result
    assert "links" in result