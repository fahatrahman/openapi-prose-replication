import os
import pytest
import requests
from googleapiclient.discovery import build

BASE_URL = "http://openapi.test"

@pytest.fixture
def service():
    credentials = ('YOUR_CREDENTIALS') # Replace with your actual credentials
    api_service_name = 'networkservices'
    api_version = 'v1'
    api_client = build(api_service_name, api_version, credentials=credentials)
    return api_client

def test_list_locations(service):
    project_name = 'YOUR_PROJECT_NAME' # Replace with your actual project name
    locations = service.projects().locations().list(name=project_name).execute()

    assert isinstance(locations, dict)
    assert 'locations' in locations
    assert isinstance(locations['locations'], list)
    assert all('displayName' in loc for loc in locations['locations'])