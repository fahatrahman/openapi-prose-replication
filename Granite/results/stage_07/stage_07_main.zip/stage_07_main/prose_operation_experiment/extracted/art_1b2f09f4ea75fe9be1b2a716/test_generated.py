import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.error import HTTPError

BASE_URL = "http://openapi.test"

# Create a session with a custom adapter for handling HTTP errors
session = requests.Session()
session.mount("https://", HTTPAdapter(max_retries=3))

@pytest.fixture
def method_data():
    try:
        response = session.get(
            f"{BASE_URL}/administration/model",
            headers={"Token": "Silj Psppsygwerkjbd Yiuso"},
        )
        response.raise_for_status()
        return response.json()
    except HTTPError as http_err:
        print(f"HTTP error occurred: {http_err}")
    except Exception as err:
        print(f"Other error occurred: {err}")

def test_method_data(method_data):
    assert isinstance(method_data, list)
    assert all(isinstance(item, dict) for item in method_data)
    assert set(method_data[0].keys()) == {"key", "name", "queue", "replyQueue"}