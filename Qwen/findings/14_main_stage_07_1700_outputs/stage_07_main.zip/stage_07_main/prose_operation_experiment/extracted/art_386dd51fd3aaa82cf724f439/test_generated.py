import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_site_search_engine_target_site():
    name = "zynntaco/{autfnhu}/yzvrewumc/{vmdixebo}/hgtxqpesxxu/{laercfidmz}/trmsLvclvu/{stzf_bcqvw}/fhciQaoqodQeaovr/pidwbhEvuhf/{pmjxui_wlaq}"
    url = f"{BASE_URL}/v1beta/{name}"
    params = {
        "_xgafv": "1",
        "access_token": "example_access_token",
        "alt": "json",
        "callback": "callback_value",
        "fields": "fields_value",
        "key": "example_key",
        "oauth_token": "example_oauth_token",
        "prettyPrint": False,
        "quotaUser": "quota_user_value",
        "uploadType": "upload_type_value",
        "upload_protocol": "upload_protocol_value"
    }
    headers = {
        "Authorization": "Bearer example_bearer_token"
    }
    response = requests.delete(url, params=params, headers=headers)
    assert response.status_code == 200
    assert "application/json" in response.headers["Content-Type"]
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()