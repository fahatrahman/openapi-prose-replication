import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_report_config():
    url = f"{BASE_URL}/v1/projects/location/reportConfigs"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    payload = {
        "name": "projects/location/reportConfigs/test-config",
        "displayName": "Test Report Config",
        "description": "This is a test report configuration.",
        "groupPreferencesetAssignments": [
            {
                "group": "projects/location/groups/group1",
                "preferenceSet": "projects/location/preferenceSets/set1"
            }
        ]
    }
    params = {
        "reportConfigId": "test-config",
        "$.xgafv": "1",
        "access_token": "YOUR_ACCESS_TOKEN",
        "alt": "json",
        "prettyPrint": "true",
        "quotaUser": "user@example.com",
        "uploadProtocol": "raw",
        "uploadType": "media"
    }

    response = requests.post(url, headers=headers, json=payload, params=params)
    
    assert response.status_code == 200
    assert response.json().get("name") == "projects/location/reportConfigs/test-config"
    assert response.json().get("displayName") == "Test Report Config"
    assert response.json().get("description") == "This is a test report configuration."
    assert len(response.json().get("groupPreferencesetAssignments")) == 1