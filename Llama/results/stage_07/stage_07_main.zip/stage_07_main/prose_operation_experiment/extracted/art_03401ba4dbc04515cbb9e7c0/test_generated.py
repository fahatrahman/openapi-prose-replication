# -*- coding: utf-8 -*-
"""Test the archived targets endpoint."""

import pytest
from requests.auth import HTTPBasicAuth
import json
import requests

BASE_URL = "http://openapi.test"

def test_archived_targets():
    """Test the archived targets endpoint."""
    # Create a list of target ids to archive
    target_ids = ["target_id_1", "target_id_2"]

    # Set up authentication
    auth = HTTPBasicAuth("username", "password")

    # Send a POST request to the archived targets endpoint
    response = requests.post(
        f"{BASE_URL}/targets/archived/",
        headers={"Content-Type": "application/json"},
        auth=auth,
        data=json.dumps({"targetIds": target_ids}),
    )

    # Check that the response was successful
    assert response.status_code == 200

    # Check that the response body contains a list of archived targets
    response_body = response.json()
    assert isinstance(response_body, dict)
    assert "results" in response_body
    assert all(isinstance(target, str) for target in response_body["results"])

def test_archived_targets_bad_request():
    """Test that sending invalid JSON raises a Bad Request error."""
    # Set up authentication
    auth = HTTPBasicAuth("username", "password")

    # Send a POST request to the archived targets endpoint with invalid JSON
    response = requests.post(
        f"{BASE_URL}/targets/archived/",
        headers={"Content-Type": "application/json"},
        auth=auth,
        data="invalid json",
    )

    # Check that the response was a Bad Request error
    assert response.status_code == 400

def test_archived_targets_unauthorized():
    """Test that sending a request without authentication raises an Unauthorized error."""
    # Send a POST request to the archived targets endpoint without authentication
    response = requests.post(f"{BASE_URL}/targets/archived/", headers={"Content-Type": "application/json"}, data=json.dumps({"targetIds": ["target_id"]}))

    # Check that the response was an Unauthorized error
    assert response.status_code == 401

def test_archived_targets_forbidden():
    """Test that sending a request with insufficient permissions raises a Forbidden error."""
    # Send a POST request to the archived targets endpoint with insufficient permissions
    response = requests.post(f"{BASE_URL}/targets/archived/", headers={"Content-Type": "application/json"}, data=json.dumps({"targetIds": ["target_id"]}), auth=None)

    # Check that the response was a Forbidden error
    assert response.status_code == 403