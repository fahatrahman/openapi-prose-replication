# -*- coding: utf-8 -*-

import pytest
import requests
from jsonschema import ValidationError
from jsonschema.exceptions import SchemaError
from jsonschema.exceptions import SchemaTypeError

BASE_URL = "http://openapi.test"

def test_add_user_to_offerings():
    headers = {"Authorization": "Bearer YOUR_TOKEN"}
    response = requests.post(
        f"{BASE_URL}/users/{'test_email@example.com'}/offerings",
        headers=headers,
        json=["offering_id_1", "offering_id_2"],
    )
    assert response.status_code == 200

def test_add_user_to_offerings_with_invalid_token():
    headers = {"Authorization": "Bearer INVALID_TOKEN"}
    response = requests.post(
        f"{BASE_URL}/users/{'test_email@example.com'}/offerings",
        headers=headers,
        json=["offering_id_1", "offering_id_2"],
    )
    assert response.status_code == 401

def test_add_user_to_offerings_with_missing_info():
    headers = {"Authorization": "Bearer YOUR_TOKEN"}
    response = requests.post(
        f"{BASE_URL}/users/{''}/offerings",
        headers=headers,
        json=["offering_id_1", "offering_id_2"],
    )
    assert response.status_code == 400

def test_add_user_to_offerings_with_schema_error():
    headers = {"Authorization": "Bearer YOUR_TOKEN"}
    response = requests.post(
        f"{BASE_URL}/users/{'invalid_email'}/offerings",
        headers=headers,
        json=["offering_id_1", "offering_id_2"],
    )
    assert response.status_code == 400

def test_add_user_to_offerings_with_type_error():
    headers = {"Authorization": "Bearer YOUR_TOKEN"}
    response = requests.post(
        f"{BASE_URL}/users/{123}/offerings",
        headers=headers,
        json=["offering_id_1", "offering_id_2"],
    )
    assert response.status_code == 400

def test_add_user_to_offerings_not_found():
    headers = {"Authorization": "Bearer YOUR_TOKEN"}
    response = requests.post(
        f"{BASE_URL}/users/{'non_existent_email'}/offerings",
        headers=headers,
        json=["offering_id_1", "offering_id_2"],
    )
    assert response.status_code == 404