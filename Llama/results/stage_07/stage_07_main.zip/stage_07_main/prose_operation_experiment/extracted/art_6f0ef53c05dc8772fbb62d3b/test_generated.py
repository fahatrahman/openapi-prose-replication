# pytest_operation.py
import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_DescribeConfigurationRevision():
    # Generate timestamp for AWS SigV4 signing
    timestamp = datetime.utcnow().isoformat() + 'Z'

    headers = {
        'X-Amz-Algorithm': 'AWS4-HMAC-SHA256',
        'X-Amz-Content-Sha256': 'UNSIGNED-PAYLOAD',
        'X-Amz-Date': timestamp,
        'X-Amz-Security-Token': '',
        'X-Amz-SignedHeaders': 'host;x-amz-date'
    }

    response = requests.get(
        f"{BASE_URL}/v1/configurations/configuration-id/revisions/configuration-revision",
        headers=headers,
        verify=False
    )

    assert response.status_code == 200