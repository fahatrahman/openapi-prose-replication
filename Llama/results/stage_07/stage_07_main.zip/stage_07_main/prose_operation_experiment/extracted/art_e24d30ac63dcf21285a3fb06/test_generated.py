# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_volume_list():
    """Test listing volumes"""
    params = {
        "filters": "{}"
    }
    response = requests.get(f"{BASE_URL}/volumes", params=params)
    assert response.status_code == 200
    response.raise_for_status()
    result = response.json()
    assert isinstance(result["Volumes"], list)
    assert isinstance(result["Warnings"], list)

def test_volume_list_dangling_true():
    """Test listing dangling volumes"""
    params = {
        "filters": "{\"dangling=true\"}"
    }
    response = requests.get(f"{BASE_URL}/volumes", params=params)
    assert response.status_code == 200
    response.raise_for_status()
    result = response.json()
    assert isinstance(result["Volumes"], list)
    assert isinstance(result["Warnings"], list)

def test_volume_list_dangling_false():
    """Test listing non-dangling volumes"""
    params = {
        "filters": "{\"dangling=false\"}"
    }
    response = requests.get(f"{BASE_URL}/volumes", params=params)
    assert response.status_code == 200
    response.raise_for_status()
    result = response.json()
    assert isinstance(result["Volumes"], list)
    assert isinstance(result["Warnings"], list)

def test_volume_list_driver_local():
    """Test listing volumes by driver"""
    params = {
        "filters": "{\"driver=local\"}"
    }
    response = requests.get(f"{BASE_URL}/volumes", params=params)
    assert response.status_code == 200
    response.raise_for_status()
    result = response.json()
    assert isinstance(result["Volumes"], list)
    assert isinstance(result["Warnings"], list)

def test_volume_list_label_key():
    """Test listing volumes by label key"""
    params = {
        "filters": "{\"label=com.example.some-label\"}"
    }
    response = requests.get(f"{BASE_URL}/volumes", params=params)
    assert response.status_code == 200
    response.raise_for_status()
    result = response.json()
    assert isinstance(result["Volumes"], list)
    assert isinstance(result["Warnings"], list)

def test_volume_list_name():
    """Test listing volumes by name"""
    params = {
        "filters": "{\"name=tardis\"}"
    }
    response = requests.get(f"{BASE_URL}/volumes", params=params)
    assert response.status_code == 200
    response.raise_for_status()
    result = response.json()
    assert isinstance(result["Volumes"], list)
    assert isinstance(result["Warnings"], list)