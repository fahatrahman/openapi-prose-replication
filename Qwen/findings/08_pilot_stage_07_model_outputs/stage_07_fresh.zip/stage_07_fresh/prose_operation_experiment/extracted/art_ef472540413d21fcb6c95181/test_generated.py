import pytest
import requests

BASE_URL = "http://openapi.test"

def test_transform_list_tool():
    url = f"{BASE_URL}/transform/list/tool/mt/dictionary"
    response = requests.get(url)
    
    assert response.status_code == 200
    assert 'application/json' in response.headers['Content-Type']
    data = response.json()
    assert isinstance(data, dict)

def test_transform_list_tool_error():
    url = f"{BASE_URL}/transform/list/tool/invalid/invalid"
    response = requests.get(url)
    
    assert response.status_code >= 400
    assert 'application/problem+json' in response.headers['Content-Type']
    problem_data = response.json()
    assert isinstance(problem_data, dict)
    assert 'type' in problem_data
    assert problem_data['type'] == 'about:blank'