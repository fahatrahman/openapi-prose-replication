import pytest
import requests

BASE_URL = "http://openapi.test"

def test_rollback_function_upgrade_traffic():
    url = f"{BASE_URL}/v2/projects/location/functions/rollbackFunctionUpgradeTraffic"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        # Add request body payload here if needed
    }
    params = {
        "_xgafv": "2",
        "access_token": "YOUR_ACCESS_TOKEN",
        "alt": "json",
        "callback": "YOUR_CALLBACK_URL",
        "fields": "YOUR_FIELDS",
        "key": "YOUR_KEY",
        "oauth_token": "YOUR_OAUTH_TOKEN",
        "prettyPrint": True,
        "quotaUser": "YOUR_QUOTA_USER",
        "uploadType": "media",
        "upload_protocol": "raw"
    }

    response = requests.post(url, headers=headers, json=payload, params=params)

    assert response.status_code == 200
    assert "Operation" in response.json()

if __name__ == "__main__":
    pytest.main()