import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_live_plays():
    url = f"{BASE_URL}/live/plays"
    params = {"id": 123}  # Replace with actual parameter value
    headers = {
        "Authorization": "Bearer YOUR_API_KEY"  # Replace with actual API key
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    for item in data:
        assert isinstance(item, dict)
        assert "clock" in item
        assert "distance" in item
        assert "down" in item
        assert "drives" in item
        assert "id" in item
        assert "period" in item
        assert "possession" in item
        assert "status" in item
        assert "teams" in item
        assert "yardsToGoal" in item
        drives = item["drives"]
        assert isinstance(drives, list)
        for drive in drives:
            assert isinstance(drive, dict)
            assert "defense" in drive
            assert "defenseId" in drive
            assert "duration" in drive
            assert "endClock" in drive
            assert "endPeriod" in drive
            assert "endYardsToGoal" in drive
            assert "id" in drive
            assert "offense" in drive
            assert "offenseId" in drive
            assert "playCount" in drive
            assert "plays" in drive
            plays = drive["plays"]
            assert isinstance(plays, list)
            for play in plays:
                assert isinstance(play, dict)
                assert "awayScore" in play
                assert "clock" in play
                assert "distance" in play
                assert "down" in play
                assert "downType" in play
                assert "epa" in play
                assert "garbageTime" in play
                assert "homeScore" in play
                assert "id" in play
                assert "period" in play
                assert "playText" in play
                assert "playType" in play
                assert "playTypeId" in play
                assert "rushPass" in play
                assert "success" in play
                assert "team" in play
                assert "teamId" in play
                assert "wallclock" in play
                assert "yardsGained" in play
                assert "yardsToGoal" in play