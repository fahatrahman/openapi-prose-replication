import pytest
import requests
from jsonschema import validate

BASE_URL = "http://openapi.test"

def test_get_analyzed_recipe_instructions():
    id = 324694
    step_breakdown = True
    headers = {"x-api-key": "your_api_key"}
    url = f"{BASE_URL}/recipes/{id}/analyzedInstructions"
    
    response = requests.get(url, params={"stepBreakdown": step_breakdown}, headers=headers)
    
    assert response.status_code == 200
    
    try:
        schema = {
            "type": "object",
            "properties": {
                "equipment": {"type": "array", "items": {"type": "object"}},
                "ingredients": {"type": "array", "items": {"type": "object"}},
                "parsedInstructions": {"type": "array", "items": {"type": "object"}}
            },
            "required": ["equipment", "ingredients", "parsedInstructions"]
        }
        
        validate(response.json(), schema)
    except Exception as e:
        print(f"JSON schema validation failed: {str(e)}")
        raise
        
def test_get_analyzed_recipe_instructions_401():
    id = 324694
    step_breakdown = True
    headers = {}
    url = f"{BASE_URL}/recipes/{id}/analyzedInstructions"
    
    response = requests.get(url, params={"stepBreakdown": step_breakdown}, headers=headers)
    
    assert response.status_code == 401

def test_get_analyzed_recipe_instructions_403():
    id = 324694
    step_breakdown = True
    headers = {"x-api-key": "invalid_api_key"}
    url = f"{BASE_URL}/recipes/{id}/analyzedInstructions"
    
    response = requests.get(url, params={"stepBreakdown": step_breakdown}, headers=headers)
    
    assert response.status_code == 403

def test_get_analyzed_recipe_instructions_404():
    id = 999999
    step_breakdown = True
    headers = {"x-api-key": "your_api_key"}
    url = f"{BASE_URL}/recipes/{id}/analyzedInstructions"
    
    response = requests.get(url, params={"stepBreakdown": step_breakdown}, headers=headers)
    
    assert response.status_code == 404