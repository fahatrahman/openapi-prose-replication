import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_live_plays():
    params = {
        'id': 12345  # Replace with actual game ID
    }
    headers = {
        'Authorization': 'Bearer your_api_key_here'  # Replace with actual API key
    }
    response = requests.get(f"{BASE_URL}/live/plays", params=params, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert 'id' in data
    assert 'period' in data
    assert 'possession' in data
    assert 'status' in data
    assert 'teams' in data
    assert 'yardsToGoal' in data
    for team in data['teams']:
        assert 'drives' in team
        assert 'epaPerPass' in team
        assert 'epaPerPlay' in team
        assert 'epaPerRush' in team
        assert 'explosiveness' in team
        assert 'homeAway' in team
        assert 'lineYards' in team
        assert 'lineYardsPerRush' in team
        assert 'openFieldYards' in team
        assert 'openFieldYardsPerRush' in team
        assert 'passingDownSuccessRate' in team
        assert 'passingEpa' in team
        assert 'plays' in team
        assert 'points' in team
        assert 'pointsPerOpportunity' in team
        assert 'rushingEpa' in team
        assert 'scoringOpportunities' in team
        assert 'secondLevelYards' in team
        assert 'secondLevelYardsPerRush' in team
        assert 'standardDownSuccessRate' in team
        assert 'successRate' in team
        assert 'totalEpa' in team
    for drive in data['drives']:
        assert 'defense' in drive
        assert 'defenseId' in drive
        assert 'duration' in drive
        assert 'endClock' in drive
        assert 'endPeriod' in drive
        assert 'endYardsToGoal' in drive
        assert 'id' in drive
        assert 'offense' in drive
        assert 'offenseId' in drive
        assert 'playCount' in drive
        assert 'plays' in drive
        for play in drive['plays']:
            assert 'awayScore' in play
            assert 'clock' in play
            assert 'distance' in play
            assert 'down' in play
            assert 'downType' in play
            assert 'epa' in play
            assert 'garbageTime' in play
            assert 'homeScore' in play
            assert 'id' in play
            assert 'period' in play
            assert 'playText' in play
            assert 'playType' in play
            assert 'playTypeId' in play
            assert 'rushPass' in play
            assert 'success' in play
            assert 'team' in play
            assert 'teamId' in play
            assert 'wallclock' in play
            assert 'yardsGained' in play
            assert 'yardsToGoal' in play
    assert isinstance(data['plays'], list)
    for play in data['plays']:
        assert 'awayScore' in play
        assert 'clock' in play
        assert 'distance' in play
        assert 'down' in play
        assert 'downType' in play
        assert 'epa' in play
        assert 'garbageTime' in play
        assert 'homeScore' in play
        assert 'id' in play
        assert 'period' in play
        assert 'playText' in play
        assert 'playType' in play
        assert 'playTypeId' in play
        assert 'rushPass' in play
        assert 'success' in play
        assert 'team' in play
        assert 'teamId' in play
        assert 'wallclock' in play
        assert 'yardsGained' in play
        assert 'yardsToGoal' in play
    assert isinstance(data['clock'], str)
    assert isinstance(data['distance'], int)
    assert isinstance(data['down'], int)
    assert isinstance(data['scoringOpportunity'], bool)
    assert isinstance(data['startClock'], str)
    assert isinstance(data['startPeriod'], int)
    assert isinstance(data['startYardsToGoal'], int)
    assert isinstance(data['yards'], int)

if __name__ == "__main__":
    pytest.main()