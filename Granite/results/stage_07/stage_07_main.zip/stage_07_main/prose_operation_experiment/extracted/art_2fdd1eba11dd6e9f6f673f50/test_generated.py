import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_FILE = "credentials.json"

@pytest.fixture
def auth():
    credentials = service_account.Credentials.from_service_account_file(
        CREDENTIALS_FILE, scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )
    return credentials

def test_list_featurestores(auth):
    url = f"{BASE_URL}/v1/{os.environ['PROJECT']}/{os.environ['LOCATION']}/featurestores"

    headers = {
        "Authorization": f"Bearer {auth.token}",
    }

    response = requests.get(url, headers=headers)
    assert response.status_code == 200

    featurestores = response.json()["featurestores"]
    # Add further assertions based on expected featurestore data