import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = "path/to/your/service_account.json"

@pytest.fixture
def auth():
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=["https://www.googleapis.com/auth/apps.order"]
    )
    return credentials

def test_list_billable_skus(auth):
    path = "/v1/{parent}/billableSkus"
    parent = "tjnnzcqy/oppVgeaep/6H1J-6634-470O"
    page_size = 100000
    page_token = ""

    headers = {
        "Accept": "application/json",
    }

    url = f"{BASE_URL}{path}".replace("{parent}", parent)

    response = requests.get(url, headers=headers, auth=auth)

    if response.status_code == 200:
        result = response.json()
        assert isinstance(result, dict)
        assert "billableSkus" in result
        assert isinstance(result["billableSkus"], list)
        assert "nextPageToken" in result
    else:
        print(f"Request failed with status code {response.status_code}")