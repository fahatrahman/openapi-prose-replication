import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def headers():
    return {
        "X-API-Token": "your_api_token_here"
    }

def test_distributionGroups_detailsForOrg(headers):
    org_name = "test_org"
    params = {"apps_limit": 10}
    url = f"{BASE_URL}/v0.1/orgs/{org_name}/distribution_groups_details"
    
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    for item in data:
        assert "id" in item
        assert "name" in item
        assert "origin" in item
        assert "is_public" in item
        assert "apps" in item
        assert "total_users_count" in item
        assert "total_apps_count" in item
        for app in item["apps"]:
            assert "id" in app
            assert "display_name" in app
            assert "name" in app
            assert "os" in app
            assert "owner" in app
            assert "release_type" in app
            assert "app_secret" in app
            assert "azure_subscription" in app
            assert "created_at" in app
            assert "member_permissions" in app
            assert "origin" in app
            assert "platform" in app
            assert "updated_at" in app
            assert "icon_source" in app
            assert "icon_url" in app
            assert "description" in app
            assert "owner" in app
            assert "avatar_url" in app
            assert "display_name" in app
            assert "email" in app
            assert "id" in app
            assert "name" in app
            assert "type" in app
            assert "is_billable" in app
            assert "is_billing" in app
            assert "is_microsoft_internal" in app
            assert "subscription_id" in app
            assert "subscription_name" in app
            assert "tenant_id" in app

if __name__ == "__main__":
    pytest.main()