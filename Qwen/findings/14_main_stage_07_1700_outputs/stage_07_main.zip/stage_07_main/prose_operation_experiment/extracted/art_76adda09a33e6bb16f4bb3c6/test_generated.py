import pytest
import requests

BASE_URL = "http://openapi.test"

def test_comptage():
    url = f"{BASE_URL}/comptage"
    payload = {
        "comptage": "1",
        "emetteur": "iSendPro",
        "keyid": "VOTRE_KEYID",
        "num": "0600123456",
        "sms": "Bonjour! Bienvenue sur iSendPro!"
    }
    headers = {
        "Content-Type": "application/json"
    }
    response = requests.post(url, json=payload, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert "etat" in data
    assert "nb_caractere" in data["etat"]
    assert "nb_sms" in data["etat"]
    assert "tel" in data["etat"]

def test_comptage_error():
    url = f"{BASE_URL}/comptage"
    payload = {
        "comptage": "invalid",
        "emetteur": "iSendPro",
        "keyid": "VOTRE_KEYID",
        "num": "0600123456",
        "sms": "Bonjour! Bienvenue sur iSendPro!"
    }
    headers = {
        "Content-Type": "application/json"
    }
    response = requests.post(url, json=payload, headers=headers)
    assert response.status_code == 400
    data = response.json()
    assert "erreur" in data
    assert "code" in data["erreur"]
    assert "message" in data["erreur"]