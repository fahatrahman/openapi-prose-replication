import pytest
import requests

BASE_URL = "http://openapi.test"

def get_task(task_id):
    headers = {
        'Authorization': f'Bearer {your_access_token}'  # Replace with actual access token
    }
    response = requests.get(f"{BASE_URL}/org/tasks/{task_id}", headers=headers)
    return response.json()

@pytest.mark.parametrize("task_id", ["e77602e0-3fb8-4734-aef9-fbc6fdcb0fa8"])
def test_get_task(task_id):
    response = get_task(task_id)
    assert response['status'] == 'processed'
    assert 'id' in response
    assert isinstance(response['id'], str)

def test_get_task_unauthorized():
    headers = {}
    response = requests.get(f"{BASE_URL}/org/tasks/e77602e0-3fb8-4734-aef9-fbc6fdcb0fa8", headers=headers)
    assert response.status_code == 401
    assert response.json() == {"description": "Access token is missing or invalid"}