from __future__ import annotations

from collections import defaultdict
import math
import random


STATISTICS_VERSION = (
    "stage06-paired-family-cluster-analysis-v1"
)

STRATA = (
    "low",
    "medium",
    "high",
)


def weighted_stratum_effect(
    rows,
    population_shares,
    conditional=False,
):
    """
    Calculate the design-weighted L1-L0 contrast.

    Required row fields:
        stratum, family_id, d, pi

    d is the paired difference.
    pi is the operation inclusion probability.
    """
    usable_rows = [
        row
        for row in rows
        if row.get("d") is not None
    ]

    represented_strata = sorted({
        row["stratum"]
        for row in usable_rows
    })

    if (
        not usable_rows
        or any(
            stratum not in STRATA
            for stratum in represented_strata
        )
    ):
        raise ValueError(
            "No estimable stratified observations."
        )

    stratum_effects = {}
    stratum_weight_totals = {}

    for stratum in represented_strata:
        subset = [
            row
            for row in usable_rows
            if row["stratum"] == stratum
        ]

        weights = [
            1.0 / float(row["pi"])
            for row in subset
        ]

        if (
            not subset
            or min(weights) <= 0
        ):
            raise ValueError(
                "Invalid inclusion probability."
            )

        total_weight = sum(
            weights
        )

        stratum_weight_totals[
            stratum
        ] = total_weight

        stratum_effects[
            stratum
        ] = (
            sum(
                weight * float(row["d"])
                for weight, row in zip(
                    weights,
                    subset,
                )
            )
            / total_weight
        )

    if (
        not conditional
        and set(represented_strata)
        != set(STRATA)
    ):
        raise ValueError(
            "A target stratum is missing."
        )

    if conditional:
        grand_total = sum(
            stratum_weight_totals.values()
        )

        target_weights = {
            stratum: (
                stratum_weight_totals[stratum]
                / grand_total
            )
            for stratum in represented_strata
        }

    else:
        target_weights = {
            stratum: float(
                population_shares[stratum]
            )
            for stratum in represented_strata
        }

    if abs(
        sum(target_weights.values()) - 1
    ) > 1e-9:
        raise ValueError(
            "Target stratum shares do not sum to one."
        )

    effect = sum(
        target_weights[stratum]
        * stratum_effects[stratum]
        for stratum in represented_strata
    )

    return {
        "effect": effect,
        "stratum_effects": stratum_effects,
        "target_shares": target_weights,
        "stratum_weight_totals": (
            stratum_weight_totals
        ),
    }


def family_cluster_standard_error(
    rows,
    population_shares,
    conditional=False,
):
    """
    Family-clustered CR1 sandwich variance.

    Correction:
        G/(G-1) * (n-1)/(n-k)
    """
    usable_rows = [
        row
        for row in rows
        if row.get("d") is not None
    ]

    effect_record = weighted_stratum_effect(
        usable_rows,
        population_shares,
        conditional=conditional,
    )

    stratum_effects = effect_record[
        "stratum_effects"
    ]

    target_weights = effect_record[
        "target_shares"
    ]

    H = effect_record[
        "stratum_weight_totals"
    ]

    n = len(
        usable_rows
    )

    families = {
        row["family_id"]
        for row in usable_rows
    }

    G = len(families)
    k = len(stratum_effects)

    if G <= 1 or n <= k:
        raise ValueError(
            "Insufficient families or residual degrees of freedom."
        )

    family_scores = defaultdict(
        lambda: defaultdict(float)
    )

    for row in usable_rows:
        stratum = row["stratum"]
        family_id = row["family_id"]

        weight = (
            1.0 / float(row["pi"])
        )

        residual = (
            float(row["d"])
            - stratum_effects[stratum]
        )

        family_scores[
            family_id
        ][stratum] += (
            weight * residual
        )

    correction = (
        G / (G - 1)
    ) * (
        (n - 1) / (n - k)
    )

    variance = correction * sum(
        (
            sum(
                target_weights[stratum]
                * scores.get(stratum, 0.0)
                / H[stratum]
                for stratum in stratum_effects
            )
        ) ** 2
        for scores in family_scores.values()
    )

    if (
        variance <= 0
        or not math.isfinite(variance)
    ):
        raise ValueError(
            "Cluster variance is not estimable."
        )

    return {
        **effect_record,
        "standard_error": math.sqrt(
            variance
        ),
        "variance": variance,
        "family_count": G,
        "pair_count": n,
        "small_sample_correction": correction,
        "degrees_of_freedom": G - 1,
    }


def primary_t_inference(
    rows,
    population_shares,
    conditional=False,
):
    from scipy.stats import t

    result = family_cluster_standard_error(
        rows,
        population_shares,
        conditional=conditional,
    )

    df = result[
        "degrees_of_freedom"
    ]

    effect = result[
        "effect"
    ]

    se = result[
        "standard_error"
    ]

    critical = float(
        t.ppf(
            0.975,
            df,
        )
    )

    p_value = float(
        2 * t.sf(
            abs(effect / se),
            df,
        )
    )

    result.update({
        "pointwise_ci_lower": (
            effect - critical * se
        ),
        "pointwise_ci_upper": (
            effect + critical * se
        ),
        "two_sided_p_value": p_value,
    })

    return result


def holm_adjustment(
    p_values,
):
    ordered = sorted(
        p_values,
        key=p_values.get,
    )

    adjusted = {}
    running_maximum = 0.0

    m = len(
        ordered
    )

    for index, endpoint in enumerate(
        ordered
    ):
        p = float(
            p_values[endpoint]
        )

        if not 0 <= p <= 1:
            raise ValueError(
                "Invalid p-value."
            )

        candidate = min(
            1.0,
            (m - index) * p,
        )

        running_maximum = max(
            running_maximum,
            candidate,
        )

        adjusted[endpoint] = (
            running_maximum
        )

    return adjusted


def family_multiplier_interval(
    rows,
    population_shares,
    seed=20261105,
    draws=10000,
    conditional=False,
):
    """
    Family-shared exponential multiplier bootstrap.

    Exponential multipliers have mean one,
    variance one, and remain nonnegative.
    """
    usable_rows = [
        row
        for row in rows
        if row.get("d") is not None
    ]

    families = sorted({
        row["family_id"]
        for row in usable_rows
    })

    if (
        len(families) < 2
        or draws < 100
    ):
        raise ValueError(
            "Insufficient bootstrap information."
        )

    generator = random.Random(
        seed
    )

    bootstrap_effects = []

    for _ in range(draws):
        multipliers = {
            family_id: generator.expovariate(
                1.0
            )
            for family_id in families
        }

        by_stratum = defaultdict(
            lambda: [0.0, 0.0]
        )

        for row in usable_rows:
            weight = (
                multipliers[row["family_id"]]
                / float(row["pi"])
            )

            values = by_stratum[
                row["stratum"]
            ]

            values[0] += (
                weight * float(row["d"])
            )

            values[1] += weight

        if any(
            values[1] <= 0
            for values in by_stratum.values()
        ):
            raise ValueError(
                "Zero bootstrap stratum weight."
            )

        if conditional:
            total_weight = sum(
                values[1]
                for values in by_stratum.values()
            )

            target_weights = {
                stratum: values[1] / total_weight
                for stratum, values
                in by_stratum.items()
            }

        else:
            if (
                set(by_stratum)
                != set(population_shares)
            ):
                raise ValueError(
                    "Bootstrap missing target stratum."
                )

            target_weights = (
                population_shares
            )

        effect = sum(
            float(target_weights[stratum])
            * values[0]
            / values[1]
            for stratum, values
            in by_stratum.items()
        )

        bootstrap_effects.append(
            effect
        )

    bootstrap_effects.sort()

    def quantile(probability):
        index = (
            probability
            * (len(bootstrap_effects) - 1)
        )

        lower = int(
            index
        )

        upper = min(
            lower + 1,
            len(bootstrap_effects) - 1,
        )

        fraction = (
            index - lower
        )

        return (
            bootstrap_effects[lower]
            + fraction
            * (
                bootstrap_effects[upper]
                - bootstrap_effects[lower]
            )
        )

    return {
        "lower": quantile(0.025),
        "upper": quantile(0.975),
        "draws": draws,
        "seed": seed,
        "family_multiplier": (
            "exponential_mean1_variance1"
        ),
    }
