import os
import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def area_model_results():
    short_name = "example_short_name"
    offset = 0
    count = 10

    url = f"{BASE_URL}/v2/tier1/{short_name}/area/areas"
    response = requests.get(url, params={"offset": offset, "count": count})

    assert response.status_code == 200
    return response.json()

def test_area_model_results(area_model_results):
    result = area_model_results
    assert isinstance(result, dict)
    assert "Count" in result
    assert "Data" in result
    assert isinstance(result["Data"], list)
    assert all(isinstance(item, dict) for item in result["Data"])