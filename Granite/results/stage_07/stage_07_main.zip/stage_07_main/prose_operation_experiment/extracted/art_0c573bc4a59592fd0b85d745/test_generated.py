import os
import pytest
import requests
from googleapiclient.discovery import build

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def service():
    api_service_name = "workstations"
    api_version = "v1"
    credentials = None  # Replace this with actual credentials if needed

    service = build(api_service_name, api_version, developerKey=credentials)
    return service

def test_list_operations(service):
    project_id = "your_project_id"  # Replace this with your actual project id
    name = f"projects/{project_id}"

    response = service.projects().locations().operations().list(
        name=name, filter="status:RUNNING", pageSize=10, pageToken=None
    ).execute()

    assert isinstance(response, dict)
    assert "operations" in response
    assert isinstance(response["operations"], list)