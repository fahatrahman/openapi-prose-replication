import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
SESSION.mount("https://", HTTPAdapter(max_retries=3))
SESSION.mount("http://", HTTPAdapter(max_retries=3))

@pytest.fixture
def api_key():
    return os.environ["API_KEY"]

@pytest.fixture
def headers():
    return {"Training-Key": api_key()}

def test_query_prediction_results(api_key):
    project_id = "bc3f7dad-5544-468c-8573-3ef04d55463e"
    response = SESSION.post(
        urljoin(BASE_URL, f"/projects/{project_id}/predictions/query"),
        json={"Token": {
            "Session": "1:286613",
            "MaxCount": 0,
            "OrderBy": "Newest",
            "Tags": [{"Id": "b5f7e6a2-a481-49a6-afec-a7cef1af3544", "MaxThreshold": 1, "MinThreshold": 0.9}]
        }},
        headers=headers(),
    )

    assert response.status_code == 200
    result = response.json()

    # Add additional assertions based on expected results
    assert result["Results"][0]["Predictions"][0]["Tag"] == "Tag 1"
    assert result["Results"][0]["Predictions"][1"]["Tag"] == "Tag 2"