# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_series():
    serie_id = "your-serie-id"
    url = f"{BASE_URL}/series/{serie_id}"
    response = requests.get(url)
    assert response.status_code == 200
    serie = response.json()
    assert serie["id"]
    assert serie["name"]
    assert serie["sets"]

def test_get_series_not_found():
    serie_id = "non-existent-serie-id"
    url = f"{BASE_URL}/series/{serie_id}"
    response = requests.get(url)
    assert response.status_code == 404

if __name__ == "__main__":
    pytest.main([__file__, "-s"])