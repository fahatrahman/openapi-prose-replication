import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
SESSION.mount("https://", HTTPAdapter(max_retries=3))
SESSION.mount("http://", HTTPAdapter(max_retries=3))

@pytest.fixture
def workspace_data():
    return {
        "collections": [
            {"id": "e1fc3c38-a0b8-44a3-bd44-d753a96b2e9d", "name": "Straw hats", "uid": "8154-e1fc3c38-a0b8-44a3-bd44-d753a96b2e9d"},
        ],
        "description": "Some description",
        "environments": [
            {"id": "83a1aaa2-a204-4bd8-9b92-4d486918906b", "name": "env", "uid": "8154-83a1aaa2-a204-4bd8-9b92-4d486918906b"},
        ],
        "mocks": [{"id": "cda672ef-1375-40e9-baee-e20ece8d7b65"}],
        "monitors": [{"id": "1e889bd2-3862-4be0-b2c2-9b1fe9673aec"}],
        "name": "New Workspace",
        "type": "personal"
    }

def test_create_workspace(workspace_data):
    url = urljoin(BASE_URL, "/workspaces")
    headers = {"X-Api-Key": "your_api_key"}  # Replace 'your_api_key' with your actual API key

    response = SESSION.post(url, json=workspace_data, headers=headers)
    assert response.status_code == 200

    result = response.json()
    assert result["workspace"]["name"] == "New Workspace"
    assert result["workspace"]["id"] is not None