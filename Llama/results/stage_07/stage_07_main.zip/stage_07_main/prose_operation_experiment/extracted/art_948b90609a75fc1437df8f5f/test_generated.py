# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_vault_operations_delete():
    url = f"{BASE_URL}/v1/{'test_name'}"
    params = {
        '$.xgafv': '1',
        'access_token': '',
        'alt': 'json',
        'callback': '',
        'fields': '',
        'key': '',
        'oauth_token': '',
        'prettyPrint': 'false',
        'quotaUser': '',
        'upload_protocol': 'raw',
        'uploadType': 'media'
    }
    response = requests.request('DELETE', url, params=params)
    assert response.status_code == 200