import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_restaurant_service_times():
    url = f"{BASE_URL}/restaurants/example_tenant/example_restaurant_id/servicetimes"
    headers = {
        "Accept": "application/json",
        "Cache-Control": "no-cache"
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert "Content-Type" in response.headers and response.headers["Content-Type"] == "application/json"
    assert "cache-control" in response.headers
    
    service_times = response.json()
    assert "serviceTimes" in service_times
    assert "monday" in service_times["serviceTimes"]
    assert "collection" in service_times["serviceTimes"]["monday"]
    assert "delivery" in service_times["serviceTimes"]["monday"]

if __name__ == "__main__":
    pytest.main()