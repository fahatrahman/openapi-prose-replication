import os
import pytest
import requests
from requests.exceptions import HTTPError

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def auth():
    """Authenticate with basic auth."""
    auth = ('admin', 'password')
    return auth

def test_read_float_vars(auth):
    """Test reading float variables."""
    headers = {"Authorization": "Basic " + str(auth[0]) + ":" + str(auth[1])}

    response = requests.get(f"{BASE_URL}/device/strategy/vars/floats", headers=headers)

    # Check if request was successful
    response.raise_for_status()

    # Parse JSON response
    float_vars = response.json()

    assert isinstance(float_vars, list)
    for var in float_vars:
        assert isinstance(var, dict)
        assert "name" in var and "value" in var
        assert isinstance(var["name"], str) and len(var["name"]) <= 50
        assert isinstance(var["value"], float)
