import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_dynamic_targeting_keys():
    url = f"{BASE_URL}/userprofiles/{pytest.profile_id}/dynamicTargetingKeys"
    params = {
        "profileId": pytest.profile_id,
        "advertiserId": pytest.advertiser_id,
        "names": pytest.names,
        "objectId": pytest.object_id,
        "objectType": pytest.object_type
    }
    headers = {
        "Authorization": f"Bearer {pytest.access_token}"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    assert "dynamicTargetingKeys" in response.json()
    assert "kind" in response.json() and response.json()["kind"] == "dfareporting#dynamicTargetingKeysListResponse"