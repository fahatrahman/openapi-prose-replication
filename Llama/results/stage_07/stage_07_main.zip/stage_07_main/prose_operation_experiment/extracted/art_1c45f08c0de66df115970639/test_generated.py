# -*- coding: utf-8 -*-
import pytest
import requests

BASE_URL = "http://openapi.test"

def test_key_retrieve():
    PK = "test_pk"
    url = f"{BASE_URL}/key/{PK}"
    response = requests.get(url)
    assert response.status_code == 200
    data = response.json()
    assert "since" in data
    assert "status" in data
    assert "sub" in data

def test_key_retrieve_404():
    PK = ""
    url = f"{BASE_URL}/key/{PK}"
    response = requests.get(url)
    assert response.status_code == 404
    data = response.json()
    assert "error" in data
    assert "title" in data
    assert "type" in data
    assert "detail" in data

def test_key_retrieve_410():
    PK = None
    url = f"{BASE_URL}/key/{PK}"
    response = requests.get(url)
    assert response.status_code == 410
    data = response.json()
    assert "error" in data
    assert "title" in data
    assert "type" in data
    assert "detail" in data

def test_key_retrieve_default():
    PK = "non_existent_PK"
    url = f"{BASE_URL}/key/{PK}"
    response = requests.get(url)
    assert response.status_code >= 400
    data = response.json()
    assert "error" in data
    assert "title" in data
    assert "type" in data
    assert "detail" in data