import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
session.mount("http://", adapter)
session.mount("https://", adapter)

@pytest.fixture
def test_payload():
    return {}

def test_get_payees_invitation_status_v4(test_payload):
    """Test GET /v4/payees/payors/{payorId}/invitationStatus"""

    headers = {"Authorization": "Bearer YOUR_ACCESS_TOKEN"}
    params = {
        "payorId": "f20b038b-e841-4d80-9175-b47c6cf19bc1",
        "invitationStatus": "ACCEPTED",
        "page": 1,
        "pageSize": 25,
    }

    response = session.get(f"{BASE_URL}/v4/payees/payors/{params['payorId']}/invitationStatus", headers=headers, params=params)

    if response.status_code == 200:
        assert response.json()["page"]["numberOfElements"] > 0
        assert isinstance(response.json()["page"]["totalElements"], int)
        assert isinstance(response.json()["page"]["totalPages"], int)
        assert isinstance(response.json()["content"], list)
        assert all(isinstance(item, dict) for item in response.json()["content"])
        assert all("payeeId" in item for item in response.json()["content"])
    elif response.status_code == 400:
        assert "errors" in response.json()
        assert len(response.json()["errors"]) >= 1
    elif response.status_code == 401:
        assert "errors" in response.json()
        assert len(response.json()["errors"]) >= 1
    elif response.status_code == 403:
        assert "errors" in response.json()
        assert len(response.json()["errors"]) >= 1
    elif response.status_code == 404:
        assert "errors" in response.json()
        assert len(response.json()["errors"]) >= 1
    else:
        raise Exception(f"Unexpected status code: {response.status_code}")