import pytest
import requests

BASE_URL = "http://openapi.test"

def test_post_cancels():
    url = f"{BASE_URL}/cancels"
    headers = {"Idempotency-Key": "test_idempotency_key"}
    payload = {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "paymentReference": "YOUR_UNIQUE_REFERENCE_FOR_THE_PAYMENT",
        "reference": "YOUR_UNIQUE_REFERENCE_FOR_THE_CANCELLATION"
    }

    response = requests.post(url, json=payload, headers=headers)
    assert response.status_code == 201

    response = requests.post(url, json=payload, headers=headers)
    assert response.status_code == 409  # Idempotent request

    response = requests.post(url, json={"invalid": "payload"}, headers=headers)
    assert response.status_code == 422

    response = requests.post(url, auth=("username", "password"), headers=headers)
    assert response.status_code == 401

    response = requests.post(url, headers=headers)
    assert response.status_code == 401

    response = requests.post(url, json=payload, headers=headers, timeout=0.01)
    assert response.status_code in [408, 500]

@pytest.mark.parametrize("code,expected_status", [
    (400, 400),
    (401, 401),
    (403, 403),
    (422, 422),
    (500, 500)
])
def test_post_cancels_error(code):
    url = f"{BASE_URL}/cancels"
    headers = {"Idempotency-Key": "test_idempotency_key"}
    payload = {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "paymentReference": "YOUR_UNIQUE_REFERENCE_FOR_THE_PAYMENT",
        "reference": "YOUR_UNIQUE_REFERENCE_FOR_THE_CANCELLATION"
    }
    response = requests.post(url, json=payload, headers=headers)
    assert response.status_code == code