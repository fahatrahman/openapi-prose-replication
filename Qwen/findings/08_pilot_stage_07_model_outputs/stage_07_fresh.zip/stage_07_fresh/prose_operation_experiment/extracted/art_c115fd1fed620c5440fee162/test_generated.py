import pytest
import requests

BASE_URL = "http://openapi.test"

def test_check_domain_verify_success():
    headers = {
        "Authorization": "Bearer your_access_token_here"
    }
    params = {
        "domain": "example.com"
    }
    response = requests.post(f"{BASE_URL}/domains/verify/{params['domain']}", headers=headers)
    assert response.status_code == 200
    assert response.json() == {"id": "example.com", "success": True}

def test_check_domain_verify_bad_request():
    headers = {
        "Authorization": "Bearer your_access_token_here"
    }
    params = {
        "domain": ""
    }
    response = requests.post(f"{BASE_URL}/domains/verify/{params['domain']}", headers=headers)
    assert response.status_code == 400

def test_check_domain_verify_unauthorized():
    headers = {
        "Authorization": "Bearer invalid_token"
    }
    params = {
        "domain": "example.com"
    }
    response = requests.post(f"{BASE_URL}/domains/verify/{params['domain']}", headers=headers)
    assert response.status_code == 401

def test_check_domain_verify_forbidden():
    headers = {
        "Authorization": "Bearer your_access_token_here"
    }
    params = {
        "domain": "forbidden.com"
    }
    response = requests.post(f"{BASE_URL}/domains/verify/{params['domain']}", headers=headers)
    assert response.status_code == 403

def test_check_domain_verify_method_not_allowed():
    headers = {
        "Authorization": "Bearer your_access_token_here"
    }
    params = {
        "domain": "example.com"
    }
    response = requests.get(f"{BASE_URL}/domains/verify/{params['domain']}", headers=headers)
    assert response.status_code == 405