import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_queries():
    url = f"{BASE_URL}/queries"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token",
        "alt": "json",
        "callback": "your_callback",
        "fields": "queries(queryId,metadata/title)",
        "key": "your_api_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": False,
        "quotaUser": "your_quota_user",
        "uploadProtocol": "raw",
        "uploadType": "media",
        "orderBy": "queryId desc",
        "pageSize": 100,
        "pageToken": ""
    }
    headers = {
        "Authorization": "Bearer your_access_token"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert "queries" in data
    assert isinstance(data["queries"], list)

if __name__ == "__main__":
    pytest.main([__file__])