# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_locations_update_attributes():
    url = f"{BASE_URL}/v1/{'some_location'}"
    headers = {
        'Content-Type': 'application/json',
    }
    params = {
        '$.xgafv': '1',
        'access_token': '',
        'alt': 'json',
        'callback': '',
        'fields': '',
        'key': '',
        'oauth_token': '',
        'prettyPrint': 'false',
        'quotaUser': '',
        'upload_protocol': 'raw',
        'uploadType': 'multipart',
        'attributeMask': 'some_attribute',
    }

    body = {
        'name': 'some_location',
        'attributes': [
            {'name': 'some_attribute', 'attributes': [{'name': 'some_sub_attribute', 'valueType': 'STRING', 'values': ['some_value']}]}
        ]
    }

    response = requests.patch(url, json=body, params=params)
    assert response.status_code == 200