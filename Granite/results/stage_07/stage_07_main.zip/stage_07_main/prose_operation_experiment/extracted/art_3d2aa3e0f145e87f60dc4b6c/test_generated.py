import os
import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

@pytest.fixture
def http_server():
    server = None
    try:
        server = requests.Session()
        server.headers.update({'Content-Type': 'application/json'})
        return server
    except Exception as e:
        print(f"Error creating HTTP session: {str(e)}")

def test_images_deleteall(http_server):
    package_name = "com.example.app"
    edit_id = "123456"
    language = "en"
    image_type = "phoneScreenshots"

    url = f"{BASE_URL}/androidpublisher/v3/applications/{package_name}/edits/{edit_id}/listings/{language}/{image_type}"

    response = http_server.delete(url)
    assert response.status_code == 200

    # Assuming we have a function to parse ImagesDeleteAllResponse
    deleted_images = parse_response(response.json())
    assert len(deleted_images) > 0

def parse_response(response):
    # Implement this function based on actual schema
    pass