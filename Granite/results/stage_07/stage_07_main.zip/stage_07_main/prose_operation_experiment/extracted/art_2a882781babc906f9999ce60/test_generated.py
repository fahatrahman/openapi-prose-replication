import os
import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def auth():
    # Replace with actual authentication logic
    return {"access_token": "dummy_token"}

def test_get_file(auth):
    profile_id = "dummy_profile_id"
    report_id = "dummy_report_id"
    file_id = "dummy_file_id"

    url = urljoin(BASE_URL, f"/userprofiles/{profile_id}/reports/{report_id}/files/{file_id}")
    response = requests.get(url, headers={"Authorization": f"Bearer {auth['access_token']}"})

    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "fileName" in response.json()
    assert "format" in response.json()
    assert "id" in response.json()
    assert "kind" in response.json()
    assert "lastModifiedTime" in response.json()
    assert "reportId" in response.json()
    assert "status" in response.json()
    assert "urls" in response.json()