import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_product_modules():
    url = f"{BASE_URL}/productmodule"
    response = requests.get(url)
    
    assert response.status_code == 200
    assert isinstance(response.json(), list)

if __name__ == "__main__":
    pytest.main()