import pytest
import requests
BASE_URL = "http://openapi.test"

@pytest.fixture
def create_rollout():
    endpoint = f"{BASE_URL}/v1/services/example_service/rollouts"
    headers = {"content-type": "application/json"}

    rollout = {
        "createTime": "2023-01-01T00:00:00Z",
        "createdBy": "example_created_by",
        "deleteServiceStrategy": {},
        "rolloutId": "example_rollout_id",
        "serviceName": "example_service",
        "status": "IN_PROGRESS",
        "trafficPercentStrategy": {
            "percentages": {
                "gppajug.mihuiogbpz.dfz/20160201": 70.00,
                "gppajug.mihuiogbpz.dfz/20160206": 30.00,
            }
        },
    }

    response = requests.post(endpoint, json=rollout, headers=headers)
    response.raise_for_status()
    return response.json()

def test_create_rollout(create_rollout):
    assert create_rollout["status"] == "IN_PROGRESS"
    assert len(create_rollout["trafficPercentStrategy"]["percentages"]) == 2
    assert create_rollout["serviceName"] == "example_service"