import pytest
import requests
from jsonschema import ValidationError, validate

BASE_URL = "http://openapi.test"

def test_add_video_tags():
    # Prepare request body
    tag_name = "test_tag"
    page = 1
    per_page = 10
    try:
        validate(instance={"name": tag_name, "page": page, "per_page": per_page},
                 schema={
                     "properties": {
                         "name": {"type": "string"},
                         "page": {"type": "number"},
                         "per_page": {"type": "number"}
                     },
                     "required": ["name", "page", "per_page"],
                     "type": "object"
                 })
    except ValidationError as err:
        print(f"Schema validation failed: {err}")
        assert False

    # Send PUT request to add tags to a video
    video_id = 258684937
    url = f"{BASE_URL}/videos/{video_id}/tags"
    headers = {"Content-Type": "application/vnd.vimeo.tag+json"}
    response = requests.put(url, headers=headers, json={"name": tag_name, "page": page, "per_page": per_page})

    # Check if response status code is 200 (OK)
    assert response.status_code == 200