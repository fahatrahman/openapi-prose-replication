import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_networkservices_projects_locations_list():
    # Define parameters
    params = {
        "_.xgafv": "1",
        "access_token": "",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "",
        "oauth_token": "",
        "prettyPrint": "false",
        "quotaUser": "",
        "uploadType": "media",
        "upload_protocol": "raw"
    }

    # Add required parameter 'name'
    name = "example-project"
    params["name"] = name

    # Add optional query parameters
    filter = ""
    params["filter"] = filter
    page_size = 10
    params["pageSize"] = page_size
    page_token = ""
    params["pageToken"] = page_token

    # Construct full URL
    url = urljoin(BASE_URL, f"/v1/{name}/locations")

    # Send GET request
    response = requests.get(url, params=params)

    # Check status code
    assert response.status_code == 200

    # Parse JSON response
    response_json = response.json()

    # Check response structure
    assert isinstance(response_json, dict)
    assert "locations" in response_json
    assert isinstance(response_json["locations"], list)
    assert "nextPageToken" in response_json

# Run tests
pytest.main([__file__, "-v"])