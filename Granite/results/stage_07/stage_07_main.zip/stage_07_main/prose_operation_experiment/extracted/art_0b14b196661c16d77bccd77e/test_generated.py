import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_PATH = "path/to/credentials.json"

def test_cancel_operation():
    # Load credentials for service account authentication
    credentials = service_account.Credentials.from_service_account_file(
        CREDENTIALS_PATH, scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )

    # Set up the request parameters
    name = "projects/my-project/apps/my-app/releases/my-release/operations/my-operation"
    headers = {"_.xgafv": "1", "alt": "json"}

    # Prepare the request body
    cancel_operation_request = {
        "name": name,
        "response": {"error": "Some error message"},
    }

    # Send the POST request
    response = requests.post(
        f"{BASE_URL}/v1/{name}:cancel",
        headers=headers,
        json=cancel_operation_request,
        verify=False,
        auth=credentials,
    )

    # Assert the expected status code
    assert response.status_code == 200

    # Assert the response content
    assert response.json() == {"response": {"error": "Some error message"}}