import pytest
import requests
from jsonschema import ValidationError as JsonValidationError

BASE_URL = "http://openapi.test"

def test_create_a_new_origin_token():
    url = f"{BASE_URL}/v1/origin_token/new"
    headers = {"Authorization": "Bearer "}
    data = {
        "origin": "example-origin"
    }
    
    response = requests.post(url, headers=headers, json=data)
    
    assert response.status_code == 201
    
    try:
        response.json()
    except JsonValidationError as e:
        assert False, str(e)

def test_create_a_new_origin_token_invalid_request_body():
    url = f"{BASE_URL}/v1/origin_token/new"
    headers = {"Authorization": "Bearer "}
    data = {
        "invalid-field": "value"
    }
    
    response = requests.post(url, headers=headers, json=data)
    
    assert response.status_code == 422
    
    try:
        response.json()
    except JsonValidationError as e:
        assert False, str(e)

def test_create_a_new_origin_token_already_exists():
    url = f"{BASE_URL}/v1/origin_token/new"
    headers = {"Authorization": "Bearer "}
    data = {
        "origin": "existing-origin"
    }
    
    response = requests.post(url, headers=headers, json=data)
    
    assert response.status_code == 409

def test_create_a_new_origin_token_missing_required_field():
    url = f"{BASE_URL}/v1/origin_token/new"
    headers = {"Authorization": "Bearer "}
    data = {}
    
    response = requests.post(url, headers=headers, json=data)
    
    assert response.status_code == 400