import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_mybusiness_accounts_locations_reviews_update_reply():
    name = "example_name"
    comment = "This is a comment."
    update_time = datetime.now().isoformat()

    url = f"{BASE_URL}/v4/{name}/reply"
    headers = {"Content-Type": "application/json"}
    data = {
        "comment": comment,
        "updateTime": update_time
    }

    response = requests.put(url, headers=headers, json=data)
    assert response.status_code == 200
    response_data = response.json()
    assert isinstance(response_data, dict)
    assert "comment" in response_data
    assert "updateTime" in response_data
    assert response_data["comment"] == comment
    assert response_data["updateTime"] == update_time