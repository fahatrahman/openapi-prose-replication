import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
SESSION.mount("https://", HTTPAdapter(max_retries=5))
SESSION.mount("http://", HTTPAdapter(max_retries=5))

@pytest.mark.parametrize("build_id", ["ajh lg co ajh bjvnygxvk nbbcmoio"])
def test_get_app_encryption_declaration_linkage(build_id):
    endpoint = f"/v1/builds/{build_id}/relationships/appEncryptionDeclaration"
    response = SESSION.get(urljoin(BASE_URL, endpoint), headers={"Authorization": "Bearer <your_access_token>"})

    if response.status_code == 200:
        data = response.json()
        assert "data" in data
        assert "links" in data["data"]
        assert isinstance(data["data"]["id"], str)
        assert data["data"]["type"] == "appEncryptionDeclarations"
        assert "self" in data["data"]["links"]
    elif response.status_code == 400:
        errors = data["errors"]
        for error in errors:
            assert "code" in error
            assert "detail" in error
            assert "id" in error
            assert "title" in error
            assert "status" in error
    elif response.status_code == 403:
        # Handle forbidden response
        pass
    elif response.status_code == 404:
        # Handle not found response
        pass
    else:
        raise Exception(f"Unexpected status code {response.status_code}")