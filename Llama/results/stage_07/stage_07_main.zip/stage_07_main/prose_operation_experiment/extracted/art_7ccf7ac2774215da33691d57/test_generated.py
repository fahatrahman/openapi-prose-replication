# pytest-openapi-test.py
import pytest
import requests
from pydantic import BaseModel

class StoreLayout(BaseModel):
    homepageId: str
    storeLayoutType: str

BASE_URL = "http://openapi.test"

def test_android_enterprise_set_store_layout():
    enterprise_id = "test-enterprise-id"
    layout = {
        "homepageId": "test-homepage-id",
        "storeLayoutType": "basic",
    }
    headers = {"Content-Type": "application/json"}
    response = requests.put(
        f"{BASE_URL}/androidenterprise/v1/enterprises/{enterprise_id}/storeLayout",
        headers=headers,
        json=layout,
    )
    assert response.status_code == 200
    result = response.json()
    assert isinstance(result, dict)
    assert "homepageId" in result
    assert "storeLayoutType" in result

def test_android_enterprise_set_store_layout_with_oauth():
    # This will fail because we're not actually authenticating here
    enterprise_id = "test-enterprise-id"
    layout = {
        "homepageId": "test-homepage-id",
        "storeLayoutType": "basic",
    }
    headers = {"Content-Type": "application/json", "Authorization": "Bearer some-token"}
    response = requests.put(
        f"{BASE_URL}/androidenterprise/v1/enterprises/{enterprise_id}/storeLayout",
        headers=headers,
        json=layout,
    )
    assert response.status_code == 401