import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"

# Define the security credentials
credentials = service_account.Credentials.from_service_account_file('path/to/your/credentials.json')

@pytest.mark.parametrize("name", ["your_operation_name"])
def test_cancel_operation(name):
    url = f"{BASE_URL}/v1/{name}:cancel"

    headers = {
        "Content-Type": "application/json"
    }

    # Prepare the request body
    request_body = {
        "resourceName": f"projects/your_project_id/apps/your_app_id/releases/your_release_id"
    }

    response = requests.post(url, headers=headers, json=request_body, verify=False, auth=credentials)

    assert response.status_code == 200
    assert response.json() == {}