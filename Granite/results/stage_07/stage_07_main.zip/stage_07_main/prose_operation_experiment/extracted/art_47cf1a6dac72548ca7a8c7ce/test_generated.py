import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Define a session with retries for idempotent requests
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def access_token():
    url = f"{BASE_URL}/users/username/tokens"

    # Create access token payload
    payload = {
        "name": "Test Token",
        "scopes": ["repo", "user"],
    }

    # Send POST request to create access token
    response = session.post(url, json=payload)

    # Assert response status code is 201 (Created)
    assert response.status_code == 201

    # Return the access token from the response
    return response.json()["token"]

def test_create_access_token(access_token):
    assert access_token is not None