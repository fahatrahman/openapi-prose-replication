import os
import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def client():
    return requests.Session()

def test_user_api(client):
    album_id = 123  # replace with actual album id
    collection_status = "Owned"
    media_type = "DigitalDownload"
    rating = 4

    response = client.post(
        f"{BASE_URL}/api/users/current/albums/{album_id}",
        params={
            "collectionStatus": collection_status,
            "mediaType": media_type,
            "rating": rating,
        },
    )

    assert response.status_code == 200
    assert isinstance(response.json(), str)
    assert isinstance(response.text, str)
    assert isinstance(response.content, str)