import os
import pytest
import requests
from requests.exceptions import RequestException
from requests.adapters import HTTPAdapter
from typing import Dict

BASE_URL = "http://openapi.test"

@pytest.fixture
def api_client():
    session = requests.Session()
    adapter = HTTPAdapter(max_retries=3)
    session.mount("https://", adapter)
    session.mount("http://", adapter)

    return session


def test_create_content_definition(api_client):
    content_definition = {
        "Attributes": [],
        "Description": "Test Description",
        "Name": "Test Content",
        "TypeID": 1,
    }

    try:
        response = api_client.post(
            f"{BASE_URL}/api/v2/ContentDefinitions", json=content_definition
        )

        response.raise_for_status()
        assert response.status_code == 200
        created_content_definition_id = response.json()

        print(f"Successfully created Content Definition with ID: {created_content_definition_id}")

    except RequestException as e:
        error_message = f"Request failed with status code {e.response.status_code}:\n{str(e)}"
        raise RuntimeError(error_message)