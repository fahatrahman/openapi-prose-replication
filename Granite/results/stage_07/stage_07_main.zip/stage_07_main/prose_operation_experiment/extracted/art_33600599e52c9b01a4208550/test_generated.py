import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Retry mechanism for requests
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

# API Key
API_KEY = os.getenv("API_KEY", None)

@pytest.mark.parametrize("padID", ["test_pad"])
def test_padUsersUsingPOST(padID):
    url = f"{BASE_URL}/padUsers"
    headers = {"Content-Type": "application/json"}

    if API_KEY:
        headers["api-key"] = API_KEY

    response = session.post(url, json={"padID": padID}, headers=headers)

    response.raise_for_status()

    result = response.json()

    assert response.status_code == 200, result["message"]
    assert result["code"] == 0, result["message"]
    assert result["data"]["message"] == "ok", result["message"]
    assert len(result["data"]["padUsers"]) > 0, "No pad users found"