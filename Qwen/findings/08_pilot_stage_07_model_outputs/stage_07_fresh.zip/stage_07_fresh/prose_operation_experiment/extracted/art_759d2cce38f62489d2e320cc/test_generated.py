import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_editorial_image_categories():
    url = f"{BASE_URL}/v2/editorial/images/categories"
    headers = {
        "Authorization": "Basic dXNlcm5hbWU6cGFzc3dvcmQ="  # Replace with actual credentials
    }
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert "data" in data
    assert isinstance(data["data"], list)
    for item in data["data"]:
        assert "name" in item
        assert isinstance(item["name"], str)

if __name__ == "__main__":
    pytest.main()