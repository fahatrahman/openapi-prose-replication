import pytest
import requests

BASE_URL = "http://openapi.test"

def test_connections():
    url = f"{BASE_URL}/net/connections"
    payload = {}
    response = requests.post(url, json=payload)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    for item in data:
        assert 'connecting' in item
        assert isinstance(item['connecting'], bool)
        assert 'last_handshake' in item
        last_handshake = item['last_handshake']
        assert 'agent' in last_handshake
        assert isinstance(last_handshake['agent'], str)
        assert 'chain_id' in last_handshake
        assert isinstance(last_handshake['chain_id'], str)
        assert 'generation' in last_handshake
        assert isinstance(last_handshake['generation'], int)
        assert 'head_id' in last_handshake
        assert isinstance(last_handshake['head_id'], str)
        assert 'head_num' in last_handshake
        assert isinstance(last_handshake['head_num'], int)
        assert 'key' in last_handshake
        assert isinstance(last_handshake['key'], str)
        assert 'last_irreversible_block_id' in last_handshake
        assert isinstance(last_handshake['last_irreversible_block_id'], str)
        assert 'last_irreversible_block_num' in last_handshake
        assert isinstance(last_handshake['last_irreversible_block_num'], int)
        assert 'network_version' in last_handshake
        assert isinstance(last_handshake['network_version'], int)
        assert 'node_id' in last_handshake
        assert isinstance(last_handshake['node_id'], str)
        assert 'os' in last_handshake
        assert isinstance(last_handshake['os'], str)
        assert 'p2p_address' in last_handshake
        assert isinstance(last_handshake['p2p_address'], str)
        assert 'sig' in last_handshake
        assert isinstance(last_handshake['sig'], str)
        assert 'time' in last_handshake
        assert isinstance(last_handshake['time'], str)
        assert 'token' in last_handshake
        assert isinstance(last_handshake['token'], str)
        assert 'peer' in item
        assert isinstance(item['peer'], str)
        assert 'syncing' in item
        assert isinstance(item['syncing'], bool)

if __name__ == "__main__":
    pytest.main(["-v", __file__])