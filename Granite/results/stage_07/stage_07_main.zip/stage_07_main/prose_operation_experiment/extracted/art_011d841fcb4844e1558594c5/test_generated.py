import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_PATH = "path/to/your/credentials.json"

@pytest.fixture
def authenticated_session():
    credentials = service_account.Credentials.from_service_account_file(
        CREDENTIALS_PATH, scopes=["https://www.googleapis.com/auth/dfareporting"]
    )
    return requests.Session(), credentials

def test_get_report_file(authenticated_session):
    session, credentials = authenticated_session

    profile_id = "YOUR_PROFILE_ID"
    report_id = "YOUR_REPORT_ID"
    file_id = "YOUR_FILE_ID"

    url = f"{BASE_URL}/userprofiles/{profile_id}/reports/{report_id}/files/{file_id}"
    headers = {"Authorization": f"Bearer {credentials.token}"}

    response = session.get(url, headers=headers)
    response.raise_for_status()

    assert response.status_code == 200
    file_data = response.json()
    # Add additional assertions based on the expected file properties
    assert isinstance(file_data, dict)
    assert file_data["kind"] == "dfareporting#file"
    assert file_data["reportId"] == report_id
    assert file_data["status"] in ["PROCESSING", "REPORT_AVAILABLE", "FAILED", "CANCELLED", "QUEUED"]