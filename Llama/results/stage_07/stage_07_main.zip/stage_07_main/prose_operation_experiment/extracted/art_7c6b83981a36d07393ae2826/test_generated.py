# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_manufacturers_accounts_languages_product_certifications_delete():
    url = f"{BASE_URL}/v1/{'tjnnzcqy/yjurfrb/kwbkatwap/srohwzhy_ihlx/lauatduHbqmarwzxyqmwc/lg'}"
    response = requests.delete(
        url,
        headers={
            "X-Google-APIS-Request": "Authorization",
            "Content-Type": "application/json; charset=utf-8"
        },
        params={
            "access_token": None,
            "alt": None,
            "callback": None,
            "fields": None,
            "key": None,
            "oauth_token": None,
            "prettyPrint": None,
            "quotaUser": None,
            "upload_protocol": None,
            "uploadType": None
        }
    )
    assert response.status_code == 200