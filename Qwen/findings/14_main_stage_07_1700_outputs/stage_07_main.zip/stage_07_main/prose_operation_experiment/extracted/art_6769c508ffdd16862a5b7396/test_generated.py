import pytest
import requests

BASE_URL = "http://openapi.test"

def test_notify_shopper():
    url = f"{BASE_URL}/notifyShopper"
    headers = {
        "Content-Type": "application/json",
        "X-API-Key": "your_api_key_here"  # Replace with actual API key
    }
    payload = {
        "amount": {
            "currency": "INR",
            "value": 1000
        },
        "billingDate": "2021-03-16",
        "displayedReference": "exampleDisplayedReference",
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",  # Replace with actual merchant account
        "reference": "Example reference",
        "shopperReference": "YOUR_SHOPPER_REFERENCE",  # Replace with actual shopper reference
        "storedPaymentMethodId": "8415995487234100"
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 200
    assert response.json()["resultCode"] == "Success"
    assert response.json()["message"] == "Request Processed Successfully"
    assert response.json()["pspReference"]
    assert response.json()["shopperNotificationReference"]

if __name__ == "__main__":
    pytest.main()