# -*- coding: utf-8 -*-
"""Test the Apigee deployment API."""

import pytest
from requests import HTTPError

BASE_URL = "http://openapi.test"

def test_get_deployments():
    """Test get deployments."""
    params = {
        "$.xgafv": "1",
        "access_token": "",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "",
        "oauth_token": "",
        "prettyPrint": "false",
        "quotaUser": "",
        "upload_protocol": "",
        "uploadType": "",
        "name": "/v1/seztsexhbkkrag/ctxoywgbkox/ktjspqitzpup/aef/oqkhfcgtqud/nubemlvnrn/vbereeqgk/lil"
    }
    try:
        response = requests.get(f"{BASE_URL}/v1/{params['name']}/deployments", params=params)
        assert response.status_code == 200
    except HTTPError as http_err:
        pytest.fail(f"HTTP error occurred: {http_err}")