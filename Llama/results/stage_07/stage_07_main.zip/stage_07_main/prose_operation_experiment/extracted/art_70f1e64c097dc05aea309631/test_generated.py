# -*- coding: utf-8 -*-
"""Tests for connectors.projects.locations.connections.entityTypes.entities.delete."""

import pytest
import requests


BASE_URL = "http://openapi.test"


def test_connectors_projects_locations_connections_entity_types_entities_delete(
    auth_header,
):
    """Tests for connectors.projects.locations.connections.entityTypes.entities.delete."""
    url = f"{BASE_URL}/v2/name"
    headers = {"Authorization": auth_header}
    response = requests.delete(url, headers=headers)
    assert response.status_code == 200
    assert response.json() is None


def test_connectors_projects_locations_connections_entity_types_entities_delete_no_auth():
    """Tests for connectors.projects.locations.connections.entityTypes.entities.delete without authentication."""
    url = f"{BASE_URL}/v2/name"
    response = requests.delete(url)
    assert response.status_code == 401


@pytest.fixture
def auth_header():
    # This would typically involve using an OAuth library or similar to get an access token
    # For this example, we'll just return a hardcoded header
    return "Bearer some_access_token"