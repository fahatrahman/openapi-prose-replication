import pytest
import requests

BASE_URL = "http://openapi.test"

def test_account_user_profiles_update():
    url = f"{BASE_URL}/userprofiles/{'profileId'} /accountUserProfiles"
    
    headers = {
        'Content-Type': 'application/json'
    }

    data = {
        "accountId": "123",
        "active": True,
        "advertiserFilter": {},
        "campaignFilter": {},
        "comments": "test comments",
        "email": "test@example.com",
        "id": "456",
        "kind": "dfareporting#accountUserProfile",
        "locale": "en",
        "name": "Test Account User Profile",
        "siteFilter": {},
        "subaccountId": "789",
        "traffickerType": "INTERNAL_TRAFFICKER",
        "userAccessType": "NORMAL_USER",
        "userRoleFilter": {},
        "userRoleId": "901"
    }

    try:
        response = requests.put(url, headers=headers, json=data)
        assert response.status_code == 200
    except requests.exceptions.RequestException as err:
        pytest.fail(err)
