# -*- coding: utf-8 -*-
import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

@pytest.fixture
def api_key():
    return "your_api_key_here"

def test_get_batch(api_key):
    url = f"{BASE_URL}/batch/your_batch_id_here"
    headers = {"X-API-KEY": api_key}
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    
    data = response.json()
    assert isinstance(data["completed"], bool)
    assert isinstance(data["count"], int)
    assert isinstance(data["created_at"], str) and datetime.strptime(data["created_at"], "%Y-%m-%dT%H:%M:%SZ") <= datetime.now()
    assert isinstance(data["id"], str)
    assert isinstance(data["operation"], str)
    assert isinstance(data["results"], list)
    assert isinstance(data["status"], str)
