import pytest
import requests

BASE_URL = "http://openapi.test"

def test_search_associated_transcripts():
    url = f"{BASE_URL}/bots/botId/botversions/botVersion/botlocales/localeId/botrecommendations/botRecommendationId/associatedtranscripts"
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "accessKeyID/region/service/aws4_request",
        "X-Amz-Date": "dateStamp",
        "X-Amz-Security-Token": "sessionToken",
        "X-Amz-Signature": "signature",
        "X-Amz-SignedHeaders": "host;x-amz-date;x-amz-security-token"
    }
    payload = {
        "filters": [
            {
                "name": "IntentId",
                "values": ["intent1"]
            }
        ],
        "maxResults": 10,
        "searchOrder": "Descending"
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert "associatedTranscripts" in response.json()
    assert "botId" in response.json()
    assert "botRecommendationId" in response.json()
    assert "botVersion" in response.json()
    assert "localeId" in response.json()
    assert "nextIndex" in response.json()
    assert "totalResults" in response.json()

if __name__ == "__main__":
    pytest.main([__file__])