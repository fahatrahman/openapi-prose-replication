import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_jurisdiction_detail():
    jurisdiction_id = "ocd-jurisdiction/country:us/state:nc/government"
    include = ["organizations", "legislative_sessions"]
    api_key = None
    x_api_key = None

    url = f"{BASE_URL}/jurisdictions/{jurisdiction_id}"
    params = {"include": include}
    headers = {}
    if api_key:
        params["apikey"] = api_key
    if x_api_key:
        headers["x-api-key"] = x_api_key

    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)

    # Perform some basic assertions about the Jurisdiction object
    assert data["id"] == jurisdiction_id
    assert data["name"] == "North Carolina"
    assert data["classification"] in ["state", "municipality", "country"]
    assert isinstance(data["latest_bill_update"], str) and datetime.fromisoformat(data["latest_bill_update"])
    assert isinstance(data["latest_people_update"], str) and datetime.fromisoformat(data["latest_people_update"])

    # Check that the included fields are present
    for field in include:
        assert field in data
        if field == "organizations":
            assert isinstance(data[field], list)
            assert all(isinstance(org, dict) for org in data[field])
        elif field == "legislative_sessions":
            assert isinstance(data[field], list)
            assert all(isinstance(session, dict) for session in data[field])

def test_jurisdiction_detail_validation_error():
    jurisdiction_id = "invalid-jurisdiction-id"
    include = []
    api_key = "valid-api-key"
    x_api_key = "valid-x-api-key"

    url = f"{BASE_URL}/jurisdictions/{jurisdiction_id}"
    params = {"include": include}
    headers = {}
    if api_key:
        params["apikey"] = api_key
    if x_api_key:
        headers["x-api-key"] = x_api_key

    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 422
    data = response.json()
    assert isinstance(data, dict)
    assert len(data["detail"]) > 0
    assert all(isinstance(error, dict) for error in data["detail"])
    assert all("loc" in error and "msg" in error and "type" in error for error in data["detail"])

if __name__ == "__main__":
    pytest.main([__file__])