import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Define custom session with retries
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[429])
adapter = HTTPAdapter(max_retries=retries)
session.mount("http://", adapter)

@pytest.fixture
def headers():
    return {"X-Api-Key": "partner-test-123"}

def test_fetch_boundaries(headers):
    url = f"{BASE_URL}/v4/boundaries/query"

    # Prepare payload
    payload = {
        "ids": ["123", "456", "789"]
    }

    try:
        response = session.post(url, json=payload, headers=headers)

        # Check if the request was successful
        assert response.status_code == 200

        # If successful, parse the JSON response
        response_data = response.json()

        # Add further assertions based on expected response structure
        assert isinstance(response_data, dict)
        assert "features" in response_data
        assert isinstance(response_data["features"], list)

    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")
        assert False, "Failed to fetch boundaries"