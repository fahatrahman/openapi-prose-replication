import pytest
import requests

BASE_URL = "http://openapi.test"

def test_change_ip_range():
    network_id = 123  # Replace with actual network ID
    ip_range = "10.0.0.0/12"
    
    url = f"{BASE_URL}/networks/{network_id}/actions/change_ip_range"
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json"
    }
    payload = {
        "ip_range": ip_range
    }
    
    response = requests.post(url, headers=headers, json=payload)
    
    assert response.status_code == 201
    assert response.json()["action"]["status"] == "success"
    assert response.json()["action"]["command"] == "change_ip_range"
    assert response.json()["action"]["error"] is None
    
    action_id = response.json()["action"]["id"]
    get_url = f"{BASE_URL}/networks/{network_id}/actions/{action_id}"
    get_response = requests.get(get_url, headers=headers)
    
    assert get_response.status_code == 200
    assert get_response.json()["action"]["id"] == action_id
    assert get_response.json()["action"]["status"] == "success"
    assert get_response.json()["action"]["command"] == "change_ip_range"
    assert get_response.json()["action"]["error"] is None