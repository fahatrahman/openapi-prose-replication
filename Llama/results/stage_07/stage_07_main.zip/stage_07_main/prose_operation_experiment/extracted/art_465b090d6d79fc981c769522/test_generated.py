# Generated from OpenAPI specification at path /v1beta1/{index}:upsertDatapoints

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_aiplatform_projects_locations_indexes_upsert_datapoints():
    url = f"{BASE_URL}/v1beta1/index/upsertDatapoints"
    
    datapoints = [
        {
            "datapointId": "test_datapoint",
            "featureVector": [1.0, 2.0, 3.0],
            "numericRestricts": [],
            "restricts": []
        }
    ]
    
    headers = {"Content-Type": "application/json"}
    data = {"datapoints": datapoints}
    
    response = requests.post(url, json=data, headers=headers)
    
    assert response.status_code == 200
    
    try:
        response.raise_for_status()
    except requests.RequestException as err:
        pytest.fail(f"Failed to upsert datapoints: {err}")