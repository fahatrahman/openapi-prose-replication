import pytest
import requests

BASE_URL = "http://openapi.test"

def test_dfareporting_advertisers_list():
    url = f"{BASE_URL}/userprofiles/profileId/advertisers"
    
    params = {
        "advertiserGroupIds": [],
        "floodlightConfigurationIds": [],
        "ids": [],
        "includeAdvertisersWithoutGroupsOnly": False,
        "maxResults": 10,
        "onlyParent": False,
        "pageToken": "",
        "searchString": "",
        "sortField": "ID",
        "sortOrder": "ASCENDING",
        "status": ["APPROVED", "ON_HOLD"],
        "subaccountId": ""
    }
    
    headers = {"Accept": "application/json"}
    
    response = requests.get(url, params=params, headers=headers)
    
    assert response.status_code == 200
    
    data = response.json()
    
    assert isinstance(data, dict)
    assert "advertisers" in data
    assert isinstance(data["advertisers"], list)
    
    for advertiser in data["advertisers"]:
        assert isinstance(advertiser, dict)
        assert "id" in advertiser
        assert isinstance(advertiser["id"], str)
        
        assert "name" in advertiser
        assert isinstance(advertiser["name"], str)

if __name__ == "__main__":
    pytest.main([__file__])