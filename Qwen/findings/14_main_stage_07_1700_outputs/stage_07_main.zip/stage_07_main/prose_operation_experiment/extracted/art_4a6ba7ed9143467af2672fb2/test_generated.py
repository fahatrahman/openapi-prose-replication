import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_certs():
    url = f"{BASE_URL}/v0.5/certs"
    response = requests.get(url)
    
    assert response.status_code == 200
    
    if response.headers['Content-Type'] == 'application/json':
        data = response.json()
        assert 'keys' in data
        assert isinstance(data['keys'], list)
        for key in data['keys']:
            assert 'alg' in key
            assert 'e' in key
            assert 'kid' in key
            assert 'kty' in key
            assert 'n' in key
            assert 'use' in key
            assert 'x5c' in key
            assert 'x5t' in key
            assert 'x5t#S256' in key
    elif response.headers['Content-Type'] == 'application/xml':
        # Implement XML parsing and validation here
        pass
    else:
        pytest.fail(f"Unexpected Content-Type: {response.headers['Content-Type']}")

if __name__ == "__main__":
    pytest.main([__file__])