import pytest
import requests

BASE_URL = "http://openapi.test"

def test_test_iam_permissions():
    url = f"{BASE_URL}/v1/projects/locations/restorePlans/restores/volumeRestores:testIamPermissions"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    params = {
        "_xgafv": "1",
        "access_token": "YOUR_ACCESS_TOKEN",
        "alt": "json",
        "callback": "YOUR_CALLBACK_URL",
        "fields": "permissions",
        "key": "YOUR_API_KEY",
        "oauth_token": "YOUR_OAUTH_TOKEN",
        "prettyPrint": True,
        "quotaUser": "YOUR_QUOTA_USER",
        "uploadType": "media",
        "upload_protocol": "simple"
    }
    body = {
        "permissions": [
            "roles/storage.objectAdmin"
        ]
    }

    response = requests.post(url, headers=headers, params=params, json=body)

    assert response.status_code == 200
    assert "permissions" in response.json()