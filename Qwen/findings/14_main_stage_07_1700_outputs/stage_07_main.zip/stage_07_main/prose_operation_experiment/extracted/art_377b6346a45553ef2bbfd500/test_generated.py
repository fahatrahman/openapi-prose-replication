import pytest
import requests

BASE_URL = "http://openapi.test"

def test_fetch_reward_program_activations():
    url = f"{BASE_URL}/reward_program_activation"
    params = {
        "filter[patient]": "mxcfvs[yhzevln]",
        "filter[groups]": "mxcfvs[tdyakb]",
        "filter[organization]": "mxcfvs[vayraxskjlkb]"
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 200
    data = response.json()
    assert "data" in data
    assert isinstance(data["data"], list)
    for item in data["data"]:
        assert "attributes" in item
        attributes = item["attributes"]
        assert "activated_at" in attributes
        assert "active" in attributes
        assert "allocated_count" in attributes
        assert "budget_unit" in attributes
        assert "deactivated_at" in attributes
        assert "earned_count" in attributes
        assert "expires_at" in attributes
        assert "fulfill_as_earned" in attributes
        assert "total_allocated_value" in attributes
        assert "total_earned_value" in attributes
        assert "id" in item
        assert "relationships" in item
        relationships = item["relationships"]
        assert "patient" in relationships
        assert "reward_program" in relationships
        assert "type" in item

def test_fetch_reward_program_activations_unauthorized():
    url = f"{BASE_URL}/reward_program_activation"
    response = requests.get(url)
    
    assert response.status_code == 401
    error_response = response.json()
    assert "errors" in error_response
    errors = error_response["errors"]
    assert len(errors) == 1
    error = errors[0]
    assert "code" in error
    assert error["code"] == "Unauthorized"
    assert "detail" in error
    assert "status" in error

def test_fetch_reward_program_activations_forbidden():
    url = f"{BASE_URL}/reward_program_activation"
    headers = {"Authorization": "Bearer invalid_token"}
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 403
    error_response = response.json()
    assert "errors" in error_response
    errors = error_response["errors"]
    assert len(errors) == 1
    error = errors[0]
    assert "code" in error
    assert error["code"] == "Forbidden"
    assert "detail" in error
    assert "status" in error