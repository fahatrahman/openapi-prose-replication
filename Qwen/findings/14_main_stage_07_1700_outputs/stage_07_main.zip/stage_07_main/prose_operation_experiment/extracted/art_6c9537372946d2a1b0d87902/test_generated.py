import pytest
import requests

BASE_URL = "http://openapi.test"

def test_directory_groups_patch():
    # Replace 'YOUR_ACCESS_TOKEN' with a valid access token
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    params = {
        "_xgafv": "1",
        "access_token": "YOUR_ACCESS_TOKEN",
        "alt": "json",
        "prettyPrint": "false",
        "quotaUser": "user@example.com",
        "upload_protocol": "raw",
        "uploadType": "multipart"
    }
    group_key = "example@domain.com"
    payload = {
        "description": "Updated description for the group"
    }

    url = f"{BASE_URL}/admin/directory/v1/groups/{group_key}"
    response = requests.patch(url, headers=headers, params=params, json=payload)

    assert response.status_code == 200
    assert "description" in response.json()
    assert response.json()["description"] == payload["description"]