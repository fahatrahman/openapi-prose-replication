# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_supported_languages():
    url = f"{BASE_URL}/v3beta1/{'zynntaco/{autfnhu-lnoksl-sg-lg}'}"
    params = {
        "displayLanguageCode": "MxghSK",
        "model": "ozqjor"
    }
    
    response = requests.get(url, params=params)
    
    assert response.status_code == 200
    
    # Parse JSON response
    data = response.json()
    
    # Check if SupportedLanguages schema is valid
    assert isinstance(data, dict)
    assert "languages" in data
    
    # Check if languages list contains at least one element
    assert len(data["languages"]) > 0
    
    # Check if each language has correct properties
    for language in data["languages"]:
        assert "displayName" in language
        assert "languageCode" in language
        assert "supportSource" in language
        assert "supportTarget" in language
        
        # Check if displayName is a string
        assert isinstance(language["displayName"], str)
        
        # Check if languageCode is a string
        assert isinstance(language["languageCode"], str)
        
        # Check if supportSource is a boolean
        assert isinstance(language["supportSource"], bool)
        
        # Check if supportTarget is a boolean
        assert isinstance(language["supportTarget"], bool)
