import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = 'path/to/your/service_account.json'
SCOPES = ['https://www.googleapis.com/auth/cloud-platform']

def get_authenticated_session():
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=SCOPES)

    if credentials.expired and credentials.refresh_token:
        credentials.refresh(requests.Request())

    return requests.Session(), credentials

@pytest.fixture
def http_client():
    session, credentials = get_authenticated_session()
    return session

def test_default_branch(http_client):
    catalog = 'your_catalog_value'
    url = f"{BASE_URL}/v2beta/{catalog}:getDefaultBranch"

    response = http_client.get(url)
    assert response.status_code == 200

    data = response.json()
    print("Branch:", data['branch'])
    print("Note:", data['note'])
    print("Set time:", data['setTime'])