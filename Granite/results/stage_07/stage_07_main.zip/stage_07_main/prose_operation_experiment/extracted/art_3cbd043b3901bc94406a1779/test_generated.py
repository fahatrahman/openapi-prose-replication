import os
import requests
import pytest
from requests_aws_sigv4 import AWSSignaturesV4Auth

BASE_URL = "http://openapi.test"

@pytest.fixture
def amazon_session():
    session = requests.Session()
    session.mount("https://", AWSSignaturesV4Auth(AWS_ACCESS_KEY, AWS_SECRET_KEY))
    return session

AWS_ACCESS_KEY = os.environ.get("AWS_ACCESS_KEY")
AWS_SECRET_KEY = os.environ.get("AWS_SECRET_KEY")

def test_list_configs(amazon_session):
    response = amazon_session.get(
        f"{BASE_URL}/config",
        headers={
            "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
            "X-Amz-Content-Sha256": "CONTENT_SHA256",
            "X-Amz-Date": "DATE",
            "X-Amz-Credential": "CREDENTIAL",
            "X-Amz-Security-Token": "SECURITY_TOKEN",
            "X-Amz-Signature": "SIGNATURE",
            "X-Amz-SignedHeaders": "SIGNED_HEADERS",
        },
    )

    assert response.status_code == 200
    # Add more assertions if needed based on the expected response schema