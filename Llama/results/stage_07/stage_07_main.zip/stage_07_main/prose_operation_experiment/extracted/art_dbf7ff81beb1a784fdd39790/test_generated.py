# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime
from urllib.parse import urlencode

BASE_URL = "http://openapi.test"

def get_bounce_counts(server_token, tag=None, fromdate=None, todate=None):
    params = {}
    if tag:
        params['tag'] = tag
    if fromdate:
        try:
            fromdate = datetime.strptime(fromdate, "%Y-%m-%d").strftime("%Y-%m-%dT%H:%M:%SZ")
        except ValueError:
            raise ValueError("Invalid fromdate format. Expected YYYY-MM-DD.")
        params['fromdate'] = fromdate
    if todate:
        try:
            todate = datetime.strptime(todate, "%Y-%m-%d").strftime("%Y-%m-%dT%H:%M:%SZ")
        except ValueError:
            raise ValueError("Invalid todate format. Expected YYYY-MM-DD.")
        params['todate'] = todate
    headers = {'X-Postmark-Server-Token': server_token}
    response = requests.get(f"{BASE_URL}/stats/outbound/bounces", headers=headers, params=params)
    assert response.status_code == 200
    return response.json()

@pytest.mark.parametrize(
    "server_token,tag,fromdate,todate",
    [
        ("token123", None, None, None),
        ("token123", "my_tag", None, None),
        ("token123", None, "2014-01-01", "2014-01-31"),
        ("token123", None, "2014-01-01", "2014-02-28"),
        ("token123", "my_tag", "2014-01-01", "2014-01-31"),
        ("token123", "my_tag", "2014-01-01", "2014-02-28"),
    ],
)
def test_get_bounce_counts(server_token, tag, fromdate, todate):
    try:
        get_bounce_counts(server_token, tag, fromdate, todate)
    except Exception as e:
        pytest.fail(str(e))