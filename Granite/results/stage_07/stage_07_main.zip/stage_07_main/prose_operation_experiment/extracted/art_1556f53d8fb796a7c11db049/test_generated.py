import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = "path/to/service_account.json"
SCOPES = ["https://www.googleapis.com/auth/content"]

@pytest.fixture
def auth():
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=SCOPES
    )
    return credentials

def test_pos_batch(auth):
    url = f"{BASE_URL}/pos/batch"

    payload = {
        "entries": [
            {
                "batchId": 1,
                "merchantId": "merchant_id",
                "method": "inventory",
                "inventory": {
                    "itemId": "item_id",
                    "storeCode": "store_code",
                    "quantity": "100",
                    "price": {"value": "10.00", "currency": "USD"},
                    "timestamp": "2022-01-01T00:00:00Z",
                    "targetCountry": "US",
                },
                "targetMerchantId": "target_merchant_id",
            }
        ]
    }

    headers = {
        "Content-Type": "application/json",
    }

    response = requests.post(url, json=payload, headers=headers, auth=auth)

    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "kind" in response.json() and response.json()["kind"] == "content#posCustomBatchResponse"