import pytest
import requests

BASE_URL = "http://openapi.test"

def get_case_related_cases(case_id, page_number=None):
    url = f"{BASE_URL}/case/{case_id}/relatedCases"
    params = {"pageNumber": page_number} if page_number else {}
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",  # Replace with actual token
    }
    response = requests.get(url, headers=headers, params=params)
    return response.json()

@pytest.mark.parametrize("case_id, page_number, expected_status_code", [
    ("CASEba328623913f9f", None, 200),
    ("CASEgued96d541f794", 1, 200),
    ("CASEgued96d541f794", None, 400),
    ("CASEzz99a698ea541d", None, 404),
    ("CASEakfbd1817d7431", None, 451),
])
def test_get_case_related_cases(case_id, page_number, expected_status_code):
    response = get_case_related_cases(case_id, page_number)
    assert response["statusCode"] == expected_status_code