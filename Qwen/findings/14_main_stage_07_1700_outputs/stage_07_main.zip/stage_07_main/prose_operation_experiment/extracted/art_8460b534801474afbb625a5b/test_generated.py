import pytest
import requests

BASE_URL = "http://openapi.test"

def test_api_users_current_albums_post():
    album_id = 123  # Example album ID
    collection_status = "Wishlisted"
    media_type = "PhysicalDisc"
    rating = 5

    url = f"{BASE_URL}/api/users/current/albums/{album_id}"
    params = {
        "collectionStatus": collection_status,
        "mediaType": media_type,
        "rating": rating
    }

    response = requests.post(url, params=params)

    assert response.status_code == 200
    assert response.text in ["PhysicalDisc", "DigitalDownload", "Other"]

if __name__ == "__main__":
    pytest.main()