import pytest
import requests

BASE_URL = "http://openapi.test"

def get_orders(authorization, offset=0, limit=10):
    url = f"{BASE_URL}/orders/status/sent"
    headers = {
        "Authorization": authorization
    }
    params = {
        "offset": offset,
        "limit": limit
    }
    response = requests.get(url, headers=headers, params=params)
    response.raise_for_status()
    return response.json()

@pytest.mark.parametrize("offset, limit", [
    (0, 10),
    (10, 5),
    (0, 20)
])
def test_get_orders(offset, limit):
    authorization = "Bearer your_access_token_here"
    try:
        result = get_orders(authorization, offset, limit)
        assert isinstance(result, dict)
        assert "orders" in result
        assert "metadata" in result
        assert isinstance(result["orders"], list)
        assert isinstance(result["metadata"], list)
        for order in result["orders"]:
            assert "orderId" in order
            assert "orderMarketplaceId" in order
            assert "createdAt" in order
            assert "updatedAt" in order
            assert "status" in order
            assert "totalAmount" in order
            assert "totalItemsAmount" in order
            assert "totalShippingAmount" in order
            assert "totalDiscountAmount" in order
            assert "freight" in order
            assert "customer" in order
            assert "billingAddress" in order
            assert "items" in order
            assert "shippingAddress" in order
            assert "shipments" in order
    except AssertionError as e:
        pytest.fail(f"Assertion error: {e}")
    except requests.exceptions.RequestException as e:
        pytest.fail(f"Request exception: {e}")

if __name__ == "__main__":
    pytest.main()