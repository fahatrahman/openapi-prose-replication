import os
import requests
import pytest
BASE_URL = "http://openapi.test"

@pytest.fixture
def test_document():
    return requests.get(
        f"{BASE_URL}/v1/data/opa/examples/public_servers",
        params={
            "pretty": True,
            "provenance": False,
            "explain": "full",
            "input": {"example": {"flag": True}},
            "metrics": False,
        },
    ).json()

def test_document_response(test_document):
    assert test_document["result"]["id"] == "example2"
    assert len(test_document["result"]) == 1
    rule = test_document["result"][0]["rules"][0]["body"][0]["terms"][0]
    assert rule["value"][0]["value"] == "$input"
    assert rule["value"][0]["type"] == "var"
    assert rule["value"][1]["value"] == "servers[_]"
    assert rule["value"][1]["type"] == "var"
    assert test_document["result"][0]["rules"][0]["head"]["name"] == "violations"
    assert test_document["result"][0]["rules"][0]["head"]["key"]["value"] == "$0"