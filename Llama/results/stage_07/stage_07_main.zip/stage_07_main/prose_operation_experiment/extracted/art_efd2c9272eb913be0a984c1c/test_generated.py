# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_operations():
    url = f"{BASE_URL}/v1alpha/projects/{'test-project'}{/locations/{'us-central1'}}/operations"
    params = {
        'filter': '',
        'pageSize': 10,
        'pageToken': ''
    }
    headers = {'Accept': 'application/json'}
    
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    response.raise_for_status()
    data = response.json()
    assert isinstance(data, dict)
    assert 'nextPageToken' in data['operations']
    assert all(isinstance(operation, dict) for operation in data['operations'])