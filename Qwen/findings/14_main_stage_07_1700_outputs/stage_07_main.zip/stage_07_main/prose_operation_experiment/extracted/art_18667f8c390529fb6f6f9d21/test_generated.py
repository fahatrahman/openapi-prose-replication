import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_vod_source():
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20130524/us-east-1/ec2/aws4_request",
        "X-Amz-Date": "20130524T000000Z",
        "X-Amz-Security-Token": "AQoDYXdzEPT//////////wEXAMPLEn+Y3JhZW5kIHRoZSBjb250ZW50IGFuZCBub3QgYWxsIGluIHNvbWUgbG9jYQ==",
        "X-Amz-Signature": "d09c41b670aa0c44d4782192a3ff0ad99b87ae190ed8290877dfcdc4b67dc00a",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-algorithm;x-amz-credential;x-amz-security-token"
    }
    path_params = {
        "SourceLocationName": "example-source-location",
        "VodSourceName": "example-vod-source"
    }
    url = f"{BASE_URL}/sourceLocation/{path_params['SourceLocationName']}/vodSource/{path_params['VodSourceName']}"
    response = requests.delete(url, headers=headers)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)