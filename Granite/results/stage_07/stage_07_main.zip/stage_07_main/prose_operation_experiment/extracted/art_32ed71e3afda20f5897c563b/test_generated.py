import os
import pytest
import requests
from typing import Dict

BASE_URL = "http://openapi.test"
HEADERS: Dict[str, str] = {"Content-Type": "application/json"}

def test_update_group():
    group_key = "example_group_key"
    new_data: Dict[str, str] = {
        "description": "Updated Group Description",
        "name": "updated_group_name"
    }

    url = f"{BASE_URL}/admin/directory/v1/groups/{group_key}"
    response = requests.patch(url, json=new_data, headers=HEADERS)

    assert response.status_code == 200
    updated_group = response.json()
    assert updated_group["description"] == new_data["description"]
    assert updated_group["name"] == new_data["name"]