import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
SESSION.mount("https://", HTTPAdapter(max_retries=3))

@pytest.fixture
def api_client():
    return SESSION

def test_articles_retrieval(api_client):
    source = "nyt"
    section = "world"
    limit = 5
    offset = 0

    response = api_client.get(
        url=urljoin(BASE_URL, f"/content/{source}/{section}.json"),
        params={"limit": limit, "offset": offset},
    )

    assert response.status_code == 200

    articles = response.json()["results"]
    assert len(articles) <= limit