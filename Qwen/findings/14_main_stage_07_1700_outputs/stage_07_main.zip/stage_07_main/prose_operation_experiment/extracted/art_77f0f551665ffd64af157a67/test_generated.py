import pytest
import requests

BASE_URL = "http://openapi.test"

def test_fetch_reward_program_activations():
    url = f"{BASE_URL}/reward_program_activation"
    params = {
        "filter[patient]": "patient_id",
        "filter[groups]": "group_id1,group_id2",
        "filter[organization]": "organization_id"
    }
    headers = {
        "Authorization": "Bearer your_access_token"
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 200
    data = response.json()
    assert "data" in data
    assert isinstance(data["data"], list)
    assert "meta" in data
    assert "count" in data["meta"]
    assert isinstance(data["meta"]["count"], int)
    assert "req_id" in data["meta"]

def test_fetch_reward_program_activations_unauthorized():
    url = f"{BASE_URL}/reward_program_activation"
    params = {
        "filter[patient]": "patient_id"
    }
    headers = {
        "Authorization": "Bearer invalid_access_token"
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 401
    error_response = response.json()
    assert "errors" in error_response
    assert len(error_response["errors"]) > 0
    assert error_response["errors"][0]["code"] == "Unauthorized"

def test_fetch_reward_program_activations_forbidden():
    url = f"{BASE_URL}/reward_program_activation"
    params = {
        "filter[patient]": "patient_id"
    }
    headers = {
        "Authorization": "Bearer forbidden_access_token"
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 403
    error_response = response.json()
    assert "errors" in error_response
    assert len(error_response["errors"]) > 0
    assert error_response["errors"][0]["code"] == "Forbidden"