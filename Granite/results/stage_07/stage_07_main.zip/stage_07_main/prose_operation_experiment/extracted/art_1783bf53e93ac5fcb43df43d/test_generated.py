import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retry strategy
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

@pytest.fixture
def player_game_projection_stats():
    competition = "FUU"
    date = "2017-02-27"
    format_ = "json"

    url = f"{BASE_URL}/{format}/PlayerGameProjectionStatsByCompetition/{competition}/{date}"

    response = session.get(url)
    response.raise_for_status()

    return response.json()

def test_player_game_projection_stats(player_game_projection_stats):
    assert isinstance(player_game_projection_stats, list)
    for player in player_game_projection_stats:
        assert set(player.keys()) == {"Assists", "BlockedShots", "Captain", "CornersWon", "Crosses", "DateTime", "Day", "DefenderCleanSheets", "DraftKingsPosition", "DraftKingsSalary", "FanDuelPosition", "FanDuelSalary", "FantasyPoints", "FantasyPointsDraftKings", "FantasyPointsFanDuel", "FantasyPointsMondogoal", "FantasyPointsYahoo", "Fouled", "Fouls", "GameId", "Games", "GlobalGameId", "GlobalOpponentId", "GlobalTeamId", "GoalkeeperCleanSheets", "GoalkeeperGoalsAgainst", "GoalkeeperSaves", "GoalkeeperSingleGoalAgainst", "GoalkeeperWins", "Goals", "HomeOrAway", "InjuryBodyPart", "InjuryNotes", "InjuryStartDate", "InjuryStatus", "Interceptions", "IsGameOver", "Jersey", "LastManTackle", "Minutes", "MondogoalPosition", "MondogoalSalary", "Name", "Offsides", "Opponent", "OpponentId", "OpponentScore", "OwnGoals", "Passes", "PassesCompleted", "PenaltiesConceded", "PenaltiesWon", "PenaltyKickGoals", "PenaltyKickMisses", "PenaltyKickSaves", "PlayerId", "Position", "PositionCategory", "RedCards", "RoundId", "Score", "Season", "SeasonType", "ShortName", "Shots", "ShotsOnGoal", "Started", "StatId", "Suspension", "SuspensionReason", "Tackles", "TacklesWon", "Team", "TeamId", "Touches", "Updated", "UpdatedUtc", "YahooPosition", "YahooSalary", "YellowCards", "YellowRedCards"}