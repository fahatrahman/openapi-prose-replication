# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_task():
    task_id = "e77602e0-3fb8-4734-aef9-fbc6fdcb0fa8"
    headers = {"Authorization": f"Bearer {''}"}
    response = requests.get(f"{BASE_URL}/org/tasks/{task_id}", headers=headers)
    
    assert response.status_code == 200
    
    try:
        response.raise_for_status()
    except requests.RequestException as e:
        pytest.fail(f"Request failed with status code {response.status_code}: {e}")
        
    # Check if Task schema matches response content
    task_schema = {
        "type": "object",
        "properties": {
            "agent_id": {"type": "string", "format": "uuid"},
            "client_id": {"type": "string", "format": "uuid"},
            "created_at": {"type": "integer", "format": "int64"},
            "created_by": {"type": "string", "format": "email"},
            "created_by_user_id": {"type": "string", "format": "uuid"},
            "cruncher_id": {"type": "string", "format": "uuid"},
            "description": {"type": "string"},
            "error": {"type": "string"},
            "hidden": {"type": "boolean"},
            "id": {"type": "string", "format": "uuid"},
            "name": {"type": "string"},
            "organization_id": {"type": "string", "format": "uuid"},
            "params": {"type": "object", "additionalProperties": {"type": "string"}},
            "parent_id": {"type": "string", "format": "uuid"},
            "recur": {"type": "boolean"},
            "recur_frequency": {"type": "string"},
            "recur_last": {"type": "integer", "format": "int64"},
            "recur_last_task_id": {"type": "string", "format": "uuid"},
            "recur_next": {"type": "integer", "format": "int64"},
            "site_id": {"type": "string", "format": "uuid"},
            "start_time": {"type": "integer", "format": "int64"},
            "stats": {"type": "object", "additionalProperties": True},
            "status": {"type": "string"},
            "template_id": {"type": "string", "format": "uuid"},
            "type": {"type": "string"},
            "updated_at": {"type": "integer", "format": "int64"}
        },
        "required": ["id"]
    }
    
    assert response.json() == pytest.approx(task_schema, reltol=1e-7)