import pytest
import requests
from jsonschema import ValidationError

BASE_URL = "http://openapi.test"

def test_certificate_siteseal_get():
    url = f"{BASE_URL}/v1/certificates/{certificate_id}/siteSeal"
    params = {"theme": theme, "locale": locale}

    response = requests.get(url, params=params)

    assert response.status_code == 200
    try:
        response.json()
    except ValidationError:
        raise AssertionError("Response body does not match schema")

@pytest.fixture
def certificate_id():
    return "test-certificate-id"

@pytest.fixture
def theme():
    return "LIGHT"

@pytest.fixture
def locale():
    return "en"