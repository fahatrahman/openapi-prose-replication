"""Deterministic OpenAPI request evaluation and frozen response delivery."""
from __future__ import annotations

import base64
import hashlib
import json
import re
from urllib.parse import parse_qs, unquote, urlsplit

from jsonschema import Draft4Validator, Draft202012Validator
from jsonschema.exceptions import SchemaError
from referencing import Registry, Resource
from referencing.jsonschema import DRAFT4, DRAFT202012


ROUTING_VERSION = "stage06-openapi-contract-v6"
DOCUMENT_URI = "urn:stage06:canonical-operation"
FORM_MEDIA_TYPE = "application/x-www-form-urlencoded"
LEGACY_FORM_RULE = {
    "op_id": "op_42818f46abfce2a2ec0520ea",
    "method": "PUT",
    "path_template": "/api/v1/filters/{id}",
    "document_sha256": "0f23e5b6c3e149d86ba4e3920ad0cb9f3a5feee81ce14b32f839852cb8b56cff",
    "declared_media_type": "application/form-data",
    "wire_media_type": FORM_MEDIA_TYPE,
    "array_fields": {"context": "context[]"},
    "sources": [
        "https://docs.joinmastodon.org/methods/filters/#update-legacy",
        "https://docs.joinmastodon.org/client/intro/#form-data",
        "https://docs.joinmastodon.org/client/intro/#array",
    ],
}
NEGATIVE_INTENTS = {
    "invalid_missing_required_parameter": ("parameter", "missing"),
    "invalid_missing_required_request_body": ("body", "missing"),
    "parameter_invalid_wrong_type": ("parameter", "type"),
    "parameter_invalid_enum_value": ("parameter", "enum"),
    "parameter_invalid_below_minimum": ("parameter", "minimum"),
    "parameter_invalid_below_minimum_items": ("parameter", "minItems"),
    "body_invalid_wrong_type": ("body", "type"),
    "body_invalid_missing_required_property": ("body", "required"),
    "body_invalid_below_minimum": ("body", "minimum"),
    "body_invalid_below_minimum_items": ("body", "minItems"),
    "body_invalid_below_minimum_length": ("body", "minLength"),
    "body_invalid_above_maximum_length": ("body", "maxLength"),
}


class UnsupportedRoute(RuntimeError):
    failure_owner = "GENERATED_OUTPUT"

    def __init__(self, code, detail=None):
        self.code = code
        self.detail = detail
        super().__init__(code)


class EvaluatorUnavailable(UnsupportedRoute):
    failure_owner = "EVALUATOR_LIMITATION"


class EvaluatorDefect(UnsupportedRoute):
    failure_owner = "EVALUATOR_FAILURE"


def normalize_prepared_request(method, url, headers=None, body=None):
    """Keep transport details even for requests the router will reject."""
    try:
        parts = urlsplit(url)
        origin_allowed = (
            parts.scheme == "http" and parts.netloc.lower() == "openapi.test"
        )
    except ValueError as error:
        raise UnsupportedRoute("MALFORMED_REQUEST_URL") from error
    headers = {str(k).lower(): str(v) for k, v in (headers or {}).items()}
    cookies = dict(
        tuple(part.strip().split("=", 1))
        for part in headers.get("cookie", "").split(";") if "=" in part
    )
    content_type = headers.get("content-type", "").lower().strip()
    media_type = content_type.split(";", 1)[0].strip()
    body_present = body is not None and body != b"" and body != ""
    body_encoding = "none"
    if body_present:
        if isinstance(body, bytes):
            try:
                body = body.decode("utf-8")
            except UnicodeDecodeError:
                body = {"base64": base64.b64encode(body).decode("ascii")}
                body_encoding = "binary"
        if isinstance(body, str):
            body_encoding = "text"
            if _is_json(media_type):
                try:
                    body = json.loads(body, parse_constant=_reject_json_constant)
                    body_encoding = "json"
                except ValueError:
                    body_encoding = "malformed_json"
            elif media_type == "application/x-www-form-urlencoded":
                body = _query(body)
                body_encoding = "form"
        elif body_encoding != "binary":
            body_encoding = "json"
    else:
        body = None
    return {
        "method": method.upper(), "raw_url": url, "origin_allowed": origin_allowed,
        "path": parts.path or "/", "query": _query(parts.query),
        "headers": headers, "cookies": cookies, "body": body,
        "body_present": body_present, "body_encoding": body_encoding,
        "media_type": content_type,
    }


def _is_json(media_type):
    return media_type in {"application/json", "text/json"} or media_type.endswith("+json")


def _reject_json_constant(value):
    raise ValueError(f"Non-JSON constant: {value}")


def _query(text):
    return {key: values[0] if len(values) == 1 else values
            for key, values in parse_qs(text, keep_blank_values=True).items()}


def match_path_template(template, actual_path):
    """Match path segments before unquoting parameter values."""
    names = re.findall(r"\{([^}]+)\}", template)
    fragments = re.split(r"\{[^}]+\}", template)
    pattern = "([^/]+)".join(re.escape(fragment) for fragment in fragments)
    match = re.fullmatch(pattern, actual_path)
    return None if match is None else dict(zip(names, map(unquote, match.groups())))


def _local_reference(document, reference):
    if not isinstance(reference, str) or not reference.startswith("#/"):
        raise EvaluatorUnavailable("UNSUPPORTED_REFERENCE", reference)
    node = document
    try:
        for part in unquote(reference[2:]).split("/"):
            node = node[part.replace("~1", "/").replace("~0", "~")]
    except (KeyError, TypeError) as error:
        raise EvaluatorUnavailable("UNRESOLVED_LOCAL_REFERENCE", reference) from error
    return node


def _object(document, value):
    seen = set()
    while isinstance(value, dict) and "$ref" in value:
        reference = value["$ref"]
        if reference in seen:
            raise EvaluatorUnavailable("CYCLIC_OBJECT_REFERENCE")
        seen.add(reference)
        value = _local_reference(document, reference)
    return value


def _schema_tree(value, openapi30):
    if isinstance(value, list):
        return [_schema_tree(item, openapi30) for item in value]
    if not isinstance(value, dict):
        return value
    result = {
        key: (item if key in {"enum", "const", "default", "example", "examples"}
              else _schema_tree(item, openapi30))
        for key, item in value.items()
    }
    if openapi30 and result.get("nullable") is True and isinstance(result.get("type"), str):
        result["type"] = [result["type"], "null"]
    return result


def _schema_errors(schema, instance, document):
    if not isinstance(schema, (dict, bool)):
        raise EvaluatorDefect("MALFORMED_FROZEN_SCHEMA")
    openapi30 = document.get("openapi", "").startswith("3.0.")
    spec = DRAFT4 if openapi30 else DRAFT202012
    validator = Draft4Validator if openapi30 else Draft202012Validator
    if openapi30 and isinstance(schema, bool):
        raise EvaluatorUnavailable("UNSUPPORTED_OPENAPI30_BOOLEAN_SCHEMA")
    # A registry without a retrieval callback only resolves the supplied
    # canonical document and built-in meta-schemas. It cannot fetch URLs.
    local_root = _schema_tree(document, openapi30)
    registry = Registry().with_resource(DOCUMENT_URI, Resource(local_root, spec))
    schema = _schema_tree(schema, openapi30)
    try:
        validator.check_schema(schema)
        return list(validator(schema, registry=registry,
                              _resolver=registry.resolver(DOCUMENT_URI),
                              format_checker=validator.FORMAT_CHECKER).iter_errors(instance))
    except SchemaError as error:
        raise EvaluatorUnavailable("UNSUPPORTED_FROZEN_SCHEMA", str(error)) from error
    except Exception as error:
        # Referencing exceptions are wrapped by jsonschema.
        if type(error).__module__.split(".")[0] in {"jsonschema", "referencing"}:
            raise EvaluatorUnavailable("UNRESOLVED_SCHEMA_REFERENCE", str(error)) from error
        raise


def _scalar(value, schema):
    kind = schema.get("type")
    if isinstance(kind, list):
        choices = [item for item in kind if item != "null"]
        if len(choices) != 1:
            raise EvaluatorUnavailable("AMBIGUOUS_PARAMETER_SERIALIZATION")
        kind = choices[0]
    if kind == "integer" and re.fullmatch(r"[+-]?[0-9]+", value):
        try:
            return int(value)
        except ValueError:
            return value
    if kind == "number" and re.fullmatch(r"[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?", value):
        number = float(value)
        if number not in (float("inf"), float("-inf")):
            return number
    if kind == "boolean" and value in {"true", "false"}:
        return value == "true"
    return value


def _parameter_value(raw, parameter, schema, document):
    location = parameter["in"]
    style = parameter.get("style", "form" if location in {"query", "cookie"} else "simple")
    explode = parameter.get("explode", style == "form")
    if style not in ({"form", "spaceDelimited", "pipeDelimited"} if location == "query"
                     else {"form"} if location == "cookie" else {"simple"}):
        raise EvaluatorUnavailable("UNSUPPORTED_PARAMETER_STYLE", (location, style))
    if schema.get("type") == "object":
        if explode:
            raise EvaluatorUnavailable("UNSUPPORTED_EXPLODED_OBJECT_PARAMETER", parameter["name"])
        if isinstance(raw, list):
            raise EvaluatorUnavailable("AMBIGUOUS_OBJECT_PARAMETER", parameter["name"])
        parts = raw.split(",")
        if len(parts) % 2:
            raise EvaluatorUnavailable("UNSUPPORTED_OBJECT_PARAMETER", parameter["name"])
        return {key: _scalar(value, schema.get("properties", {}).get(key, {}))
                for key, value in zip(parts[::2], parts[1::2])}
    if schema.get("type") != "array":
        if isinstance(raw, list):
            return raw
        return _scalar(raw, schema)
    items = _object(document, schema.get("items") or {})
    if style == "form" and explode:
        values = raw if isinstance(raw, list) else [raw]
    else:
        if isinstance(raw, list):
            raise EvaluatorUnavailable("AMBIGUOUS_ARRAY_SERIALIZATION", parameter["name"])
        values = raw.split({"spaceDelimited": " ", "pipeDelimited": "|"}.get(style, ","))
    return [_scalar(value, items) for value in values]


def _select_media(content, received):
    if not received:
        raise EvaluatorUnavailable("REQUEST_MEDIA_TYPE_UNSPECIFIED")
    received, *parameters = [part.strip() for part in received.split(";")]
    received_params = set(parameters)
    matches = []
    for declared, media in content.items():
        name, *params = [part.strip() for part in declared.lower().split(";")]
        if not set(params).issubset(received_params):
            continue
        if name == received:
            matches.append(((2, len(params)), media))
        elif name == received.split("/", 1)[0] + "/*":
            matches.append(((1, len(params)), media))
        elif name == "*/*":
            matches.append(((0, len(params)), media))
    if not matches:
        return None
    best = max(rank for rank, _ in matches)
    winners = [media for rank, media in matches if rank == best]
    if len(winners) != 1:
        raise EvaluatorUnavailable("AMBIGUOUS_REQUEST_MEDIA_TYPE")
    return winners[0]


def _operation(document, template, method):
    try:
        path = _object(document, document["paths"][template])
        return path, _object(document, path[method.lower()])
    except (KeyError, TypeError) as error:
        raise EvaluatorDefect("ORACLE_OPERATION_NOT_IN_CANONICAL_DOCUMENT") from error


SUCCESS_STATUS_POLICY = "single-explicit-success-v1"


def success_status_mapping(document, path_template, method):
    """Return a status only when the operation has one explicit success candidate."""
    _, operation = _operation(document, path_template, method)
    responses = operation.get("responses", {})
    codes = sorted(str(code) for code in responses if re.fullmatch(r"2[0-9]{2}", str(code)))
    has_range = any(str(code).upper() == "2XX" for code in responses)
    if len(codes) > 1 or has_range:
        raise EvaluatorUnavailable("AMBIGUOUS_SUCCESS_STATUS_MAPPING",
                                   {"statuses": codes, "has_2xx_range": has_range})
    return {"status": int(codes[0])} if codes else None


def verify_success_status_mapping(document, scenario):
    if scenario["expected_validity"] != "VALID":
        return
    expected = success_status_mapping(document, scenario["path_template"], scenario["method"])
    if expected is None:
        raise EvaluatorUnavailable("NO_DOCUMENTED_RESPONSE_MAPPING")
    if scenario.get("documented_response_mapping") != expected:
        raise EvaluatorDefect("FROZEN_SUCCESS_STATUS_MAPPING_MISMATCH")


def legacy_form_rule(document, template, method):
    rule = LEGACY_FORM_RULE
    if (template, method.upper()) != (rule["path_template"], rule["method"]):
        return None
    encoded = json.dumps(document, sort_keys=True, separators=(",", ":"),
                         ensure_ascii=False).encode()
    return rule if hashlib.sha256(encoded).hexdigest() == rule["document_sha256"] else None


def _decode_form(body, media, document, rule):
    schema = _object(document, media.get("schema", {}))
    if media.get("encoding") or not isinstance(body, dict):
        raise EvaluatorUnavailable("UNSUPPORTED_FORM_ENCODING")
    properties = schema.get("properties", {})
    aliases = {wire: logical for logical, wire in (rule or {}).get("array_fields", {}).items()}
    decoded = {}
    for wire, raw in body.items():
        if wire in (rule or {}).get("array_fields", {}):
            raise EvaluatorUnavailable("UNSUPPORTED_UNBRACKETED_FORM_ARRAY", wire)
        logical = aliases.get(wire, wire)
        property_schema = _object(document, properties.get(logical, {}))
        decoded[logical] = _parameter_value(
            raw, {"in": "query", "name": logical}, property_schema, document)
    return decoded


def _security_observation(document, operation, request):
    """Record credential presence; never infer authentication success offline."""
    alternatives = operation.get("security", document.get("security", []))
    if not alternatives or {} in alternatives:
        return "NOT_REQUIRED"
    schemes = (document.get("components") or {}).get("securitySchemes", {})
    for option in alternatives:
        supplied = []
        for name in option:
            scheme = _object(document, schemes.get(name, {}))
            if scheme.get("type") == "apiKey":
                location, key = scheme.get("in"), scheme.get("name", "")
                source = {"header": request["headers"], "query": request["query"],
                          "cookie": request["cookies"]}.get(location, {})
                supplied.append(bool(source.get(key.lower() if location == "header" else key)))
            else:
                supplied.append(bool(request["headers"].get("authorization")))
        if supplied and all(supplied):
            return "PRESENT_NOT_VERIFIED"
    return "MISSING_OR_UNVERIFIABLE"


def _assess(request, document, template, path_values):
    path, operation = _operation(document, template, request["method"])
    parameters = {}
    for raw in [*path.get("parameters", []), *operation.get("parameters", [])]:
        parameter = _object(document, raw)
        location, name = parameter.get("in"), parameter.get("name")
        if location not in {"path", "query", "header", "cookie"} or not name:
            raise EvaluatorUnavailable("UNSUPPORTED_PARAMETER_DEFINITION")
        key = name.lower() if location == "header" else name
        parameters[location, key] = parameter
    values = {"path": path_values, "query": request["query"],
              "header": request["headers"], "cookie": request["cookies"]}
    violations = set()
    typed = {}
    for (location, key), parameter in parameters.items():
        if key not in values[location]:
            if parameter.get("required") is True or location == "path":
                violations.add(("parameter", location, key, "missing"))
            continue
        if "content" in parameter:
            raise EvaluatorUnavailable("UNSUPPORTED_PARAMETER_CONTENT", (location, key))
        schema = parameter.get("schema") or {}
        effective_schema = _object(document, schema)
        value = _parameter_value(values[location][key], parameter, effective_schema, document)
        typed.setdefault(location, {})[key] = value
        for error in _schema_errors(schema, value, document):
            violations.add(("parameter", location, key, str(error.validator)))
        if (isinstance(value, int) and not isinstance(value, bool)
                and effective_schema.get("format") in {"int32", "int64"}):
            bits = 32 if effective_schema["format"] == "int32" else 64
            if not -(2 ** (bits - 1)) <= value < 2 ** (bits - 1):
                violations.add(("parameter", location, key, "format"))
    request_body = _object(document, operation.get("requestBody", {}))
    if not request["body_present"]:
        if request_body.get("required") is True:
            violations.add(("body", "", "", "missing"))
    elif request_body:
        content = request_body.get("content", {})
        rule = legacy_form_rule(document, template, request["method"])
        wire_type = request["media_type"].split(";", 1)[0].strip()
        media = (_select_media(content, rule["declared_media_type"])
                 if rule and wire_type == rule["wire_media_type"]
                 else _select_media(content, request["media_type"]))
        if rule and wire_type == rule["declared_media_type"]:
            raise EvaluatorUnavailable("UNSUPPORTED_LEGACY_FORM_WIRE_TYPE")
        if media is None:
            violations.add(("body", "", "", "media_type"))
        elif request["body_encoding"] == "malformed_json":
            violations.add(("body", "", "", "malformed_json"))
        else:
            if request["body_encoding"] not in {"json", "form"}:
                raise EvaluatorUnavailable("UNSUPPORTED_REQUEST_BODY_SERIALIZATION")
            value = request["body"]
            schema = media.get("schema", {})
            if request["body_encoding"] == "form":
                value = _decode_form(value, media, document, rule)
            for error in _schema_errors(schema, value, document):
                pointer = "/".join(map(str, error.absolute_path))
                if error.validator == "required" and isinstance(error.instance, dict):
                    for missing in set(error.validator_value) - error.instance.keys():
                        violations.add(("body", "", f"{pointer}/{missing}", "required"))
                else:
                    violations.add(("body", "", pointer, str(error.validator)))
    return typed, violations, _security_observation(document, operation, request)


def _literal(value):
    if isinstance(value, bool):
        return str(value).lower()
    return str(value)


def _fixture_values(scenario):
    values = scenario.get("parameter_values") or {}
    return {
        location: {
            key.lower() if location == "header" else key:
            ([_literal(x) for x in value] if isinstance(value, list) and len(value) != 1
             else _literal(value[0]) if isinstance(value, list) and len(value) == 1
             else _literal(value))
            for key, value in (values.get(location) or {}).items()
        }
        for location in ("path", "query", "header", "cookie")
    }


def _exact_fixture(request, path, scenario):
    values = _fixture_values(scenario)
    return (
        path == values["path"] and request["query"] == values["query"]
        and all(request["headers"].get(k) == v for k, v in values["header"].items())
        and all(request["cookies"].get(k) == v for k, v in values["cookie"].items())
        and (scenario.get("body") is not None) == request["body_present"]
        and json.dumps(request["body"], sort_keys=True)
        == json.dumps(scenario.get("body"), sort_keys=True)
    )


def _negative_signature(scenario, document, template, request):
    values = _fixture_values(scenario)
    fixture_request = {
        **request, "query": values["query"], "headers": values["header"],
        "cookies": values["cookie"], "body": scenario.get("body"),
        "body_present": scenario.get("body") is not None, "body_encoding": "json",
    }
    try:
        _, violations, _ = _assess(fixture_request, document, template, values["path"])
    except EvaluatorUnavailable:
        return set()
    return violations


def prepare_frozen_fixture(document, scenario):
    """Serialize a frozen positive fixture according to its operation."""
    from urllib.parse import quote, urlencode

    template = scenario["path_template"]
    path, operation = _operation(document, template, scenario["method"])
    parameters = {}
    for raw in [*path.get("parameters", []), *operation.get("parameters", [])]:
        parameter = _object(document, raw)
        parameters[parameter["in"], parameter["name"].lower()
                   if parameter["in"] == "header" else parameter["name"]] = parameter
    values = _fixture_values(scenario)
    for location, entries in (scenario.get("parameter_values") or {}).items():
        for name, value in entries.items():
            key = name.lower() if location == "header" else name
            parameter = parameters.get((location, key), {})
            style = parameter.get("style", "form" if location in {"query", "cookie"} else "simple")
            explode = parameter.get("explode", style == "form")
            if isinstance(value, dict) and not value and style == "form" and explode:
                # An empty exploded object produces no wire parameters.
                values[location].pop(key, None)
            elif isinstance(value, list) and (style != "form" or not explode):
                separator = {"spaceDelimited": " ", "pipeDelimited": "|"}.get(style, ",")
                values[location][key] = separator.join(map(_literal, value))
    url_path = template
    for key, value in values["path"].items():
        url_path = url_path.replace("{" + key + "}", quote(value, safe=""))
    if "{" in url_path:
        raise EvaluatorUnavailable("FROZEN_FIXTURE_PATH_UNSERIALIZABLE")
    headers = values["header"]
    if values["cookie"]:
        headers["cookie"] = "; ".join(f"{k}={v}" for k, v in values["cookie"].items())
    body = scenario.get("body")
    if body is not None:
        content = _object(document, operation.get("requestBody", {})).get("content", {})
        json_media = [m for m in content if _is_json(m.split(";", 1)[0].strip().lower())]
        rule = legacy_form_rule(document, template, scenario["method"])
        if rule and rule["declared_media_type"] in content and isinstance(body, dict):
            headers["content-type"] = rule["wire_media_type"]
            form = {}
            for name, value in body.items():
                wire = rule["array_fields"].get(name, name)
                form[wire] = ([_literal(item) for item in value]
                              if isinstance(value, list) else _literal(value))
            encoded = urlencode(form, doseq=True)
            decoded = _decode_form(_query(encoded), content[rule["declared_media_type"]],
                                   document, rule)
            if decoded != body:
                raise EvaluatorDefect("FROZEN_FORM_ROUNDTRIP_MISMATCH")
            body = encoded.encode()
        elif json_media:
            declared = headers.get("content-type", "")
            if declared not in json_media:
                headers["content-type"] = min(
                    json_media, key=lambda media: (media != "application/json", media)
                )
            body = json.dumps(body).encode()
        elif "application/x-www-form-urlencoded" in content and isinstance(body, dict):
            headers["content-type"] = "application/x-www-form-urlencoded"
            body = urlencode(body, doseq=True).encode()
        else:
            raise EvaluatorUnavailable("FROZEN_FIXTURE_BODY_UNSERIALIZABLE", sorted(content))
    query = urlencode(values["query"], doseq=True)
    return normalize_prepared_request(
        scenario["method"], "http://openapi.test" + url_path + ("?" + query if query else ""),
        headers, body,
    )


def prepare_frozen_response(record, baseline):
    """Serialize JSON strings as JSON and preserve registered response headers."""
    evidence = record.get("source_evidence") or ()
    if isinstance(evidence, dict):
        evidence = [evidence]
    baseline_evidence = baseline.get("source_evidence") or ()
    if isinstance(baseline_evidence, dict):
        baseline_evidence = [baseline_evidence]
    media_type = next((row["media_type"] for row in [*evidence, *baseline_evidence]
                       if row.get("media_type")), "")
    headers = dict(record.get("headers") or {})
    content_type = next((v for k, v in headers.items() if k.lower() == "content-type"), "")
    body = record.get("body")
    if body is None:
        return headers, b""
    if not content_type and media_type:
        headers["Content-Type"] = media_type
        content_type = media_type
    if _is_json(content_type.split(";", 1)[0].strip().lower()) or not isinstance(body, str):
        return headers, json.dumps(body, allow_nan=False).encode()
    return headers, body.encode()


def audit_frozen_response(document, scenario, record, baseline):
    """Independently check that a baseline or variation obeys its response contract."""
    verify_success_status_mapping(document, scenario)
    _, operation = _operation(document, scenario["path_template"], scenario["method"])
    code = str(record["status"])
    responses = operation.get("responses", {})
    response = responses.get(code, responses.get(code[:1] + "XX", responses.get("default")))
    if response is None:
        raise EvaluatorDefect("UNDOCUMENTED_FROZEN_RESPONSE_STATUS", code)
    response = _object(document, response)
    headers, _ = prepare_frozen_response(record, baseline)
    headers = {key.lower(): value for key, value in headers.items()}
    for name, raw in (response.get("headers") or {}).items():
        declaration = _object(document, raw)
        if declaration.get("required") and name.lower() not in headers:
            raise EvaluatorDefect("MISSING_REQUIRED_FROZEN_RESPONSE_HEADER", name)
    if code == "204":
        if record.get("body") is not None:
            raise EvaluatorDefect("UNDOCUMENTED_FROZEN_RESPONSE_BODY")
        return
    content = response.get("content") or {}
    if not content:
        if record.get("body") is not None:
            raise EvaluatorDefect("UNDOCUMENTED_FROZEN_RESPONSE_BODY")
        return
    media = _select_media(content, headers.get("content-type", ""))
    if media is None:
        raise EvaluatorDefect("FROZEN_RESPONSE_MEDIA_TYPE_MISMATCH")
    errors = _schema_errors(media.get("schema", {}), record.get("body"), document)
    if errors:
        raise EvaluatorDefect("FROZEN_RESPONSE_SCHEMA_MISMATCH",
                              sorted({str(error.validator) for error in errors}))


def classify_request(request, frozen_scenarios, operation_document=None):
    if not request["origin_allowed"]:
        raise UnsupportedRoute("UNAUTHORIZED_HOST")
    matches = []
    for scenario in frozen_scenarios:
        if (scenario.get("applicability") == "APPLICABLE"
                and request["method"] == scenario["method"].upper()):
            template = scenario["path_template"]
            path = match_path_template(template, request["path"])
            if path is not None:
                matches.append((scenario, template, path))
    if not matches:
        raise UnsupportedRoute("REQUEST_OUTSIDE_TARGET_OPERATION")
    if len({scenario["scenario_id"] for scenario, _, _ in matches}) != len(matches):
        raise EvaluatorDefect("DUPLICATE_REGISTERED_SCENARIO")
    if len({template for _, template, _ in matches}) != 1:
        raise EvaluatorUnavailable("AMBIGUOUS_OPERATION_TEMPLATE")
    if operation_document is None:
        raise EvaluatorDefect("MISSING_CANONICAL_OPERATION_DOCUMENT")
    _, template, path = matches[0]
    typed, violations, security = _assess(request, operation_document, template, path)
    candidates = []
    if violations:
        for scenario, _, _ in matches:
            if scenario["expected_validity"] != "INVALID":
                continue
            signature = _negative_signature(scenario, operation_document, template, request)
            # An invalid fixture with multiple discrepancies does not define
            # a single-violation scenario that the evaluator can credit.
            if len(signature) == 1 and signature == violations:
                scope, _, _, validator = next(iter(signature))
                if NEGATIVE_INTENTS.get(scenario["intent"]) == (scope, validator):
                    candidates.append(scenario)
        exact = [s for s in candidates if _exact_fixture(request, path, s)]
        candidates = exact or candidates
        status = "SEMANTIC_NEGATIVE_MATCH"
    else:
        valid = [s for s, _, _ in matches if s["expected_validity"] == "VALID"]
        exact = [s for s in valid if _exact_fixture(request, path, s)]
        candidates = exact or [s for s in valid if s["intent"] == "valid_baseline_request"]
        status = "EXACT_FROZEN_SCENARIO_REPLAY" if exact else "SEMANTIC_VALID_BASELINE"

    if len(candidates) != 1:
        raise EvaluatorUnavailable("AMBIGUOUS_OR_UNMAPPED_REQUEST_SEMANTICS", {
            "candidate_ids": [s["scenario_id"] for s in candidates],
            "observed_violations": sorted(violations),
        })
    matched = candidates[0]
    verify_success_status_mapping(operation_document, matched)
    return {
        "classification_status": status, "classifiable": True,
        "scenario_id": matched["scenario_id"], "intent": matched["intent"],
        "expected_validity": matched["expected_validity"], "positive": not violations,
        "documented_response_mapping": matched.get("documented_response_mapping"),
        "typed_parameters": typed, "observed_violations": sorted(violations),
        "security_observation": security,
    }


def select_frozen_response(classification, baselines, mode="baseline", mutation=None):
    scenario_id = classification["scenario_id"]
    mapping = classification.get("documented_response_mapping")
    if mapping is None:
        raise EvaluatorUnavailable("NO_DOCUMENTED_RESPONSE_MAPPING")
    linked = [row for row in baselines if row["scenario_id"] == scenario_id]
    if len(linked) != 1:
        raise EvaluatorDefect("FROZEN_BASELINE_LINK_COUNT", len(linked))
    baseline = linked[0]
    if int(baseline["status"]) != int(mapping["status"]):
        raise EvaluatorDefect("FROZEN_BASELINE_STATUS_MISMATCH")
    if mode == "baseline":
        return baseline
    if mode not in {"fault", "variation"} or mutation is None:
        raise EvaluatorDefect("INVALID_REPLAY_CONFIGURATION")
    # Only the designated baseline is replaced. Other requests in the same
    # run still receive their own frozen baseline responses.
    if mutation.get("baseline_id") != baseline["baseline_id"]:
        return baseline
    if mutation.get("scenario_id") not in {None, scenario_id}:
        raise EvaluatorDefect("MUTATION_SCENARIO_LINK_MISMATCH")
    return mutation
