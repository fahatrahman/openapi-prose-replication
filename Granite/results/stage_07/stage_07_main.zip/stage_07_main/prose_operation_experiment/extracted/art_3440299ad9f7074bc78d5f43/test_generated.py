import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup retry strategy for requests
retries = Retry(
    total=5,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
adapter = HTTPAdapter(max_retries=retries)
http = requests.Session()
http.mount("https://", adapter)
http.mount("http://", adapter)

requests.adapters.DEFAULT_RETRIES = retries

@pytest.fixture
def http_client():
    return http

def test_update_placement(http_client):
    path_params = {
        'projectName': 'testProject',
        'placementName': 'testPlacement'
    }

    payload = {
        'attributes': {
            'key1': 'value1',
            'key2': '',  # Clearing an attribute by passing an empty value
        }
    }

    response = http_client.put(
        f"{BASE_URL}/projects/{path_params['projectName']}/placements/{path_params['placementName']}",
        json=payload,
        headers={},
        timeout=10,
        verify=False  # Disable SSL verification for this example
    )

    assert response.status_code == 200  # Assuming success based on the provided OpenAPI description