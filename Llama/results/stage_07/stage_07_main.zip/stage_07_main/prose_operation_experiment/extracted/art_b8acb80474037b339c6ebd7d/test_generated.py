import pytest
import requests
from datetime import datetime
import hashlib

BASE_URL = "http://openapi.test"

def get_amz_date():
    return datetime.now().strftime("%Y%m%dT%H%M%SZ")

def sign_request(method, path, secret_key):
    amz_date = get_amz_date()
    headers = {
        'X-Amz-Algorithm': 'AWS4-HMAC-SHA256',
        'X-Amz-Content-Sha256': hashlib.sha256(f"{method}\n{path}\n{amz_date}\naws4_request".encode()).hexdigest(),
        'X-Amz-Credential': f"AKIAIOSFODNN7EXAMPLE/20181225/us-east-1/sqs/aws4_request",
        'X-Amz-Date': amz_date,
        'X-Amz-Security-Token': 'optional',
        'X-Amz-SignedHeaders': 'host;x-amz-date',
        'X-Amz-Signature': ''
    }
    
    # For simplicity, we're not calculating the signature here.
    # In a real-world application, you would calculate the signature using your AWS secret key.
    # This is omitted for security reasons.

    return headers

def delete_custom_verification_email_template(tmpl_name):
    url = f"{BASE_URL}/v2/email/custom-verification-email-templates/{tmpl_name}"
    method = 'DELETE'
    
    secret_key = 'YOUR_AWS_SECRET_KEY'  # Replace with your actual AWS secret key
    
    headers = sign_request(method, url, secret_key)
    
    response = requests.request(method, url, headers=headers)
    assert response.status_code == 200
    response.raise_for_status()

def test_delete_custom_verification_email_template():
    tmpl_name = "CvypAqdlnjmmnAosqc"
    delete_custom_verification_email_template(tmpl_name)

pytest.main([__file__])