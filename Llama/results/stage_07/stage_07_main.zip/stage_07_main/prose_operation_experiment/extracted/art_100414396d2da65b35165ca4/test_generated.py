# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_instance_config_operations():
    url = f"{BASE_URL}/v1/{'projects'}"
    headers = {}
    params = {
        'key': 'your_api_key',
        'quotaUser': 'your_quota_user',
        'fields': '*',
        'pageSize': 100,
        'pageToken': ''
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

def test_list_instance_config_operations_with_filter():
    url = f"{BASE_URL}/v1/{'projects'}"
    headers = {}
    params = {
        'key': 'your_api_key',
        'quotaUser': 'your_quota_user',
        'fields': '*',
        'pageSize': 100,
        'pageToken': '',
        'filter': '(metadata.@type="type.googleapis.com/google.spanner.admin.instance.v1.CreateInstanceConfigMetadata")'
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)