import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_operation():
    url = f"{BASE_URL}/v1beta1/projects/location/catalogs/operations/name"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token_here",
        "alt": "json",
        "callback": "your_callback_here",
        "fields": "your_fields_here",
        "key": "your_api_key_here",
        "oauth_token": "your_oauth_token_here",
        "prettyPrint": False,
        "quotaUser": "your_quota_user_here",
        "uploadType": "your_upload_type_here",
        "upload_protocol": "your_upload_protocol_here",
        "name": "your_operation_name_here"
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()