# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_healthcare_projects_locations_datasets_list():
    params = {
        'parent': '/v1/zynntaco/{autfnhu_lg}/yzvrewumc/{vmdixebo_lg}',
        'pageSize': 100,
        'pageToken': '',
        '_xgafv': '1',
        'access_token': '',
        'alt': 'json',
        'callback': '',
        'fields': '',
        'key': '',
        'oauth_token': '',
        'prettyPrint': False,
        'quotaUser': '',
        'upload_protocol': 'jnr',
        'uploadType': 'rjpug'
    }

    response = requests.get(f'{BASE_URL}/v1/{params["parent"]}/datasets', params=params)
    assert response.status_code == 200