import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_album_tracks():
    album_id = 123  # Replace with actual album ID
    fields = "None"
    lang = "Default"

    url = f"{BASE_URL}/api/albums/{album_id}/tracks?fields={fields}&lang={lang}"
    response = requests.get(url)

    assert response.status_code == 200
    assert isinstance(response.json(), list)
    for track in response.json():
        assert isinstance(track, dict)
        assert 'id' in track
        assert 'name' in track
        assert 'song' in track
        assert 'trackNumber' in track
        assert 'discNumber' in track
        assert isinstance(track['song'], dict)
        assert 'id' in track['song']
        assert 'name' in track['song']

if __name__ == "__main__":
    pytest.main()