import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_info_clusters():
    params = {
        "p_qid": "test_qid",
        "p_pretty_print": 1,
        "output": "XDD"
    }
    response = requests.get(f"{BASE_URL}/rcra_rest_services.get_info_clusters", params=params)
    assert response.status_code == 200
    assert response.headers["Content-Type"].startswith("application/")