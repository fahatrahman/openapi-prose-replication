import pytest
import requests
from requests.exceptions import HTTPError

BASE_URL = "http://openapi.test"

@pytest.mark.parametrize(
    "offering_id",
    [
        pytest.param("valid_offering_id", marks=pytest.mark.passing(reason="Assuming test case passes for a valid offering ID")),
        pytest.param("invalid_offering_id", marks=pytest.mark.skip(reason="Skipping test case for an invalid offering ID")),
    ],
)
def test_find_offering_by_id(offering_id):
    url = f"{BASE_URL}/offerings/{offering_id}"

    headers = {"Authorization": "your_api_key_here"}  # Replace with your actual API key

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        offering_data = response.json()
        assert isinstance(offering_data, dict)
        assert "contentId" in offering_data
        assert "coverImageUrl" in offering_data
        assert "description" in offering_data
        assert "earlyCloseOffDate" in offering_data
        assert "end" in offering_data
        assert "enrollmentLimit" in offering_data
        assert "hasEarlyCloseOff" in offering_data
        assert "id" in offering_data
        assert "identifier" in offering_data
        assert "isReadonly" in offering_data
        assert "metadata" in offering_data
        assert "name" in offering_data
        assert "overview" in offering_data
        assert "price" in offering_data
        assert "start" in offering_data
        assert "tasksEnabled" in offering_data
        assert "trailerVideoUrl" in offering_data
        assert "useRelativeDates" in offering_data
    elif response.status_code == 401:
        assert response.json() == {"details": "No authorization token was found.", "name": "NotAuthorizedError"}
    elif response.status_code == 403:
        assert response.json() == {"details": "You are not allowed to access this resource.", "name": "AccessDeniedError"}
    elif response.status_code == 404:
        assert response.json() == {"details": "The content badcontentId was not found.", "name": "ObjectNotFoundError"}
    else:
        response.raise_for_status()