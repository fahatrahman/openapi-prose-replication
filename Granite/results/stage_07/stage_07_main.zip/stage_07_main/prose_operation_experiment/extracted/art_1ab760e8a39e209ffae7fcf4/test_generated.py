import pytest
import requests
from datetime import datetime
from pydantic import BaseModel
BASE_URL = "http://openapi.test"

class RecoverIn(BaseModel):
    since: datetime
    until: datetime | None

def test_recover_failed_webhooks():
    url = f"{BASE_URL}/api/v1/app/app_id/endpoint/endpoint_id/recover/"
    headers = {"idempotency-key": "test_key"}
    data = RecoverIn(since=datetime(2019, 8, 24, 14, 15, 22, tzinfo=datetime.utcnow().tzinfo), until=None)

    response = requests.post(url, headers=headers, json=data)

    assert response.status_code == 202, f"Unexpected status code: {response.status_code}"
    # Add additional assertions based on the expected response structure if needed