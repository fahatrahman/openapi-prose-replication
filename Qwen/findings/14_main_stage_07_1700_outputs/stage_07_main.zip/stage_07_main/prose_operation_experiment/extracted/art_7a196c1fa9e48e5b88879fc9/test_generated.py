import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_templates():
    url = f"{BASE_URL}/templates"
    headers = {
        "Authorization": "Basic XyvylscjGNAYiusoLG:LCknolcjGNAYiusoKrxmdv"
    }
    params = {
        "query": "2",
        "parent_folder_id": "fld_000000000000000001",
        "page": 2,
        "per_page": 1
    }
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    for item in data:
        assert "allow_additional_properties" in item
        assert "description" in item
        assert "document_url" in item
        assert "editable_submissions" in item
        assert "expiration_interval" in item
        assert "expire_after" in item
        assert "expire_submissions" in item
        assert "id" in item
        assert "locked" in item
        assert "name" in item
        assert "page_dimensions" in item
        assert "parent_folder_id" in item
        assert "path" in item
        assert "permanent_document_url" in item
        assert "public_submissions" in item
        assert "public_web_form" in item
        assert "redirect_url" in item
        assert "slack_webhook_url" in item
        assert "template_type" in item
        assert "webhook_url" in item

def test_list_templates_unauthorized():
    url = f"{BASE_URL}/templates"
    headers = {}
    params = {
        "query": "2",
        "parent_folder_id": "fld_000000000000000001",
        "page": 2,
        "per_page": 1
    }
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 401
    data = response.json()
    assert "error" in data
    assert data["error"] == "Unauthorized"

def test_list_templates_not_found():
    url = f"{BASE_URL}/templates"
    headers = {
        "Authorization": "Basic XyvylscjGNAYiusoLG:LCknolcjGNAYiusoKrxmdv"
    }
    params = {
        "query": "nonexistent",
        "parent_folder_id": "nonexistent",
        "page": 2,
        "per_page": 1
    }
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 404
    data = response.json()
    assert "error" in data
    assert data["error"]