# -*- coding: utf-8 -*-

import pytest
import requests
from jsonschema import validate

BASE_URL = "http://openapi.test"

def test_get_live_plays():
    game_id = 12345  # replace with actual game ID
    url = f"{BASE_URL}/live/plays?id={game_id}"
    headers = {"Authorization": "ApiKeyAuth"}  # replace with actual API key
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    
    try:
        schema = {
            "$ref": "#/components/schemas/LivePlayByPlay"
        }
        validate(instance=response.json(), schema=schema)
    except Exception as e:
        pytest.fail(f"Failed to validate JSON response: {e}")