import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_images_from_files():
    url = f"{BASE_URL}/projects/{pytest.project_id}/images/files"
    headers = {
        "Training-Key": pytest.api_key,
        "Content-Type": "application/json"
    }
    payload = {
        "images": [
            {
                "contents": open("hemlock_10.jpg", "rb").read(),
                "name": "hemlock_10.jpg",
                "regions": [],
                "tagIds": []
            }
        ],
        "tagIds": []
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert response.json()["isBatchSuccessful"]