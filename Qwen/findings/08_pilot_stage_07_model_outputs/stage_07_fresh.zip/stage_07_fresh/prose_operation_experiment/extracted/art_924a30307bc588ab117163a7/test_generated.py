import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_payment_status():
    payment_id = "test_payment_id"
    headers = {
        "x-api-key": "{{your_api_key}}"
    }
    url = f"{BASE_URL}/v1/payment/{payment_id}"
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert response.headers["CF-Cache-Status"] == "DYNAMIC"
    assert response.headers["Connection"] == "keep-alive"
    assert response.headers["Content-Encoding"] == "br"
    assert response.headers["Date"].startswith("Wed, ")
    assert response.headers["Expect-CT"]
    assert response.headers["NEL"]
    assert response.headers["Report-To"]
    assert response.headers["Server"] == "cloudflare"
    assert response.headers["Strict-Transport-Security"] == "max-age=15768000"
    assert response.headers["Transfer-Encoding"] == "chunked"
    assert response.headers["Vary"] == "Origin"
    assert response.headers["X-Content-Type-Options"] == "nosniff"
    assert response.headers["X-DNS-Prefetch-Control"] == "false"
    assert response.headers["X-Download-Options"] == "noopen"
    assert response.headers["X-Frame-Options"] == "SAMEORIGIN"
    assert response.headers["X-XSS-Protection"] == "1; mode=block"
    assert response.headers["cf-request-id"]
    
    data = response.json()
    assert isinstance(data, dict)
    assert "actually_paid" in data
    assert "created_at" in data
    assert "order_description" in data
    assert "order_id" in data
    assert "outcome_amount" in data
    assert "outcome_currency" in data
    assert "pay_address" in data
    assert "pay_amount" in data
    assert "pay_currency" in data
    assert "payment_id" in data
    assert "payment_status" in data
    assert "price_amount" in data
    assert "price_currency" in data
    assert "purchase_id" in data
    assert "updated_at" in data

if __name__ == "__main__":
    pytest.main([__file__])