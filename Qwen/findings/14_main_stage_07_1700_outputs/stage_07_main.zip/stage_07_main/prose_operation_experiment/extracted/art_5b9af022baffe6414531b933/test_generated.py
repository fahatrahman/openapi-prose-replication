import pytest
import requests

BASE_URL = "http://openapi.test"

def test_put_rest_api():
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20130524/us-east-1/service/aws4_request",
        "X-Amz-Date": "20130524T000000Z",
        "X-Amz-Security-Token": "AQoEXAMPLEH4aoAHFODn8kFhcZB0jvosTcWp/Iq3GMDQVwnT1nfXmtdiaowgaAlCoXOWcyGi5QtQT5AvMZFiADUvJSUrXDyxS7CRivOsNt8Cwwo3AcDVTdzRRqydFeQBncL02QU+X26iDFv44pTZtG4DDuTi3ZNF0LXTz2WPZYrdY447G2p8nNLuYJzPLRHws0c19y0Bm3U3iQlW0s496hG5UJ4IYW8wCdGBXiTX72TS1y905bYw9IzOKa4XzHPwZJ8n64XzgW1YR1a7yDhU51G1YwFhI2p8Q8Bq770QdBQVYTFX2wbk0pKBF4u0XqK6XW4K8k1IyXw0L2k739kXN2Z3J18yGw==",
        "X-Amz-Signature": "d0f4a12d1abe55277fc4447928febad83f3ce08a4a4f8c5ac1a66e2e0c90258f",
        "X-Amz-SignedHeaders": "host;x-amz-algorithm;x-amz-content-sha256;x-amz-credential;x-amz-date;x-amz-security-token"
    }
    params = {
        "mode": "merge",
        "failonwarnings": False,
        "parameters": {
            "key1": "value1",
            "key2": "value2"
        }
    }
    json_data = {
        "body": "This is the request body"
    }
    response = requests.put(f"{BASE_URL}/restapis/restapi_id", headers=headers, params=params, json=json_data)
    
    assert response.status_code == 200
    assert "application/json" in response.headers["Content-Type"]
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()