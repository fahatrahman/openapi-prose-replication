import pytest
import requests

BASE_URL = "http://openapi.test"

def test_getStats():
    url = f"{BASE_URL}/getStats"
    headers = {
        "apikey": "your_api_key_here"
    }
    response = requests.post(url, headers=headers)
    
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert 'code' in data
    assert 'message' in data
    assert data['code'] == 0
    assert data['message'] == 'ok'

def test_getStats_400():
    url = f"{BASE_URL}/getStats"
    headers = {
        "apikey": "wrong_api_key"
    }
    response = requests.post(url, headers=headers)
    
    assert response.status_code == 400
    data = response.json()
    assert isinstance(data, dict)
    assert 'code' in data
    assert 'message' in data
    assert data['code'] == 1
    assert data['message'] == 'error message'

def test_getStats_401():
    url = f"{BASE_URL}/getStats"
    headers = {}
    response = requests.post(url, headers=headers)
    
    assert response.status_code == 401
    data = response.json()
    assert isinstance(data, dict)
    assert 'code' in data
    assert 'message' in data
    assert data['code'] == 4
    assert data['message'] == 'no or wrong API key'

def test_getStats_500():
    url = f"{BASE_URL}/getStats"
    headers = {
        "apikey": "your_api_key_here",
        "broken_header": "value"
    }
    response = requests.post(url, headers=headers)
    
    assert response.status_code == 500
    data = response.json()
    assert isinstance(data, dict)
    assert 'code' in data
    assert 'message' in data
    assert data['code'] == 2
    assert data['message'] == 'internal error'