import os
import pytest
import requests
from googleapiclient.discovery import build

BASE_URL = "http://openapi.test"
SCOPES = ["https://www.googleapis.com/auth/dfatrafficking"]

def test_create_subaccount():
    # Authenticate using Oauth2
    credentials = None  # Replace with actual credentials retrieval process
    service = build('dfareporting', 'v3.1', credentials=credentials)

    profile_id = "your_profile_id"  # Replace with actual profile ID
    subaccount = {
        "name": "New Subaccount",
        "accountId": "parent_account_id"  # Replace with actual parent account ID
    }

    try:
        response = service.subaccounts().insert(profileId=profile_id, body=subaccount).execute()
        assert response["kind"] == "dfareporting#subaccount"
        print(f"Successfully created subaccount with ID: {response['id']}")
    except Exception as e:
        print(f"Error creating subaccount: {str(e)}")