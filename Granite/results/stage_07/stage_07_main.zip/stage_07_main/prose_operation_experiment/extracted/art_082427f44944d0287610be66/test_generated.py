import os
import pytest
import requests
from google.rpc import Status
from google.type import Expr

BASE_URL = "http://openapi.test"

@pytest.fixture
def test_project_location_source_deletion():
    path_params = {"name": "your_resource_name"}
    headers = {
        "x-goog-request-params": f"name={path_params['name']}",
    }

    # Make the DELETE request
    response = requests.delete(
        url=f"{BASE_URL}/v1/{path_params['name']}",
        headers=headers,
    )

    # Check if the request was successful
    assert response.status_code == 200

    # Parse the Operation response
    operation = response.json()

    # Assert that the operation is done
    assert operation["done"] is True

    # Assert that there's no error
    assert operation["error"] is None

    # Assert that the response contains the expected data
    assert "response" in operation