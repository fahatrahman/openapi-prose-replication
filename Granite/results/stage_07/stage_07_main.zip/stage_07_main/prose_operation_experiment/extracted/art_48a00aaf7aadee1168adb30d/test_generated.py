import os
import pytest
import requests
from googleapiclient.discovery import build

BASE_URL = "http://openapi.test"

@pytest.fixture
def dataplex():
    service = build('dataplex', 'v1', developerToken='your_developer_token')
    return service

def test_list_actions(dataplex):
    parent = "zynntaco/your_autfnhu_lnoksl/yzvrewumc/your_vmdixebo_lg/wkxgf/your_orga_lg/gsprb/your_uzhf_lg/ktgwvm/your_gddfe_lg"
    page_size = 10
    page_token = ''

    response = dataplex.projects().locations().lakes().zones().assets().actions().list(
        parent=parent,
        pageSize=page_size,
        pageToken=page_token
    ).execute()

    assert response.get('actions') is not None
    assert isinstance(response['actions'], list)