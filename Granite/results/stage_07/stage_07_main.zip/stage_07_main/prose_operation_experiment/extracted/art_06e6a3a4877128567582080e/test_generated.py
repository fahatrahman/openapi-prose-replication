import os
import requests
import pytest
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# AWS SigV4 auth handler
class AwsAuth(requests.auth.AuthBase):
    def __init__(self, access_key, secret_key):
        self.access_key = access_key
        self.secret_key = secret_key

    def __call__(self, r):
        r.headers["Authorization"] = self._get_authorization_header(r)
        return r

    def _get_authorization_header(self, r):
        # Implement your AWS SigV4 signature generation here
        pass


# Create a session with retries
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def aws_access_key():
    return os.environ["AWS_ACCESS_KEY"]

@pytest.fixture
def aws_secret_key():
    return os.environ["AWS_SECRET_KEY"]

def test_deregister_wireless_device(aws_access_key, aws_secret_key):
    identifier = "example_identifier"
    wireless_device_type = "Sidewalk"

    url = f"{BASE_URL}/wireless-devices/{identifier}"

    response = session.patch(url, json={"Identifier": identifier, "WirelessDeviceType": wireless_device_type}, headers={}, auth=AwsAuth(aws_access_key, aws_secret_key))

    assert response.status_code == 200