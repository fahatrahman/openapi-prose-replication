import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_certificate_detail_by_cert_identifier():
    customer_id = "test_customer_id"
    certificate_id = "test_certificate_id"
    url = f"{BASE_URL}/v2/customers/{customer_id}/certificates/{certificate_id}"
    
    response = requests.get(url)
    
    assert response.status_code == 200
    assert 'application/json' in response.headers['Content-Type']
    assert 'certificateId' in response.json()
    assert 'commonName' in response.json()
    assert 'period' in response.json()
    assert 'type' in response.json()
    assert 'status' in response.json()
    assert 'createdAt' in response.json()
    assert 'contact' in response.json()
    assert 'certificateId' in response.json()['contact']
    assert 'nameFirst' in response.json()['contact']
    assert 'nameLast' in response.json()['contact']
    assert 'email' in response.json()['contact']
    assert 'phone' in response.json()['contact']

def test_get_certificate_detail_by_cert_identifier_not_found():
    customer_id = "non_existent_customer_id"
    certificate_id = "non_existent_certificate_id"
    url = f"{BASE_URL}/v2/customers/{customer_id}/certificates/{certificate_id}"
    
    response = requests.get(url)
    
    assert response.status_code == 404
    assert 'application/json' in response.headers['Content-Type']
    assert 'code' in response.json()
    assert response.json()['code'] == 'NOT_FOUND'
    assert 'message' in response.json()

def test_get_certificate_detail_by_cert_identifier_unauthorized():
    customer_id = "test_customer_id"
    certificate_id = "test_certificate_id"
    url = f"{BASE_URL}/v2/customers/{customer_id}/certificates/{certificate_id}"
    
    response = requests.get(url, headers={"Authorization": "Bearer invalid_token"})
    
    assert response.status_code == 401
    assert 'application/json' in response.headers['Content-Type']
    assert 'code' in response.json()
    assert response.json()['code'] == 'UNAUTHORIZED'
    assert 'message' in response.json()