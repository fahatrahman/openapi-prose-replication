import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)


def test_application_request_export():
    application_id = "example_application_id"
    format_option = "csv"

    url = f"{BASE_URL}/api/v2/application/{application_id}/request-export"

    query_params = {
        "format": format_option,
    }

    response = SESSION.post(url, json={}, params=query_params)
    response.raise_for_status()

    result = response.json()

    assert "message" in result
    assert "submissions" in result
    assert "token" in result