import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_issue_check_subscription():
    owner = "test_owner"
    repo = "test_repo"
    index = 123

    url = f"{BASE_URL}/repos/{owner}/{repo}/issues/{index}/subscriptions/check"
    headers = {
        "Authorization": "Bearer your_access_token",
        "Content-Type": "application/json"
    }

    response = requests.get(url, headers=headers)

    assert response.status_code == 200
    assert "created_at" in response.json()
    assert "ignored" in response.json()
    assert "reason" in response.json()
    assert "repository_url" in response.json()
    assert "subscribed" in response.json()
    assert "url" in response.json()

    created_at = response.json()["created_at"]
    assert isinstance(created_at, str)
    try:
        datetime.strptime(created_at, "%Y-%m-%dT%H:%M:%SZ")
    except ValueError:
        pytest.fail("created_at is not a valid ISO 8601 date-time string")

    ignored = response.json()["ignored"]
    assert isinstance(ignored, bool)

    reason = response.json()["reason"]
    assert isinstance(reason, str)

    repository_url = response.json()["repository_url"]
    assert isinstance(repository_url, str)

    subscribed = response.json()["subscribed"]
    assert isinstance(subscribed, bool)

    url = response.json()["url"]
    assert isinstance(url, str)