import os
import pytest
import requests
BASE_URL = "http://openapi.test"

@pytest.fixture
def begin_transaction_request():
    return {
        "options": {
            "readWrite": {}
        }
    }

def test_begin_transaction(begin_transaction_request):
    url = f"{BASE_URL}/v1/your_database/documents/beginTransaction"
    headers = {
        "Content-Type": "application/json",
    }
    response = requests.post(url, json=begin_transaction_request, headers=headers)
    
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "transaction" in response.json()