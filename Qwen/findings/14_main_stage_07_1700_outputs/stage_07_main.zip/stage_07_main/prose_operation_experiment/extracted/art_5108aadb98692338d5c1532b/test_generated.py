import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_vod_genres():
    url = f"{BASE_URL}/ondemand/genres"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    genres = response.json()
    assert isinstance(genres, list)
    for genre in genres:
        assert "canonical" in genre
        assert "interactions" in genre
        assert "link" in genre
        assert "metadata" in genre
        assert "name" in genre
        assert "uri" in genre