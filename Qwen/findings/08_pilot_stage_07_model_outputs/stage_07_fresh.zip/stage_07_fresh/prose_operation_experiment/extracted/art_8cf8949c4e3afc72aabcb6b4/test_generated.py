import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_region_opt_status():
    url = f"{BASE_URL}/getRegionOptStatus"
    headers = {
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Date": "20230401T000000Z",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20230401/us-east-1/sts/aws4_request",
        "X-Amz-Security-Token": "AQoEXAMPLEHIGlhGgdi7YPiUGRbVgWmTDyXTJe3YpiEfBAzqu5RM5JUm9p7/nFXYfKXZfqxqeNtcQZSWtyWCaKnBVcNRUZ0wqFlK4XmxkXa6FxWz8/z54AikipX3Z4y3v0wX+Xq3P3B7m57KJ3zXJp46iuYRYhpwzlFVsEJ6Iqz0Jv/1XjF2XzCv0Q==",
        "X-Amz-Signature": "EXAMPLEHASH",
        "X-Amz-SignedHeaders": "host;x-amz-algorithm;x-amz-content-sha256;x-amz-credential;x-amz-date;x-amz-security-token;x-amz-signedheaders"
    }
    payload = {
        "AccountId": "123456789012",
        "RegionName": "us-east-1"
    }

    response = requests.post(url, json=payload, headers=headers)

    assert response.status_code == 200
    assert "RegionName" in response.json()
    assert "RegionOptStatus" in response.json()

if __name__ == "__main__":
    pytest.main()