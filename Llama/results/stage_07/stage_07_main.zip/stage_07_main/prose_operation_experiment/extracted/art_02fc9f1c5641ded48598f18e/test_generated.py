import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_call_broadcast_batches():
    url = f"{BASE_URL}/calls/broadcasts/{123}/batches"
    params = {
        'fields': 'lg,qfyo',
        'limit': 50,
        'offset': 25
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    assert response.json()['totalCount'] >= 75
    for batch in response.json()['items']:
        assert isinstance(batch['id'], int)
        assert isinstance(batch['created'], int)
        assert isinstance(batch['remaining'], int)
        assert isinstance(batch['size'], int)
        assert batch['status'] in ['NEW', 'VALIDATING', 'ERRORS', 'SOURCE_ERROR', 'ACTIVE']

def test_get_call_broadcast_batches_invalid_id():
    url = f"{BASE_URL}/calls/broadcasts/-1/batches"
    response = requests.get(url)
    assert response.status_code == 404

def test_get_call_broadcast_batches_missing_fields():
    url = f"{BASE_URL}/calls/broadcasts/123/batches"
    response = requests.get(url)
    assert response.status_code == 200

def test_get_call_broadcast_batches_large_limit():
    url = f"{BASE_URL}/calls/broadcasts/123/batches"
    params = {'limit': 100000}
    response = requests.get(url, params=params)
    assert response.status_code == 400

def test_get_call_broadcast_batches_negative_offset():
    url = f"{BASE_URL}/calls/broadcasts/123/batches"
    params = {'offset': -1}
    response = requests.get(url, params=params)
    assert response.status_code == 400