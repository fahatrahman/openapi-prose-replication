import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def employer_id():
    return "ER001"

@pytest.fixture
def authorization_header():
    return 'Auto'

@pytest.fixture
def api_version():
    return "default"

def test_get_employer_revisions(employer_id, authorization_header, api_version):
    url = f"{BASE_URL}/Employer/{employer_id}/Revisions"

    headers = {
        "Authorization": authorization_header,
        "Api-Version": api_version,
    }

    response = session.get(url, headers=headers)

    if response.status_code == 200:
        assert response.json()["Title"] == "LinkCollection"
    elif response.status_code in [400, 401, 404, 500]:
        error_model = response.json()
        assert isinstance(error_model, dict)
        assert "Description" in error_model
        assert "ErrorCategory" in error_model["Errors"][0]
        assert "@href" in error_model["Errors"][0]["Link"][0]
    else:
        pytest.fail(f"Unexpected status code: {response.status_code}")