import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def get_sip_media_application_logging_configuration(sip_media_application_id):
    headers = {
        'X-Amz-Algorithm': '',
        'X-Amz-Content-Sha256': '',
        'X-Amz-Credential': '',
        'X-Amz-Date': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': '',
        'X-Amz-SignedHeaders': '',
        'Authorization': ''
    }
    params = {'sipMediaApplicationId': sip_media_application_id}
    response = requests.get(f'{BASE_URL}/sip-media-applications/{sip_media_application_id}/logging-configuration', 
                            headers=headers)
    assert response.status_code == 200
    return response.json()

def test_get_sip_media_application_logging_configuration():
    try:
        get_sip_media_application_logging_configuration('test-id')
    except Exception as e:
        print(e)

def test_get_sip_media_application_logging_configuration_unauthorized_client_exception():
    headers = {
        'X-Amz-Algorithm': '',
        'X-Amz-Content-Sha256': '',
        'X-Amz-Credential': '',
        'X-Amz-Date': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': '',
        'X-Amz-SignedHeaders': '',
        'Authorization': ''
    }
    response = requests.get(f'{BASE_URL}/sip-media-applications/test-id/logging-configuration', 
                            headers=headers)
    assert response.status_code == 480

def test_get_sip_media_application_logging_configuration_not_found_exception():
    headers = {
        'X-Amz-Algorithm': '',
        'X-Amz-Content-Sha256': '',
        'X-Amz-Credential': '',
        'X-Amz-Date': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': '',
        'X-Amz-SignedHeaders': '',
        'Authorization': ''
    }
    response = requests.get(f'{BASE_URL}/sip-media-applications/not-found-id/logging-configuration', 
                            headers=headers)
    assert response.status_code == 481

def test_get_sip_media_application_logging_configuration_forbidden_exception():
    headers = {
        'X-Amz-Algorithm': '',
        'X-Amz-Content-Sha256': '',
        'X-Amz-Credential': '',
        'X-Amz-Date': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': '',
        'X-Amz-SignedHeaders': '',
        'Authorization': ''
    }
    response = requests.get(f'{BASE_URL}/sip-media-applications/test-id/logging-configuration', 
                            headers=headers)
    assert response.status_code != 482

def test_get_sip_media_application_logging_configuration_bad_request_exception():
    headers = {
        'X-Amz-Algorithm': '',
        'X-Amz-Content-Sha256': '',
        'X-Amz-Credential': '',
        'X-Amz-Date': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': '',
        'X-Amz-SignedHeaders': '',
        'Authorization': ''
    }
    response = requests.get(f'{BASE_URL}/sip-media-applications/test-id/logging-configuration', 
                            headers=headers)
    assert response.status_code != 483

def test_get_sip_media_application_logging_configuration_throttled_client_exception():
    headers = {
        'X-Amz-Algorithm': '',
        'X-Amz-Content-Sha256': '',
        'X-Amz-Credential': '',
        'X-Amz-Date': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': '',
        'X-Amz-SignedHeaders': '',
        'Authorization': ''
    }
    response = requests.get(f'{BASE_URL}/sip-media-applications/test-id/logging-configuration', 
                            headers=headers)
    assert response.status_code != 484

def test_get_sip_media_application_logging_configuration_service_unavailable_exception():
    headers = {
        'X-Amz-Algorithm': '',
        'X-Amz-Content-Sha256': '',
        'X-Amz-Credential': '',
        'X-Amz-Date': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': '',
        'X-Amz-SignedHeaders': '',
        'Authorization': ''
    }
    response = requests.get(f'{BASE_URL}/sip-media-applications/test-id/logging-configuration', 
                            headers=headers)
    assert response.status_code != 485

def test_get_sip_media_application_logging_configuration_service_failure_exception():
    headers = {
        'X-Amz-Algorithm': '',
        'X-Amz-Content-Sha256': '',
        'X-Amz-Credential': '',
        'X-Amz-Date': datetime.now().strftime('%Y%m%dT%H%M%SZ'),
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': '',
        'X-Amz-SignedHeaders': '',
        'Authorization': ''
    }
    response = requests.get(f'{BASE_URL}/sip-media-applications/test-id/logging-configuration', 
                            headers=headers)
    assert response.status_code != 486

# Run all tests
pytest.main([__file__, '-v'])