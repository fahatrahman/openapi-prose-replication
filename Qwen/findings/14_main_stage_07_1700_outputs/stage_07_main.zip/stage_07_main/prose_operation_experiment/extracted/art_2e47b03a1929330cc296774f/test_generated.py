import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_queues():
    url = f"{BASE_URL}/apps/test_app/queues"
    headers = {
        "Authorization": "Bearer your_access_token_here"
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert isinstance(response.json(), list)

if __name__ == "__main__":
    pytest.main()