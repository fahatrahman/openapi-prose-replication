import pytest
import requests
from uuid import UUID

BASE_URL = "http://openapi.test"

def test_create_account_organization():
    url = f"{BASE_URL}/account/orgs"
    headers = {"Authorization": f"Bearer {generate_bearer_token()}"}
    data = {
        "description": "Wobbly Widgets, Inc.",
        "expiration_assets_offline": "365",
        "expiration_assets_stale": "365",
        "expiration_scans": "365",
        "export_token": "ETXXXXXXXXXXXXXXXX",
        "name": "My Organization",
        "parent_id": str(UUID("e77602e0-3fb8-4734-aef9-fbc6fdcb0fa8")),
        "project": False,
    }
    response = requests.put(url, json=data, headers=headers)
    assert response.status_code == 200
    organization = response.json()
    assert isinstance(organization["asset_count"], int)
    assert isinstance(organization["client_id"], UUID)
    assert isinstance(organization["created_at"], int)
    assert isinstance(organization["deactivated_at"], int)
    assert isinstance(organization["description"], str)
    assert isinstance(organization["download_token"], str)
    assert isinstance(organization["download_token_created_at"], int)
    assert isinstance(organization["expiration_assets_offline"], int)
    assert isinstance(organization["expiration_assets_stale"], int)
    assert isinstance(organization["expiration_scans"], int)
    assert isinstance(organization["export_token"], str)
    assert isinstance(organization["export_token_counter"], int)
    assert isinstance(organization["export_token_created_at"], int)
    assert isinstance(organization["export_token_last_used_at"], int)
    assert isinstance(organization["export_token_last_used_by"], str)
    assert isinstance(organization["id"], UUID)
    assert isinstance(organization["inactive"], bool)
    assert isinstance(organization["name"], str)
    assert isinstance(organization["parent_id"], UUID)
    assert isinstance(organization["permanent"], bool)
    assert isinstance(organization["project"], bool)
    assert isinstance(organization["service_count"], int)
    assert isinstance(organization["service_count_arp"], int)
    assert isinstance(organization["service_count_icmp"], int)
    assert isinstance(organization["service_count_tcp"], int)
    assert isinstance(organization["service_count_udp"], int)
    assert isinstance(organization["updated_at"], int)

def generate_bearer_token():
    # This is a very basic implementation of generating a bearer token
    # You should replace this with your actual authentication logic
    return "your_bearer_token_here"