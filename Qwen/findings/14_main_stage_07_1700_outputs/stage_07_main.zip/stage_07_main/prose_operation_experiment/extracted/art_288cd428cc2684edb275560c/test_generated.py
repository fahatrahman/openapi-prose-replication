import pytest
import requests

BASE_URL = "http://openapi.test"

def test_analytics_data_ga_get():
    params = {
        "ids": "ga:XXXX",
        "start-date": "today",
        "end-date": "today",
        "metrics": "ga:sessions,ga:pageviews",
        "dimensions": "ga:browser,ga:city"
    }
    response = requests.get(f"{BASE_URL}/data/ga", params=params)
    assert response.status_code == 200
    assert "application/json" in response.headers["Content-Type"]
    data = response.json()
    assert isinstance(data, dict)
    assert "columnHeaders" in data
    assert "rows" in data
    assert "totalsForAllResults" in data