import os
import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

@pytest.fixture
def http_server():
    # Assuming a mock server setup for testing purposes
    pass

def test_analytics_generic_log_flow(http_server):
    headers = {"X-API-Token": os.environ["API_TOKEN"]}

    params = {
        "start": None,  # Use current time by default
    }

    response = requests.get(
        f"{BASE_URL}/v0.1/apps/owner_name/app_name/analytics/generic_log_flow",
        headers=headers,
        params=params,
    )

    assert response.status_code == 200

    data = response.json()
    assert "logs" in data
    assert isinstance(data["logs"], list)
    assert len(data["logs"]) <= 100

    last_log_timestamp = data["last_received_log_timestamp"]
    assert isinstance(last_log_timestamp, str)
    assert datetime.strptime(last_log_timestamp, "%Y-%m-%dT%H:%M:%S.%fZ") > datetime.utcnow() - datetime.resolution

    exceeded_max_limit = data.get("exceeded_max_limit", False)
    assert isinstance(exceeded_max_limit, bool)