import os
import pytest
import requests
from googleapiclient.discovery import build

BASE_URL = "http://openapi.test"

@pytest.fixture
def dfa_service():
    """Build DFA service."""
    api_service_name = "dfareporting"
    api_version = "v3"
    credentials = None

    if credentials is None:
        assert os.environ["GOOGLE_APPLICATION_CREDENTIALS"], (
            "Google Application Credentials not found in environment variable"
            "GOOGLE_APPLICATION_CREDENTIALS"
        )
        credentials = os.environ["GOOGLE_APPLICATION_CREDENTIALS"]

    service = build(api_service_name, api_version, credentials=credentials)
    return service

def test_update_account_user_profile(dfa_service):
    """Test updating account user profile."""
    profile_id = "YOUR_PROFILE_ID"
    account_user_profile = {
        "accountId": "ACCOUNT_ID",
        "active": True,
        "campaignFilter": {"status": "ACTIVE"},
        "email": "TEST_EMAIL@example.com",
        "locale": "en",
        "name": "TEST_NAME",
        "userRoleId": 123456
    }

    request_body = account_user_profile
    path = f"/userprofiles/{profile_id}/accountUserProfiles"

    response = dfa_service.accountUserProfiles().update(profileId=profile_id, body=request_body).execute()

    assert response["kind"] == "dfareporting#accountUserProfile"
    print("Updated account user profile successfully.")