# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_domain():
    url = f"{BASE_URL}/domain/{'48cf1c9b-f027-4223-b405-d48018ffb900'}"
    response = requests.get(url)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data['result'], dict)
    assert 'domain_key' in data['result']
    assert 'checksum' in data['result']

def test_get_domain_invalid_key():
    url = f"{BASE_URL}/domain/{'invalid-key'}"
    response = requests.get(url)
    assert response.status_code != 200
    data = response.json()
    assert isinstance(data, dict)
    assert 'code' in data
    assert 'message' in data

if __name__ == "__main__":
    pytest.main([__file__])