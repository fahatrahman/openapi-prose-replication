import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_track_collection_list():
    params = {
        "page": 1,
        "per_page": 100,
        "embed": ["share_code"]
    }
    response = requests.get(f"{BASE_URL}/v2/audio/collections", params=params)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "data" in data
    assert isinstance(data["data"], list)
    for item in data["data"]:
        assert isinstance(item, dict)
        assert "id" in item
        assert "name" in item
        assert "total_item_count" in item

if __name__ == "__main__":
    pytest.main([__file__])