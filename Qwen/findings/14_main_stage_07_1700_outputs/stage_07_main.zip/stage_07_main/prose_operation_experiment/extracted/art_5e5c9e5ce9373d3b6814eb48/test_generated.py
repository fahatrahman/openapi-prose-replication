import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_content():
    params = {
        "limit": 20,
        "offset": 0
    }
    response = requests.get(f"{BASE_URL}/content/all/all.json", params=params)
    assert response.status_code == 200
    data = response.json()
    assert "copyright" in data
    assert "num_results" in data
    assert "results" in data
    assert "status" in data
    for article in data["results"]:
        assert "abstract" in article
        assert "blog_name" in article
        assert "byline" in article
        assert "created_date" in article
        assert "des_facet" in article
        assert "geo_facet" in article
        assert "headline" in article
        assert "item_type" in article
        assert "kicker" in article
        assert "material_type_facet" in article
        assert "multimedia" in article
        assert "org_facet" in article
        assert "per_facet" in article
        assert "published_date" in article
        assert "related_urls" in article
        assert "section" in article
        assert "short_url" in article
        assert "source" in article
        assert "subsection" in article
        assert "thumbnail_standard" in article
        assert "title" in article
        assert "updated_date" in article
        assert "url" in article