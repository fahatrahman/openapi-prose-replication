import pytest
import json
import requests

BASE_URL = "http://openapi.test"

def test_get_wifi_config():
    url = f"{BASE_URL}/api/v1/config/wifi"
    response = requests.get(url)
    assert response.status_code == 200
    data = response.json()
    required_keys = ["ssid", "password", "mode"]
    assert all(key in data for key in required_keys)

def test_get_wifi_config_schema():
    url = f"{BASE_URL}/api/v1/config/wifi"
    response = requests.get(url)
    assert response.status_code == 200
    schema = {
        "type": "object",
        "required": ["ssid", "password", "mode"],
        "properties": {
            "mode": {"type": "string", "enum": ["ap", "client"]},
            "password": {"type": "string"},
            "ssid": {"type": "string"}
        }
    }
    try:
        json.dumps(response.json(), indent=4)
        json.loads(json.dumps(response.json()).replace('"mode": "', ''))
        actual_data = json.loads(json.dumps(response.json()).replace('"mode": "', ''))
        assert actual_data == schema['properties']['mode']
        assert isinstance(actual_data, dict)
    except ValueError as e:
        print(e)
        assert False

if __name__ == "__main__":
    pytest.main([__file__])