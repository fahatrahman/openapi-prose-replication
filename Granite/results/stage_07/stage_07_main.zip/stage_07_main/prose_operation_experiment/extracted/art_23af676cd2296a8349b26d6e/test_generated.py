import os
import requests
import pytest
BASE_URL = "http://openapi.test"

@pytest.fixture
def client():
    session = requests.Session()
    session.headers.update({"Authorization": f"Bearer {os.environ['ACCESS_TOKEN']}"})
    return session

def test_list_answers(client):
    response = client.get(
        f"{BASE_URL}/workloads/workload_id/lensReviews/lens_alias",
        params={
            "PillarId": "pillar_id",
            "MilestoneNumber": 1,
            "NextToken": "next_token",
            "MaxResults": 10,
            "QuestionPriority": "PRIORITIZED"
        }
    )

    assert response.status_code == 200, f"Received status code {response.status_code}"

    data = response.json()
    # Add more assertions based on expected response structure