import os
import pytest
import requests
from requests_aws_sigv4 import AWSRequestsAuth

BASE_URL = "http://openapi.test"

@pytest.mark.parametrize("discoverer_id", ["some_discoverer_id"])
def test_stop_discoverer(discoverer_id):
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "aki.us-east-1.eksctr.amazonaws.com/20150101/region/eks/ec2/aws4_request",
        "X-Amz-Date": "20150401T000000Z",
        "X-Amz-Security-Token": "",
        "X-Amz-SignedHeaders": "host;x-amz-algorithm;x-amz-credential;x-amz-date;x-amz-security-token",
    }

    response = requests.post(
        f"{BASE_URL}/v1/discoverers/{discoverer_id}/stop",
        headers=headers,
        auth=AWSRequestsAuth(
            access_key="aki.us-east-1.eksctr.amazonaws.com",
            secret_key="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
        ),
    )

    assert response.status_code == 200
    # Add more assertions based on the expected response schema
    # For now, we'll just check for a successful status code