import pytest
import requests

BASE_URL = "http://openapi.test"

def test_test_iam_permissions():
    url = f"{BASE_URL}/v1/projects/my-project:testIamPermissions"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "permissions": ["roles/storage.objectViewer"]
    }
    params = {
        "key": "YOUR_API_KEY"
    }

    response = requests.post(url, headers=headers, json=payload, params=params)

    assert response.status_code == 200
    assert "permissions" in response.json()

if __name__ == "__main__":
    pytest.main()