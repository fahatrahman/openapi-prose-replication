# -*- coding: utf-8 -*-
import pytest
import requests
from typing import Dict

BASE_URL = "http://openapi.test"

def test_apigateway_projects_locations_list():
    url = f"{BASE_URL}/v1/{'projects'} /locations"
    headers = {
        'Content-Type': 'application/json',
    }
    params = {
        '$.xgafv': '1',
        'access_token': '',
        'alt': 'json',
        'callback': '',
        'fields': '',
        'key': '',
        'oauth_token': '',
        'prettyPrint': 'false',
        'quotaUser': '',
        'upload_protocol': '',
        'uploadType': ''
    }
    data = {
        'name': 'projects'
    }

    # Remove empty parameters
    params = {k: v for k, v in params.items() if v}

    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 200