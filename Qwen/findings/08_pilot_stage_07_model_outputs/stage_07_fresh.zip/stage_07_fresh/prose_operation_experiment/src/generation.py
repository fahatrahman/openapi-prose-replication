from __future__ import annotations

import hashlib
import json
import os
import random
import re
import time
from pathlib import Path


GENERATION_MODULE_VERSION = "stage07-generation-v1-frozen-paired"
OUTER_PYTHON_FENCE = re.compile(
    r"\A\s*```python[ \t]*\r?\n(?P<code>[\s\S]*?)\r?\n```\s*\Z",
    flags=re.IGNORECASE,
)


def module_hash(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def module_json_bytes(value) -> bytes:
    return (json.dumps(value, sort_keys=True, ensure_ascii=False,
                       separators=(",", ":")) + "\n").encode("utf-8")


def atomic_replace_bytes(path, data: bytes):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp-" + str(os.getpid()))
    try:
        with temporary.open("wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def immutable_bytes(path, data: bytes):
    path = Path(path)
    if path.exists():
        if path.read_bytes() != data:
            raise RuntimeError("Immutable raw artifact differs: " + str(path))
        return "REUSED_IDENTICAL"
    atomic_replace_bytes(path, data)
    return "WRITTEN"


def write_task_checkpoint(path, record):
    atomic_replace_bytes(path, module_json_bytes(record))


def validate_task_checkpoint(record, task, fingerprint):
    if record["task_id"] != task["task_id"]:
        raise RuntimeError("Checkpoint task identity mismatch")
    if record["fingerprint"] != fingerprint:
        raise RuntimeError("STALE_CHECKPOINT_BLOCK: generation runtime/config changed")
    if record["prompt_sha256"] != task["prompt_sha256"]:
        raise RuntimeError("STALE_CHECKPOINT_BLOCK: prompt hash changed")
    if record["expected_output_path"] != task["expected_output_path"]:
        raise RuntimeError("STALE_CHECKPOINT_BLOCK: output location changed")
    if record["task_sha256"] != module_hash(module_json_bytes(task)):
        raise RuntimeError("STALE_CHECKPOINT_BLOCK: task row changed")
    if record["state"] not in ("STARTED", "GENERATED", "RAW_RECOVERED",
                               "NO_OUTPUT_RUNTIME_FAILURE"):
        raise RuntimeError("Unknown checkpoint state")
    if not isinstance(record["attempts"], list) or len(record["attempts"]) > 2:
        raise RuntimeError("Invalid checkpoint attempt history")


def extract_python_module(raw_text: str):
    """The exact Stage 00 extraction policy, with no repairs or compilation."""
    match = OUTER_PYTHON_FENCE.fullmatch(raw_text)
    if match:
        code = match.group("code")
        if "```" in code:
            return None, "rejected", "nested_or_multiple_fences"
        return code, "accepted_outer_python_fence", None
    if "```" in raw_text:
        return None, "rejected", "mixed_or_multiple_fences"
    if not raw_text.strip():
        return None, "rejected", "empty_output"
    return raw_text, "accepted_raw_python", None


def generated_continuation(model, tokenizer, prompt_bytes: bytes,
                           seed: int, generation_settings: dict, input_device):
    """One independent seeded inference; no prompt alteration or text repair."""
    import torch

    prompt_text = prompt_bytes.decode("utf-8")
    token_ids = tokenizer.encode(prompt_text, add_special_tokens=False)
    max_new_tokens = int(generation_settings["max_new_tokens"])
    if not token_ids or len(token_ids) > int(generation_settings["max_input_tokens"]):
        raise ValueError("Unexpected frozen input-token count")
    if len(token_ids) + max_new_tokens > int(generation_settings["max_total_tokens"]):
        raise ValueError("Frozen total-token limit exceeded")

    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    input_ids = torch.tensor([token_ids], dtype=torch.long, device=input_device)
    attention_mask = torch.ones_like(input_ids)
    torch.cuda.synchronize()
    started = time.perf_counter()
    with torch.inference_mode():
        sequences = model.generate(
            input_ids=input_ids, attention_mask=attention_mask,
            max_new_tokens=max_new_tokens,
            do_sample=generation_settings["do_sample"],
            temperature=generation_settings["temperature"],
            top_p=generation_settings["top_p"],
            top_k=generation_settings["top_k"],
            repetition_penalty=generation_settings["repetition_penalty"],
            num_beams=generation_settings["num_beams"],
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id,
            use_cache=True, prefill_chunk_size=512, cache_implementation="dynamic",
            return_dict_in_generate=False, output_scores=False,
        )
    torch.cuda.synchronize()
    elapsed = time.perf_counter() - started
    generated_ids = sequences[0, len(token_ids):].detach().cpu().tolist()
    output_text = tokenizer.decode(
        generated_ids, skip_special_tokens=True,
        clean_up_tokenization_spaces=False,
    )
    eos_ids = tokenizer.eos_token_id
    if not isinstance(eos_ids, (tuple, list, set)):
        eos_ids = [eos_ids]
    finish_reason = (
        "eos" if generated_ids and generated_ids[-1] in eos_ids
        else "max_new_tokens" if len(generated_ids) >= max_new_tokens
        else "stopped_other"
    )
    return output_text.encode("utf-8"), {
        "input_tokens": len(token_ids), "generated_tokens": len(generated_ids),
        "finish_reason": finish_reason, "duration_seconds": round(elapsed, 4),
        "generated_token_ids_sha256": module_hash(json.dumps(
            generated_ids, separators=(",", ":")
        ).encode("utf-8")),
    }


def refresh_attempt_log(task_list, checkpoint_directory, destination):
    """Atomic complete ledger built only from durable per-task journals."""
    records = []
    for task in task_list:
        path = checkpoint_directory / (task["task_id"] + ".json")
        if path.is_file():
            record = json.loads(path.read_text(encoding="utf-8"))
            records.append({
                "task_id": task["task_id"], "state": record["state"],
                "attempts": record["attempts"],
                "raw_sha256": record.get("raw_sha256"),
                "generated_tokens": record.get("generated_tokens"),
                "finish_reason": record.get("finish_reason"),
                "diagnostic": record.get("diagnostic"),
            })
    atomic_replace_bytes(destination, b"".join(module_json_bytes(x) for x in records))
