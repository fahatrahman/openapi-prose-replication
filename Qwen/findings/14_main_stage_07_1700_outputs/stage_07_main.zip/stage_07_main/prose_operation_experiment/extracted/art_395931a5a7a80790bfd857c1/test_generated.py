import pytest
import requests

BASE_URL = "http://openapi.test"

def test_convert():
    url = f"{BASE_URL}/convert"
    params = {
        "from-value": "10.95",
        "from-type": "DMQ",
        "to-type": "KVH"
    }
    headers = {
        "api-key": "your_api_key_here",
        "user-id": "your_user_id_here"
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 200
    assert "ConvertResponse" in response.json()

def test_convert_invalid_params():
    url = f"{BASE_URL}/convert"
    params = {
        "from-value": "invalid_value",
        "from-type": "DMQ",
        "to-type": "KVH"
    }
    headers = {
        "api-key": "your_api_key_here",
        "user-id": "your_user_id_here"
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 400
    assert "APIError" in response.json()
    assert "api-error" in response.json()["APIError"]
    assert "api-error-msg" in response.json()["APIError"]

def test_convert_forbidden():
    url = f"{BASE_URL}/convert"
    params = {
        "from-value": "10.95",
        "from-type": "DMQ",
        "to-type": "KVH"
    }
    headers = {
        "api-key": "your_api_key_here",
        "user-id": "invalid_user_id"
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 403
    assert "APIError" in response.json()
    assert "api-error" in response.json()["APIError"]
    assert "api-error-msg" in response.json()["APIError"]

def test_convert_internal_error():
    url = f"{BASE_URL}/convert"
    params = {
        "from-value": "10.95",
        "from-type": "DMQ",
        "to-type": "KVH"
    }
    headers = {
        "api-key": "your_api_key_here",
        "user-id": "your_user_id_here"
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 500
    assert "APIError" in response.json()
    assert "api-error" in response.json()["APIError"]
    assert "api-error-msg" in response.json()["APIError"]

if __name__ == "__main__":
    pytest.main()