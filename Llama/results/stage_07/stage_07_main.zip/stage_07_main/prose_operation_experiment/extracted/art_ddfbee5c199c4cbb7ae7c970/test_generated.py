# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_get_user():
    id = 12345
    url = urljoin(BASE_URL, f"/api/v2/Users/{id}")
    response = requests.get(url)
    assert response.status_code == 200
    user_data = response.json()
    assert isinstance(user_data['UserID'], int)
    assert 'ChangePassword' in user_data
    assert 'Email' in user_data
    assert 'Name' in user_data
    assert 'Password' in user_data
    assert 'Username' in user_data