import os
import pytest
import requests
from googleapiclient.discovery import build

BASE_URL = "http://openapi.test"
SCOPES = ["https://www.googleapis.com/auth/admin.directory.resource.calendar"]

def test_patch_feature():
    """Test patching a feature."""
    customer = "your_customer_id"
    feature_key = "your_feature_key"

    # Prepare request body
    feature = {
        "name": "updated_feature_name",
        "etags": "updated_etag"
    }

    # Make patched request
    service = build("admin", "directory_v1", credentials=None)
    try:
        response = service.resources().features().patch(
            customer=customer, featureKey=feature_key, body=feature).execute()

        # Assert successful response
        assert response["kind"] == "admin#directory#resources#features#Feature"
        assert response["name"] == "updated_feature_name"
        assert response["etags"] == "updated_etag"

        print("Patch feature test passed.")
    except Exception as e:
        print(f"Patch feature test failed: {str(e)}")

if __name__ == "__main__":
    pytest.main([__file__, "-v"])