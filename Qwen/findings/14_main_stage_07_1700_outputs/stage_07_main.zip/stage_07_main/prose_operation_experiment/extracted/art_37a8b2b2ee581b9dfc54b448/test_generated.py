import pytest
import requests

BASE_URL = "http://openapi.test"

def test_describe_folder_contents():
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "access_key_id/region/service/aws4_request",
        "X-Amz-Date": "20230401T000000Z",
        "X-Amz-Security-Token": "session_token",
        "X-Amz-Signature": "signature",
        "X-Amz-SignedHeaders": "host"
    }
    params = {
        "FolderId": "folder_id",
        "sort": "DATE",
        "order": "ASCENDING",
        "limit": 100,
        "marker": "",
        "type": "ALL",
        "include": "INITIALIZED",
        "Limit": "100",
        "Marker": ""
    }
    response = requests.get(f"{BASE_URL}/api/v1/folders/{params['FolderId']}/contents", headers=headers, params=params)
    assert response.status_code == 200
    assert "Documents" in response.json()
    assert "Folders" in response.json()
    assert "Marker" in response.json()

if __name__ == "__main__":
    pytest.main([__file__])