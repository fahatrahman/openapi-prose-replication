import pytest
import requests
from xml.etree.ElementTree import fromstring

BASE_URL = "http://openapi.test"

@pytest.fixture
def heartbeat_response():
    url = f"{BASE_URL}/v0.5/heartbeat"
    response = requests.get(url)

    assert response.status_code == 200

    return response

def test_heartbeat_response(heartbeat_response):
    data = heartbeat_response.json()

    assert isinstance(data, dict)
    assert "error" not in data or (
        isinstance(data["error"], dict)
        and set(["code", "message"]).issubset(data["error"].keys())
    )
    assert "status" in data and data["status"] in ["UP", "DOWN"]
    assert "timestamp" in data and isinstance(data["timestamp"], str)

def test_heartbeat_response_xml(heartbeat_response):
    data = fromstring(heartbeat_response.content)

    assert isinstance(data, str)
    assert data.tag == "HeartbeatResponse"

    error_node = data.find("error")
    if error_node is not None:
        assert set(["code", "message"]).issubset({child.tag for child in error_node})

    status_node = data.find("status")
    assert status_node is not None and status_node.text in ["UP", "DOWN"]

    timestamp_node = data.find("timestamp")
    assert timestamp_node is not None and isinstance(timestamp_node.text, str)