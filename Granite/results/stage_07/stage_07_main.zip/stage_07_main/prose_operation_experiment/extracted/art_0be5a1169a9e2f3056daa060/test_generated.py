import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def symptom_details():
    url = f"{BASE_URL}/symptoms/sample_id"  # Replace 'sample_id' with actual test ID
    response = requests.get(url)

    if response.status_code == 200:
        return response.json()
    elif response.status_code == 400:
        raise ValueError("Invalid id specified")
    elif response.status_code == 404:
        raise Exception("symptom not found")
    else:
        raise RuntimeError(f"Unexpected status code: {response.status_code}")

def test_get_symptom_details(symptom_details):
    assert isinstance(symptom_details, dict)
    assert set(symptom_details.keys()) == {"id", "name", "question", "sex_filter"}