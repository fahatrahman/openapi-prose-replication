import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def headers():
    return {
        "Ocp-Apim-Subscription-Key": "your_subscription_key"
    }

@pytest.mark.parametrize("format", ["json"])
def test_player_season_stats_by_player(format, headers):
    roundid = "1"
    playerid = "90026231"
    url = f"{BASE_URL}/{format}/PlayerSeasonStatsByPlayer/{roundid}/{playerid}"
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert isinstance(response.json(), list)

if __name__ == "__main__":
    pytest.main()