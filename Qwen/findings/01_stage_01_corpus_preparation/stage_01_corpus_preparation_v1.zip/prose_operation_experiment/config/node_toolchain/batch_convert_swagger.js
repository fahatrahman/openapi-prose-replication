"use strict";

const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const converter = require("swagger2openapi");

const fsp = fs.promises;

const [
    manifestPath,
    corpusRootArgument,
    canonicalRootArgument,
    itemMetadataRootArgument,
    resultsPath,
    summaryPath,
    concurrencyArgument
] = process.argv.slice(2);

if (
    !manifestPath
    || !corpusRootArgument
    || !canonicalRootArgument
    || !itemMetadataRootArgument
    || !resultsPath
    || !summaryPath
) {
    console.error(
        "Missing batch-conversion arguments."
    );
    process.exit(2);
}

const corpusRoot = path.resolve(
    corpusRootArgument
);

const canonicalRoot = path.resolve(
    canonicalRootArgument
);

const itemMetadataRoot = path.resolve(
    itemMetadataRootArgument
);

const concurrency = Math.max(
    1,
    Number(concurrencyArgument || 1)
);

const HARNESS_VERSION = 1;
const TARGET_VERSION = "3.0.3";

const CONVERTER_VERSION =
    require(
        "swagger2openapi/package.json"
    ).version;

function sha256Buffer(value) {
    return crypto
        .createHash("sha256")
        .update(value)
        .digest("hex");
}

async function sha256File(filePath) {
    return sha256Buffer(
        await fsp.readFile(filePath)
    );
}

async function fileExists(filePath) {
    try {
        await fsp.access(
            filePath,
            fs.constants.F_OK
        );

        return true;
    } catch {
        return false;
    }
}

async function writeAtomic(
    filePath,
    content
) {
    await fsp.mkdir(
        path.dirname(filePath),
        {
            recursive: true
        }
    );

    const temporaryPath =
        `${filePath}.${process.pid}.tmp`;

    await fsp.writeFile(
        temporaryPath,
        content,
        "utf8"
    );

    await fsp.rename(
        temporaryPath,
        filePath
    );
}

function normalizeWarnings(warnings) {
    if (!Array.isArray(warnings)) {
        return [];
    }

    return warnings.map(
        (warning) => {
            if (
                typeof warning === "string"
            ) {
                return warning;
            }

            if (
                warning
                && typeof warning.message
                    === "string"
            ) {
                return warning.message;
            }

            try {
                return JSON.stringify(
                    warning
                );
            } catch {
                return String(warning);
            }
        }
    );
}

function countOperations(document) {
    const methods = new Set([
        "get",
        "put",
        "post",
        "delete",
        "options",
        "head",
        "patch",
        "trace"
    ]);

    let count = 0;

    for (
        const pathItem
        of Object.values(
            document.paths || {}
        )
    ) {
        if (
            !pathItem
            || typeof pathItem !== "object"
            || Array.isArray(pathItem)
        ) {
            continue;
        }

        for (
            const method
            of Object.keys(pathItem)
        ) {
            if (
                methods.has(
                    method.toLowerCase()
                )
            ) {
                count += 1;
            }
        }
    }

    return count;
}

function convertFile(sourcePath) {
    return new Promise(
        (resolve, reject) => {
            const options = {
                patch: false,
                warnOnly: false,
                resolve: false,
                targetVersion:
                    TARGET_VERSION,
                rbname:
                    "x-original-body-parameter-name"
            };

            converter.convertFile(
                sourcePath,
                options,
                (error, result) => {
                    if (error) {
                        reject(error);
                        return;
                    }

                    resolve({
                        openapi:
                            result.openapi,
                        warnings:
                            normalizeWarnings(
                                result.warnings
                            ),
                        patches:
                            Number(
                                result.patches
                                || 0
                            )
                    });
                }
            );
        }
    );
}

function safeDiagnostic(error) {
    const text = (
        error
        && (
            error.stack
            || error.message
        )
    )
        ? String(
            error.stack
            || error.message
        )
        : String(error);

    return text.slice(0, 12000);
}

async function loadReusableResult(
    record,
    outputPath,
    itemPath
) {
    if (
        !(await fileExists(outputPath))
        || !(await fileExists(itemPath))
    ) {
        return null;
    }

    try {
        const item = JSON.parse(
            await fsp.readFile(
                itemPath,
                "utf8"
            )
        );

        if (
            item.status !== "SUCCESS"
            || item.harness_version
                !== HARNESS_VERSION
            || item.converter_version
                !== CONVERTER_VERSION
            || item.target_openapi_version
                !== TARGET_VERSION
            || item.source_sha256
                !== record.source_sha256
        ) {
            return null;
        }

        const observedOutputHash =
            await sha256File(
                outputPath
            );

        if (
            observedOutputHash
            !== item.converted_sha256
        ) {
            return null;
        }

        return item;
    } catch {
        return null;
    }
}

async function processRecord(record) {
    const sourcePath = path.resolve(
        corpusRoot,
        record.relative_path
    );

    const relativeCheck = path.relative(
        corpusRoot,
        sourcePath
    );

    if (
        relativeCheck.startsWith("..")
        || path.isAbsolute(relativeCheck)
    ) {
        return {
            result: {
                harness_version:
                    HARNESS_VERSION,
                spec_id: record.spec_id,
                raw_id: record.raw_id,
                relative_path:
                    record.relative_path,
                source_sha256:
                    record.source_sha256,
                status:
                    "SOURCE_PATH_REJECTED",
                diagnostic:
                    "Source path escapes corpus root."
            },
            resumed: false
        };
    }

    if (
        !/^spec_[a-zA-Z0-9]+$/.test(
            record.spec_id
        )
    ) {
        return {
            result: {
                harness_version:
                    HARNESS_VERSION,
                spec_id: record.spec_id,
                raw_id: record.raw_id,
                relative_path:
                    record.relative_path,
                source_sha256:
                    record.source_sha256,
                status:
                    "SPEC_ID_REJECTED",
                diagnostic:
                    "Unsafe spec_id."
            },
            resumed: false
        };
    }

    const outputPath = path.join(
        canonicalRoot,
        `${record.spec_id}.json`
    );

    const itemPath = path.join(
        itemMetadataRoot,
        `${record.spec_id}.json`
    );

    const reusable =
        await loadReusableResult(
            record,
            outputPath,
            itemPath
        );

    if (reusable) {
        return {
            result: reusable,
            resumed: true
        };
    }

    let result;

    try {
        const sourceBytes =
            await fsp.readFile(
                sourcePath
            );

        const observedSourceHash =
            sha256Buffer(sourceBytes);

        if (
            observedSourceHash
            !== record.source_sha256
        ) {
            result = {
                harness_version:
                    HARNESS_VERSION,
                converter_version:
                    CONVERTER_VERSION,
                target_openapi_version:
                    TARGET_VERSION,
                spec_id: record.spec_id,
                raw_id: record.raw_id,
                relative_path:
                    record.relative_path,
                provider_directory:
                    record.provider_directory,
                source_sha256:
                    record.source_sha256,
                observed_source_sha256:
                    observedSourceHash,
                source_bytes:
                    sourceBytes.length,
                source_operation_count:
                    record.source_operation_count,
                status:
                    "SOURCE_HASH_MISMATCH",
                diagnostic:
                    "Observed source hash "
                    + "differs from the "
                    + "frozen inventory."
            };
        } else {
            const converted =
                await convertFile(
                    sourcePath
                );

            if (
                !converted.openapi
                || typeof converted.openapi
                    !== "object"
            ) {
                throw new Error(
                    "Converter returned no "
                    + "OpenAPI document."
                );
            }

            const serialized =
                JSON.stringify(
                    converted.openapi,
                    null,
                    2
                ) + "\n";

            const convertedBytes =
                Buffer.from(
                    serialized,
                    "utf8"
                );

            const convertedHash =
                sha256Buffer(
                    convertedBytes
                );

            await writeAtomic(
                outputPath,
                serialized
            );

            const outputOperationCount =
                countOperations(
                    converted.openapi
                );

            result = {
                harness_version:
                    HARNESS_VERSION,
                converter_version:
                    CONVERTER_VERSION,
                target_openapi_version:
                    TARGET_VERSION,
                spec_id: record.spec_id,
                raw_id: record.raw_id,
                relative_path:
                    record.relative_path,
                provider_directory:
                    record.provider_directory,
                source_sha256:
                    record.source_sha256,
                observed_source_sha256:
                    observedSourceHash,
                source_bytes:
                    sourceBytes.length,
                source_operation_count:
                    record.source_operation_count,
                status: "SUCCESS",
                output_relative_path:
                    path.posix.join(
                        "data",
                        "canonical",
                        `${record.spec_id}.json`
                    ),
                converted_sha256:
                    convertedHash,
                converted_bytes:
                    convertedBytes.length,
                output_openapi_version:
                    converted.openapi.openapi
                    || null,
                output_operation_count:
                    outputOperationCount,
                operation_count_matches:
                    outputOperationCount
                    === record
                        .source_operation_count,
                warning_count:
                    converted.warnings.length,
                warnings:
                    converted.warnings,
                patches:
                    converted.patches
            };
        }
    } catch (error) {
        result = {
            harness_version:
                HARNESS_VERSION,
            converter_version:
                CONVERTER_VERSION,
            target_openapi_version:
                TARGET_VERSION,
            spec_id: record.spec_id,
            raw_id: record.raw_id,
            relative_path:
                record.relative_path,
            provider_directory:
                record.provider_directory,
            source_sha256:
                record.source_sha256,
            source_bytes:
                record.source_bytes,
            source_operation_count:
                record.source_operation_count,
            status:
                "CONVERSION_FAILED",
            diagnostic:
                safeDiagnostic(error)
        };
    }

    await writeAtomic(
        itemPath,
        JSON.stringify(
            result,
            null,
            2
        ) + "\n"
    );

    return {
        result,
        resumed: false
    };
}

async function main() {
    const startedAt = Date.now();

    await fsp.mkdir(
        canonicalRoot,
        {
            recursive: true
        }
    );

    await fsp.mkdir(
        itemMetadataRoot,
        {
            recursive: true
        }
    );

    const manifest = JSON.parse(
        await fsp.readFile(
            manifestPath,
            "utf8"
        )
    );

    const records =
        manifest.records || [];

    const results = new Array(
        records.length
    );

    let nextIndex = 0;
    let completedCount = 0;
    let resumedCount = 0;

    async function worker() {
        while (true) {
            const currentIndex =
                nextIndex++;

            if (
                currentIndex
                >= records.length
            ) {
                return;
            }

            const outcome =
                await processRecord(
                    records[currentIndex]
                );

            results[currentIndex] =
                outcome.result;

            if (outcome.resumed) {
                resumedCount += 1;
            }

            completedCount += 1;

            if (
                completedCount % 25 === 0
                || completedCount
                    === records.length
            ) {
                const elapsedSeconds =
                    (
                        Date.now()
                        - startedAt
                    ) / 1000;

                const rate = (
                    elapsedSeconds > 0
                    ? completedCount
                        / elapsedSeconds
                    : 0
                );

                const remaining =
                    records.length
                    - completedCount;

                const etaSeconds = (
                    rate > 0
                    ? remaining / rate
                    : null
                );

                console.log(
                    JSON.stringify({
                        progress:
                            completedCount,
                        total:
                            records.length,
                        resumed:
                            resumedCount,
                        elapsed_seconds:
                            Number(
                                elapsedSeconds
                                .toFixed(1)
                            ),
                        rate_per_second:
                            Number(
                                rate.toFixed(3)
                            ),
                        eta_seconds:
                            etaSeconds === null
                            ? null
                            : Number(
                                etaSeconds
                                .toFixed(1)
                            )
                    })
                );
            }
        }
    }

    await Promise.all(
        Array.from(
            {
                length: concurrency
            },
            () => worker()
        )
    );

    const sortedResults = [
        ...results
    ].sort(
        (left, right) => {
            const pathComparison =
                String(
                    left.relative_path
                ).localeCompare(
                    String(
                        right.relative_path
                    )
                );

            if (pathComparison !== 0) {
                return pathComparison;
            }

            return String(
                left.spec_id
            ).localeCompare(
                String(
                    right.spec_id
                )
            );
        }
    );

    const jsonl =
        sortedResults
        .map(
            (record) =>
                JSON.stringify(record)
        )
        .join("\n")
        + "\n";

    await writeAtomic(
        resultsPath,
        jsonl
    );

    const countStatus = (
        status
    ) => sortedResults.filter(
        (record) =>
            record.status === status
    ).length;

    const successful =
        sortedResults.filter(
            (record) =>
                record.status
                === "SUCCESS"
        );

    const failures =
        sortedResults.filter(
            (record) =>
                record.status
                !== "SUCCESS"
        );

    const sourceIntegrityFailures =
        countStatus(
            "SOURCE_HASH_MISMATCH"
        )
        + countStatus(
            "SOURCE_PATH_REJECTED"
        )
        + countStatus(
            "SPEC_ID_REJECTED"
        );

    const summary = {
        status: (
            sortedResults.length
                === records.length
            && sourceIntegrityFailures === 0
            ? "PASS"
            : "BLOCKED"
        ),
        converter:
            "swagger2openapi",
        converter_version:
            CONVERTER_VERSION,
        target_openapi_version:
            TARGET_VERSION,
        concurrency,
        source_record_count:
            records.length,
        result_record_count:
            sortedResults.length,
        resumed_success_count:
            resumedCount,
        conversion_success_count:
            successful.length,
        conversion_failure_count:
            failures.length,
        source_integrity_failure_count:
            sourceIntegrityFailures,
        success_with_warnings_count:
            successful.filter(
                (record) =>
                    record.warning_count > 0
            ).length,
        success_with_patches_count:
            successful.filter(
                (record) =>
                    record.patches > 0
            ).length,
        output_version_mismatch_count:
            successful.filter(
                (record) =>
                    record
                    .output_openapi_version
                    !== TARGET_VERSION
            ).length,
        operation_count_mismatch_count:
            successful.filter(
                (record) =>
                    !record
                    .operation_count_matches
            ).length,
        converted_output_bytes:
            successful.reduce(
                (
                    total,
                    record
                ) =>
                    total
                    + Number(
                        record
                        .converted_bytes
                        || 0
                    ),
                0
            ),
        results_sha256:
            sha256Buffer(
                Buffer.from(
                    jsonl,
                    "utf8"
                )
            ),
        duration_seconds:
            Number(
                (
                    (
                        Date.now()
                        - startedAt
                    ) / 1000
                ).toFixed(3)
            ),
        failure_examples:
            failures.slice(0, 20),
        results_path:
            resultsPath
    };

    await writeAtomic(
        summaryPath,
        JSON.stringify(
            summary,
            null,
            2
        ) + "\n"
    );

    console.log(
        JSON.stringify({
            completed: true,
            status: summary.status,
            successes:
                summary
                .conversion_success_count,
            failures:
                summary
                .conversion_failure_count
        })
    );

    if (summary.status !== "PASS") {
        process.exitCode = 1;
    }
}

main().catch((error) => {
    console.error(
        error.stack || String(error)
    );

    process.exitCode = 1;
});
