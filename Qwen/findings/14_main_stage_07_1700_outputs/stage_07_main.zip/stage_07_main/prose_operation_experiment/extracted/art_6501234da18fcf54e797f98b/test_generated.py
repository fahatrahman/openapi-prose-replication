import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_operation():
    url = f"{BASE_URL}/v1/{pytest.config.getoption('--name')}"
    params = {
        "$.xgafv": pytest.config.getoption("--xgafv"),
        "access_token": pytest.config.getoption("--access-token"),
        "alt": pytest.config.getoption("--alt"),
        "callback": pytest.config.getoption("--callback"),
        "fields": pytest.config.getoption("--fields"),
        "key": pytest.config.getoption("--key"),
        "oauth_token": pytest.config.getoption("--oauth-token"),
        "prettyPrint": pytest.config.getoption("--pretty-print"),
        "quotaUser": pytest.config.getoption("--quota-user"),
        "uploadType": pytest.config.getoption("--upload-type"),
        "upload_protocol": pytest.config.getoption("--upload-protocol")
    }
    headers = {
        "Authorization": f"Bearer {pytest.config.getoption('--token')}"
    }
    response = requests.delete(url, params=params, headers=headers)
    assert response.status_code == 200
    assert response.json() == {}