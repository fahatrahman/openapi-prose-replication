# -*- coding: utf-8 -*-

import pytest
import requests
from jsonschema import validate

BASE_URL = "http://openapi.test"

def test_new_address():
    url = f"{BASE_URL}/v2/ethereum/addresses"
    headers = {
        'Content-Type': 'application/json'
    }
    payload = {
        "password": "test123"
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 200
    data = response.json()

    schema = {
        "type": "object",
        "properties": {
            "data": {
                "type": "object",
                "properties": {
                    "ethereumaddress": {"type": "string"}
                }
            },
            "message": {"type": "string"},
            "ok": {"type": "boolean"},
            "status": {"type": "integer"}
        }
    }

    try:
        validate(instance=data, schema=schema)
    except Exception as e:
        pytest.fail(f"JSON schema validation failed: {str(e)}")

    assert data["data"]["ethereumaddress"]
    assert data["message"] == "Success! Ethereum Address was successfully created."
    assert data["ok"] is True
    assert data["status"] == 200