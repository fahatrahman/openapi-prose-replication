import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_chain_parameters():
    url = f"{BASE_URL}/v2/tron/chainparameters"
    response = requests.get(url)
    
    assert response.status_code == 200
    data = response.json()
    
    assert data["ok"]
    assert data["status"] == 200
    assert "data" in data
    
    chain_parameters = data["data"][0]["chainParameter"]
    expected_keys = [
        "getMaintenanceTimeInterval",
        "getAccountUpgradeCost",
        "getCreateAccountFee",
        "getTransactionFee",
        "getAssetIssueFee",
        "getWitnessPayPerBlock",
        "getWitnessStandbyAllowance",
        "getCreateNewAccountFeeInSystemContract",
        "getCreateNewAccountBandwidthRate",
        "getAllowCreationOfContracts",
        "getRemoveThePowerOfTheGr",
        "getEnergyFee",
        "getExchangeCreateFee",
        "getMaxCpuTimeOfOneTx",
        "getAllowUpdateAccountName",
        "getAllowSameTokenName",
        "getAllowDelegateResource",
        "getTotalEnergyLimit",
        "getAllowTvmTransferTrc10",
        "getTotalEnergyCurrentLimit",
        "getAllowMultiSign",
        "getAllowAdaptiveEnergy",
        "getTotalEnergyTargetLimit",
        "getTotalEnergyAverageUsage",
        "getUpdateAccountPermissionFee",
        "getMultiSignFee",
        "getAllowAccountStateRoot",
        "getAllowProtoFilterNum",
        "getAllowTvmConstantinople",
        "getAllowTvmSolidity059",
        "getAllowTvmIstanbul",
        "getAllowShieldedTRC20Transaction",
        "getForbidTransferToContract",
        "getAdaptiveResourceLimitTargetRatio",
        "getAdaptiveResourceLimitMultiplier",
        "getChangeDelegation",
        "getWitness127PayPerBlock",
        "getAllowMarketTransaction",
        "getMarketSellFee",
        "getMarketCancelFee",
        "getAllowPBFT",
        "getAllowTransactionFeePool",
        "getMaxFeeLimit",
        "getAllowOptimizeBlackHole",
        "getAllowNewResourceModel",
        "getAllowTvmFreeze",
        "getAllowTvmVote",
        "getAllowTvmLondon",
        "getAllowTvmCompatibleEvm",
        "getAllowAccountAssetOptimization",
        "getFreeNetLimit",
        "getTotalNetLimit"
    ]
    
    for param in chain_parameters:
        assert param["key"] in expected_keys
        assert isinstance(param["value"], (int, float))

if __name__ == "__main__":
    pytest.main([__file__])