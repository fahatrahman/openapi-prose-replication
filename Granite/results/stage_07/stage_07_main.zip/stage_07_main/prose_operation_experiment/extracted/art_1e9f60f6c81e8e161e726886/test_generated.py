import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retries for transient errors
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

@pytest.fixture
def new_ethereum_address():
    endpoint = "/v2/ethereum/addresses"
    payload = {"password": "test123"}

    response = session.post(BASE_URL + endpoint, json=payload)

    assert response.status_code == 200
    data = response.json()

    assert data["ok"] is True
    assert data["status"] == 200
    assert data["message"] == "Success! Ethereum Address was successfully created."
    assert len(data["data"]["ethereumaddress"]) > 0

    return data["data"]["ethereumaddress"]

def test_new_ethereum_address(new_ethereum_address):
    # Here you can add more assertions or tests based on your requirements
    pass