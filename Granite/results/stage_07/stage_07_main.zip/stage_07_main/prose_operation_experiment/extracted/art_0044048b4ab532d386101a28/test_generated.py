import os
import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def auth():
    return HTTPBasicAuth("your_client_id", "your_client_secret")

def test_insert_custom_dimension(auth):
    account_id = "your_account_id"
    web_property_id = "your_web_property_id"

    custom_dimension = {
        "accountId": account_id,
        "active": True,
        "name": "Test Dimension",
        "scope": "HIT",
        "webPropertyId": web_property_id
    }

    response = requests.post(
        f"{BASE_URL}/management/accounts/{account_id}/webproperties/{web_property_id}/customDimensions",
        json=custom_dimension,
        auth=auth
    )

    assert response.status_code == 200
    inserted_dimension = response.json()
    assert all(k in inserted_dimension for k in custom_dimension)