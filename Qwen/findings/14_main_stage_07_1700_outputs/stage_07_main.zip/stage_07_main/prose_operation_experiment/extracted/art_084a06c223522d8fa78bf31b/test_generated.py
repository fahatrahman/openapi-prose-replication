import pytest
import requests

BASE_URL = "http://openapi.test"

def test_fetch_dialing_permissions_country():
    iso_code = "US"
    url = f"{BASE_URL}/v1/DialingPermissions/Countries/{iso_code}"
    headers = {
        "Authorization": "Basic YWNjb3VudFNpZDphY2NvdW50VG9rZW4="
    }
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert "iso_code" in data
    assert "name" in data
    assert "continent" in data