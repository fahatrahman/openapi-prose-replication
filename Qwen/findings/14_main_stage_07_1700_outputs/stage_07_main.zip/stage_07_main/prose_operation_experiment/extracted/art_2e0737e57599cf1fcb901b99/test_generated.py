import pytest
import requests

BASE_URL = "http://openapi.test"

def test_purge_user_events():
    url = f"{BASE_URL}/v2beta/projects/locations/catalogs/userEvents:purge"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "filter": "your_filter_here",
        "force": True
    }
    response = requests.post(url, headers=headers, json=payload)
    
    assert response.status_code == 200
    assert "name" in response.json()
    assert "metadata" in response.json()
    assert "done" in response.json()

if __name__ == "__main__":
    pytest.main()