import pytest
import requests

BASE_URL = "http://openapi.test"

def get_contact_lists(offset=0, limit=10, sort=None):
    headers = {
        "Authorization": "Bearer your_api_key_here"
    }
    params = {
        "offset": offset,
        "limit": limit
    }
    if sort:
        params["sort"] = sort
    response = requests.get(f"{BASE_URL}/contacts/lists", headers=headers, params=params)
    return response.json()

def test_get_contact_lists():
    response = get_contact_lists()
    assert response["status_code"] == 200
    assert isinstance(response["data"], dict)
    assert "page" in response["data"]
    assert "total" in response["data"]

def test_get_contact_lists_with_offset():
    response = get_contact_lists(offset=10)
    assert response["status_code"] == 200
    assert isinstance(response["data"], dict)
    assert "page" in response["data"]
    assert "total" in response["data"]

def test_get_contact_lists_with_limit():
    response = get_contact_lists(limit=5)
    assert response["status_code"] == 200
    assert isinstance(response["data"], dict)
    assert "page" in response["data"]
    assert "total" in response["data"]

def test_get_contact_lists_with_sort():
    response = get_contact_lists(sort="name")
    assert response["status_code"] == 200
    assert isinstance(response["data"], dict)
    assert "page" in response["data"]
    assert "total" in response["data"]

def test_get_contact_lists_unauthorized():
    response = get_contact_lists(headers={"Authorization": "Bearer invalid_api_key"})
    assert response["status_code"] == 401
    assert isinstance(response["data"], list)
    assert len(response["data"]) > 0

def test_get_contact_lists_not_found():
    response = get_contact_lists(offset=1000)
    assert response["status_code"] == 404
    assert isinstance(response["data"], list)
    assert len(response["data"]) > 0

def test_get_contact_lists_validation_error():
    response = get_contact_lists(limit=-1)
    assert response["status_code"] == 422
    assert isinstance(response["data"], list)
    assert len(response["data"]) > 0