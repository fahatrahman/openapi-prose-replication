import pytest
import requests

BASE_URL = "http://openapi.test"

def test_demote_destination():
    url = f"{BASE_URL}/v1/projects/location/migrationJobs/demoteDestination"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        # Add required body parameters here
    }
    params = {
        "_xgafv": "2",
        "access_token": "YOUR_ACCESS_TOKEN",
        "alt": "json",
        "callback": "YOUR_CALLBACK",
        "fields": "YOUR_FIELDS",
        "key": "YOUR_KEY",
        "oauth_token": "YOUR_OAUTH_TOKEN",
        "prettyPrint": True,
        "quotaUser": "YOUR_QUOTA_USER",
        "uploadType": "media",
        "upload_protocol": "raw",
        "name": "projects/location/migrationJobs/demoteDestination"
    }

    response = requests.post(url, headers=headers, json=payload, params=params)

    assert response.status_code == 200
    assert "application/json" in response.headers["Content-Type"]
    assert isinstance(response.json(), dict)