import pytest
import requests

BASE_URL = "http://openapi.test"

def test_batch_snooze_alarm():
    url = f"{BASE_URL}/alarms/snooze"
    headers = {
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Date": "20230401T000000Z",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20230401/us-east-1/iotevents/aws4_request",
        "X-Amz-Security-Token": "AQoDYXdzEPT//////////wEXAMPLEtc7IRISlCBIQg+CtFRSRqTM4mRJpTAVVrKk6jwaizkXuYEdemPllVMDJS françaises.",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-algorithm;x-amz-credential;x-amz-security-token"
    }
    payload = {
        "snoozeActionRequests": [
            {
                "requestId": "unique-id-1",
                "alarmModelName": "example-model",
                "keyValue": "example-key",
                "snoozeDuration": 3600,
                "note": "This is a snooze action."
            },
            {
                "requestId": "unique-id-2",
                "alarmModelName": "another-model",
                "keyValue": "another-key",
                "snoozeDuration": 7200,
                "note": "Another snooze action."
            }
        ]
    }
    response = requests.post(url, json=payload, headers=headers)
    assert response.status_code == 202
    assert "errorEntries" not in response.json()