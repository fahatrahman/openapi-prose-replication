import os
import pytest
import requests
from requests.exceptions import HTTPError

BASE_URL = "http://openapi.test"

@pytest.fixture
def http_client():
    session = requests.Session()
    return session

def test_listDeploymentFiles(http_client):
    id = "example_id"
    teamId = "example_teamId"

    url = f"{BASE_URL}/v6/deployments/{id}/files"
    headers = {"Authorization": "Bearer your_token"}
    params = {"teamId": teamId}

    response = http_client.get(url, headers=headers, params=params)

    if response.status_code == 200:
        files = response.json()
        assert isinstance(files, list)
        for file in files:
            assert all(key in file for key in ["name", "type", "mode"])
    elif response.status_code == 400:
        assert response.json()["detail"] == "Bad Request error."
    elif response.status_code == 403:
        assert response.json()["detail"] == "Forbidden error."
    elif response.status_code == 404:
        assert response.json()["detail"] == "Not Found error."
    else:
        raise HTTPError(f"Unexpected status code: {response.status_code}")