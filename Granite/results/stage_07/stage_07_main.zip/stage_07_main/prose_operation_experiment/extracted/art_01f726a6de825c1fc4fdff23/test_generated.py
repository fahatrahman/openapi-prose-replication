import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retry logic for handling transient errors
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["GET", "OPTIONS"],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def voice_settings():
    url = f"{BASE_URL}/v1/voices/settings/default"
    response = session.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Request failed with status code {response.status_code}")

def test_get_default_voice_settings(voice_settings):
    assert isinstance(voice_settings, dict)
    assert set(voice_settings.keys()) == {"stability", "similarity_boost"}