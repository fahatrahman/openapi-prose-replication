# -*- coding: utf-8 -*-
"""
pytest module for testing SeasonTeams endpoint.
"""

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_season_teams():
    """
    Test getting season teams.

    :return:
    """

    url = f"{BASE_URL}/{{format}}/SeasonTeams/{{seasonid}}"
    params = {"format": "json", "seasonid": "100000057"}
    headers = {}
    auth = None

    response = requests.get(url, params=params, headers=headers, auth=auth)

    assert response.status_code == 200

    # Check if the response content is in JSON format
    assert response.headers["Content-Type"] == "application/json"

    # Parse the JSON response
    json_response = response.json()

    # Check if the response contains an array of SeasonTeam objects
    assert isinstance(json_response, list)
    for team in json_response:
        assert isinstance(team, dict)
        required_keys = ["Active", "SeasonId", "SeasonTeamId", "Team"]
        for key in required_keys:
            assert key in team