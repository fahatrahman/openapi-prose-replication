import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_PATH = "path/to/credentials.json"

@pytest.fixture
def chrome_management_service():
    credentials = service_account.Credentials.from_service_account_file(
        CREDENTIALS_PATH)

    def get_request(*args, **kwargs):
        url = f"{BASE_URL}/v1/my_customer/reports:findInstalledAppDevices"
        headers = {"Content-Type": "application/json"}
        params = {
            "appId": "ehoadneljpdggcbbknedodolkkjodefl",
            "appType": "EXTENSION",
            "filter": "last_active_date > '2022-01-01'",
            "orderBy": "machine",
            "pageSize": 10,
            "pageToken": "abc123"
        }

        response = requests.get(url, headers=headers, params=params, auth=credentials)
        response.raise_for_status()

        return response.json()

    return get_request

def test_find_installed_app_devices(chrome_management_service):
    response = chrome_management_service()
    assert isinstance(response, dict)
    assert "devices" in response
    assert len(response["devices"]) > 0