import pytest
import requests
BASE_URL = "http://openapi.test"

@pytest.fixture
def client():
    return requests.Client()

def test_apply_configuration(client):
    parent = "hwjekqwev/123456" # replace with actual value
    response = client.post(
        f"{BASE_URL}/v1/{parent}/devices:applyConfiguration",
        json={
            "configuration": "sample_configuration",
            "device": {
                "deviceId": 123456,
                "deviceIdentifier": {
                    "chromeOsAttestedDeviceId": "sample_attested_device_id",
                    "deviceType": "DEVICE_TYPE_ANDROID",
                    "imei": "sample_imei",
                    "manufacturer": "sample_manufacturer",
                    "meid": "sample_meid",
                    "model": "sample_model",
                    "serialNumber": "sample_serial_number"
                }
            }
        }
    )
    assert response.status_code == 200