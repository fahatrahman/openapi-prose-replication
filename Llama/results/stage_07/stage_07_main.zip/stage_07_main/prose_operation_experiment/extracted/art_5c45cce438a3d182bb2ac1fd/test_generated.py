# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_get_domain():
    domain_name = "example"
    response = requests.get(
        f"{BASE_URL}/domains/{domain_name}",
        params={"domain_name": domain_name}
    )
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    required_keys = ["can_toggle_renew", "domain_name", "expiration_date", "name_servers", "registrant", "will_renew"]
    for key in required_keys:
        assert key in data
    try:
        expiration_date = datetime.fromisoformat(data["expiration_date"])
        assert isinstance(expiration_date, datetime)
    except ValueError:
        pytest.fail("Invalid date format")