import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_input_devices():
    headers = {
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Date": "20230401T000000Z",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20230401/us-east-1/mediaconnect/aws4_request",
        "X-Amz-Security-Token": "AQoEXAMPLEHIL2CLQ==",
        "X-Amz-Signature": "EXAMPLESIGNATURE"
    }
    params = {
        "maxResults": 10,
        "nextToken": None
    }
    response = requests.get(f"{BASE_URL}/prod/inputDevices", headers=headers, params=params)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "InputDevices" in response.json()
    assert isinstance(response.json()["InputDevices"], list)

if __name__ == "__main__":
    pytest.main([__file__])