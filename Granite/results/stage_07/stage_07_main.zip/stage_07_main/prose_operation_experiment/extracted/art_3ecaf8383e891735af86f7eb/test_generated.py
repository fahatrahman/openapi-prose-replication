import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Define custom retry strategy for requests
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def client():
    return session

def test_get_related_jobs(client):
    id = "your_id_here" # Replace with actual ID
    url = f"{BASE_URL}/skills/{id}/related_jobs"

    response = client.get(url)
    
    if response.status_code == 200:
        assert response.json()["normalized_job_title"] is not None
        assert response.json()["skill_name"] is not None
    else:
        assert response.json()["code"] == response.status_code
        assert response.json()["message"]
