import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_stub_mapping():
    url = f"{BASE_URL}/__admin/mappings"
    payload = {
        "request": {
            "method": "POST",
            "url": "/some/thing",
            "headers": {
                "Content-Type": "application/json"
            },
            "bodyPatterns": [
                {
                    "equalToJson": "{\"numbers\": [1, 2, 3]}"
                }
            ]
        },
        "response": {
            "status": 200,
            "body": "Hello world!",
            "headers": {
                "Content-Type": "text/plain"
            }
        }
    }
    headers = {
        "Content-Type": "application/json"
    }
    response = requests.post(url, json=payload, headers=headers)
    assert response.status_code == 201
    assert response.json()["request"]["url"] == "/some/thing"
    assert response.json()["response"]["body"] == "Hello world!"