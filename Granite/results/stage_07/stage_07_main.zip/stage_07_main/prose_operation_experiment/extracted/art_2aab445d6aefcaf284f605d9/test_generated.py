import os
import pytest
import requests
from base64 import b64decode

BASE_URL = "http://openapi.test"
AUTH_TOKEN = os.environ.get("OPENAPI_AUTH_TOKEN")

# Prepare basic auth header
if AUTH_TOKEN:
    credentials = b64decode(AUTH_TOKEN.encode()).decode()
    auth_header = f"Basic {credentials}"
else:
    auth_header = None


@pytest.fixture
def request_session():
    session = requests.Session()
    session.headers.update({"Authorization": auth_header})
    return session


def test_list_conversations(request_session):
    response = request_session.get(
        f"{BASE_URL}/v1/Conversations", headers={"Content-Type": "application/json"}
    )

    assert response.status_code == 200
    data = response.json()["conversations"]
    assert isinstance(data, list)