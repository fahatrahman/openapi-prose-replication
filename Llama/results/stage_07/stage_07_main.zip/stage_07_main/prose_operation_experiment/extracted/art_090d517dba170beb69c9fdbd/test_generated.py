# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_list_attachments():
    parent = "projects/some-project/cases/43595344"
    headers = {"Authorization": "Bearer some-access-token"}
    params = {
        "key": "some-api-key",
        "prettyPrint": "true",
        "quotaUser": "some-quota-user",
        "uploadProtocol": "some-upload-protocol",
        "uploadType": "some-upload-type",
        "pageSize": 10,
        "pageToken": None
    }

    url = urljoin(BASE_URL, f"/v2/{parent}/attachments")
    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 200
    response_json = response.json()
    assert isinstance(response_json, dict)
    assert 'attachments' in response_json.keys()
    assert isinstance(response_json['attachments'], list)
    assert len(response_json['attachments']) > 0
    assert isinstance(response_json['attachments'][0], dict)
    assert 'name' in response_json['attachments'][0].keys()
    assert isinstance(response_json['attachments'][0]['name'], str)