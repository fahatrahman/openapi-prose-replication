import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_PATH = "path/to/credentials.json"

@pytest.fixture
def authenticated_session():
    credentials = service_account.Credentials.from_service_account_file(
        CREDENTIALS_PATH)
    delegated_credentials = credentials.with_subject("primary@self-hosted.dev")
    delegate = requests.Session()
    delegate.headers.update({"Authorization": f"Bearer {delegated_credentials.access_token}"})
    return delegate

def test_purge_artifacts(authenticated_session):
    parent = "projects/<PROJECT_ID>/locations/<LOCATION>/metadataStores/<METADATASTORE>"
    request_body = {
        "filter": "<FILTER>",
        "force": True
    }

    url = f"{BASE_URL}/{parent}:purge"
    response = authenticated_session.post(url, json=request_body)

    assert response.status_code == 200
    # Add further assertions based on expected responses