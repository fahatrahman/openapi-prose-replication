import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"

@pytest.fixture
def dialogflow_service():
    credentials = service_account.Credentials.from_service_account_file(
        filename="path/to/your/service_account_key.json",
        scopes=["https://www.googleapis.com/auth/cloud-platform",
               "https://www.googleapis.com/auth/dialogflow"],
    )

    def _get():
        headers = {
            "x-goog-api-client": "gl-python/0.1.0",
            "x-goog-api-version": "v3",
            "accept": "application/json",
            "content-type": "application/json",
        }

        if credentials:
            headers["Authorization"] = f"Bearer {credentials.token}"

        response = requests.post(
            f"{BASE_URL}/v3/{parent}/testCases:batchRun",
            json={
                "environment": "projects/*/locations/*/agents/*",
                "testCases": ["your_test_case_ids_here"]
            },
            headers=headers,
        )

        return response.json()

    return _get

def test_batch_run_cases(dialogflow_service):
    result = dialogflow_service()
    assert result['name'] == 'operations/your_operation_id'
    assert result['metadata']['@type'] == 'type.googleapis.com/google.longrunning.Operation'
    assert result['done'] is True  # or False depending on actual implementation
    assert result['response']['status']['code'] == 200