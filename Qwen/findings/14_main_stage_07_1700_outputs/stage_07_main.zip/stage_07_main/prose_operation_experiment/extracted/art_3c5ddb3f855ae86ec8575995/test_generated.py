import pytest
import requests

BASE_URL = "http://openapi.test"

def test_update_role():
    url = f"{BASE_URL}/admin/directory/v1/customer/YOUR_CUSTOMER_ID/roles/YOUR_ROLE_ID"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "roleName": "Updated Role Name",
        "roleDescription": "Updated role description",
        "rolePrivileges": [
            {
                "privilegeName": "admin.directory.user",
                "serviceId": "admin"
            }
        ]
    }
    response = requests.put(url, headers=headers, json=payload)
    assert response.status_code == 200
    updated_role = response.json()
    assert updated_role["roleName"] == "Updated Role Name"
    assert updated_role["roleDescription"] == "Updated role description"
    assert len(updated_role["rolePrivileges"]) == 1
    assert updated_role["rolePrivileges"][0]["privilegeName"] == "admin.directory.user"
    assert updated_role["rolePrivileges"][0]["serviceId"] == "admin"