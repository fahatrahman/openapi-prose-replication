import pytest
import requests

BASE_URL = "http://openapi.test"

def test_listDeviceSetsOfUser():
    url = f"{BASE_URL}/v0.1/apps/owner_name/app_name/user/device_sets"
    headers = {
        "X-API-Token": "your_api_token_here"
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert isinstance(response.json(), list)

if __name__ == "__main__":
    pytest.main()