import pytest
import requests

BASE_URL = "http://openapi.test"

def test_erc20_get():
    url = f"{BASE_URL}/erc20"
    response = requests.get(url)
    assert response.status_code == 200
    assert response.json() == {}