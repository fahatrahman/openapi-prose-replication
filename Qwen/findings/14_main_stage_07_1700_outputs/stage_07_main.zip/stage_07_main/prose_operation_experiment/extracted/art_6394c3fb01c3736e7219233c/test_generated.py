import pytest
import requests

BASE_URL = "http://openapi.test"

def test_calendar_settings_watch():
    url = f"{BASE_URL}/users/me/settings/watch"
    headers = {
        "Authorization": "Bearer YOUR_OAUTH_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "address": "example@example.com",
        "expiration": "1672531200000",
        "id": "12345",
        "kind": "api#channel",
        "params": {},
        "payload": True,
        "resourceId": "resource_id_123",
        "resourceUri": "http://example.com/resource",
        "token": "example_token",
        "type": "qbc_nliu"
    }
    params = {
        "alt": "json",
        "fields": "*",
        "key": "YOUR_API_KEY",
        "oauth_token": "YOUR_OAUTH_TOKEN",
        "prettyPrint": False,
        "quotaUser": "user@example.com",
        "userIp": "127.0.0.1",
        "maxResults": 100,
        "pageToken": "",
        "syncToken": ""
    }

    response = requests.post(url, headers=headers, json=payload, params=params)
    assert response.status_code == 200
    assert "id" in response.json()
    assert response.json()["id"] == "12345"