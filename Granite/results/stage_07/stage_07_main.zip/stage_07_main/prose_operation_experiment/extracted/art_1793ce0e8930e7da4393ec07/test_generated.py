import pytest
import requests
from requests.exceptions import RequestException
BASE_URL = "http://openapi.test"

def test_authorization_code():
    endpoint = "/api/v2/AuthorizationCodes"
    url = BASE_URL + urlencode(endpoint)

    try:
        response = requests.post(url, json={"Code": "TESTCODE",
                                            "CreatedByUserID": 123,
                                            "CreatedDate": "2022-01-01T00:00:00Z",
                                            "DataParameters": [],
                                            "DefinitionID": "TESTDEF",
                                            "DeletedByUserID": None,
                                            "DeletedDate": None,
                                            "EffectiveDate": None,
                                            "ID": None,
                                            "IsDeleted": False,
                                            "ValidationParameters": []})

        response.raise_for_status()
        assert response.status_code == 200
        assert isinstance(response.json(), int)

    except RequestException as e:
        pytest.fail(f"Request failed: {e}")