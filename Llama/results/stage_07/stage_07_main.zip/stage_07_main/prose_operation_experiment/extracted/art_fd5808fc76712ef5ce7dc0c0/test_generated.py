# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_fetch_file_diff():
    workspace = "my_workspace"
    path = "/path/to/file.txt"

    params = {
        "workspace": workspace,
        "path": path,
        "$.xgafv": "1",
        "key": "your_api_key",  # Replace with your actual API key
        "prettyPrint": "false",
        "quotaUser": "",
        "uploadProtocol": "raw",
        "uploadType": "media",
    }

    headers = {"Content-Type": "application/json"}

    url = urljoin(BASE_URL, f"/v1beta1/{workspace}:fetchFileDiff")
    response = requests.get(url, params=params)

    assert response.status_code == 200
    assert response.json()["formattedDiff"]