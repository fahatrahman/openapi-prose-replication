import pytest
import requests

BASE_URL = "http://openapi.test"

def test_submit_third_party():
    url = f"{BASE_URL}/submitThirdParty"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Basic YWR5ZW46YWR5ZW4="  # Replace with actual credentials
    }
    payload = {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "reference": "PayoutPayment-0001",
        "amount": {
            "currency": "EUR",
            "value": 1000
        },
        "shopperEmail": "shopper@email.com",
        "shopperName": {
            "firstName": "Adyen",
            "lastName": "Test"
        },
        "shopperReference": "YOUR_UNIQUE_SHOPPER_ID",
        "entityType": "Company",
        "nationality": "NL",
        "dateOfBirth": "1990-01-01",
        "recurring": {
            "contract": "PAYOUT"
        },
        "selectedRecurringDetailReference": "LATEST"
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 200
    assert response.json()["resultCode"] == "payout-submit-received"

def test_submit_third_party_bad_request():
    url = f"{BASE_URL}/submitThirdParty"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Basic YWR5ZW46YWR5ZW4="  # Replace with actual credentials
    }
    payload = {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "reference": "PayoutPayment-0001",
        "amount": {
            "currency": "EUR",
            "value": 1000
        },
        "shopperEmail": "shopper@email.com",
        "shopperName": {
            "firstName": "Adyen",
            "lastName": "Test"
        },
        "shopperReference": "YOUR_UNIQUE_SHOPPER_ID",
        "entityType": "InvalidEntityType",  # Intentionally invalid
        "nationality": "NL",
        "dateOfBirth": "1990-01-01",
        "recurring": {
            "contract": "PAYOUT"
        },
        "selectedRecurringDetailReference": "LATEST"
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 400
    assert response.json()["errorCode"] == "702"
    assert response.json()["errorType"] == "validation"
    assert response.json()["message"].startswith("Unexpected input")

if __name__ == "__main__":
    pytest.main()