import pytest
import requests

BASE_URL = "http://openapi.test"

def create_section_for_project(project_gid, section_data, fields=None, pretty=False):
    url = f"{BASE_URL}/projects/{project_gid}/sections"
    params = {}
    if fields:
        params['opt_fields'] = fields
    if pretty:
        params['opt_pretty'] = pretty
    headers = {
        'Authorization': 'Bearer YOUR_ACCESS_TOKEN'
    }
    response = requests.post(url, json={'data': section_data}, params=params, headers=headers)
    return response.json()

@pytest.fixture
def project_gid():
    # Replace with actual project gid for testing
    return "1331"

@pytest.fixture
def section_request_data():
    # Replace with actual section request data for testing
    return {
        "name": "New Section",
        "insert_before": "86420"
    }

def test_create_section_for_project_success(project_gid, section_request_data):
    response = create_section_for_project(project_gid, section_request_data, fields="gid,name", pretty=True)
    assert response['data']['status_code'] == 201
    assert 'gid' in response['data']
    assert 'name' in response['data']

def test_create_section_for_project_bad_request(project_gid, section_request_data):
    response = create_section_for_project(project_gid, {"invalid_key": "value"})
    assert response['data']['status_code'] == 400

def test_create_section_for_project_unauthorized(project_gid, section_request_data):
    headers = {'Authorization': 'Bearer INVALID_ACCESS_TOKEN'}
    response = requests.post(f"{BASE_URL}/projects/{project_gid}/sections", json={'data': section_request_data}, headers=headers)
    assert response.status_code == 401

def test_create_section_for_project_forbidden(project_gid, section_request_data):
    response = create_section_for_project("INVALID_PROJECT_GID", section_request_data)
    assert response['data']['status_code'] == 403

def test_create_section_for_project_not_found(project_gid, section_request_data):
    response = create_section_for_project("INVALID_PROJECT_GID", section_request_data)
    assert response['data']['status_code'] == 404

def test_create_section_for_project_internal_server_error(project_gid, section_request_data):
    response = create_section_for_project(project_gid, section_request_data)
    assert response['data']['status_code'] == 500