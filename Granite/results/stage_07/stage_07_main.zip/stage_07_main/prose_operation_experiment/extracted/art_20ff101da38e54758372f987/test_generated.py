import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Define custom retry strategy for requests
session = requests.Session()
retry_strategy = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("http://", adapter)
session.mount("https://", adapter)

# Replace placeholders with actual values before using in API calls
@pytest.mark.parametrize(
    "company_id, api_credential_id, domain",
    [
        ("YOUR_COMPANY_ACCOUNT", "YOUR_API_CREDENTIAL", "https://www.eu.mystore.com")
    ],
)
def test_add_allowed_origin(company_id, api_credential_id, domain):
    url = f"{BASE_URL}/companies/{company_id}/apiCredentials/{api_credential_id}/allowedOrigins"

    # Prepare the request body
    payload = {"domain": domain}

    # Make the POST request
    response = session.post(url, json=payload)

    # Check the response status code
    assert response.status_code == 200, f"Request failed with status code {response.status_code}"

    # Optionally, you can add more assertions based on the expected response structure

if __name__ == "__main__":
    pytest.main([__file__, "-vv"])