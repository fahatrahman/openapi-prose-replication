# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_issue_edit_milestone():
    owner = "test_owner"
    repo = "test_repo"
    milestone_id = "12345"
    
    url = f"{BASE_URL}/repos/{owner}/{repo}/milestones/{milestone_id}"
    
    edit_milestone_option = {
        "description": "Test description",
        "due_on": (datetime.now() + datetime.timedelta(days=30)).isoformat(),
        "state": "active",
        "title": "Test title"
    }
    
    response = requests.patch(url, json=edit_milestone_option)
    
    assert response.status_code == 200
    
    # Assert response content type is JSON or HTML
    if 'json' in response.headers['Content-Type']:
        milestone = response.json()
        assert isinstance(milestone, dict)
        assert milestone.get('id') == int(milestone_id)
        assert milestone.get('title') == edit_milestone_option['title']
        assert milestone.get('due_on') == edit_milestone_option['due_on']
        assert milestone.get('state') == edit_milestone_option['state']
        assert milestone.get('description') == edit_milestone_option['description']
    elif 'html' in response.headers['Content-Type']:
        print(response.text)

if __name__ == "__main__":
    pytest.main([__file__])