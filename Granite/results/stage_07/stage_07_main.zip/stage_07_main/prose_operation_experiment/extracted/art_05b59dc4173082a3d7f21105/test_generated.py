import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
SESSION.mount("https://", HTTPAdapter(max_retries=3))
SESSION.mount("http://", HTTPAdapter(max_retries=3))

@pytest.fixture
def api():
    return SESSION

@pytest.mark.parametrize("recipe_id, normalize", [(69095, True)])
def test_get_recipe_taste(api, recipe_id, normalize):
    endpoint = "/recipes/{}/tasteWidget.json".format(recipe_id)
    headers = {"x-api-key": os.environ["OPENAPI_TEST_API_KEY"]}
    response = api.get(
        urljoin(BASE_URL, endpoint), headers=headers, params={"normalize": normalize}
    )

    assert response.status_code == 200, f"Received status code {response.status_code}"

    data = response.json()
    expected_keys = [
        "bitterness",
        "fattiness",
        "saltiness",
        "savoriness",
        "sourness",
        "spiciness",
        "sweetness",
    ]
    for key in expected_keys:
        assert key in data, f"{key} missing in response"