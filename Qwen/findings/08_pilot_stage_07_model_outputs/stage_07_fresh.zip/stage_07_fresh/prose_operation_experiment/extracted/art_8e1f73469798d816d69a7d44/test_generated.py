import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_report_config():
    url = f"{BASE_URL}/v1/projects/location/reportConfigs"
    headers = {
        "Content-Type": "application/json",
    }
    params = {
        "_xgafv": "2",
        "access_token": "your_access_token_here",
        "alt": "json",
        "prettyPrint": False,
        "quotaUser": "your_quota_user_here",
        "uploadType": "multipart",
        "upload_protocol": "raw",
        "reportConfigId": "your_report_config_id_here",
        "requestId": "your_request_id_here",
    }
    data = {
        "description": "Test Report Config",
        "displayName": "Test Display Name",
        "groupPreferencesetAssignments": [
            {
                "group": "group1",
                "preferenceSet": "preferenceSet1"
            },
            {
                "group": "group2",
                "preferenceSet": "preferenceSet2"
            }
        ]
    }

    response = requests.post(url, headers=headers, params=params, json=data)

    assert response.status_code == 200
    assert "Operation" in response.json()
    assert "name" in response.json()["Operation"]
    assert "response" in response.json()["Operation"]

pytest.main(["-v", __file__])