import os
import pytest
import requests
from requests_toolbelt import Headers

BASE_URL = "http://openapi.test"
HEADERS = Headers({
    'X-Amz-Algorithm': 'string',
    'X-Amz-Content-Sha256': 'sha256_hash',
    'X-Amz-Credential': 'credential_string',
    'X-Amz-Date': 'iso8601_date',
    'X-Amz-Security-Token': 'token',
    'X-Amz-Signature': 'signature',
    'X-Amz-SignedHeaders': 'signed_headers'
})

@pytest.mark.parametrize("namespace, name, max_results, next_token", [
    ("example-namespace", "example-name", 10, None),
    ("another-namespace", "another-name", 20, "next-page-token"),
])
def test_list_extension_versions(namespace, name, max_results, next_token):
    url = f"{BASE_URL}/extension/{namespace}/{name}/version"
    params = {"MaxResults": max_results}
    if next_token:
        params["NextToken"] = next_token

    response = requests.get(url, headers=HEADERS, params=params)
    assert response.status_code == 200

    # Add assertions based on the expected structure of ListExtensionVersionsResult
    result = response.json()
    assert isinstance(result, dict)
    assert "ExtensionVersions" in result
    assert isinstance(result["ExtensionVersions"], list)
    assert "NextToken" in result
