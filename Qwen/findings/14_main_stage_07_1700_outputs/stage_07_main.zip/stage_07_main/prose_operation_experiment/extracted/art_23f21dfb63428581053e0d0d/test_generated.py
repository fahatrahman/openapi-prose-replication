import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_dns_peerings():
    url = f"{BASE_URL}/v1beta1/zynntaco/example/yzvrewumc/example/vminkgxan/example/cmrSvcabkzj/example/dnsPeerings"
    params = {
        "pageSize": 50,
        "pageToken": "example_page_token",
        "$.xgafv": "1",
        "access_token": "example_access_token",
        "alt": "json",
        "callback": "example_callback",
        "fields": "example_fields",
        "key": "example_key",
        "oauth_token": "example_oauth_token",
        "prettyPrint": False,
        "quotaUser": "example_quota_user",
        "uploadType": "example_upload_type",
        "upload_protocol": "example_upload_protocol"
    }
    headers = {
        "Authorization": "Bearer example_bearer_token"
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "dnsPeerings" in response.json()
    assert "nextPageToken" in response.json()

if __name__ == "__main__":
    pytest.main()