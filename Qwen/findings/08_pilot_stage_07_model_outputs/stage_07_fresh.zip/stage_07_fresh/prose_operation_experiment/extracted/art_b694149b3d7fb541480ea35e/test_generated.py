import pytest
import requests

BASE_URL = "http://openapi.test"

def mark_played_item(user_id, item_id, date_played=None):
    url = f"{BASE_URL}/Users/{user_id}/PlayedItems/{item_id}"
    headers = {
        "X-Emby-Authorization": "your_api_key_here"
    }
    params = {}
    if date_played:
        params["datePlayed"] = date_played
    response = requests.post(url, headers=headers, params=params)
    return response

@pytest.mark.parametrize("user_id, item_id, date_played, expected_status", [
    ("user123", "item456", None, 200),
    ("user123", "item456", "2023-04-01T12:00:00Z", 200),
    ("invalid_user", "item456", None, 401),
    ("user123", "invalid_item", None, 403),
])
def test_mark_played_item(user_id, item_id, date_played, expected_status):
    response = mark_played_item(user_id, item_id, date_played)
    assert response.status_code == expected_status
    if expected_status == 200:
        assert response.json()