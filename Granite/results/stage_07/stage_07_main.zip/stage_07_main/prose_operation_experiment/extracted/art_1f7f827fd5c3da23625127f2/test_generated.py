import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.mark.parametrize("question_id,expected_status", [(123, 200), (456, 404)])
def test_published_early_day_motion_get(question_id, expected_status):
    url = f"{BASE_URL}/EarlyDayMotion/{question_id}"

    response = SESSION.get(url)
    assert response.status_code == expected_status

    if expected_status == 200:
        # Process the response based on ApiResponse_List_PublishedWrittenQuestion_ schema
        response_data = response.json()
        # Add assertions based on your expectations for the PublishedWrittenQuestion object

    elif expected_status == 404:
        # Process the response based on ApiResponse_Object_ schema
        response_data = response.json()
        # Add assertions based on your expectations for the ApiResponse_Object_ schema

    else:
        raise Exception(f"Unexpected status code: {response.status_code}")