import pytest
import requests

BASE_URL = "http://openapi.test"

def test_hooks_post():
    url = f"{BASE_URL}/hooks"
    params = {
        "action": "subscribe",
        "id": 123,
        "target_url": "http://example.com",
        "event_type": "all",
        "request_method": "POST"
    }
    headers = {
        "X-API-Key": "your_api_key_here"
    }
    response = requests.post(url, params=params, headers=headers)
    
    assert response.status_code == 200
    assert response.json().get("success") is True