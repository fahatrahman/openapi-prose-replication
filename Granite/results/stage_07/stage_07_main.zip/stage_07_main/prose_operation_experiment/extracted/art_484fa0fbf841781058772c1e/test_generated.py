import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
SESSION.mount("https://", HTTPAdapter(max_retries=3))
SESSION.mount("http://", HTTPAdapter(max_retries=3))


def get_tag_from_pay_schedule(employer_id, pay_schedule_id, tag_id):
    endpoint = f"/Employer/{employer_id}/PaySchedule/{pay_schedule_id}/Tag/{tag_id}"
    headers = {"Authorization": "Auto", "Api-Version": "default"}

    response = SESSION.get(urljoin(BASE_URL, endpoint), headers=headers)

    if response.status_code == 200:
        return response.json()
    else:
        error_model = response.json()
        raise Exception(error_model["Description"])


@pytest.mark.parametrize(
    "employer_id, pay_schedule_id, tag_id, expected_result",
    [
        ("GD001", "KFM001", "DpFoa", {"Tag": {"Text": "some tagged item", "@href": "/.../DpFoa", "@rel": "self", "@title": "Some Tag"}}),
    ],
)
def test_get_tag_from_pay_schedule(employer_id, pay_schedule_id, tag_id, expected_result):
    result = get_tag_from_pay_schedule(employer_id, pay_schedule_id, tag_id)
    assert result == expected_result