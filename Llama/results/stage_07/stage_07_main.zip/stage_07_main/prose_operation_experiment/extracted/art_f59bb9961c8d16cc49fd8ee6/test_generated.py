import pytest
import requests
from datetime import datetime
import hmac
import hashlib
import base64

BASE_URL = "http://openapi.test"

def get_amz_date():
    return datetime.utcnow().isoformat() + 'Z'

def sign_request(method, path, secret_key):
    amz_date = get_amz_date()
    payload = f"{method}\n{path}\n\n\n\n\n\n{xencode(amz_date)}\n".encode('utf-8')
    signature = hmac.new(secret_key.encode('utf-8'), payload, hashlib.sha256).digest()
    return base64.b64encode(signature)

def xencode(date_string):
    date_bytes = date_string.encode('utf-8')
    encoded = base64.b64encode(date_bytes)
    return encoded.decode('utf-8')

@pytest.fixture
def headers():
    secret_key = "your_secret_key_here"
    method = "GET"
    path = "/prod/inputDevices"
    signed_headers = "host;x-amz-date"
    algorithm = "AWS4-HMAC-SHA256"
    credential = f"AWS4 {secret_key}"
    amz_date = get_amz_date()
    date_region = f"{amz_date[:8]}0000/{amz_date[9:15]}/{amz_date[16:20]}"
    signing_key = hmac.new(secret_key.encode('utf-8'), date_region.encode('utf-8'), hashlib.sha256).digest()
    signing_key = hmac.new(signing_key, b'aws4_request', hashlib.sha256).digest()
    signature = sign_request(method, path, secret_key)
    headers = {
        "X-Amz-Algorithm": algorithm,
        "X-Amz-Credential": credential,
        "X-Amz-Date": amz_date,
        "X-Amz-Expires": 3600,
        "X-Amz-SignedHeaders": signed_headers,
        "X-Amz-Signature": signature.decode('utf-8'),
        "Host": BASE_URL.split("//")[-1]
    }
    return headers

def test_list_input_devices(headers):
    response = requests.get(BASE_URL + "/prod/inputDevices", headers=headers)
    assert response.status_code == 200