import pytest
import requests
from requests.exceptions import RequestException
BASE_URL = "http://openapi.test"

def test_authorization_code():
    endpoint = "/api/v2/AuthorizationCodes"
    url = BASE_URL + endpoint

    # Prepare the request body
    request_body = {
        "Code": "example_code",
        "CreatedByUserID": 123,
        "CreatedDate": "2022-01-01T00:00:00Z",
        "DataParameters": [
            {"Name": "param1", "Value": "value1"},
            {"Name": "param2", "Value": "value2"}
        ],
        "DefinitionID": "example_definition",
        "DeletedByUserID": None,
        "DeletedDate": None,
        "EffectiveDate": "2022-01-01T00:00:00Z",
        "ID": 1,
        "IsDeleted": False,
        "ValidationParameters": [
            {"Name": "vali_param1", "Value": "vali_value1"},
            {"Name": "vali_param2", "Value": "vali_value2"}
        ]
    }

    try:
        response = requests.post(url, json=request_body)

        # Check if the request was successful (status code 200)
        assert response.status_code == 200
        
        # If the request is successful, we expect an integer response
        response_data = response.json()
        assert isinstance(response_data, int)

    except RequestException as e:
        pytest.fail(f"Request failed: {e}")