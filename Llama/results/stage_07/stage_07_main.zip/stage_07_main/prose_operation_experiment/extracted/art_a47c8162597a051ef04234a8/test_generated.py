# pylint: disable=invalid-name, unused-import
import pytest
import requests
from datetime import timedelta
from google.protobuf.json_format import MessageToDict
from google.protobuf.duration_pb2 import Duration

BASE_URL = "http://openapi.test"

def test_create_backup_schedule():
    """Test creating a new backup schedule."""
    url = f"{BASE_URL}/v1/projects/databases/backupSchedules"
    payload = {
        "dailyRecurrence": {"time": "12:00:00"},
        "retention": str(Duration(seconds=int(timedelta(days=7).total_seconds())))
    }
    headers = {'Content-Type': 'application/json'}

    response = requests.post(url, json=payload, headers=headers)
    assert response.status_code == 200
    data = MessageToDict(response.json())
    assert data["name"]
    assert data["createTime"]
    assert data["updateTime"]

def test_create_backup_schedule_with_weekly_recurrence():
    """Test creating a new backup schedule with weekly recurrence."""
    url = f"{BASE_URL}/v1/projects/databases/backupSchedules"
    payload = {
        "weeklyRecurrence": {"day": "MONDAY", "time": "12:00:00"},
        "retention": str(Duration(seconds=int(timedelta(weeks=2).total_seconds())))
    }
    headers = {'Content-Type': 'application/json'}

    response = requests.post(url, json=payload, headers=headers)
    assert response.status_code == 200
    data = MessageToDict(response.json())
    assert data["name"]
    assert data["createTime"]
    assert data["updateTime"]