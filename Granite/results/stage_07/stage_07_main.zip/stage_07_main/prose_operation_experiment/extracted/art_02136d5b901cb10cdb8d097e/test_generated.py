import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retries
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('https://', adapter)
session.mount('http://', adapter)

# Set up authorization header
def setup_module():
    os.environ["AWS_ACCESS_KEY_ID"] = "your_access_key"
    os.environ["AWS_SECRET_ACCESS_KEY"] = "your_secret_key"
    os.environ["AWS_SESSION_TOKEN"] = "your_session_token" # if applicable

@pytest.mark.parametrize("SourceLocationName, VodSourceName", [
    ("source_location_example", "vod_source_example"),
])
def test_delete_vod_source(SourceLocationName, VodSourceName):
    url = f"{BASE_URL}/sourceLocation/{SourceLocationName}/vodSource/{VodSourceName}"

    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c85fc694e9",  # Dummy value
        "X-Amz-Date": "20220101T000000Z",  # Dummy value
        "X-Amz-Credential": "your_access_key/20220101/us-east-1/s3/aws4_request",  # Dummy value
        "X-Amz-Security-Token": "dummy_token",  # If applicable
        "X-Amz-Signature": "dummy_signature",  # Dummy value
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date",  # Dummy value
    }

    response = session.delete(url, headers=headers)

    assert response.status_code == 200