import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup retry strategy for requests
retries = Retry(
    total=5,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
adapter = HTTPAdapter(max_retries=retries)
http = requests.Session()
http.mount("https://", adapter)
http.mount("http://", adapter)
requests.adapters.default = adapter

# Set API token for authentication
API_TOKEN = os.environ.get("API_TOKEN")
headers = {"X-API-Token": API_TOKEN}

@pytest.fixture
def test_gdpr_export_hash_file():
    """Test the gdprExportHashFile operation"""
    url = f"{BASE_URL}/v0.1/apps/test/app_name/test/export/hashFiles"

    response = http.get(url, headers=headers)

    # Check if the request was successful (status code 200)
    assert response.status_code == 200

    # Parse JSON response
    data = response.json()

    # Assertions based on the expected structure
    assert isinstance(data, dict)
    assert "filename" in data
    assert "id" in data
    assert isinstance(data["filename"], str)
    assert isinstance(data["id"], str)