import pytest
import requests

BASE_URL = "http://openapi.test"

def test_erc20_post():
    address = "test_address"
    url = f"{BASE_URL}/erc20/{address}"
    response = requests.post(url)
    
    assert response.status_code == 200
    assert response.json() == {}