# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_sites():
    response = requests.get(f"{BASE_URL}/org/sites", headers={"Authorization": f"Bearer {pytest.config.getoption('access_token')}"})
    assert response.status_code == 200
    sites = response.json()
    assert isinstance(sites, list)
    for site in sites:
        assert isinstance(site, dict)
        required_keys = ["id", "name"]
        for key in required_keys:
            assert key in site

def test_get_sites_unauthorized(mocker):
    mocker.patch("requests.get")
    requests.get.return_value.status_code = 401
    response = requests.get(f"{BASE_URL}/org/sites")
    assert response.status_code == 401
    assert response.reason == "Unauthorized"