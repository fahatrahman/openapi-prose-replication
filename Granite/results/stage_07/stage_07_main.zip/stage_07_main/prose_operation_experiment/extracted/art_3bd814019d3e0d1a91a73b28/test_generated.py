import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retries for transient errors
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

@pytest.fixture
def season_teams():
    format_ = "json"  # Change as needed
    season_id = "example_season_id"  # Replace with actual value

    url = f"{BASE_URL}/{format}/SeasonTeams/{season_id}"
    
    response = session.get(url)
    response.raise_for_status()  # Raise exception for 4xx or 5xx status codes

    return response.json()["data"] if "data" in response.json() else []

def test_season_teams(season_teams):
    assert isinstance(season_teams, list)