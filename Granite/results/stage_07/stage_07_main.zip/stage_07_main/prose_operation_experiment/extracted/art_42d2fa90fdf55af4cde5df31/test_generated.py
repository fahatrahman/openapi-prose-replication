import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["GET", "OPTIONS"],
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.fixture
def server_id():
    return 1  # Replace with actual server ID

@pytest.fixture
def server_metrics(server_id):
    url = f"{BASE_URL}/servers/{server_id}/metrics"

    params = {
        "type": "cpu,disk",
        "start": "2022-01-01T00:00:00+00:00",
        "end": "2022-01-02T00:00:00+00:00",
        "step": 60,
    }

    response = SESSION.get(url, params=params)
    response.raise_for_status()

    return response.json()["metrics"]

def test_server_metrics(server_metrics):
    assert isinstance(server_metrics, dict)
    assert "start" in server_metrics
    assert "end" in server_metrics
    assert "step" in server_metrics
    assert "time_series" in server_metrics
    assert isinstance(server_metrics["time_series"], dict)