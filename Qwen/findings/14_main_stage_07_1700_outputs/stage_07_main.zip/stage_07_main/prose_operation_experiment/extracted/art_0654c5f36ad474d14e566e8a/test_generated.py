import pytest
import requests

BASE_URL = "http://openapi.test"

def test_invalidate_approval_request():
    url = f"{BASE_URL}/v1/projects/my-project/approvalRequests/my-request:invalidate"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {}
    
    response = requests.post(url, headers=headers, json=payload)
    
    assert response.status_code == 200
    assert response.json()["name"] == "my-project/approvalRequests/my-request"