import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = 'path/to/your/service_account.json'

@pytest.fixture(scope="session")
def authenticated_session():
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=['https://www.googleapis.com/auth/cloud-platform']
    )
    delegated_credentials = credentials.with_subject('primary@example.com')

    http_authorize = requests.auth.HTTPBasicAuth(*delegated_credentials.access_token_response['access_token'], ''))
    return requests.Session(), http_authorize

def test_list_adaptive_mt_files(authenticated_session):
    session, http_authorize = authenticated_session
    headers = {'Authorization': http_authorize}
    
    parent = "projects/-/-/adaptiveMtDatasets/-" # Replace with actual project, location, and dataset IDs
    params = {
        'parent': parent,
        'pageSize': 10,
        'pageToken': ''
    }

    response = session.get(f"{BASE_URL}/v3/{parent}/adaptiveMtFiles", headers=headers, params=params)

    assert response.status_code == 200
    adaptive_mt_files = response.json().get("adaptiveMtFiles")
    assert isinstance(adaptive_mt_files, list)