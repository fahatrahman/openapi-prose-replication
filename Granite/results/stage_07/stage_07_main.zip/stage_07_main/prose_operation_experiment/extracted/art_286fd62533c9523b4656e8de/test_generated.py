import os
import pytest
import requests
from googleapiclient.discovery import build

BASE_URL = "http://openapi.test"

@pytest.fixture
def content_service():
    """Build Content API service."""
    api_service_name = "content"
    api_version = "v2.1"
    api_key = os.environ.get("GOOGLE_API_KEY")

    if api_key:
        return build(api_service_name, api_version, developerKey=api_key)
    else:
        raise Exception("No GOOGLE_API_KEY found in environment variables.")

def test_retrieve_datafeed(content_service):
    """Test retrieving a datafeed configuration."""
    merchant_id = "your_merchant_id"
    datafeed_id = "your_datafeed_id"

    response = content_service.datafeeds().get(
        merchantId=merchant_id, datafeedId=datafeed_id
    ).execute()

    assert response["kind"] == "content#datafeed"
    print(f"Successfully retrieved Datafeed {datafeed_id}")
