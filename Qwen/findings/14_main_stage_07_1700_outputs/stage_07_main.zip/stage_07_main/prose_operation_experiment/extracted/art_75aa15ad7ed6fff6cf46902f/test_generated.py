import pytest
import requests

BASE_URL = "http://openapi.test"

def test_health_check():
    headers = {
        "Authorization": "Bearer <access_token>",
        "Telstra-api-version": "3.1.0"
    }
    response = requests.get(f"{BASE_URL}/health-check", headers=headers)
    
    assert response.status_code == 200
    assert response.json() == {"status": "up"}
    assert response.headers["Content-Language"] == "en-au"

@pytest.mark.parametrize("status_code, expected_error", [
    (401, {"code": "TOKEN_INVALID", "suggested_action": "Check the access token."}),
    (402, {"code": "ACCOUNT_ERR", "suggested_action": "Contact telstradev@team.telstra.com for help with your account."}),
    (403, {"code": "RESOURCE_AUTH_ERR", "suggested_action": "Check the permissions associated with your account."}),
    (404, {"code": "RESOURCE_TEMP_ERR", "suggested_action": "Check the API status page to see if an active incident is causing a temporary issue with the resource."}),
    (405, {"code": "METHOD_INVALID", "suggested_action": "Ensure the method is GET."}),
    (429, {"code": "TOO_MANY_REQUESTS", "suggested_action": "Reduce the number of concurrent calls."}),
    (500, {"code": "INTERNAL_TIMEOUT", "suggested_action": "Try the call again. If the issue persists, check the API status page to see if there's an active incident."}),
    (504, {"code": "GATEWAY_TIMEOUT", "suggested_action": "The service is temporarily down. Check the API Live Status page or contact support."})
])
def test_health_check_errors(status_code, expected_error):
    headers = {
        "Authorization": "Bearer <access_token>",
        "Telstra-api-version": "3.1.0"
    }
    response = requests.get(f"{BASE_URL}/health-check?error={status_code}", headers=headers)
    
    assert response.status_code == status_code
    assert response.json()["errors"][0] == expected_error
    assert response.headers["Content-Language"] == "en-au"