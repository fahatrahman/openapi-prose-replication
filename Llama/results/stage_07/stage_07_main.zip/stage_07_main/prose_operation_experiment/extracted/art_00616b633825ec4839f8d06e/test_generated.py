# -*- coding: utf-8 -*-

import pytest
import json
import requests

BASE_URL = "http://openapi.test"

def test_get_trailer_remote_search_results():
    url = f"{BASE_URL}/Items/RemoteSearch/Trailer"
    headers = {"X-Emby-Authorization": "Your Custom Authentication Token"}
    
    query = {
        "IncludeDisabledProviders": False,
        "ItemId": "your_item_id",
        "SearchInfo": {
            "IndexNumber": None,
            "IsAutomated": False,
            "MetadataCountryCode": None,
            "MetadataLanguage": None,
            "Name": None,
            "ParentIndexNumber": None,
            "Path": None,
            "PremiereDate": None,
            "ProviderIds": {},
            "Year": None
        },
        "SearchProviderName": "Your Search Provider Name"
    }
    
    response = requests.post(url, headers=headers, json=query)
    
    assert response.status_code == 200
    
    try:
        results = response.json()
        
        for result in results:
            assert isinstance(result, dict)
            
            required_keys = ["AlbumArtist", "Artists", "ImageUrl", "IndexNumber", "IndexNumberEnd", "Name", "Overview", "ParentIndexNumber", "PremiereDate", "ProductionYear", "ProviderIds", "SearchProviderName"]
            for key in required_keys:
                assert key in result
        
        # Add assertions for specific keys if necessary
    except json.JSONDecodeError:
        assert False, "Invalid JSON response"