import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_api():
    url = f"{BASE_URL}/apis/owner/api"
    headers = {
        "Authorization": "Bearer your_access_token_here"
    }
    response = requests.delete(url, headers=headers)
    
    assert response.status_code == 200
    assert isinstance(response.json(), list)

if __name__ == "__main__":
    pytest.main()