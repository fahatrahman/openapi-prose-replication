import pytest
import requests

BASE_URL = "http://openapi.test"

def test_update_cluster():
    url = f"{BASE_URL}/v2/projects/{project}/instances/{instance}/clusters/{cluster}"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    payload = {
        "cluster": {
            "name": f"projects/{project}/instances/{instance}/clusters/{cluster}",
            "serveNodes": 5,
            "clusterConfig": {
                "clusterAutoscalingConfig": {
                    "autoscalingLimits": {
                        "maxServeNodes": 10,
                        "minServeNodes": 2
                    },
                    "autoscalingTargets": {
                        "cpuUtilizationPercent": 70,
                        "storageUtilizationGibPerNode": 4096
                    }
                }
            }
        }
    }
    response = requests.put(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert response.json()["done"]