import pytest
import requests

BASE_URL = "http://openapi.test"

def test_cancel_operation():
    url = f"{BASE_URL}/v1/projects/locations/operations/cancel"
    params = {
        "_xgafv": "1",
        "access_token": "test_access_token",
        "alt": "json",
        "callback": "test_callback",
        "fields": "test_fields",
        "key": "test_key",
        "oauth_token": "test_oauth_token",
        "prettyPrint": False,
        "quotaUser": "test_quota_user",
        "uploadType": "test_upload_type",
        "upload_protocol": "test_upload_protocol",
        "name": "test_name"
    }
    headers = {
        "Authorization": "Bearer test_bearer_token"
    }
    response = requests.post(url, json={}, params=params, headers=headers)
    assert response.status_code == 200
    assert response.json() == {}