# -*- coding: utf-8 -*-
"""Tests for Operation slice."""
import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_symptom():
    """Test getSymptom operation."""
    # Given
    symptom_id = "some_id"
    params = {
        "age.value": 18,
        "age.unit": "year",
        "enable_triage_5": True
    }

    # When
    response = requests.get(
        f"{BASE_URL}/symptoms/{symptom_id}",
        params=params
    )

    # Then
    assert response.status_code == 200
    response.raise_for_status()
    assert response.json()["category"]
    assert response.json()["children"]
    assert response.json()["common_name"]
    assert response.json()["extras"]
    assert response.json()["id"] == symptom_id
    assert response.json()["image_source"]
    assert response.json()["image_url"]
    assert response.json()["name"]
    assert response.json()["parent_id"]
    assert response.json()["parent_relation"]
    assert response.json()["question"]
    assert response.json()["sex_filter"]

def test_get_symptom_invalid_id():
    """Test getSymptom operation with invalid id."""
    # Given
    symptom_id = "invalid_id"
    params = {
        "age.value": 18,
        "age.unit": "year",
        "enable_triage_5": True
    }

    # When
    response = requests.get(
        f"{BASE_URL}/symptoms/{symptom_id}",
        params=params
    )

    # Then
    assert response.status_code == 400

def test_get_symptom_not_found():
    """Test getSymptom operation with non-existent id."""
    # Given
    symptom_id = "non_existent_id"
    params = {
        "age.value": 18,
        "age.unit": "year",
        "enable_triage_5": True
    }

    # When
    response = requests.get(
        f"{BASE_URL}/symptoms/{symptom_id}",
        params=params
    )

    # Then
    assert response.status_code == 404