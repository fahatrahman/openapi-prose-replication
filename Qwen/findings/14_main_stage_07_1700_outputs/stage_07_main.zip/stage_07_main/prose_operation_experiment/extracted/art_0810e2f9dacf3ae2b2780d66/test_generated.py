import pytest
import requests

BASE_URL = "http://openapi.test"

def test_validate_attestation_occurrence():
    url = f"{BASE_URL}/v1beta1/projects/my-project/attestors/my-attempt:validateAttestationOccurrence"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    payload = {
        "attestation": {
            "jwts": [
                {
                    "compactJwt": "YOUR_COMPACT_JWT"
                }
            ],
            "serializedPayload": "YOUR_SERIALIZED_PAYLOAD",
            "signatures": [
                {
                    "publicKeyId": "YOUR_PUBLIC_KEY_ID",
                    "signature": "YOUR_SIGNATURE"
                }
            ]
        },
        "occurrenceNote": "NOTE_NAME",
        "occurrenceResourceUri": "RESOURCE_URI"
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert response.json()["result"] in ["RESULT_UNSPECIFIED", "VERIFIED", "ATTESTATION_NOT_VERIFIABLE"]