import pytest
import requests
from urllib.parse import urlencode

BASE_URL = "http://openapi.test"

def test_synthesize_speech():
    url = f"{BASE_URL}/v1/speech"
    
    headers = {
        'X-Amz-Algorithm': '',
        'X-Amz-Content-Sha256': '',
        'X-Amz-Credential': '',
        'X-Amz-Date': '',
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': '',
        'X-Amz-SignedHeaders': ''
    }

    params = {}

    body = {
        "Engine": "standard",
        "LanguageCode": "en-US",
        "LexiconNames": [],
        "OutputFormat": "mp3",
        "SampleRate": "22050",
        "SpeechMarkTypes": [],
        "Text": "Hello world!",
        "TextType": "text",
        "VoiceId": "Aditi"
    }

    response = requests.post(url, headers=headers, params=params, json=body)

    assert response.status_code == 200
    print(response.json())

def test_synthesize_speech_with_invalid_sample_rate():
    url = f"{BASE_URL}/v1/speech"
    
    headers = {
        'X-Amz-Algorithm': '',
        'X-Amz-Content-Sha256': '',
        'X-Amz-Credential': '',
        'X-Amz-Date': '',
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': '',
        'X-Amz-SignedHeaders': ''
    }

    params = {}

    body = {
        "Engine": "standard",
        "LanguageCode": "en-US",
        "LexiconNames": [],
        "OutputFormat": "mp3",
        "SampleRate": "10000", # Invalid sample rate
        "SpeechMarkTypes": [],
        "Text": "Hello world!",
        "TextType": "text",
        "VoiceId": "Aditi"
    }

    response = requests.post(url, headers=headers, params=params, json=body)

    assert response.status_code == 481
    print(response.json())