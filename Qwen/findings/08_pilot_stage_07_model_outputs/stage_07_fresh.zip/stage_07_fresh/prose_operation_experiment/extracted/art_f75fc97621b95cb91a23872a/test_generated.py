import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_holiday_schemes_with_tag():
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    params = {
        "EmployerId": "GD001",
        "TagId": "DpFoa"
    }
    response = requests.get(f"{BASE_URL}/Employer/{params['EmployerId']}/HolidaySchemes/Tag/{params['TagId']}", headers=headers)
    
    assert response.status_code == 200
    assert response.headers["Content-Type"] == "application/json"
    assert "LinkCollection" in response.json()

def test_get_holiday_schemes_with_tag_400():
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    params = {
        "EmployerId": "invalid_id",
        "TagId": "DpFoa"
    }
    response = requests.get(f"{BASE_URL}/Employer/{params['EmployerId']}/HolidaySchemes/Tag/{params['TagId']}", headers=headers)
    
    assert response.status_code == 400
    assert response.headers["Content-Type"] == "application/json"
    assert "ErrorModel" in response.json()
    assert response.json()["ErrorModel"]["ErrorCategory"] == "ValidationFailure"

def test_get_holiday_schemes_with_tag_401():
    headers = {
        "Authorization": "InvalidToken",
        "Api-Version": "default"
    }
    params = {
        "EmployerId": "GD001",
        "TagId": "DpFoa"
    }
    response = requests.get(f"{BASE_URL}/Employer/{params['EmployerId']}/HolidaySchemes/Tag/{params['TagId']}", headers=headers)
    
    assert response.status_code == 401
    assert response.headers["Content-Type"] == "application/json"
    assert "ErrorModel" in response.json()
    assert response.json()["ErrorModel"]["ErrorCategory"] == "NotAuthorised"

def test_get_holiday_schemes_with_tag_404():
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    params = {
        "EmployerId": "NonExistentId",
        "TagId": "DpFoa"
    }
    response = requests.get(f"{BASE_URL}/Employer/{params['EmployerId']}/HolidaySchemes/Tag/{params['TagId']}", headers=headers)
    
    assert response.status_code == 404
    assert response.headers["Content-Type"] == "application/json"
    assert "ErrorModel" in response.json()
    assert response.json()["ErrorModel"]["ErrorCategory"] == "NotFound"

def test_get_holiday_schemes_with_tag_500():
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    params = {
        "EmployerId": "ServerFaultId",
        "TagId": "DpFoa"
    }
    response = requests.get(f"{BASE_URL}/Employer/{params['EmployerId']}/HolidaySchemes/Tag/{params['TagId']}", headers=headers)
    
    assert response.status_code == 500
    assert response.headers["Content-Type"] == "application/json"
    assert "ErrorModel" in response.json()
    assert response.json()["ErrorModel"]["ErrorCategory"] == "General"