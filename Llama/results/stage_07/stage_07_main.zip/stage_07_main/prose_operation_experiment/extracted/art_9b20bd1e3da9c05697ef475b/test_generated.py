# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime
from typing import Dict, Any

BASE_URL = "http://openapi.test"

def test_get_ticket_messages():
    """Test GET /ticket/{ticketId}/messages"""
    
    # Given
    ticket_id = "12345"
    authorization_token = "your_authorization_token"
    offset = 0
    limit = 10
    
    url = f"{BASE_URL}/ticket/{ticket_id}/messages"
    headers = {"Authorization": authorization_token}
    params = {"offset": offset, "limit": limit}
    
    # When
    response = requests.get(url, headers=headers, params=params)
    
    # Then
    assert response.status_code == 200, response.text
    
    try:
        get_ticket_messages_response = response.json()
        
        assert isinstance(get_ticket_messages_response, dict), type(get_ticket_messages_response)
        assert 'messages' in get_ticket_messages_response.keys(), get_ticket_messages_response.keys()
        assert 'metadata' in get_ticket_messages_response.keys(), get_ticket_messages_response.keys()
        
        for message in get_ticket_messages_response['messages']:
            assert isinstance(message, dict), type(message)
            assert 'body' in message.keys(), message.keys()
            assert 'createdAt' in message.keys(), message.keys()
            assert 'id' in message.keys(), message.keys()
            assert 'visibility' in message.keys(), message.keys()
            
            assert isinstance(message['body'], str), type(message['body'])
            assert isinstance(message['createdAt'], str), type(message['createdAt'])
            assert isinstance(message['id'], str), type(message['id'])
            assert isinstance(message['visibility'], str), type(message['visibility'])
            
            created_at = datetime.fromisoformat(message['createdAt'].replace('Z', '+00:00'))
            assert created_at.tzinfo is not None, created_at.tzinfo
            
        for metadata in get_ticket_messages_response['metadata']:
            assert isinstance(metadata, dict), type(metadata)
            assert 'key' in metadata.keys(), metadata.keys()
            assert 'value' in metadata.keys(), metadata.keys()
            
            assert isinstance(metadata['key'], str), type(metadata['key'])
            assert isinstance(metadata['value'], str), type(metadata['value'])
            
    except AssertionError as e:
        print(f"Assertion failed: {e}")
        raise
        
@pytest.mark.parametrize("invalid_offset", [-1, -100])
def test_get_ticket_messages_invalid_offset(invalid_offset):
    """Test GET /ticket/{ticketId}/messages with invalid offset"""
    
    # Given
    ticket_id = "12345"
    authorization_token = "your_authorization_token"
    offset = invalid_offset
    limit = 10
    
    url = f"{BASE_URL}/ticket/{ticket_id}/messages"
    headers = {"Authorization": authorization_token}
    params = {"offset": offset, "limit": limit}
    
    # When
    response = requests.get(url, headers=headers, params=params)
    
    # Then
    assert response.status_code == 400, response.text

@pytest.mark.parametrize("invalid_limit", [0, 101])
def test_get_ticket_messages_invalid_limit(invalid_limit):
    """Test GET /ticket/{ticketId}/messages with invalid limit"""
    
    # Given
    ticket_id = "12345"
    authorization_token = "your_authorization_token"
    offset = 0
    limit = invalid_limit
    
    url = f"{BASE_URL}/ticket/{ticket_id}/messages"
    headers = {"Authorization": authorization_token}
    params = {"offset": offset, "limit": limit}
    
    # When
    response = requests.get(url, headers=headers, params=params)
    
    # Then
    assert response.status_code == 400, response.text

@pytest.mark.parametrize("missing_authorization_header", [{"headers": {}, "expected_status_code": 401},
                                                         {"headers": {"Authorization": ""}, "expected_status_code": 401}])
def test_get_ticket_messages_missing_authorization_header(missing_authorization_header):
    """Test GET /ticket/{ticketId}/messages without authorization header"""
    
    # Given
    ticket_id = "12345"
    authorization_token = missing_authorization_header["headers"].get("Authorization")
    offset = 0
    limit = 10
    
    url = f"{BASE_URL}/ticket/{ticket_id}/messages"
    headers = missing_authorization_header["headers"]
    params = {"offset": offset, "limit": limit}
    
    # When
    response = requests.get(url, headers=headers, params=params)
    
    # Then
    assert response.status_code == missing_authorization_header["expected_status_code"], response.text

@pytest.mark.parametrize("invalid_ticket_id", ["invalid_ticket_id"])
def test_get_ticket_messages_invalid_ticket_id(invalid_ticket_id):
    """Test GET /ticket/{ticketId}/messages with invalid ticket id"""
    
    # Given
    ticket_id = invalid_ticket_id
    authorization_token = "your_authorization_token"
    offset = 0
    limit = 10
    
    url = f"{BASE_URL}/ticket/{ticket_id}/messages"
    headers = {"Authorization": authorization_token}
    params = {"offset": offset, "limit": limit}
    
    # When
    response = requests.get(url, headers=headers, params=params)
    
    # Then
    assert response.status_code == 403, response.text