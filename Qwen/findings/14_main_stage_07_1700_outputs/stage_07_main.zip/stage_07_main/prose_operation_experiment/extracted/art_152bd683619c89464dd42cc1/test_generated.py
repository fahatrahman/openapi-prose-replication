import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_locations():
    url = f"{BASE_URL}/v1beta1/projects/-/locations"
    params = {
        "filter": "displayName=tokyo",
        "pageSize": 10,
        "pageToken": None
    }
    headers = {
        "Authorization": "Bearer YOUR_OAUTH_TOKEN"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    assert "locations" in response.json()
    assert isinstance(response.json()["locations"], list)

if __name__ == "__main__":
    pytest.main([__file__])