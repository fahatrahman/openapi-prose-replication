import os
import requests
import pytest

BASE_URL = "http://openapi.test"

@pytest.fixture
def client():
    return requests.Session()

def test_erc20_get(client):
    url = f"{BASE_URL}/erc20"
    response = client.get(url)

    assert response.status_code == 200
    assert response.json() == {}