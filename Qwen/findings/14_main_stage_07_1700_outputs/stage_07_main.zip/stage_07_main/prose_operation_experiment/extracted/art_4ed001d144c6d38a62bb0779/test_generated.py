import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_gateways():
    url = f"{BASE_URL}/v1/zynntaco/yzvrewumc/gateways"
    params = {
        "pageSize": 1,
        "pageToken": ""
    }
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert "gateways" in data
    assert isinstance(data["gateways"], list)

if __name__ == "__main__":
    pytest.main([__file__])