import pytest
import requests

BASE_URL = "http://openapi.test"

def test_search_detailed_lead_reports():
    url = f"{BASE_URL}/v1/detailedLeadReports:search"
    params = {
        "endDate.day": 31,
        "endDate.month": 12,
        "endDate.year": 2023,
        "pageSize": 1000,
        "query": "manager_customer_id:123",
        "startDate.day": 1,
        "startDate.month": 1,
        "startDate.year": 2023
    }
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    assert "detailedLeadReports" in response.json()