import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_listing_extra_attributes():
    api_key = "your_api_key_here"
    listing_id = "your_listing_id_here"
    headers = {
        "Authorization": f"Basic {api_key}"
    }
    url = f"{BASE_URL}/listing/car/{listing_id}/extra"
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert "ListingExtraAttributes" in response.json()
    assert isinstance(response.json()["ListingExtraAttributes"], dict)

if __name__ == "__main__":
    pytest.main()