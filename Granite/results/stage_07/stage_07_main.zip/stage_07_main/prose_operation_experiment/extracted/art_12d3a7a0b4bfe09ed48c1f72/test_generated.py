import os
import pytest
import requests
from requests_toolbelt import Headers

BASE_URL = "http://openapi.test"

@pytest.fixture
def auth():
    return Headers({
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": os.environ["AWS_ACCESS_KEY_ID"] + "/"os.environ["AWS_SECRET_ACCESS_KEY"],
        "X-Amz-Date": os.environ["AWS_DATE_FORMAT"].format(
            datetime.datetime.utcnow()),
        "X-Amz-Expires": "900",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256",
        "X-Amz-SignatureMethod": "HmacSHA256"
    })

def test_list_custom_data_identifiers(auth):
    url = f"{BASE_URL}/custom-data-identifiers/list"

    # Define the request body
    body = {
        "maxResults": "10",
        "nextToken": "token_example"
    }

    response = requests.post(url, headers=auth, json=body)

    assert response.status_code == 200