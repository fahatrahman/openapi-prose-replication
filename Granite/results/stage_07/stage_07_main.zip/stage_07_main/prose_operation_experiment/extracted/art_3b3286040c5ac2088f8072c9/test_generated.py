import pytest
import requests
BASE_URL = "http://openapi.test"

@pytest.fixture
def case_type_groups():
    url = f"{BASE_URL}/masterData/caseTypeGroup"

    # Test GET request for successful response
    def get_successful_response():
        response = requests.get(url, params={"q": "caseTypeGroupId: 'CTYGSpWaVityBQndsv'"})
        assert response.status_code == 200

        data = response.json()
        assert data["object"] == "CaseTypeGroupResponse"
        assert len(data["caseTypeGroupArray"]) == 1
        assert data["caseTypeGroupArray"][0]["name"] == "Tax and Revenue"

    yield get_successful_response

    # Test GET request for invalid input query
    def get_invalid_input_query():
        response = requests.get(url, params={"q": "caseTypeGrouId: 'CTYGSpWaVityBQndsv'"})
        assert response.status_code == 400
        data = response.json()
        assert data["object"] == "Exception"
        assert data["code"] == "UN400"
        assert data["message"] == "INVALID_INPUT"

    yield get_invalid_input_query

    # Test GET request for internal server error
    def get_internal_server_error():
        # Simulate an error by sending a malformed request
        response = requests.get(url, params={"q": "malformed_request"})
        assert response.status_code == 500
        data = response.json()
        assert data["object"] == "Exception"
        assert data["code"] == "UN500"
        assert data["message"] == "INTERNAL_SERVER_ERROR"

    yield get_internal_server_error