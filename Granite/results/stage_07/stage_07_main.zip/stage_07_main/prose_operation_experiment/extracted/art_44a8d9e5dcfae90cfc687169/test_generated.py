import pytest
import requests
from requests.exceptions import RequestException

BASE_URL = "http://openapi.test"

@pytest.fixture
def headers():
    return {"Content-Type": "application/json"}

@pytest.mark.parametrize("provider, external_id, application", [
    ("messenger", "page_id", "applicationId"),
    ("viber_service_msg", "viber_id", "applicationId"),
    ("whatsapp", "whatsapp_number", "applicationId"),
])
def test_link_application(provider, external_id, application):
    url = f"{BASE_URL}/{provider}/{external_id}/applications"

    payload = {
        "application": application
    }

    response = requests.post(url, headers=headers, json=payload)

    if response.status_code == 200:
        assert response.json()["provider"] == provider
        assert response.json()["api_key"] != ""
        assert response.json()["external_id"] == external_id
    elif response.status_code == 401:
        assert response.json()["title"] == "Unauthorised"
        assert response.json()["detail"] == "Request header 'Authorization' missing / Invalid Token"
    elif response.status_code == 403:
        assert response.json()["title"] == "Forbidden"
        assert response.json()["detail"] == "Cannot link application"
    elif response.status_code == 409:
        assert response.json()["title"] == "Application conflict"
        assert response.json()["detail"] == "Unable to link application"
    else:
        raise AssertionError(f"Unexpected status code: {response.status_code}")