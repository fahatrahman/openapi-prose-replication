import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retry logic for handling transient errors
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["HEAD", "GET", "OPTIONS", "PUT", "PATCH", "DELETE"],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def defend_dispute_data():
    return {
        "defenseReasonCode": "SupplyDefenseMaterial",
        "disputePspReference": "DZ4DPSHB4WD2WN82",
        "merchantAccountCode": "YOUR_MERCHANT_ACCOUNT",
    }

@pytest.mark.parametrize("data", [defend_dispute_data])
def test_defend_dispute(data):
    url = f"{BASE_URL}/defendDispute"

    response = session.post(url, json=data)
    
    assert response.status_code == 200, f"Expected status code 200, got {response.status_code}"
    assert response.json()["disputeServiceResult"]["success"] is True, "Defend dispute failed"