import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_authorization_policy():
    url = f"{BASE_URL}/v1/projects/{your_project_id}/locations/{your_location}/authorizationPolicies"
    params = {
        "authorizationPolicyId": "test-authz-policy",
        "$.xgafv": "2",
        "access_token": "your_access_token",
        "alt": "json",
        "callback": "your_callback",
        "fields": "name,createTime,updateTime",
        "key": "your_api_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": False,
        "quotaUser": "your_quota_user",
        "uploadProtocol": "raw",
        "uploadType": "multipart"
    }
    headers = {
        "Content-Type": "application/json"
    }
    payload = {
        "action": "ALLOW",
        "description": "Test authorization policy",
        "name": "projects/{your_project_id}/locations/{your_location}/authorizationPolicies/test-authz-policy",
        "rules": [
            {
                "destinations": [
                    {
                        "hosts": ["example.com"],
                        "ports": [80]
                    }
                ],
                "sources": [
                    {
                        "ipBlocks": ["0.0.0.0/0"]
                    }
                ]
            }
        ]
    }

    response = requests.post(url, headers=headers, json=payload, params=params)
    assert response.status_code == 200
    assert response.json().get("name") == "projects/{your_project_id}/locations/{your_location}/authorizationPolicies/test-authz-policy"