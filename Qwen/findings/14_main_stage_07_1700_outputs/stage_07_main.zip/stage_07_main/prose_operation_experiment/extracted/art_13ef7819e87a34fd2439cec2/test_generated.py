import pytest
import requests

BASE_URL = "http://openapi.test"

def test_retrieve_target_site(target_id):
    url = f"{BASE_URL}/targets/{target_id}/site/"
    headers = {
        "Authorization": "Bearer YOUR_JWT_TOKEN"
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert "site" in response.json()