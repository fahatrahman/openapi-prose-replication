import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_group():
    url = f"{BASE_URL}/admin/directory/v1/groups/group@example.com"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token",
        "alt": "json",
        "callback": "your_callback",
        "fields": "id,name,email",
        "key": "your_api_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": False,
        "quotaUser": "your_quota_user",
        "uploadType": "media",
        "upload_protocol": "raw"
    }
    headers = {
        "Authorization": "Bearer your_access_token"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    assert 'id' in response.json()
    assert 'name' in response.json()
    assert 'email' in response.json()

if __name__ == "__main__":
    pytest.main()