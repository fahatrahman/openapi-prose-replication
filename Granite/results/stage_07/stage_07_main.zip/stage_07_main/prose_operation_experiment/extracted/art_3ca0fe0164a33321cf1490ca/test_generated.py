import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retry logic
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("http://", adapter)
session.mount("https://", adapter)

@pytest.fixture()
def health_check():
    headers = {"Accept-Language": "en-US"}
    response = session.get(f"{BASE_URL}/health/check", headers=headers)
    response.raise_for_status()
    return response.json()

def test_health_check_success(health_check):
    assert health_check["allGood"] is True
    assert health_check["capiOk"] is True
    assert health_check["dbOk"] is True
    assert health_check["memcachedOk"] is True
    assert health_check["message"] == "Viator API is operational."