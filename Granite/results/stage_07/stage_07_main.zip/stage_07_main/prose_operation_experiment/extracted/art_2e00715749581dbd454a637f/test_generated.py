import os
import pytest
import requests
from googleapiclient.discovery import build

BASE_URL = "http://openapi.test"

@pytest.fixture
def dfa_service():
    api_service_name = "dfareporting"
    api_version = "v3"

    credentials = None
    if "GOOGLE_APPLICATION_CREDENTIALS" in os.environ:
        credentials = os.environ["GOOGLE_APPLICATION_CREDENTIALS"]

    http_auth = None
    if credentials:
        http_auth = (
            "Bearer",
            requests.utils.dict_from_cookiejar(
                requests.cookies.request_cookie_jar(credentials)
            )["Authorization"]
            .split(" ")[1]
        )

    service = build(api_service_name, api_version, credentials=credentials, host=BASE_URL)
    return service

def test_list_dynamic_targeting_keys(dfa_service):
    profile_id = "your_profile_id"  # replace with actual profile ID
    request = dfa_service.dynamicTargetingKeys().list(profileId=profile_id)

    response = request.execute()
    assert isinstance(response, dict)
    assert "dynamicTargetingKeys" in response
    assert "kind" in response