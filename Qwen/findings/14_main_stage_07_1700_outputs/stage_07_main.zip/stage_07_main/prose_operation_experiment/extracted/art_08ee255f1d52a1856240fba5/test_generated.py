import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_product_modules():
    url = f"{BASE_URL}/productmodule"
    headers = {
        "Authorization": "Basic dXNlcm5hbWU6cGFzc3dvcmQ="  # Replace with actual credentials
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert isinstance(response.json(), list)

if __name__ == "__main__":
    pytest.main()