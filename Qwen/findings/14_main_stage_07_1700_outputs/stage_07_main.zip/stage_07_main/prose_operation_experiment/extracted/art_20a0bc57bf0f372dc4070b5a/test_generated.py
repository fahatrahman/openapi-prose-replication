import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def api_client():
    def client(operation_id, **kwargs):
        url = f"{BASE_URL}/designer/templates"
        headers = {
            "x-api-key": "your_api_key_here"  # Replace with actual API key
        }
        response = requests.get(url, headers=headers, params=kwargs)
        return response.json()
    return client

def test_list_templates(api_client):
    response = api_client("list_templates_designer_templates_get", limit=10, offset=0)
    assert response["status"] == "success"
    assert isinstance(response["data"]["results"], list)

if __name__ == "__main__":
    pytest.main()