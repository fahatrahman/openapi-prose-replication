import pytest
import requests
from urllib.parse import urlencode

BASE_URL = "http://openapi.test"

def test_placements_generatetags():
    url = f"{BASE_URL}/userprofiles/{profile_id}/placements/generatetags"
    params = {
        "campaignId": "test_campaign",
        "placementIds": ["test_placement"],
        "tagFormats": ["PLACEMENT_TAG_STANDARD"]
    }
    headers = {}
    
    response = requests.post(url, headers=headers, params=urlencode(params))
    assert response.status_code == 200
    
    response_json = response.json()
    assert "kind" in response_json
    assert "placementTags" in response_json
    
    # Test that each placement has at least one tag
    for placement_tag in response_json["placementTags"]:
        assert len(placement_tag["tagDatas"]) >= 1
        
    # Test that each tag has a valid format
    for placement_tag in response_json["placementTags"]:
        for tag_data in placement_tag["tagDatas"]:
            assert tag_data["format"] in ["PLACEMENT_TAG_STANDARD", "PLACEMENT_TAG_IFRAME_JAVASCRIPT", "PLACEMENT_TAG_IFRAME_ILAYER", "PLACEMENT_TAG_INTERNAL_REDIRECT", "PLACEMENT_TAG_JAVASCRIPT", "PLACEMENT_TAG_INTERSTITIAL_IFRAME_JAVASCRIPT", "PLACEMENT_TAG_INTERSTITIAL_INTERNAL_REDIRECT", "PLACEMENT_TAG_INTERSTITIAL_JAVASCRIPT", "PLACEMENT_TAG_CLICK_COMMANDS", "PLACEMENT_TAG_INSTREAM_VIDEO_PREFETCH", "PLACEMENT_TAG_TRACKING", "PLACEMENT_TAG_TRACKING_IFRAME", "PLACEMENT_TAG_TRACKING_JAVASCRIPT", "PLACEMENT_TAG_INSTREAM_VIDEO_PREFETCH_VAST_3", "PLACEMENT_TAG_IFRAME_JAVASCRIPT_LEGACY", "PLACEMENT_TAG_JAVASCRIPT_LEGACY", "PLACEMENT_TAG_INTERSTITIAL_IFRAME_JAVASCRIPT_LEGACY", "PLACEMENT_TAG_INTERSTITIAL_JAVASCRIPT_LEGACY", "PLACEMENT_TAG_INSTREAM_VIDEO_PREFETCH_VAST_4", "PLACEMENT_TAG_TRACKING_THIRD_PARTY_MEASUREMENT"]

def test_placements_generatetags_negative():
    url = f"{BASE_URL}/userprofiles/{profile_id}/placements/generatetags"
    params = {
        "campaignId": "test_campaign",
        "placementIds": [],
        "tagFormats": []
    }
    headers = {}
    
    response = requests.post(url, headers=headers, params=urlencode(params))
    assert response.status_code != 200
    
    response.raise_for_status()

@pytest.fixture
def profile_id():
    return "test_profile"