import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Define retry strategy for handling server errors
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
http = requests.Session()
http.mount("https://", adapter)
http.mount("http://", adapter)

@pytest.fixture
def compile_response():
    url = f"{BASE_URL}/v1/compile"

    payload = {
        "ffnqw": "stzf.gppajug.mfbmr == vbnu",
        "qocqi": {"msatlzk": {"johzwuchy_awkwn": 4}},
        "reuirpsf": ["stzf.tflackw"],
    }
    
    response = http.post(url, json=payload)
    assert response.status_code == 200, f"Unexpected status code: {response.status_code}"
    
    return response.json()

def test_compile_response(compile_response):
    result = compile_response["result"]
    explanation = compile_response["explanations"][0]["locals"]
    metrics = compile_response["metrics"]

    # Add assertions here based on expected values from the OpenAPI description
    assert len(result) > 0, "Expected at least one rule in the result"
    assert all(isinstance(r, dict) for r in result), "Each item in 'result' should be a dictionary"
    assert "package" in result[0], "Each rule's 'package' field should exist"
    assert "rules" in result[0], "Each rule's 'rules' field should exist"
    assert isinstance(explanation, list), "Explanation should be a list of locals"
    assert all(isinstance(local, dict) for local in explanation), "Each local should be a dictionary"
    assert "type" in explanation[0], "Each local should have a 'type' field"
    assert all(isinstance(metric, int) for metric in metrics.values()), "All metrics should be integers"