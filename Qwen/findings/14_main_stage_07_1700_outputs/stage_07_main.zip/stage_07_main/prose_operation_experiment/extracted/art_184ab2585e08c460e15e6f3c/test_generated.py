import pytest
import requests

BASE_URL = "http://openapi.test"

def test_purge_user_events():
    url = f"{BASE_URL}/v2beta/projects/your-project-id/locations/global/catalogs/your-catalog-id/userEvents:purge"
    headers = {
        "Authorization": "Bearer your-access-token",
        "Content-Type": "application/json"
    }
    payload = {
        "filter": "eventType = \"detail-page-view\"",
        "force": True
    }
    response = requests.post(url, headers=headers, json=payload)
    
    assert response.status_code == 200
    assert response.json().get("done") is True