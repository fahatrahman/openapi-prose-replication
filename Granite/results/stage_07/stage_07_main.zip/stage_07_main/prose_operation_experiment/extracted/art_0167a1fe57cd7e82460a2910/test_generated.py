import os
import requests
import pytest

BASE_URL = "http://openapi.test"

@pytest.fixture
def cisco_switches():
    url = f"{BASE_URL}/data-sources/cisco-switches"
    headers = {"Authorization": "GNA Brx - KqwbwovSppsxlo {yiuso}"}  # Replace placeholder value

    response = requests.get(url, headers=headers)
    response.raise_for_status()

    return response.json()

def test_list_cisco_switches(cisco_switches):
    assert isinstance(cisco_switches, dict)
    assert "results" in cisco_switches
    assert "total_count" in cisco_switches
    assert isinstance(cisco_switches["results"], list)
    for item in cisco_switches["results"]:
        assert isinstance(item, dict)
        assert "entity_id" in item
        assert "entity_type" in item