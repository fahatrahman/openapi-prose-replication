from __future__ import annotations

from pathlib import Path
import base64
import ctypes.util
import importlib.metadata
import re
import sysconfig
import json
import os
import platform
import resource
import selectors
import shutil
import signal
import socket
import socketserver
import types
import subprocess
import sys
import tempfile
import threading
import time

from routing import (
    normalize_prepared_request,
    classify_request,
    select_frozen_response,
    prepare_frozen_response,
    UnsupportedRoute,
    EvaluatorUnavailable,
    EvaluatorDefect,
)


WORKER_VERSION = "stage06-main-worker-v12-excluded-request-evidence"
REPLAY_TARGET_POLICY = "first_delivered_request_in_passing_item"


# This is the trusted entry script executed INSIDE the sandbox.
# It is deliberately separate from generated test source.
SANDBOX_BOOTSTRAP = r'''
import base64
import ctypes
import ctypes.util
import importlib.metadata
import re
import sysconfig
import errno
import json
import os
import socket
import sys
import sysconfig

# Python -S prevents all host/user site hooks. Add only the packaged site root.
site_path = sysconfig.get_path("purelib")
version_dir = "python%d.%d" % sys.version_info[:2]
for path in (site_path, sysconfig.get_path("platlib"),
             "/usr/local/lib/" + version_dir + "/dist-packages",
             "/usr/local/lib/" + version_dir + "/site-packages",
             "/usr/lib/" + version_dir + "/dist-packages",
             "/usr/lib/python3/dist-packages"):
    if path not in sys.path:
        sys.path.append(path)

libname = "libseccomp.so.2"

if not libname:
    raise SystemExit("SECURITY_BLOCK: libseccomp missing")

lib = ctypes.CDLL(libname, use_errno=True)

libc = ctypes.CDLL(None, use_errno=True)
PR_SET_NO_NEW_PRIVS = 38
if libc.prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) != 0:
    raise SystemExit("SECURITY_BLOCK: PR_SET_NO_NEW_PRIVS failed")

lib.seccomp_init.argtypes = [ctypes.c_uint32]
lib.seccomp_init.restype = ctypes.c_void_p

lib.seccomp_syscall_resolve_name.argtypes = [
    ctypes.c_char_p
]
lib.seccomp_syscall_resolve_name.restype = ctypes.c_int

lib.seccomp_rule_add.argtypes = [
    ctypes.c_void_p,
    ctypes.c_uint32,
    ctypes.c_int,
    ctypes.c_uint,
]
lib.seccomp_rule_add.restype = ctypes.c_int

class ScmpArgCmp(ctypes.Structure):
    _fields_ = [("arg", ctypes.c_uint), ("op", ctypes.c_uint32),
                ("datum_a", ctypes.c_uint64), ("datum_b", ctypes.c_uint64)]

lib.seccomp_rule_add_array.argtypes = [ctypes.c_void_p, ctypes.c_uint32,
                                        ctypes.c_int, ctypes.c_uint,
                                        ctypes.POINTER(ScmpArgCmp)]
lib.seccomp_rule_add_array.restype = ctypes.c_int

lib.seccomp_load.argtypes = [ctypes.c_void_p]
lib.seccomp_load.restype = ctypes.c_int

lib.seccomp_release.argtypes = [ctypes.c_void_p]
lib.seccomp_release.restype = None

SCMP_ACT_ALLOW = 0x7FFF0000
SCMP_ACT_ERRNO = 0x00050000 | errno.EPERM

context = lib.seccomp_init(SCMP_ACT_ALLOW)

if not context:
    raise SystemExit("SECURITY_BLOCK: seccomp_init failed")

try:
    blocked_syscalls = (
        b"execve",
        b"execveat",
        b"fork",
        b"vfork",
        b"clone",
        b"clone3",
        b"ptrace",
        b"socketpair",
        b"connect",
        b"bind",
        b"listen",
        b"accept",
        b"accept4",
        b"io_uring_setup",
        b"io_uring_enter",
        b"io_uring_register",
        b"pidfd_getfd",
        b"mount",
        b"umount2",
        b"pivot_root",
        b"chroot",
        b"unshare",
        b"setns",
        b"bpf",
        b"perf_event_open",
        b"process_vm_readv",
        b"process_vm_writev",
        b"keyctl",
        b"add_key",
        b"request_key",
    )

    for name in blocked_syscalls:
        number = lib.seccomp_syscall_resolve_name(name)

        if number < 0:
            continue

        result = lib.seccomp_rule_add(
            context,
            SCMP_ACT_ERRNO,
            number,
            0,
        )

        if result != 0:
            raise RuntimeError(
                "Cannot deny syscall: "
                + name.decode()
            )

    # Deny ALL new sockets, including abstract Unix sockets.
    # The trusted parent hands off one connected socketpair descriptor.
    socket_syscall = lib.seccomp_syscall_resolve_name(b"socket")
    if socket_syscall < 0:
        raise RuntimeError("socket syscall not resolvable")
    if lib.seccomp_rule_add(context, SCMP_ACT_ERRNO,
                             socket_syscall, 0) != 0:
        raise RuntimeError("Cannot prohibit socket creation")

    if lib.seccomp_load(context) != 0:
        raise RuntimeError("seccomp_load failed")

finally:
    lib.seccomp_release(context)


import requests
from requests.adapters import BaseAdapter

offline_router_connection = socket.socket(
    fileno=int(os.environ["STAGE06_ROUTER_FD"])
)
offline_router_connection.settimeout(3)
current_item_id = None


class OfflineAdapter(BaseAdapter):
    def send(self, request, **kwargs):
        body = request.body

        if isinstance(body, str):
            body = body.encode("utf-8")

        payload = {
            "method": request.method,
            "pytest_item_id": current_item_id,
            "url": request.url,
            "headers": dict(request.headers),
            "body_b64": base64.b64encode(
                body or b""
            ).decode("ascii"),
        }

        # Connected descriptor was created by the trusted parent before
        # installing seccomp. Generated code cannot create/connect sockets.
        connection = offline_router_connection

        connection.sendall(
            json.dumps(payload).encode("utf-8")
            + b"\n"
        )

        response_bytes = b""

        while b"\n" not in response_bytes:
            chunk = connection.recv(65536)

            if not chunk:
                raise RuntimeError(
                    "Offline coordinator disconnected"
                )

            response_bytes += chunk

            if len(response_bytes) > 2_000_000:
                raise RuntimeError(
                    "Offline coordinator reply too large"
                )

        result = json.loads(
            response_bytes.split(b"\n", 1)[0]
        )

        if result.get("error"):
            raise RuntimeError(
                "EVALUATOR_UNSUPPORTED_ROUTE:"
                + result["error"]
            )

        response = requests.Response()

        response.status_code = int(
            result["status"]
        )

        response._content = base64.b64decode(
            result["body_b64"]
        )

        response.headers = (
            requests.structures.CaseInsensitiveDict(
                result.get("headers") or {}
            )
        )

        response.url = request.url
        response.request = request

        return response

    def close(self):
        pass


original_session_init = requests.Session.__init__


def offline_session_init(
    self,
    *args,
    **kwargs,
):
    original_session_init(
        self,
        *args,
        **kwargs,
    )

    self.mount(
        "http://",
        OfflineAdapter(),
    )

    self.mount(
        "https://",
        OfflineAdapter(),
    )


requests.Session.__init__ = offline_session_init


import pytest

pytest_arguments = [
    "-q",
    "--capture=no",
    "-p",
    "no:cacheprovider",
    "--disable-warnings",
    "--tb=short",
]

if os.environ.get("STAGE06_PHASE") == "collect":
    pytest_arguments.append("--collect-only")

pytest_arguments.append(
    "/work/generated_test.py"
)

class OutcomeRecorder:
    def __init__(self):
        self.outcomes = {}
        self.assertion_failures = set()

    @pytest.hookimpl(hookwrapper=True)
    def pytest_runtest_protocol(self, item, nextitem):
        global current_item_id
        current_item_id = item.nodeid
        try:
            yield
        finally:
            current_item_id = None

    @pytest.hookimpl(hookwrapper=True)
    def pytest_runtest_makereport(self, item, call):
        result = yield
        report = result.get_result()
        if (report.when == "call" and report.failed and not hasattr(report, "wasxfail")
                and call.excinfo is not None and call.excinfo.errisinstance(AssertionError)):
            self.assertion_failures.add(item.nodeid)

    def pytest_runtest_logreport(self, report):
        node_id = report.nodeid
        if report.failed:
            self.outcomes[node_id] = "failed" if report.when == "call" else "error"
        elif report.skipped and node_id not in self.outcomes:
            self.outcomes[node_id] = "xfailed" if hasattr(report, "wasxfail") else "skipped"
        elif report.when == "call" and report.passed:
            self.outcomes[node_id] = "xpassed" if hasattr(report, "wasxfail") else "passed"


recorder = OutcomeRecorder()
print("STAGE06_PYTEST_READY", flush=True)
exit_code = pytest.main(pytest_arguments, plugins=[recorder])
if os.environ.get("STAGE06_PHASE") != "collect":
    print("\nSTAGE06_ASSERTION_FAILURES=" + json.dumps(sorted(recorder.assertion_failures)), flush=True)
    print("\nSTAGE06_ITEM_OUTCOMES=" + json.dumps(recorder.outcomes, sort_keys=True), flush=True)

sys.exit(
    int(exit_code)
)
'''


def enforce_resource_limits():
    limits = (
        (resource.RLIMIT_CPU, 20),
        (resource.RLIMIT_AS, 2 * 1024**3),
        (resource.RLIMIT_FSIZE, 2 * 1024**2),
        (resource.RLIMIT_NOFILE, 64),
        (resource.RLIMIT_NPROC, 32),
    )

    for resource_kind, soft_limit in limits:
        current_soft, current_hard = (
            resource.getrlimit(resource_kind)
        )

        actual_soft = (
            soft_limit
            if current_hard < 0
            else min(
                soft_limit,
                current_hard,
            )
        )

        resource.setrlimit(
            resource_kind,
            (
                actual_soft,
                current_hard,
            ),
        )



# The runtime template contains only Python, its bounded standard library,
# pytest/requests dependencies and required ELF libraries; it NEVER contains
# /kaggle/input, the project tree, environment secrets or hidden oracle files.
_RUNTIME_TEMPLATE = None
_BOUNDARY_QUALIFIED_REPORT = None
_CHROOT_COMMAND = shutil.which("chroot")


def _copy_host_file(source_path, root):
    p = Path(source_path)
    if not p.is_absolute() or not p.exists() or p.is_dir():
        raise RuntimeError("SECURITY_BLOCK: invalid runtime source " + str(p))
    destination = root / str(p).lstrip("/")
    destination.parent.mkdir(parents=True, exist_ok=True)
    if not destination.exists():
        shutil.copy2(p, destination, follow_symlinks=True)


def _copy_dynamic_dependencies(source_paths, root):
    """Only trusted ELF libraries referenced by the interpreter/extensions."""
    paths = [Path(p) for p in source_paths]
    copied = set()
    while paths:
        src = paths.pop()
        if str(src) in copied or not src.is_file():
            continue
        copied.add(str(src))
        probe = subprocess.run(["ldd", str(src)], stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, text=True, timeout=15,
                               check=False)
        if probe.returncode != 0:
            # Some Python extension .so files are static/no dynamic deps.
            if "not a dynamic executable" in probe.stderr.lower():
                continue
            raise RuntimeError("SECURITY_BLOCK: ELF dependency probe failed: "
                               + str(src) + ": " + probe.stderr[:300])
        for dependency in re.findall(r"(?<![A-Za-z0-9_])(/[^\s()]+)",
                                     probe.stdout):
            dep = Path(dependency)
            if not dep.is_file():
                raise RuntimeError("SECURITY_BLOCK: missing shared library " + dependency)
            _copy_host_file(dep, root)
            if str(dep) not in copied:
                paths.append(dep)


def _copy_package_distributions(root):
    # Frozen minimal import surface required by generated requests/pytest tests.
    names = (
        "pytest", "requests", "urllib3", "idna", "charset-normalizer",
        "certifi", "pluggy", "iniconfig", "packaging", "colorama",
        "typing-extensions", "tomli", "exceptiongroup",
        "importlib-metadata", "zipp", "attrs", "pygments",
        "jsonschema", "jsonschema-specifications", "referencing", "rpds-py",
        "six", "PyYAML", "pydantic", "pydantic-core",
    )
    required = {"pytest", "requests", "urllib3", "idna", "certifi",
                "pluggy", "iniconfig", "packaging"}
    copied_shared_objects = set()
    found = set()
    for name in names:
        try:
            dist = importlib.metadata.distribution(name)
        except importlib.metadata.PackageNotFoundError:
            if name in required:
                raise RuntimeError("SECURITY_BLOCK: dependency missing: " + name)
            continue
        found.add(name)
        if not dist.files:
            raise RuntimeError("SECURITY_BLOCK: missing distribution file list " + name)
        for relative in dist.files:
            src = Path(dist.locate_file(relative))
            if not src.is_file():
                continue
            # Only the registered distribution and metadata, never arbitrary
            # user/project paths or unrelated site packages.
            if not any(part in src.parts for part in ("site-packages", "dist-packages")):
                continue
            _copy_host_file(src, root)
            if ".so" in src.name:
                copied_shared_objects.add(src)
    return copied_shared_objects


def _build_runtime_template():
    global _RUNTIME_TEMPLATE
    if _RUNTIME_TEMPLATE is not None and _RUNTIME_TEMPLATE.is_dir():
        return _RUNTIME_TEMPLATE
    if platform.system() != "Linux" or os.geteuid() != 0 or not _CHROOT_COMMAND:
        raise RuntimeError(
            "SECURITY_BLOCK: Kaggle OS worker requires root with CAP_SYS_CHROOT "
            "and the system chroot utility; no unisolated fallback is permitted"
        )
    if not ctypes.util.find_library("seccomp"):
        raise RuntimeError("SECURITY_BLOCK: libseccomp unavailable")
    runtime_dir = Path(tempfile.mkdtemp(prefix="stage06_osruntime_"))
    try:
        python_exe = Path(sys.executable)
        if not python_exe.is_file():
            raise RuntimeError("SECURITY_BLOCK: Python executable not found")
        stdlib = Path(sysconfig.get_path("stdlib"))
        if not stdlib.is_dir():
            raise RuntimeError("SECURITY_BLOCK: Python stdlib missing")
        _copy_host_file(python_exe, runtime_dir)
        target_stdlib = runtime_dir / str(stdlib).lstrip("/")

        def ignore(directory, files):
            excluded = {"site-packages", "dist-packages", "__pycache__",
                        "test", "tests", "tkinter", "idlelib", "ensurepip",
                        "venv", "turtledemo"}
            return [name for name in files if name in excluded]

        shutil.copytree(stdlib, target_stdlib, ignore=ignore,
                        symlinks=False, dirs_exist_ok=True)
        extensions = set(target_stdlib.rglob("*.so"))
        extensions.update(_copy_package_distributions(runtime_dir))

        # Host loader needs its referenced interpreter/extension libraries.
        host_extensions = [python_exe]
        for extension in extensions:
            # stdlib extensions are already copied beneath runtime_dir;
            # distribution extensions are still absolute HOST source paths.
            # Never call relative_to(runtime_dir) on a host path.
            host = (
                Path("/") / extension.relative_to(runtime_dir)
                if extension.is_relative_to(runtime_dir)
                else extension
            )
            if host.is_file():
                host_extensions.append(host)
        _copy_dynamic_dependencies(host_extensions, runtime_dir)

        # libseccomp is linked dynamically by ctypes in bootstrap.py.
        lib_candidates = [
            p for prefix in ("/lib", "/usr/lib", "/lib64", "/usr/local/lib")
            for p in Path(prefix).glob("**/libseccomp.so.2")
            if p.is_file()
        ]
        if not lib_candidates:
            raise RuntimeError("SECURITY_BLOCK: libseccomp.so.2 not found")
        seccomp_source = sorted(lib_candidates, key=lambda p: len(str(p)))[0]
        _copy_host_file(seccomp_source, runtime_dir)
        _copy_dynamic_dependencies([seccomp_source], runtime_dir)

        # Dynamic linker configuration is non-secret, needed for libpython.
        if Path("/etc/ld.so.cache").is_file():
            _copy_host_file(Path("/etc/ld.so.cache"), runtime_dir)
        # GNU chroot may resolve supplemental groups after entering the root.
        etc = runtime_dir / "etc"
        etc.mkdir(parents=True, exist_ok=True)
        (etc / "passwd").write_text(
            "root:x:0:0:root:/root:/bin/sh\n"
            "nobody:x:65534:65534:nobody:/work:/usr/sbin/nologin\n",
            encoding="utf-8",
        )
        (etc / "group").write_text(
            "root:x:0:\n"
            "nogroup:x:65534:\n",
            encoding="utf-8",
        )
        for name in ("work", "tmp", "dev"):
            (runtime_dir / name).mkdir(exist_ok=True)
        (runtime_dir / "tmp").chmod(0o1777)
        # Some pytest startup paths open os.devnull even when output
        # capture is disabled. A sandbox-local regular file is sufficient
        # and avoids exposing the host /dev tree inside the chroot.
        sandbox_devnull = runtime_dir / "dev/null"
        sandbox_devnull.write_bytes(b"")
        sandbox_devnull.chmod(0o666)
        # mkdtemp starts 0700. Without this, UID 65534 cannot traverse '/'!
        runtime_dir.chmod(0o755)
        _RUNTIME_TEMPLATE = runtime_dir
    except BaseException:
        shutil.rmtree(runtime_dir, ignore_errors=True)
        raise
    return _RUNTIME_TEMPLATE


def _create_worker_root(workspace):
    runtime = _build_runtime_template()
    worker_root = Path(workspace) / "sandbox"
    try:
        shutil.copytree(runtime, worker_root, copy_function=os.link,
                        symlinks=False)
    except OSError as error:
        raise RuntimeError(
            "SECURITY_BLOCK: cannot create fresh immutable sandbox runtime: "
            + str(error)
        ) from error
    # The synthetic dev/null is the only writable runtime file. Give each
    # worker its own inode so generated code cannot persist data across runs.
    sandbox_devnull = worker_root / "dev/null"
    sandbox_devnull.unlink()
    sandbox_devnull.touch(mode=0o666)
    sandbox_devnull.chmod(0o666)
    work = worker_root / "work"
    worker_root.chmod(0o755)
    work.chmod(0o1777)
    return worker_root, work


def construct_sandbox_command(worker_root, python_executable):
    _build_runtime_template()
    executable = Path(python_executable)
    if not (Path(worker_root) / str(executable).lstrip("/")).is_file():
        raise RuntimeError("SECURITY_BLOCK: Python missing in chroot runtime")
    return [
        _CHROOT_COMMAND,
        "--userspec=65534:65534",
        str(worker_root),
    ]


def qualify_os_boundary():
    # This is a real root-change and drop-UID test. A successful 'which chroot'
    # alone is NOT an isolation qualification.
    global _BOUNDARY_QUALIFIED_REPORT
    if _BOUNDARY_QUALIFIED_REPORT is not None:
        return dict(_BOUNDARY_QUALIFIED_REPORT)
    _build_runtime_template()
    with tempfile.TemporaryDirectory(prefix="stage06_boundary_") as directory:
        root, work = _create_worker_root(directory)
        command = construct_sandbox_command(root, sys.executable)
        command.extend([sys.executable, "-I", "-B", "-S", "-c",
                        "import os; print('BOUNDARY_OK', os.getuid(), "
                        "os.getgid(), ','.join(map(str,os.getgroups())))"])
        try:
            result = subprocess.run(command, stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE, timeout=15,
                                    check=False)
        except (subprocess.TimeoutExpired, OSError) as error:
            raise RuntimeError("SECURITY_BLOCK: chroot qualification failed") from error
        words = result.stdout.decode(errors="replace").strip().split()
        group_tokens = words[3].split(",") if len(words) > 3 else []
        if (result.returncode != 0 or len(words) < 3
                or words[:3] != ["BOUNDARY_OK", "65534", "65534"]
                or "0" in group_tokens):
            raise RuntimeError(
                "SECURITY_BLOCK: Kaggle denied an isolated chroot worker "
                "or runtime imports: " + result.stderr[-1000:].decode(errors="replace")
            )
    _BOUNDARY_QUALIFIED_REPORT = {
        "status": "PASS",
        "worker_version": WORKER_VERSION,
        "os_boundary": "chroot_with_dropped_uid_gid",
        "user_namespaces_required": False,
        "syscall_policy": "libseccomp_non_unix_network_and_process_denied",
        "resource_limits": True,
    }
    return dict(_BOUNDARY_QUALIFIED_REPORT)


def bounded_process(
    command,
    timeout,
    maximum_output,
    phase="run",
    router_fd=None,
):
    process = subprocess.Popen(
        command,
        stdin=subprocess.DEVNULL,
        pass_fds=(router_fd,),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env={
            "PATH": "/usr/bin:/bin",
            "HOME": "/work",
            "TMPDIR": "/tmp",
            "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONNOUSERSITE": "1",
            "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1",
            "STAGE06_PHASE": phase,
            "STAGE06_ROUTER_FD": str(router_fd),
        },
        preexec_fn=enforce_resource_limits,
        start_new_session=True,
    )

    selector = selectors.DefaultSelector()

    assert process.stdout is not None
    assert process.stderr is not None

    buffers = {
        process.stdout: bytearray(),
        process.stderr: bytearray(),
    }

    for stream in buffers:
        os.set_blocking(
            stream.fileno(),
            False,
        )

        selector.register(
            stream,
            selectors.EVENT_READ,
        )

    deadline = (
        time.monotonic()
        + timeout
    )

    timed_out = False
    output_truncated = False

    try:
        while (
            selector.get_map()
            or process.poll() is None
        ):
            if time.monotonic() > deadline:
                timed_out = True
                break

            remaining_time = max(
                0.01,
                deadline - time.monotonic(),
            )

            events = selector.select(
                timeout=min(
                    0.1,
                    remaining_time,
                )
            )

            for key, _ in events:
                stream = key.fileobj

                try:
                    chunk = os.read(
                        stream.fileno(),
                        65536,
                    )

                except BlockingIOError:
                    continue

                if not chunk:
                    selector.unregister(
                        stream
                    )
                    continue

                remaining_bytes = (
                    maximum_output
                    - sum(
                        len(buffer)
                        for buffer in buffers.values()
                    )
                )

                if len(chunk) > remaining_bytes:
                    if remaining_bytes > 0:
                        buffers[stream].extend(
                            chunk[:remaining_bytes]
                        )

                    output_truncated = True
                    break

                buffers[stream].extend(
                    chunk
                )

            if output_truncated:
                break

        if timed_out or output_truncated:
            try:
                os.killpg(
                    process.pid,
                    signal.SIGKILL,
                )

            except ProcessLookupError:
                pass

        exit_code = process.wait(
            timeout=5
        )

    finally:
        selector.close()

        for stream in buffers:
            stream.close()

    return {
        "exit_code": exit_code,
        "timed_out": timed_out,
        "output_truncated": output_truncated,
        "stdout": bytes(
            buffers[process.stdout]
        ).decode(errors="replace"),
        "stderr": bytes(
            buffers[process.stderr]
        ).decode(errors="replace"),
    }


def matches_replay_target(attempt, target):
    return (
        attempt["pytest_item_id"] == target["pytest_item_id"]
        and attempt["item_request_ordinal"] == target["item_request_ordinal"]
        and attempt["baseline_id"] == target["baseline_id"]
        and attempt["scenario_id"] == target["scenario_id"]
        and json.dumps(attempt["request"], sort_keys=True)
        == json.dumps(target["request"], sort_keys=True)
    )


def make_router_coordinator(route, phase):
    mode = route.get("mode", "baseline")
    mutation = route.get("mutation")
    target = route.get("replay_target")
    if mode == "baseline":
        if mutation is not None or target is not None:
            raise ValueError("Baseline execution cannot specify a replay target or mutation")
    else:
        if mode not in {"fault", "variation"} or phase != "run":
            raise ValueError("Fault and variation replay require the run phase")
        if not isinstance(mutation, dict) or not mutation.get(f"{mode}_id"):
            raise ValueError("Replay requires an identified frozen mutation")
        if (
            not isinstance(target, dict)
            or not isinstance(target.get("pytest_item_id"), str)
            or not target["pytest_item_id"]
            or type(target.get("item_request_ordinal")) is not int
            or target["item_request_ordinal"] < 1
            or not isinstance(target.get("request"), dict)
            or not target.get("scenario_id")
            or not target.get("baseline_id")
            or target["baseline_id"] != mutation.get("baseline_id")
            or mutation.get("scenario_id") not in {None, target["scenario_id"]}
            or not any(row["baseline_id"] == target["baseline_id"]
                       and row["scenario_id"] == target["scenario_id"]
                       for row in route["baselines"])
        ):
            raise ValueError("Replay requires a request occurrence linked to its frozen baseline")

    return types.SimpleNamespace(
        scenarios=route["scenarios"],
        excluded_scenarios=route.get("excluded_scenarios", []),
        operation_document=route["operation_document"],
        baselines=route["baselines"],
        mode=mode,
        mutation=mutation,
        replay_target=target,
        mutation_applied=False,
        item_request_ordinals={},
        request_log=[],
    )


def classify_response_backed_request(request, coordinator):
    """Try the frozen suite first. Match excluded cases only for audit evidence."""
    try:
        return classify_request(request, coordinator.scenarios, coordinator.operation_document)
    except EvaluatorUnavailable as error:
        if error.code != "AMBIGUOUS_OR_UNMAPPED_REQUEST_SEMANTICS" or error.detail.get("candidate_ids"):
            raise
        if not coordinator.excluded_scenarios:
            raise
        try:
            excluded = classify_request(request, coordinator.excluded_scenarios,
                                        coordinator.operation_document)
        except EvaluatorDefect:
            raise
        except UnsupportedRoute:
            raise error
        if excluded["documented_response_mapping"] is not None:
            raise EvaluatorDefect("EXCLUDED_SCENARIO_HAS_RESPONSE_MAPPING")
        raise EvaluatorUnavailable(
            "AUDIT_ONLY_SCENARIO_NO_DOCUMENTED_RESPONSE",
            {"excluded_scenario_id": excluded["scenario_id"],
             "intent": excluded["intent"], "observed_violations": excluded["observed_violations"]},
        ) from error


class OfflineRouterHandler(
    socketserver.StreamRequestHandler
):
    def handle(self):
        while self.handle_one():
            pass

    def handle_one(self):
        coordinator = self.server

        request_line = self.rfile.readline(2_000_000)
        if not request_line:
            return False

        original = None
        prepared = None
        classification = None
        item_id = None
        item_ordinal = None
        try:
            original = json.loads(request_line)
            item_id = original.get("pytest_item_id")
            item_ordinal = coordinator.item_request_ordinals.get(item_id, 0) + 1
            coordinator.item_request_ordinals[item_id] = item_ordinal
            body = base64.b64decode(original["body_b64"], validate=True)
            prepared = normalize_prepared_request(
                original["method"], original["url"], original.get("headers"), body,
            )
            classification = classify_response_backed_request(prepared, coordinator)
            baseline = select_frozen_response(classification, coordinator.baselines)
            inject = (
                coordinator.replay_target is not None
                and not coordinator.mutation_applied
                and matches_replay_target({
                    "pytest_item_id": item_id,
                    "item_request_ordinal": item_ordinal,
                    "baseline_id": baseline["baseline_id"],
                    "scenario_id": classification["scenario_id"],
                    "request": prepared,
                }, coordinator.replay_target)
            )
            selected = (select_frozen_response(
                classification, coordinator.baselines,
                mode=coordinator.mode, mutation=coordinator.mutation,
            ) if inject else baseline)
            headers, body_bytes = prepare_frozen_response(selected, baseline)
            response = {
                "status": int(selected["status"]), "headers": headers,
                "body_b64": base64.b64encode(body_bytes).decode("ascii"),
            }
            evidence = {"status": "DELIVERED", "baseline_id": baseline["baseline_id"],
                        "response_status": response["status"],
                        "replay_mutation_applied": inject,
                        "fault_id": selected.get("fault_id") if inject else None,
                        "variation_id": selected.get("variation_id") if inject else None}
        except UnsupportedRoute as error:
            response = {"error": error.code}
            evidence = {"status": "UNSUPPORTED", "diagnostic": str(error),
                        "reason_code": error.code, "failure_owner": error.failure_owner,
                        "detail": error.detail}
        except Exception as error:
            response = {"error": "OFFLINE_EVALUATOR_INTERNAL_ERROR"}
            evidence = {"status": "UNSUPPORTED", "diagnostic": str(error),
                        "reason_code": "OFFLINE_EVALUATOR_INTERNAL_ERROR",
                        "failure_owner": "EVALUATOR_FAILURE"}
        self.wfile.write(
            json.dumps(response).encode("utf-8") + b"\n"
        )
        self.wfile.flush()
        if evidence.get("replay_mutation_applied"):
            coordinator.mutation_applied = True
        coordinator.request_log.append({
            **evidence, "original_request": original, "request": prepared,
            "classification": classification,
            "pytest_item_id": item_id,
            "item_request_ordinal": item_ordinal,
            "scenario_id": classification["scenario_id"] if classification else None,
        })

        return True


class OfflineRouterServer(
    socketserver.ThreadingUnixStreamServer
):
    daemon_threads = True
    allow_reuse_address = True


def parse_pytest_item_outcomes(stdout):
    prefix = "STAGE06_ITEM_OUTCOMES="
    records = [line[len(prefix):] for line in stdout.splitlines() if line.startswith(prefix)]
    if len(records) != 1:
        return None
    try:
        outcomes = json.loads(records[0])
    except ValueError:
        return None
    allowed = {"passed", "failed", "error", "skipped", "xfailed", "xpassed"}
    if not isinstance(outcomes, dict) or any(
        not isinstance(value, str) or value not in allowed for value in outcomes.values()
    ):
        return None
    return outcomes


def parse_pytest_assertion_failures(stdout, outcomes):
    prefix = "STAGE06_ASSERTION_FAILURES="
    records = [line[len(prefix):] for line in stdout.splitlines() if line.startswith(prefix)]
    if outcomes is None or len(records) != 1:
        return None
    try:
        items = json.loads(records[0])
    except ValueError:
        return None
    if not isinstance(items, list) or any(
        not isinstance(item, str) or outcomes.get(item) != "failed" for item in items
    ) or len(set(items)) != len(items):
        return None
    return items


def summarize_worker_result(result, request_log, phase):
    owners = {row.get("failure_owner") for row in request_log}
    item_outcomes = parse_pytest_item_outcomes(result["stdout"])
    assertion_failures = parse_pytest_assertion_failures(result["stdout"], item_outcomes)
    if ("EVALUATOR_FAILURE" in owners or result["exit_code"] in {3, 4}
            or "STAGE06_PYTEST_READY" not in result["stdout"].splitlines()
            or "SECURITY_BLOCK:" in result["stderr"]):
        status = "EVALUATOR_FAILURE"
    elif "EVALUATOR_LIMITATION" in owners:
        status = "EVALUATOR_UNAVAILABLE"
    elif result["timed_out"]:
        status = "TIMEOUT"
    elif result["output_truncated"]:
        status = "OUTPUT_LIMIT"
    elif "GENERATED_OUTPUT" in owners:
        status = "TEST_FAILURE"
    elif phase == "run" and assertion_failures is None:
        status = "EVALUATOR_FAILURE"
    elif result["exit_code"] == 0:
        if phase == "collect":
            status = "PASS"
        elif item_outcomes is None:
            status = "EVALUATOR_FAILURE"
        else:
            outcomes = set(item_outcomes.values())
            status = ("PASS" if "passed" in outcomes
                      and outcomes <= {"passed", "skipped", "xfailed"}
                      else "TEST_FAILURE")
    elif phase == "run" and item_outcomes is None:
        status = "EVALUATOR_FAILURE"
    else:
        status = "TEST_FAILURE"

    return status, item_outcomes, assertion_failures


def evaluate_isolated(
    source,
    route,
    phase="run",
    timeout=30,
    maximum_output=200000,
):
    qualify_os_boundary()

    if phase not in (
        "collect",
        "run",
    ):
        raise ValueError(
            "Invalid evaluation phase"
        )

    if (
        not isinstance(source, str)
        or len(source.encode("utf-8")) > 2_000_000
    ):
        raise ValueError(
            "Generated source too large or invalid"
        )

    started = time.monotonic()
    coordinator = make_router_coordinator(route, phase)

    with tempfile.TemporaryDirectory(
        prefix="stage06_worker_"
    ) as temporary_directory:
        workspace = Path(temporary_directory)
        worker_root, work_dir = _create_worker_root(workspace)

        (work_dir / "generated_test.py").write_text(
            source,
            encoding="utf-8",
        )

        (work_dir / "bootstrap.py").write_text(
            SANDBOX_BOOTSTRAP,
            encoding="utf-8",
        )

        # Explicitly readable after dropping privileges, even with umask 077.
        (work_dir / "generated_test.py").chmod(0o644)
        (work_dir / "bootstrap.py").chmod(0o644)
        host_socket, child_socket = socket.socketpair(
            socket.AF_UNIX, socket.SOCK_STREAM
        )
        try:
            server_thread = threading.Thread(
                target=OfflineRouterHandler,
                args=(host_socket, None, coordinator),
                daemon=True,
            )
            server_thread.start()

            command = construct_sandbox_command(worker_root, sys.executable)
            command.extend([
                sys.executable, "-I", "-B", "-S", "/work/bootstrap.py",
            ])
            try:
                result = bounded_process(
                    command, timeout, maximum_output,
                    phase=phase,
                    router_fd=child_socket.fileno(),
                )
            finally:
                child_socket.close()
                server_thread.join(timeout=3)
        finally:
            host_socket.close()
            if child_socket.fileno() != -1:
                child_socket.close()

        status, item_outcomes, assertion_failures = summarize_worker_result(
            result, coordinator.request_log, phase,
        )
        return {
            "phase": phase,
            "item_outcomes": item_outcomes,
            "assertion_failures": assertion_failures,
            "status": status,
            "exit_code": result["exit_code"],
            "stdout": result["stdout"],
            "stderr": result["stderr"],
            "output_truncated": (
                result["output_truncated"]
            ),
            "duration_seconds": round(
                time.monotonic() - started,
                3,
            ),
            "request_attempts": (
                coordinator.request_log
            ),
        }
