import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retry mechanism
session = requests.Session()
retries = Retry(total=3, backoff_factor=0.1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def albums():
    params = {
        "ignoreIds": [1, 2, 3],
        "languagePreference": "Japanese",
        "fields": "AdditionalNames,Artists,Description,Discs,Identifiers,MainPicture,Names,PVs,ReleaseEvent,Tags,Tracks,WebLinks"
    }

    response = session.get(f"{BASE_URL}/api/albums/top", params=params)
    response.raise_for_status()
    return response.json()

def test_albums(albums):
    assert isinstance(albums, list)
    for album in albums:
        assert all(key in album for key in ["AdditionalNames", "Artists", "Description", "Discs", "Identifiers", "MainPicture", "Names", "PVs", "ReleaseEvent", "Tags", "Tracks", "WebLinks"])