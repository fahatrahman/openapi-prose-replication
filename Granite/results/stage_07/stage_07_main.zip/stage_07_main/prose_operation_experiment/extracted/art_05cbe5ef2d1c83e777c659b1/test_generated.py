import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["GET"],
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

def test_get_symptom():
    symptom_id = "example_id"
    age_value = 18
    age_unit = "year"
    enable_triage_5 = False

    url = f"{BASE_URL}/symptoms/{symptom_id}"
    params = {
        "age.value": age_value,
        "age.unit": age_unit,
        "enable_triage_5": enable_triage_5,
    }

    response = SESSION.get(url, params=params)
    assert response.status_code == 200

    symptom_details = response.json()
    assert isinstance(symptom_details, dict)
    assert all(key in symptom_details for key in ["id", "name", "question", "sex_filter"])