# -*- coding: utf-8 -*-

import pytest
import json
import requests

BASE_URL = "http://openapi.test"

def test_detect_device():
    # Prepare request body
    device_features = {
        "ftp_banner": "",
        "hostname": "",
        "http_response": "",
        "https_response": "",
        "nic_mac": "",
        "snmp_sysdescr": "",
        "snmp_sysoid": "",
        "telnet_banner": "",
        "upnp_response": ""
    }
    
    headers = {"Content-Type": "application/json"}
    response = requests.post(f"{BASE_URL}/device/detect", headers=headers, json=device_features)
    
    assert response.status_code == 200
    
    try:
        response.raise_for_status()
    except requests.RequestException as err:
        pytest.fail(err)

    # Parse JSON response
    device_info = response.json()
    
    # Check if required fields are present
    required_fields = ["cve_list", "device_type", "firmware_info", "firmware_version"]
    for field in required_fields:
        assert field in device_info
    
    # Check if firmware info is not None
    firmware_info = device_info["firmware_info"]
    assert firmware_info is not None
    
    # Check if firmware info has required fields
    required_firmware_fields = ["download_url", "name", "release_date", "sha2", "version"]
    for field in required_firmware_fields:
        assert field in firmware_info
    
    # Check if latest firmware info is not None
    latest_firmware_info = device_info.get("latest_firmware_info")
    assert latest_firmware_info is not None
    
    # Check if latest firmware info has required fields
    required_latest_firmware_fields = ["download_url", "name", "release_date", "sha2", "version"]
    for field in required_latest_firmware_fields:
        assert field in latest_firmware_info