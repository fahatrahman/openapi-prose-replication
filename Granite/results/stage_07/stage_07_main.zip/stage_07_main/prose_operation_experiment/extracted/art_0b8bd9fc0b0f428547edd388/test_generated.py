import os
import json
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retry mechanism for handling transient errors
session = requests.Session()
retries = Retry(total=3, backoff_factor=0.1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def get_comments():
    def _get_comments(song_id):
        url = f"{BASE_URL}/api/songs/{song_id}/comments"
        response = session.get(url)
        response.raise_for_status()
        return response.json()["items"]

    return _get_comments

def test_get_comments(get_comments):
    song_id = 123  # Replace with actual song ID for testing
    comments = get_comments(song_id)
    
    assert isinstance(comments, list)
    for comment in comments:
        assert isinstance(comment, dict)
        required_keys = ["author", "created", "entry", "id", "message"]
        for key in required_keys:
            assert key in comment