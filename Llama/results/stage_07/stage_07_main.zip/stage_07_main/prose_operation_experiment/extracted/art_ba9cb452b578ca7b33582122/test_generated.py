# -*- coding: utf-8 -*-
"""Tests for the Operation slice API."""
import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_SeasonTeams():
    """Test the Season Teams endpoint."""
    # Construct the full URL for the request
    season_id = "100000057"
    url = urljoin(BASE_URL, f"/{{format}}/SeasonTeams/{{seasonid}}")
    
    # Replace {{format}} and {{seasonid}} with desired values
    params = {"format": "json", "seasonid": season_id}
    headers = {}
    key = None
    
    # If you have a subscription key, uncomment the following lines:
    # if key is not None:
    #     headers["Ocp-Apim-Subscription-Key"] = key
    # elif key is not None:
    #     params["key"] = key
    
    # Send the GET request
    response = requests.get(url, params=params, headers=headers)
    
    # Check that the response was successful
    assert response.status_code == 200
    
    # Check that the response content matches expectations (e.g., JSON schema)
    assert response.json()