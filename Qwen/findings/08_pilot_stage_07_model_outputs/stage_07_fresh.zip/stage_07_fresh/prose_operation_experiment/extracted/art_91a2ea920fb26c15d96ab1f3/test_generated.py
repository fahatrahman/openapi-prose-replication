import pytest
import requests

BASE_URL = "http://openapi.test"

def test_data_exporter_template():
    url = f"{BASE_URL}/api/data-exporter-configs/_template"
    params = {"type": "kafka"}
    headers = {
        "Authorization": "Basic Y3VycmVudDpwYXNzd29yZA=="  # Replace with actual credentials
    }
    response = requests.get(url, params=params, headers=headers)
    
    assert response.status_code == 200
    assert response.json()["type"] == "kafka"

def test_data_exporter_template_invalid_type():
    url = f"{BASE_URL}/api/data-exporter-configs/_template"
    params = {"type": "invalid"}
    headers = {
        "Authorization": "Basic Y3VycmVudDpwYXNzd29yZA=="  # Replace with actual credentials
    }
    response = requests.get(url, params=params, headers=headers)
    
    assert response.status_code == 400

def test_data_exporter_template_unauthorized():
    url = f"{BASE_URL}/api/data-exporter-configs/_template"
    params = {"type": "kafka"}
    headers = {
        "Authorization": "Basic invalid_credentials"  # Invalid credentials
    }
    response = requests.get(url, params=params, headers=headers)
    
    assert response.status_code == 401

def test_data_exporter_template_not_found():
    url = f"{BASE_URL}/api/data-exporter-configs/_template"
    params = {"type": "nonexistent"}
    headers = {
        "Authorization": "Basic Y3VycmVudDpwYXNzd29yZA=="  # Replace with actual credentials
    }
    response = requests.get(url, params=params, headers=headers)
    
    assert response.status_code == 404