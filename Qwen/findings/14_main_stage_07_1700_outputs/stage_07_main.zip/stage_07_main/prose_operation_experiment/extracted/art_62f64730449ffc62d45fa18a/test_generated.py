import pytest
import requests

BASE_URL = "http://openapi.test"

def test_update_an_api_version():
    api_id = "test_api_id"
    api_version_id = "test_api_version_id"
    update_data = {
        "version": {
            "name": "2.1"
        }
    }

    response = requests.put(
        f"{BASE_URL}/apis/{api_id}/versions/{api_version_id}",
        json=update_data,
        headers={"Content-Type": "application/json"}
    )

    assert response.status_code == 200
    assert response.json()["version"]["name"] == "2.1"