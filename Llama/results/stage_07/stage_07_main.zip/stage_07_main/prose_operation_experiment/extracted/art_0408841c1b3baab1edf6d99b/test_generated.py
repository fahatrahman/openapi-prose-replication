import pytest
import requests

BASE_URL = "http://openapi.test"

def test_cloudresourcemanager_organizations_testIamPermissions():
    url = f"{BASE_URL}/v1/{'organizations/123'}:testIamPermissions"
    headers = {
        'Content-Type': 'application/json'
    }
    body = {
        "permissions": ["permissions1", "permissions2"]
    }

    response = requests.post(url, headers=headers, json=body)

    assert response.status_code == 200
    assert response.json()["permissions"]

def test_cloudresourcemanager_organizations_testIamPermissions_invalid_resource():
    url = f"{BASE_URL}/v1/{'invalid-resource'}:testIamPermissions"
    headers = {
        'Content-Type': 'application/json'
    }
    body = {
        "permissions": ["permissions1", "permissions2"]
    }

    response = requests.post(url, headers=headers, json=body)

    assert response.status_code != 200

def test_cloudresourcemanager_organizations_testIamPermissions_empty_permissions():
    url = f"{BASE_URL}/v1/{'organizations/123'}:testIamPermissions"
    headers = {
        'Content-Type': 'application/json'
    }
    body = {
        "permissions": []
    }

    response = requests.post(url, headers=headers, json=body)

    assert response.status_code == 200
    assert not response.json()["permissions"]