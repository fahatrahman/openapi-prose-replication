import os
import json
import pytest
import requests
from requests_aws_sigv4 import AWSSignaturesV4Auth

BASE_URL = "http://openapi.test"

@pytest.fixture
def amazon_signature_authorization():
    return AWSSignaturesV4Auth(
        access_key=os.environ["AWS_ACCESS_KEY"],
        secret_key=os.environ["AWS_SECRET_KEY"],
        service="execute-api",
        region="us-east-1",
    )

def test_update_route(amazon_signature_authorization):
    mesh_name = "your_mesh_name"
    virtual_router_name = "your_virtual_router_name"
    route_name = "your_route_name"

    client_token = "unique_client_token"
    spec = {
        "httpRoute": {
            "action": {
                "weight": 1,
                "orderedTargets": [
                    {
                        "virtualNode": {
                            "name": "your_virtual_node_name",
                        },
                        "weight": 100,
                    }
                ],
            },
            "match": {"prefix": "/"},
        }
    }

    url = f"{BASE_URL}/meshes/{mesh_name}/virtualRouter/{virtual_router_name}/routes/{route_name}"

    headers = {
        "Content-Type": "application/json",
        "X-Amzn-Authorizer": "CognitoUserPools",
    }

    response = requests.put(
        url,
        headers=headers,
        json={"clientToken": client_token, "spec": spec},
        auth=amazon_signature_authorization,
    )

    assert response.status_code == 200