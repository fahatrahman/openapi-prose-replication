# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_organizations_list():
    # Get API token (for demonstration purposes, assume we have a valid token)
    api_token = "my_secret_api_token"
    
    response = requests.get(
        urljoin(BASE_URL, "/v0.1/orgs"),
        headers={"X-API-Token": api_token}
    )

    assert response.status_code == 200

    try:
        response.json()
    except ValueError:
        pytest.fail("Invalid JSON in response")

def test_organizations_list_unauthorized():
    response = requests.get(urljoin(BASE_URL, "/v0.1/orgs"))

    assert response.status_code == 401