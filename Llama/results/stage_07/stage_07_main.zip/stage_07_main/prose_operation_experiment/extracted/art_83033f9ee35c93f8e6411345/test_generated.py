# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime
import json

BASE_URL = "http://openapi.test"

def test_application_list():
    headers = {
        'client-request-id': '9C4D50EE-2D56-4CD3-8152-34347DC9F2B0',
        'ocp-date': datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT'),
        'return-client-request-id': 'True'
    }
    
    params = {
        'api-version': '1.0.0',
        'maxresults': 10,
        'timeout': 30
    }

    try:
        response = requests.get(f"{BASE_URL}/applications", headers=headers, params=params)
        response.raise_for_status()
        
        assert response.status_code == 200
        
        data = response.json()
        assert isinstance(data, dict)
        assert 'odata.nextLink' in data
        assert 'value' in data
        assert len(data['value']) > 0
    except requests.exceptions.RequestException as err:
        pytest.fail(str(err))

    try:
        response = requests.get(f"{BASE_URL}/applications", headers=headers, params=params)
        response.raise_for_status()
        
        assert response.status_code == 200
        
        data = response.json()
        assert isinstance(data, dict)
        assert 'odata.nextLink' in data
        assert 'value' in data
        assert len(data['value']) > 0
    except requests.exceptions.RequestException as err:
        pytest.fail(str(err))