# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_partners_stores():
    url = f"{BASE_URL}/partners/stores.json"
    params = {
        "partner_code": "your_partner_code",
        "auth_token": "your_auth_token",
        "from": "2022-01-01",
        "to": "2022-12-31",
        "page": 1
    }
    
    response = requests.get(url, params=params)
    
    assert response.status_code == 200
    
    try:
        response_json = response.json()
        assert isinstance(response_json, list)
        
        # Check if each item in the list is a dictionary
        for item in response_json:
            assert isinstance(item, dict)
            
            # Check if the dictionary contains required keys
            required_keys = ["code", "stats"]
            assert all(key in item for key in required_keys)
            
            # Check if the stats dictionary contains required keys
            required_stats_keys = ["best_sold", "conversions", "currency", "daily_visits", 
                                   "from", "new_vs_returning_customers", "new_vs_returning_orders", 
                                   "orders", "payment_methods", "referrers", "region_orders", 
                                   "shipping_methods", "to", "visits"]
            assert all(key in item["stats"] for key in required_stats_keys)
            
            # Check if the best_sold array contains dictionaries with required keys
            for sold_item in item["stats"]["best_sold"]:
                required_best_sold_keys = ["count", "product_id", "product_name", "total"]
                assert all(key in sold_item for key in required_best_sold_keys)
                
            # Check if the conversions dictionary contains required keys
            for conversion_key in item["stats"]["conversions"].keys():
                required_conversions_keys = {"added_to_cart", "checkout", "paid"}
                assert required_conversions_keys.issubset(set(item["stats"]["conversions"][conversion_key].keys()))
                
            # Check if the daily_visits array contains dictionaries with required keys
            for visit_item in item["stats"]["daily_visits"]:
                required_daily_visits_keys = ["date", "visits"]
                assert all(key in visit_item for key in required_daily_visits_keys)
                
            # Check if the new_vs_returning_customers dictionary contains required keys
            for customer_key in item["stats"]["new_vs_returning_customers"].keys():
                required_new_vs_returning_customers_keys = {"global", "per_day"}
                assert required_new_vs_returning_customers_keys.issubset(set(item["stats"]["new_vs_returning_customers"][customer_key].keys()))
                
                # Check if the per_day array contains dictionaries with required keys
                for day_item in item["stats"]["new_vs_returning_customers"][customer_key]["per_day"]:
                    required_per_day_keys = ["date", "new", "returning"]
                    assert all(key in day_item for key in required_per_day_keys)
                    
            # Check if the new_vs_returning_orders dictionary contains required keys
            for order_key in item["stats"]["new_vs_returning_orders"].keys():
                required_new_vs_returning_orders_keys = {"global", "per_day"}
                assert required_new_vs_returning_orders_keys.issubset(set(item["stats"]["new_vs_returning_orders"][order_key].keys()))
                
                # Check if the per_day array contains dictionaries with required keys
                for day_item in item["stats"]["new_vs_returning_orders"][order_key]["per_day"]:
                    required_per_day_keys = ["date", "new", "returning"]
                    assert all(key in day_item for key in required_per_day_keys)
                    
            # Check if the orders dictionary contains required keys
            for order_key in item["stats"]["orders"].keys():
                required_orders_keys = {"average", "count", "data", "total"}
                assert required_orders_keys.issubset(set(item["stats"]["orders"][order_key].keys()))
                
                # Check if the data array contains dictionaries with required keys
                for data_item in item["stats"]["orders"][order_key]["data"]:
                    required_data_keys = {"average", "count", "date", "paid", "pending", "total"}
                    assert all(key in data_item for key in required_data_keys)
                    
            # Check if the payment_methods array contains dictionaries with required keys
            for method_item in item["stats"]["payment_methods"]:
                required_payment_method_keys = ["count", "name"]
                assert all(key in method_item for key in required_payment_method_keys)
                
            # Check if the referrers array contains dictionaries with required keys
            for referrer_item in item["stats"]["referrers"]:
                required_referrer_keys = ["count", "source"]
                assert all(key in referrer_item for key in required_referrer_keys)
                
            # Check if the region_orders dictionary contains required keys
            for order_key in item["stats"]["region_orders"].keys():
                required_region_orders_keys = {"display_mode", "regions_orders"}
                assert required_region_orders_keys.issubset(set(item["stats"]["region_orders"][order_key].keys()))
                
                # Check if the regions_orders array contains dictionaries with required keys
                for order_item in item["stats"]["region_orders"][order_key]["regions_orders"]:
                    required_order_keys = {"code", "country", "orders"}
                    assert all(key in order_item for key in required_order_keys)
                    
            # Check if the shipping_methods array contains dictionaries with required keys
            for method_item in item["stats"]["shipping_methods"]:
                required_shipping_method_keys = ["count", "name"]
                assert all(key in method_item for key in required_shipping_method_keys)
                
            # Check if the visits integer is valid
            assert isinstance(item["stats"]["visits"], int)
            
    except AssertionError as err:
        print(f"Assertion error: {err}")
        assert False

def test_get_partners_stores_invalid_from():
    url = f"{BASE_URL}/partners/stores.json"
    params = {
        "partner_code": "your_partner_code",
        "auth_token": "your_auth_token",
        "from": "invalid_date",
        "to": "2022-12-31",
        "page": 1
    }
    
    response = requests.get(url, params=params)
    
    assert response.status_code == 400
    
    try:
        response_json = response.json()
        assert isinstance(response_json, dict)
        
        # Check if the response contains required keys
        required_keys = ["error", "field", "message"]
        assert all(key in response_json for key in required_keys)
        
    except AssertionError as err:
        print(f"Assertion error: {err}")
        assert False