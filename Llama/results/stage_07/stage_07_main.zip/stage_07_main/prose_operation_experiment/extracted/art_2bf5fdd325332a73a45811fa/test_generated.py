# -*- coding: utf-8 -*-
"""
Tests for Operation slice API
"""

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_diary_allocation():
    """
    Test getting a specific diary allocation by its unique Object ID (OID)
    """

    # Construct the full path for the API request
    path = f"{BASE_URL}/v2/tier1/{'staff'}_/diary/allocations/{'allocation'}_"
    
    # Send a GET request to the API endpoint
    response = requests.get(path)

    # Check if the request was successful
    assert response.status_code == 200

    # Check if the response is in JSON format
    assert response.headers['Content-Type'] == 'application/json'

    # Parse the JSON response into a Python dictionary
    data = response.json()

    # Assert that the parsed data matches the expected schema
    assert data['AppointmentType']
    assert data['ETag']
    assert data['End']
    assert data['OID']
    assert data['Staff']
    assert data['Start']

if __name__ == "__main__":
    pytest.main([__file__])