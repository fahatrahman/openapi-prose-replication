# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_cloudfunctions_projects_locations_functions_rollback_function_upgrade_traffic():
    url = f"{BASE_URL}/v2/{'function-name'}:rollbackFunctionUpgradeTraffic"
    headers = {}
    params = {
        "$.xgafv": "1",
        "access_token": None,
        "alt": "json",
        "callback": None,
        "fields": None,
        "key": None,
        "oauth_token": None,
        "prettyPrint": "false",
        "quotaUser": None,
        "upload_protocol": None,
        "uploadType": None,
    }
    body = {
        "name": "function-name",
    }

    response = requests.post(
        url=url,
        headers=headers,
        params=params,
        json=body,
    )

    assert response.status_code == 200