import os
import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def client():
    return requests.Session()

def test_get_thumbnail(client):
    id = 123  # replace with actual test id
    url = f"{BASE_URL}/resources/media/{id}/thumbnail.jpg"

    response = client.get(url)

    assert response.status_code == 200, f"Expected status code 200, got {response.status_code}"
    # Add additional assertions based on expected response structure