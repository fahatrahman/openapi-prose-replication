import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_template():
    headers = {
        "carbone-version": 4,
        "Authorization": "Bearer eyJhbGci..."
    }
    params = {
        "templateId": "valid-template-id"
    }
    response = requests.delete(f"{BASE_URL}/template/{params['templateId']}", headers=headers)
    
    assert response.status_code == 200
    assert response.json() == {"success": True}

def test_delete_template_not_found():
    headers = {
        "carbone-version": 4,
        "Authorization": "Bearer eyJhbGci..."
    }
    params = {
        "templateId": "nonexistent-template-id"
    }
    response = requests.delete(f"{BASE_URL}/template/{params['templateId']}", headers=headers)
    
    assert response.status_code == 404
    assert response.json() == {"error": "Template not found", "success": False}

def test_delete_template_unauthorized():
    headers = {
        "carbone-version": 4,
        "Authorization": "Bearer invalid-token"
    }
    params = {
        "templateId": "valid-template-id"
    }
    response = requests.delete(f"{BASE_URL}/template/{params['templateId']}", headers=headers)
    
    assert response.status_code == 401
    assert response.json() == {"error": "Unauthorized, please provide a valid API key on the 'Authorization' header", "success": False}

def test_delete_template_invalid_id():
    headers = {
        "carbone-version": 4,
        "Authorization": "Bearer eyJhbGci..."
    }
    params = {
        "templateId": "invalid-template-id"
    }
    response = requests.delete(f"{BASE_URL}/template/{params['templateId']}", headers=headers)
    
    assert response.status_code == 400
    assert response.json() == {"error": "Invalid templateId", "success": False}