import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"

@pytest.fixture
def auth():
    credentials = service_account.Credentials.from_service_account_file('path/to/credentials.json')
    return credentials

def test_create_rollup_property(auth):
    url = f"{BASE_URL}/v1alpha/properties:createRollupProperty"

    request_body = {
        "rollupProperty": {
            "displayName": "Test Rollup Property",
            "timeZone": "America/Los_Angeles",
            "currencyCode": "USD",
            "propertyType": "PROPERTY_TYPE_ROLLUP"
        },
        "sourceProperties": ["properties/source1", "properties/source2"]
    }

    headers = {
        "Content-Type": "application/json"
    }

    response = requests.post(url, json=request_body, headers=headers, auth=auth)

    assert response.status_code == 200
    assert response.json()["rollupProperty"]["displayName"] == "Test Rollup Property"