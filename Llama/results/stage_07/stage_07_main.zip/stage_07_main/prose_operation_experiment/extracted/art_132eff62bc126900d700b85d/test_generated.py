import pytest
import requests
from urllib.parse import urlencode

BASE_URL = "http://openapi.test"

def test_list_client_users():
    url = f"{BASE_URL}/v2beta1/accounts/{'account_id'}/clients/{'client_account_id'}users"
    params = {
        '$.xgafv': '1',
        'access_token': '',
        'alt': 'json',
        'callback': '',
        'fields': '',
        'key': '',
        'oauth_token': '',
        'prettyPrint': 'false',
        'quotaUser': '',
        'uploadProtocol': '',
        'uploadType': ''
    }
    params['pageSize'] = 10
    params['pageToken'] = ''

    headers = {'Accept': 'application/json'}
    response = requests.get(url, headers=headers, params=urlencode(params))
    assert response.status_code == 200
    response.raise_for_status()