import pytest
import requests

BASE_URL = "http://openapi.test"

def test_wallet_transaction_execute():
    headers = {
        "PLAID-CLIENT-ID": "your_client_id",
        "PLAID-SECRET": "your_secret",
        "Plaid-Version": "2020-09-14"
    }
    payload = {
        "client_id": "your_client_id",
        "secret": "your_secret",
        "wallet_id": "your_wallet_id",
        "idempotency_key": "unique_idempotency_key",
        "reference": "TXN-123456",
        "amount": {
            "iso_currency_code": "GBP",
            "value": 100.00
        },
        "counterparty": {
            "name": "John Doe",
            "numbers": {
                "ibans": ["GB12BARC2000000012345678"]
            }
        }
    }
    response = requests.post(f"{BASE_URL}/wallet/transaction/execute", json=payload, headers=headers)
    assert response.status_code == 200
    assert response.json()["status"] == "EXECUTED"
    assert "transaction_id" in response.json()