import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

def get_currencies():
    url = f"{BASE_URL}/currencies/"
    response = SESSION.get(url)
    response.raise_for_status()
    return response.json()["currencies"]

def test_get_currencies(mocker):
    mock_response = {
        "currencies": [
            {
                "code": "GBP",
                "name": "Pound",
                "minDeposit": "5.00",
                "maxDeposit": "100.00",
                "minWithdrawal": "20.00",
                "maxWithdrawal": "1000.00",
                "exchangeRate": "1.00",
            }
        ]
    }

    mocker.patch("requests.get", side_effect=[mock_response])

    currencies = get_currencies()

    assert len(currencies) == 1
    assert currencies[0]["code"] == "GBP"
    assert currencies[0]["name"] == "Pound"
    assert currencies[0]["minDeposit"] == "5.00"
    assert currencies[0]["maxDeposit"] == "100.00"
    assert currencies[0]["minWithdrawal"] == "20.00"
    assert currencies[0]["maxWithdrawal"] == "1000.00"
    assert currencies[0]["exchangeRate"] == "1.00"