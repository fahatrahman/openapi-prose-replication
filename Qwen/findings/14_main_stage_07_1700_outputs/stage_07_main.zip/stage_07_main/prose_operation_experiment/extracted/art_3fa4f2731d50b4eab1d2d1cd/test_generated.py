import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_all_cis_line_type_tags():
    employer_id = "example_employer_id"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    url = f"{BASE_URL}/Employer/{employer_id}/CisLineTypes/Tags"
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert response.headers["Content-Type"] == "application/json"
    assert isinstance(response.json(), dict)
    assert "LinkCollection" in response.json()

# Add more tests for other status codes if needed