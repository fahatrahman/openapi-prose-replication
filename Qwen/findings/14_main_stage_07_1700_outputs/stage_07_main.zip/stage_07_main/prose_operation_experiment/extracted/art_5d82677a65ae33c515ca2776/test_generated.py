import pytest
import requests

BASE_URL = "http://openapi.test"

def test_update_source():
    url = f"{BASE_URL}/v1/projects/locations/sources/source-name"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "displayName": "Updated Source Name",
        "description": "Updated description"
    }
    params = {
        "requestId": "YOUR_REQUEST_ID",
        "updateMask": "displayName,description"
    }

    response = requests.patch(url, headers=headers, json=payload, params=params)

    assert response.status_code == 200
    assert "name" in response.json()
    assert response.json()["displayName"] == "Updated Source Name"
    assert response.json()["description"] == "Updated description"