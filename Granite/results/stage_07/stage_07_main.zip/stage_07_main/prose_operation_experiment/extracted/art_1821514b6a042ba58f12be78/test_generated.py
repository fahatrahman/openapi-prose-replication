import os
import pytest
import requests
from urllib3.exceptions import InsecureRequestWarning

# Ignore warnings from urllib3
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

BASE_URL = "http://openapi.test"

@pytest.fixture
def dynamic_targeting_keys():
    url = f"{BASE_URL}/userprofiles/{profile_id}/dynamicTargetingKeys"

    headers = {
        "accept": "application/json",
    }

    params = {
        "profile_id": profile_id,
    }

    response = requests.get(url, headers=headers, params=params, verify=False)

    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Failed to fetch dynamic targeting keys: {response.text}")

def test_dynamic_targeting_keys(dynamic_targeting_keys):
    assert isinstance(dynamic_targeting_keys, dict)
    assert "dynamicTargetingKeys" in dynamic_targeting_keys
    assert all("name" in dt and "objectId" in dt for dt in dynamic_targeting_keys["dynamicTargetingKeys"])