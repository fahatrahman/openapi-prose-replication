import pytest
import requests
from urllib.parse import urlencode

BASE_URL = "http://openapi.test"

def test_accounts_authinfo():
    params = {
        "_xgafv": "1",
        "access_token": None,
        "alt": "json",
        "callback": None,
        "fields": None,
        "key": None,
        "oauth_token": None,
        "prettyPrint": False,
        "quotaUser": None,
        "upload_protocol": None,
        "uploadType": None
    }
    
    headers = {"Authorization": f"Bearer {params['access_token']}"}
    query_string = urlencode({k: v for k, v in params.items() if v is not None})

    url = f"{BASE_URL}/accounts/authinfo?{query_string}"
    response = requests.get(url, headers=headers)

    assert response.status_code == 200
    assert response.json()["kind"] == "content#accountsAuthInfoResponse"