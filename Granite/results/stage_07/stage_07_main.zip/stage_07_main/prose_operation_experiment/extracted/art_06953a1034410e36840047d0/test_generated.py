import os
import pytest
import requests
from requests_toolbelt import MultipartEncoder

BASE_URL = "http://openapi.test"

@pytest.fixture
def http_server():
    """Mock HTTP server"""
    class MockResponse:
        def __init__(self, json_data, status_code):
            self.json_data = json_data
            self.status_code = status_code

        def json(self):
            return self.json_data

    return MockResponse

@pytest.mark.usefixtures("http_server")
class TestListDevices:

    def test_list_devices(self, http_server):
        mock_response = http_server({"Devices": [], "NextToken": None}, 200)
        headers = {"Authorization": "mock_auth_value",
                   "X-Amz-Algorithm": "EventSource",
                   "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
                   "X-Amz-Date": "20170919T000000Z",
                   "X-Amz-Credential": "aki/20170919/us-east-1/s3/aws4_request",
                   "X-Amz-Security-Token": "mock_security_token",
                   "X-Amz-Signature": "mock_signature_value",
                   "X-Amz-SignedHeaders": "host;x-amz-algorithm;x-amz-content-sha256;x-amz-date;x-amz-credential;x-amz-security-token;x-amz-signature",
                   }
        
        response = requests.get(f"{BASE_URL}/devices", headers=headers)
        assert response.status_code == 200
        assert response.json() == {"Devices": [], "NextToken": None}