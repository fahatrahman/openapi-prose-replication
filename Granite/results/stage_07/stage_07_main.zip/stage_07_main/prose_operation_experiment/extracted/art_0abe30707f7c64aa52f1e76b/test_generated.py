import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

def get_server_type(server_type_id):
    session = requests.Session()
    retry = Retry(total=3, backoff_factor=0.1, status_forcelist=[ 429, 500, 502, 503, 504 ])
    adapter = HTTPAdapter(max_retries=retry)
    session.mount('http://', adapter)

    url = f"{BASE_URL}/server_types/{server_type_id}"
    response = session.get(url)
    response.raise_for_status()
    return response.json()

@pytest.fixture
def server_type():
    return get_server_type(1)

def test_server_type(server_type):
    assert server_type["server_type"]["id"] == 1
    assert server_type["server_type"]["name"] == "cx11"
    assert server_type["server_type"]["description"] == "CX11"
    assert server_type["server_type"]["cores"] == 1
    assert server_type["server_type"]["memory"] == 1
    assert server_type["server_type"]["disk"] == 24
    assert server_type["server_type"]["deprecated"] == False
    assert server_type["server_type"]["prices"][0]["location"] == "fsn1"
    assert server_type["server_type"]["storage_type"] == "local"
    assert server_type["server_type"]["cpu_type"] == "shared"
    assert server_type["server_type"]["architecture"] == "x86"