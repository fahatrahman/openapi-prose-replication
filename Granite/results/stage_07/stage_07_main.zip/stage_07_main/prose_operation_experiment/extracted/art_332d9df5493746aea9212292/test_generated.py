import os
import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def client():
    return requests.Session()

def get_sentences(client, limit=1):
    """Test getting sentences"""
    url = f"{BASE_URL}/sentences"
    response = client.get(url, params={"limit": limit})
    response.raise_for_status()
    data = response.json()
    assert "data" in data
    assert "items" in data["data"]
    assert len(data["data"]["items"]) <= limit
    return data["data"]["items"]