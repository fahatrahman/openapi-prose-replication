import pytest
import requests

BASE_URL = "http://openapi.test"

def test_disable_service():
    url = f"{BASE_URL}/v1/projects/123/services/serviceusage.googleapis.com:disable"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "checkIfServiceHasUsage": "CHECK",
        "disableDependentServices": True
    }
    params = {
        "$.xgafv": "2",
        "access_token": "YOUR_ACCESS_TOKEN",
        "alt": "json",
        "prettyPrint": False,
        "quotaUser": "user@example.com",
        "upload_protocol": "raw"
    }
    response = requests.post(url, headers=headers, json=payload, params=params)
    assert response.status_code == 200
    assert response.json().get("name") is not None
    assert response.json().get("done") is False

if __name__ == "__main__":
    pytest.main()