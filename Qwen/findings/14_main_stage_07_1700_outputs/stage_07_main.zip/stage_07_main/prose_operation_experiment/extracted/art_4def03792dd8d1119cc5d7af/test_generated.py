import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_locations():
    url = f"{BASE_URL}/v1/projects/my-project/locations"
    params = {
        "filter": "displayName=tokyo",
        "pageSize": 1,
        "prettyPrint": True
    }
    headers = {
        "Authorization": "Bearer YOUR_OAUTH_TOKEN"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "locations" in data
    assert isinstance(data["locations"], list)
    assert len(data["locations"]) > 0
    assert "name" in data["locations"][0]
    assert "displayName" in data["locations"][0]

if __name__ == "__main__":
    pytest.main([__file__])