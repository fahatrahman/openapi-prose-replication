import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retry logic
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

# Replace '{API Key}' with actual API key for testing
API_KEY = "{API Key}"
headers = {"ApiKey": API_KEY}

@pytest.fixture
def get_projects():
    response = session.get(f"{BASE_URL}/projects", headers=headers)
    response.raise_for_status()
    return response.json()

def test_get_projects(get_projects):
    projects = get_projects
    assert isinstance(projects, list)
    project = projects[0]
    assert all(key in project for key in ["created", "description", "id", "lastModified", "name", "settings", "thumbnailUri"])
    assert isinstance(project["id"], str)
    assert isinstance(project["created"], str)
    assert isinstance(project["lastModified"], str)
    assert isinstance(project["name"], str)
    assert isinstance(project["description"], (str, type(None)))
    assert isinstance(project["settings"], dict)
    assert isinstance(project["thumbnailUri"], (str, type(None)))