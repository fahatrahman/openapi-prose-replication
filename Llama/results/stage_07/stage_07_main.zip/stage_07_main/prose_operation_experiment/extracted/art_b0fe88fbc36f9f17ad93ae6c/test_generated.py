# pylint: disable=C0103
import pytest
import requests
from urllib.parse import urlencode

BASE_URL = "http://openapi.test"

def test_list_operations():
    """Test listing operations."""
    params = {
        "key": "your_api_key",
        "filter": "serviceName={service-name}.googleapis.com",
        "pageSize": 50,
    }
    query_string = urlencode(params)
    url = f"{BASE_URL}/v1/operations?{query_string}"
    headers = {"Content-Type": "application/json"}

    response = requests.get(url, headers=headers)

    assert response.status_code == 200
    response_data = response.json()
    assert isinstance(response_data, dict)
    assert "nextPageToken" in response_data
    assert isinstance(response_data["nextPageToken"], str)
    assert "operations" in response_data
    assert isinstance(response_data["operations"], list)

@pytest.mark.parametrize("filter_value", [
    "serviceName={service-name}.googleapis.com",
    "serviceName={service-name}.googleapis.com AND startTime>=\"2022-01-01\"",
    "serviceName={service-name}.googleapis.com AND status=done",
    "serviceName={service-name}.googleapis.com AND (status=done OR startTime>=\"2022-01-01\")"
])
def test_filter_operations(filter_value):
    """Test filtering operations."""
    params = {
        "key": "your_api_key",
        "filter": filter_value,
        "pageSize": 50,
    }
    query_string = urlencode(params)
    url = f"{BASE_URL}/v1/operations?{query_string}"
    headers = {"Content-Type": "application/json"}

    response = requests.get(url, headers=headers)

    assert response.status_code == 200
    response_data = response.json()
    assert isinstance(response_data, dict)
    assert "nextPageToken" in response_data
    assert isinstance(response_data["nextPageToken"], str)
    assert "operations" in response_data
    assert isinstance(response_data["operations"], list)