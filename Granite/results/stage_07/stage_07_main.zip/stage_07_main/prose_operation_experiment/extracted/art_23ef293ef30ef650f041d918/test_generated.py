import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = "path/to/your/service_account.json"

@pytest.fixture
def token():
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )

    access_token_request = {
        "vmToken": "qunbu://hqijk.ogjjes.dfz/phcucgv/ekpm/vminkgxan/apmndjqqx-yfnotwzk-pmlycxcs"
    }

    response = requests.post(
        f"{BASE_URL}/v1beta1/zynntaco/{credentials.owner.email}/yzvrewumc/{credentials.project_id}/cgcrzjrvGrfcbixe/{credentials.instance_id}/generateAccessToken",
        json=access_token_request,
        headers={"Authorization": f"Bearer {credentials.token}"}
    )

    assert response.status_code == 200
    return response.json()

def test_generate_access_token(token):
    assert "accessToken" in token
    assert "expiresIn" in token
    assert "scope" in token
    assert "tokenType" in token