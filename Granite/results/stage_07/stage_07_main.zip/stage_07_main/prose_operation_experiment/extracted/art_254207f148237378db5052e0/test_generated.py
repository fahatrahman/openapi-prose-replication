import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_PATH = os.environ.get("CREDENTIALS_PATH")

@pytest.fixture(scope="session", autouse=True)
def setup():
    if not CREDENTIALS_PATH:
        pytest.skip("Skipping test because CREDENTIALS_PATH is not set.")

    credentials = service_account.Credentials.from_service_account_file(
        CREDENTIALS_PATH, scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )
    requests.auth = (credentials.username, credentials.password)

def test_invalidate_approval_request(mocker):
    endpoint = "/v1/projects/{}/approvalRequests/invalidate".format("your_project_id")
    mock_response = {
        "approve": None,
        "dismiss": None,
        "name": "projects/your_project_id/approvalRequests/some_approval_request",
        "requestTime": "2022-01-01T00:00:00Z",
        "requestedDuration": "3600s",
        "requestedExpiration": "2022-01-02T00:00:00Z",
        "requestedLocations": {},
        "requestedReason": {"detail": "Test reason", "type": "CUSTOMER_INITIATED_SUPPORT"},
        "requestedResourceName": "services/compute.googleapis.com/instances/instance-name",
        "requestedResourceProperties": {},
    }

    mocker.patch("requests.post", return_value=requests.Response(), autospec=True)
    requests.post(
        f"{BASE_URL}{endpoint}", json={"invalidateApprovalRequestMessage": {}}
    ).return_value.json.return_value = mock_response

    response = requests.post(f"{BASE_URL}{endpoint}", json={"invalidateApprovalRequestMessage": {}})

    assert response.status_code == 200
    assert response.json() == mock_response