import pytest
import requests

BASE_URL = "http://openapi.test"

def test_search_success():
    url = f"{BASE_URL}/v3/search/test"
    params = {
        "route_types": [0, 1],
        "latitude": -37.81,
        "longitude": 145.12,
        "max_distance": 5000,
        "include_outlets": True,
        "match_stop_by_suburb": True,
        "match_route_by_suburb": True,
        "match_stop_by_gtfs_stop_id": False,
        "devid": "your_developer_id",
        "signature": "your_authentication_signature"
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    result = response.json()
    assert "outlets" in result
    assert "routes" in result
    assert "stops" in result
    assert "status" in result

def test_search_invalid_request():
    url = f"{BASE_URL}/v3/search/123"
    params = {
        "route_types": [0, 1],
        "latitude": -37.81,
        "longitude": 145.12,
        "max_distance": 5000,
        "include_outlets": True,
        "match_stop_by_suburb": True,
        "match_route_by_suburb": True,
        "match_stop_by_gtfs_stop_id": False,
        "devid": "your_developer_id",
        "signature": "your_authentication_signature"
    }
    response = requests.get(url, params=params)
    assert response.status_code == 400
    result = response.json()
    assert "error" in result

def test_search_access_denied():
    url = f"{BASE_URL}/v3/search/test"
    params = {
        "route_types": [0, 1],
        "latitude": -37.81,
        "longitude": 145.12,
        "max_distance": 5000,
        "include_outlets": True,
        "match_stop_by_suburb": True,
        "match_route_by_suburb": True,
        "match_stop_by_gtfs_stop_id": False,
        "devid": "invalid_developer_id",
        "signature": "invalid_authentication_signature"
    }
    response = requests.get(url, params=params)
    assert response.status_code == 403
    result = response.json()
    assert "error" in result