import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Define retry strategy for requests
session = requests.Session()
retries = Retry(total=3, backoff_factor=0.1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

@pytest.fixture
def create_comment():
    def _create_comment(topic_id, comment):
        url = f"{BASE_URL}/api/discussions/topics/{topic_id}/comments"
        response = session.post(url, json=comment)
        response.raise_for_status()
        return response.json()

    yield _create_comment

def test_create_comment(create_comment):
    topic_id = 123  # Replace with actual topic ID
    comment = {
        "author": {"id": 456},  # Replace with actual user ID
        "authorName": "Test User",
        "created": "2022-01-01T00:00:00Z",
        "entry": {"id": 789},  # Replace with actual entry ID
        "id": 1,
        "message": "This is a test comment."
    }
    response = create_comment(topic_id, comment)
    assert response["id"] == 1
    assert response["author"]["id"] == 456
    assert response["authorName"] == "Test User"
    assert response["created"] == "2022-01-01T00:00:00Z"
    assert response["entry"]["id"] == 789
    assert response["message"] == "This is a test comment."