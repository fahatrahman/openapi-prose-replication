import pytest
import requests

BASE_URL = "http://openapi.test"

def test_search_paragraph():
    reference = "test_reference"
    url = f"{BASE_URL}/api/Search/Paragraph/{reference}"
    
    response = requests.get(url)
    
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert 'id' in response.json()
    assert 'title' in response.json()
    assert 'titleChain' in response.json()
    assert 'subSections' in response.json() and isinstance(response.json()['subSections'], list)

if __name__ == "__main__":
    pytest.main()