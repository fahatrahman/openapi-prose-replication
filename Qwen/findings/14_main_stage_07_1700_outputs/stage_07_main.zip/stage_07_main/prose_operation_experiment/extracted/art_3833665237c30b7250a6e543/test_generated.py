import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_datafeed(mocker):
    merchant_id = "test_merchant_id"
    datafeed_id = "test_datafeed_id"
    access_token = "test_access_token"
    
    mock_response = {
        "attributeLanguage": "en",
        "contentLanguage": "en",
        "contentType": "text/csv",
        "fetchSchedule": {},
        "fileName": "example.csv",
        "format": {},
        "id": "123456789",
        "intendedDestinations": ["Shopping"],
        "kind": "content#datafeed",
        "name": "Test Datafeed",
        "targetCountry": "US",
        "targets": []
    }
    
    mocker.patch('requests.get', return_value=mock_response)
    
    response = requests.get(
        f"{BASE_URL}/{merchant_id}/datafeeds/{datafeed_id}",
        params={
            "_xgafv": "2",
            "access_token": access_token,
            "alt": "json",
            "prettyPrint": False,
            "quotaUser": "test_quota_user"
        },
        headers={"Authorization": f"Bearer {access_token}"}
    )
    
    assert response.status_code == 200
    assert response.json() == mock_response