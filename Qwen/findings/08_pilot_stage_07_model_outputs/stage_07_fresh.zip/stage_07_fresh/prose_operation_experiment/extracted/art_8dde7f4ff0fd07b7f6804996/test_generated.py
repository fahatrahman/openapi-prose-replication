import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_annotations():
    url = f"{BASE_URL}/v1/projects/locations/datasets/dataItems/annotations"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token",
        "alt": "json",
        "fields": "*",
        "key": "your_api_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": False,
        "quotaUser": "user@example.com",
        "uploadProtocol": "raw",
        "uploadType": "multipart",
        "parent": "projects/your-project-id/locations/your-location/datasets/your-dataset-id/dataItems/your-data-item-id/tjmyXrszz/your-stzf-niit",
        "filter": "field=value",
        "orderBy": "field",
        "pageSize": 10,
        "pageToken": "",
        "readMask": "field1,field2"
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    assert "annotations" in response.json()

if __name__ == "__main__":
    pytest.main()