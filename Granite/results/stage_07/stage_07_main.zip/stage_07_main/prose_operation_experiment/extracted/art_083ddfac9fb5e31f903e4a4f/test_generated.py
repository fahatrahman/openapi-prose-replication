import pytest
import requests
from requests.auth import HTTPBasicAuth
BASE_URL = "http://openapi.test"

@pytest.fixture
def test_move_file():
    url = f"{BASE_URL}/v1beta1/{workspace}/moveFile"
    headers = {
        "Content-Type": "application/json",
    }
    move_file_request = {
        "path": "old_path",
        "newPath": "new_path",
    }

    response = requests.post(url, json=move_file_request, headers=headers, verify=False)
    assert response.status_code == 200
    return response.json()