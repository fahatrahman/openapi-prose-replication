# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_nearest_place():
    # Test case 1: Successful response
    params = {
        "lat": "23.2N",
        "lon": "15.3E",
        "language": "en"
    }
    headers = {"X-API-Key": "your_api_key"}
    response = requests.get(f"{BASE_URL}/nearest_place", params=params, headers=headers)
    assert response.status_code == 200
    assert response.json()["adm_area1"] == "England"
    assert response.json()["adm_area2"] == "Greater London"
    assert response.json()["country"] == "United Kingdom"
    assert response.json()["lat"] == "23.2N"
    assert response.json()["lon"] == "15.3E"
    assert response.json()["name"] == "London"
    assert response.json()["place_id"] == "london"
    assert response.json()["timezone"] == "Europe/London"
    assert response.json()["type"] == "settlement"

    # Test case 2: Invalid API key
    headers = {}
    response = requests.get(f"{BASE_URL}/nearest_place", params=params, headers=headers)
    assert response.status_code == 403
    error_response = response.json()
    assert isinstance(error_response, dict) and "detail" in error_response

    # Test case 3: Validation error
    params = {
        "lat": "invalid_lat",
        "lon": "15.3E",
        "language": "en"
    }
    headers = {"X-API-Key": "your_api_key"}
    response = requests.get(f"{BASE_URL}/nearest_place", params=params, headers=headers)
    assert response.status_code == 422
    error_response = response.json()
    assert isinstance(error_response, list)

    # Test case 4: Maximum requests per minute limit exceeded
    for _ in range(10):
        params = {
            "lat": "23.2N",
            "lon": "15.3E",
            "language": "en"
        }
        headers = {"X-API-Key": "your_api_key"}
        response = requests.get(f"{BASE_URL}/nearest_place", params=params, headers=headers)
        assert response.status_code != 429
    response = requests.get(f"{BASE_URL}/nearest_place", params=params, headers=headers)
    assert response.status_code == 429
    error_response = response.json()
    assert isinstance(error_response, dict) and "detail" in error_response

    # Test case 5: Maximum requests per day limit exceeded
    for _ in range(60):
        params = {
            "lat": "23.2N",
            "lon": "15.3E",
            "language": "en"
        }
        headers = {"X-API-Key": "your_api_key"}
        response = requests.get(f"{BASE_URL}/nearest_place", params=params, headers=headers)
        assert response.status_code != 402
    response = requests.get(f"{BASE_URL}/nearest_place", params=params, headers=headers)
    assert response.status_code == 402
    error_response = response.json()
    assert isinstance(error_response, dict) and "detail" in error_response

    # Test case 6: General request error
    params = {
        "lat": "invalid_lat",
        "lon": "invalid_lon"
    }
    headers = {"X-API-Key": "your_api_key"}
    response = requests.get(f"{BASE_URL}/nearest_place", params=params, headers=headers)
    assert response.status_code == 400
    error_response = response.json()
    assert isinstance(error_response, dict) and "detail" in error_response