import pytest
import requests

BASE_URL = "http://openapi.test"

def test_cloudkms_projects_locations_list():
    url = f"{BASE_URL}/v1/projects/my-project/locations"
    params = {
        "filter": "status=ACTIVE",
        "pageSize": 10,
        "pageToken": "",
        "_xgafv": "1",
        "access_token": "fake_access_token",
        "alt": "json",
        "callback": "",
        "fields": "*",
        "key": "fake_key",
        "oauth_token": "fake_oauth_token",
        "prettyPrint": True,
        "quotaUser": "user@example.com",
        "uploadProtocol": "raw",
        "uploadType": "multipart"
    }
    headers = {
        "Authorization": "Bearer fake_access_token"
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    assert "locations" in response.json()
    assert len(response.json()["locations"]) > 0