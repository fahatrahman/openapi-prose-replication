import pytest
import requests

BASE_URL = "http://openapi.test"

def test_app_price_points_get_collection():
    url = f"{BASE_URL}/v1/appPricePoints"
    params = {
        "filter[priceTier]": ["tier1", "tier2"],
        "filter[territory]": ["territory1", "territory2"],
        "fields[appPricePoints]": ["customerPrice", "proceeds"],
        "limit": 50,
        "include": ["priceTier", "territory"],
        "fields[territories]": ["currency"]
    }
    headers = {
        "Authorization": "Bearer your_access_token_here"
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 200
    data = response.json()
    assert "data" in data
    assert isinstance(data["data"], list)
    for item in data["data"]:
        assert "type" in item
        assert item["type"] == "appPricePoints"
        assert "id" in item
        assert "attributes" in item
        attributes = item["attributes"]
        assert "customerPrice" in attributes
        assert "proceeds" in attributes
        if "priceTier" in item:
            assert "relationships" in item
            price_tier = item["relationships"]["priceTier"]
            assert "data" in price_tier
            assert "id" in price_tier["data"]
            assert "type" in price_tier["data"]
            assert price_tier["data"]["type"] == "appPriceTiers"
        if "territory" in item:
            assert "relationships" in item
            territory = item["relationships"]["territory"]
            assert "data" in territory
            assert "id" in territory["data"]
            assert "type" in territory["data"]
            assert territory["data"]["type"] == "territories"