import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.fixture
def teams():
    path = "/{format}/teams".format(format="JSON")
    response = SESSION.get(BASE_URL + path, headers={"Ocp-Apim-Subscription-Key": "YOUR_SUBSCRIPTION_KEY"})
    assert response.status_code == 200
    return response.json()

def test_teams(teams):
    assert isinstance(teams, list)
    for team in teams:
        assert all(key in team for key in ["Active", "ApRank", "Conference", "GlobalTeamID", "Name", "Stadium", "TeamID", "Wins", "Losses"])
        assert isinstance(team["GlobalTeamID"], int)
        assert isinstance(team["Name"], str)
        assert isinstance(team["Stadium"]["Name"], str) if "Stadium" in team else True