# -*- coding: utf-8 -*-
"""Tests for Operation slice."""

import pytest
from requests import Response

BASE_URL = "http://openapi.test"

def test_get_articles():
    """Test getting articles."""
    
    url = f"{BASE_URL}/content/all/all.json"
    params = {"limit": 10, "offset": 5}
    
    response: Response = pytest.requests.get(url, params=params)
    
    assert response.status_code == 200
    
    data = response.json()
    
    assert isinstance(data, dict)
    assert "copyright" in data
    assert isinstance(data["copyright"], str)
    
    assert "num_results" in data
    assert isinstance(data["num_results"], int)
    
    assert "results" in data
    assert isinstance(data["results"], list)
    
    for article in data["results"]:
        assert isinstance(article, dict)
        
        required_keys = ["abstract", "blog_name", "byline", "created_date",
                         "des_facet", "geo_facet", "headline", "item_type",
                         "kicker", "material_type_facet", "multimedia",
                         "org_facet", "per_facet", "published_date",
                         "related_urls", "section", "short_url", "source",
                         "subsection", "thumbnail_standard", "title",
                         "updated_date", "url"]
        
        for key in required_keys:
            assert key in article
            
            if key in ["des_facet", "geo_facet", "per_facet", "multimedia",
                       "related_urls"]:
                assert isinstance(article[key], list)
                
            elif key in ["multimedia", "related_urls"]:
                for item in article[key]:
                    assert isinstance(item, dict)
                    
            else:
                assert isinstance(article[key], (str, int))
                
def test_get_articles_limit():
    """Test getting articles with limit parameter."""
    
    url = f"{BASE_URL}/content/all/all.json"
    params = {"limit": 2, "offset": 0}
    
    response: Response = pytest.requests.get(url, params=params)
    
    assert response.status_code == 200
    
    data = response.json()
    
    assert len(data["results"]) == 2

def test_get_articles_offset():
    """Test getting articles with offset parameter."""
    
    url = f"{BASE_URL}/content/all/all.json"
    params = {"limit": 10, "offset": 5}
    
    response: Response = pytest.requests.get(url, params=params)
    
    assert response.status_code == 200
    
    data = response.json()
    
    assert len(data["results"]) >= 5

class TestOperationSlice:
    def setup_method(self):
        """Setup method."""
        
        pytest.requests.session().headers.update({"X-API-Key": "my_secret_key"})
        
    def teardown_method(self):
        """Teardown method."""
        
        pass
        
@pytest.fixture(autouse=True)
def enable_request_mocking():
    """Enable request mocking."""
    
    pytest.importorskip("pytest_mock")
    
    mock = pytest.mock.Mock(spec="requests.Session")
    mock.headers = {}
    
    pytest.requests.Session = mock
    
@pytest.fixture
def mocked_requests_get(mocker):
    """Mocked requests get."""
    
    return mocker.patch("requests.get")

@pytest.fixture
def mocked_requests_session(mocker):
    """Mocked requests session."""
    
    return mocker.patch("requests.Session")