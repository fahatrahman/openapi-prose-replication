import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.fixture
def app_preview():
    def _app_preview(id):
        url = f"{BASE_URL}/v1/appPreviews/{id}"
        params = {"fields[appPreviews]": ["appPreviewSet", "assetDeliveryState", "fileName", "fileSize", "mimeType", "previewFrameTimeCode", "previewImage", "sourceFileChecksum", "uploadOperations", "uploaded", "videoUrl"], "include": ["appPreviewSet"]}
        response = SESSION.get(url, headers={"Authorization": "Bearer <your_token>"}, params=params)
        response.raise_for_status()
        return AppPreviewResponse.parse_raw(response.json())

    yield _app_preview

class AppPreviewResponse:
    @staticmethod
    def parse_raw(raw_data):
        data = raw_data["data"]
        links = raw_data["links"]
        return {
            "id": data["id"],
            "links": ResourceLinks(**data["links"]),
            **data["attributes"],
        }

class ResourceLinks:
    def __init__(self, self_link):
        self.self = self_link

class ErrorResponse:
    @staticmethod
    def parse_raw(raw_data):
        return [{"code": e["code"], "detail": e["detail"], "id": e["id"], "source": e["source"], "status": e["status"], "title": e["title"]} for e in raw_data["errors"]]

class ImageAsset:
    pass

class AppMediaAssetState:
    pass

class AppMediaStateError:
    pass

class UploadOperation:
    pass

class UploadOperationHeader:
    pass

class AppPreview:
    pass

class AppPreviewSet:
    pass