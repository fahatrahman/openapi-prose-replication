import pytest
import requests

BASE_URL = "http://openapi.test"

def test_publishers_list():
    params = {
        "page": 1,
        "page_size": 10
    }
    response = requests.get(f"{BASE_URL}/publishers", params=params)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "count" in data
    assert isinstance(data["count"], int)
    assert "next" in data
    assert "previous" in data
    assert "results" in data
    assert isinstance(data["results"], list)
    for publisher in data["results"]:
        assert isinstance(publisher, dict)
        assert "id" in publisher
        assert isinstance(publisher["id"], int)
        assert "name" in publisher
        assert isinstance(publisher["name"], str)
        assert "slug" in publisher
        assert isinstance(publisher["slug"], str)
        assert "games_count" in publisher
        assert isinstance(publisher["games_count"], int)
        assert "image_background" in publisher
        assert isinstance(publisher["image_background"], str)

if __name__ == "__main__":
    pytest.main([__file__])