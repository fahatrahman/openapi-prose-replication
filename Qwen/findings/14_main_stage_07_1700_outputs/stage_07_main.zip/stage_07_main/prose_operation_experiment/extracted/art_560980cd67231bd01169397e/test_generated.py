import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_a_new_origin_token():
    url = f"{BASE_URL}/v1/origin_token/new"
    headers = {
        "Authorization": "Bearer your_access_token_here"
    }
    payload = {
        "origin": "example_origin"
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    assert response.status_code == 200
    assert "self" in response.json()
    assert "region_id" in response.json()
    assert "origin" in response.json()
    assert "status" in response.json()
    assert "created_at" in response.json()
    assert "updated_at" in response.json()

def test_create_a_new_origin_token_with_validation_error():
    url = f"{BASE_URL}/v1/origin_token/new"
    headers = {
        "Authorization": "Bearer your_access_token_here"
    }
    payload = {}
    
    response = requests.post(url, json=payload, headers=headers)
    
    assert response.status_code == 422
    assert "detail" in response.json()
    for error in response.json()["detail"]:
        assert "loc" in error
        assert "msg" in error
        assert "type" in error