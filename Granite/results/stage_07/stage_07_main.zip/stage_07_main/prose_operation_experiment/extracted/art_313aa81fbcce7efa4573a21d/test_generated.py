import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

# Create a session with a custom adapter for handling retries
session = requests.Session()
retry_strategy = HTTPAdapter(max_retries=3)
session.mount("https://", retry_strategy)
session.mount("http://", retry_strategy)

@pytest.fixture
def api():
    return session

def test_get_revision_changeset(api):
    padID = "test_padID"
    rev = "test_rev"

    # Prepare request parameters
    params = {
        "padID": padID,
        "rev": rev
    }

    url = urljoin(BASE_URL, "/getRevisionChangeset")

    response = api.get(url, params=params, headers={"apikey": "test_apikey"})

    assert response.status_code == 200, f"Unexpected status code: {response.status_code}. Message: {response.json()['message']}"

    expected_result = {
        "code": 0,
        "data": None,
        "message": "ok"
    }

    assert response.json() == expected_result, f"Unexpected response: {response.json()}"