import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from typing import Dict

BASE_URL = "http://openapi.test"

# Create a session with read timeout
session = requests.Session()
session.mount("https://", HTTPAdapter(max_retries=3))
session.mount("http://", HTTPAdapter(max_retries=3))

@pytest.fixture
def authtoken():
    return os.getenv("AUTHTOKEN")

@pytest.fixture
def login():
    return os.getenv("LOGIN")

@pytest.fixture
def product_id():
    return int(os.getenv("PRODUCT_ID"))

def get_product_option_value(
    authtoken: str,
    login: str,
    product_id: int,
    option_id: int,
    value_id: int,
) -> Dict:
    url = f"{BASE_URL}/products/{product_id}/options/{option_id}/values/{value_id}.json"

    headers: Dict[str, str] = {
        "Authorization": f"Bearer {authtoken}",
        "Content-Type": "application/json",
    }

    response = session.get(url, headers=headers)

    # Raise exception on 4xx status codes
    response.raise_for_status()

    return response.json()
