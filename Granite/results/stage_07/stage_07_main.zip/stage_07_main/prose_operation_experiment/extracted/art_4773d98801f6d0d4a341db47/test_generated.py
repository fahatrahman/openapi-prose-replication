import pytest
import requests
from requests.auth import HTTPBasicAuth
BASE_URL = "http://openapi.test"

@pytest.fixture(scope='session')
def setup():
    return HTTPBasicAuth('client_id', 'client_secret')

def test_list_members(setup):
    url = f"{BASE_URL}/youtube/v3/members"
    headers = {'Accept': 'application/json'}
    params = {
        'part': ['snippet'],
        'filterByMemberChannelId': 'CHANNEL_ID',
        'hasAccessToLevel': 'LEVEL',
        'maxResults': 100,
        'mode': 'listMembersModeUnknown',
        'pageToken': 'PAGE_TOKEN'
    }
    response = requests.get(url, headers=headers, params=params, auth=setup)
    assert response.status_code == 200
    response_data = response.json()
    # Add more assertions based on expected response schema