import os
import json
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session for retry on failure
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["GET", "OPTIONS"],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

def test_get_application():
    org_id = "org_id"
    app_id = "app_id"

    url = f"{BASE_URL}/organisations/{org_id}/applications/{app_id}"

    response = session.get(url)
    assert response.status_code == 200

    application = response.json()
    # Add more assertions based on expected structure and values
    assert application["archived"] is False
    assert application["branch"] != ""
    assert application["buildFlavor"]
    assert application["cancelOnPush"] is False
    assert application["commitId"]
    assert application["creationDate"]
    assert application["deployUrl"]
    assert application["deployment"]
    assert application["description"]
    assert application["favourite"] is False
    assert application["homogeneous"] is False
    assert application["id"]
    assert application["instance"]
    assert 0 <= application["last_deploy"] < 2**31
    assert application["name"]
    assert application["ownerId"]
    assert application["separateBuild"] is False
    assert application["state"]
    assert application["stickySessions"] is False
    assert application["vhosts"]
    assert application["webhookSecret"]
    assert application["webhookUrl"]
    assert application["zone"]