import pytest
import requests
from requests.exceptions import RequestException
BASE_URL = "http://openapi.test"

def get_restaurant_service_times(tenant, restaurant_id):
    url = f"{BASE_URL}/restaurants/{tenant}/{restaurant_id}/servicetimes"
    try:
        response = requests.get(url)
        response.raise_for_status()
        return response.json()
    except RequestException as e:
        print(f"Request failed: {e}")
        return None

@pytest.mark.parametrize("tenant, restaurant_id, expected", [
    ("example_tenant", "12345", {
        "serviceTimes": {
            "monday": {"collection": [{"start": "09:00", "end": "18:00"}],
                      "delivery": [{"start": "10:00", "end": "20:00"}]},
            "tuesday": {"collection": [{"start": "09:00", "end": "18:00"}],
                        "delivery": [{"start": "10:00", "end": "20:00"}]},
            # Add more test cases...
        }
    })
])
def test_get_restaurant_service_times(tenant, restaurant_id, expected):
    result = get_restaurant_service_times(tenant, restaurant_id)

    assert result == expected, f"Expected {expected}, got {result}"