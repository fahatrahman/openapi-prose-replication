import os
import pytest
import requests
from googleapiclient.errors import HttpError

BASE_URL = "http://openapi.test"

@pytest.fixture
def sample_request():
    return {
        "requests": [
            {
                "labelPermission": {
                    "email": "user@example.com",
                    "role": "READER"
                },
                "useAdminAccess": False
            }
        ],
        "useAdminAccess": False
    }

def test_batch_update_label_permissions(sample_request):
    url = f"{BASE_URL}/v2beta/labels/permissions:batchUpdate"

    headers = {
        "Content-Type": "application/json"
    }

    try:
        response = requests.post(url, json=sample_request, headers=headers)
        response.raise_for_status()

        result = response.json()
        assert result["permissions"][0]["email"] == "user@example.com"
        assert result["permissions"][0]["role"] == "READER"

    except HttpError as error:
        print(f"An HTTP error occurred: {error}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")