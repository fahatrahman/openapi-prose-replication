import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.mark.parametrize(
    "employer_id, subcontractor_id, cis_instruction_id, authorization, api_version",
    [
        (
            "GD001",
            "VVZ001",
            "QXG001",
            "Auto",
            "default",
        )
    ],
)
def test_get_cis_instruction(
    employer_id, subcontractor_id, cis_instruction_id, authorization, api_version
):
    url = f"{BASE_URL}/Employer/{employer_id}/SubContractor/{subcontractor_id}/CisInstruction/{cis_instruction_id}"

    headers = {"Authorization": authorization, "Api-Version": api_version}

    response = SESSION.get(url, headers=headers)

    if response.status_code == 200:
        assert response.json()["CisInstruction"] is not None
    else:
        error_model = response.json()["ErrorModel"]
        assert error_model["ErrorCategory"] in [
            "General",
            "NotFound",
            "NotAuthorised",
            "ValidationFailure",
        ]