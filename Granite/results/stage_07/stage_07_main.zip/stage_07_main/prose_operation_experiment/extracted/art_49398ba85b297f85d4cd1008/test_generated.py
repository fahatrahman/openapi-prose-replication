import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.fixture
def api_client():
    return SESSION

def test_put_rest_api(api_client):
    restapi_id = "example_restapi_id"  # Replace with actual ID
    mode = "merge"  # or "overwrite"
    failonwarnings = False

    url = f"{BASE_URL}/restapis/{restapi_id}"

    headers = {
        "X-Amz-Algorithm": "AWS4-HMACV4",
        "X-Amz-Credential": "CREDENTIALS",  # Replace with actual credentials
        "X-Amz-Date": "DATE",  # Replace with actual date
        "X-Amz-ExponentialBackoff": "0",
        "X-Amz-SignedHeaders": "host;x-amz-algorithm;x-amz-credential;x-amz-date;x-amz-exponential-backoff",
        "X-Amz-Signature": "SIGNATURE",  # Replace with actual signature
    }

    data = {
        "body": '{"some": "external_api_definition"}'  # Replace with actual data
    }

    response = api_client.put(url, headers=headers, json=data, verify=False)

    assert response.status_code == 200