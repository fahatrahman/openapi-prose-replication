# -*- coding: utf-8 -*-
"""
Test module for query_status_names_v1_asn_status_all_get endpoint.

This module contains tests for the query_status_names_v1_asn_status_all_get endpoint.
"""

import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_query_status_names_v1_asn_status_all_get():
    """
    Test query_status_names_v1_asn_status_all_get endpoint.

    This test sends a GET request to the query_status_names_v1_asn_status_all_get endpoint
    and checks if the response was successful (status code 200).
    """

    # Construct full URL by joining the base URL and path
    url = urljoin(BASE_URL, "/v1/asn/status/all")

    # Send GET request to the endpoint
    response = requests.get(url)

    # Check if the response was successful (status code 200)
    assert response.status_code == 200

    # Parse JSON response
    data = response.json()

    # Check if the response matches the expected schema
    for item in data:
        assert isinstance(item, dict)
        assert 'self' in item
        assert 'name' in item
        assert 'code' in item
        assert item['code'] in ['assigned', 'reserved', 'allocated', 'available']

if __name__ == "__main__":
    pytest.main([__file__])