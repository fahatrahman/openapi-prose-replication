import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_connector():
    url = f"{BASE_URL}/v1/projects/location/connectors"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "connectorId": "example-connector-id",
        "connector": {
            "name": "example-connector-name",
            "ipCidrRange": "10.132.0.0/28",
            "machineType": "zones/us-central1-a/machineTypes/e2-medium",
            "maxInstances": 1,
            "minInstances": 1,
            "minThroughput": 100,
            "maxThroughput": 300,
            "network": "global/networks/default",
            "state": "STATE_UNSPECIFIED"
        }
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert response.json()["name"].startswith("projects/")
    assert response.json()["metadata"]["@type"] == "type.googleapis.com/google.longrunning.OperationMetadata"
    assert response.json()["done"] is False

if __name__ == "__main__":
    pytest.main()