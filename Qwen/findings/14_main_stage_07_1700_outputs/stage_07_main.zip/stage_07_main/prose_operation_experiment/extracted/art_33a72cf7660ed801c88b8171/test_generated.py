import pytest
import requests

BASE_URL = "http://openapi.test"

def test_errors_group_model_counts():
    url = f"{BASE_URL}/v0.1/apps/owner_name/app_name/errors/errorGroups/errorGroupId/models"
    headers = {
        "X-API-Token": "your_api_token_here"
    }
    params = {
        "$top": 30
    }
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "errorCount" in data
    assert isinstance(data["errorCount"], int)
    assert "models" in data
    assert isinstance(data["models"], list)
    for model in data["models"]:
        assert "errorCount" in model
        assert isinstance(model["errorCount"], int)
        assert "modelCode" in model
        assert isinstance(model["modelCode"], str)
        assert "modelName" in model
        assert isinstance(model["modelName"], str)

if __name__ == "__main__":
    pytest.main([__file__])