import pytest
import requests

BASE_URL = "http://openapi.test"

def test_modify_labels():
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    params = {
        "_xgafv": "2",
        "access_token": "YOUR_ACCESS_TOKEN",
        "alt": "json",
        "callback": "onLoad",
        "fields": "modifiedLabels(id)",
        "key": "YOUR_API_KEY",
        "oauth_token": "YOUR_OAUTH_TOKEN",
        "prettyPrint": "true",
        "quotaUser": "user@example.com",
        "uploadType": "media",
        "upload_protocol": "raw"
    }
    file_id = "YOUR_FILE_ID"
    payload = {
        "kind": "drive#modifyLabelsRequest",
        "labelModifications": [
            {
                "kind": "drive#labelModification",
                "labelId": "YOUR_LABEL_ID",
                "fieldModifications": [
                    {
                        "kind": "drive#labelFieldModification",
                        "fieldId": "YOUR_FIELD_ID",
                        "setTextValues": ["new_value"]
                    }
                ]
            }
        ]
    }

    url = f"{BASE_URL}/files/{file_id}/modifyLabels"
    response = requests.post(url, headers=headers, params=params, json=payload)

    assert response.status_code == 200
    assert "modifiedLabels" in response.json()
    assert len(response.json()["modifiedLabels"]) > 0