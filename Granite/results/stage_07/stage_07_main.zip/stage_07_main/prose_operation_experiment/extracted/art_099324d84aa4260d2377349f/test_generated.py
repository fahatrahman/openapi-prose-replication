import pytest
import requests
from requests_aws_sigv4 import AWS4Auth
BASE_URL = "http://openapi.test"

@pytest.fixture
def api():
    return requests.put, f"{BASE_URL}/restapis/mock_restapi_id", {"body": "{\"body\": \"sample_body\"}"}, {
        "headers": {
            "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
            "X-Amz-Credential": "mock_credential",
            "X-Amz-Date": "mock_date",
            "X-Amz-Expires": "900",
            "X-Amz-SignedHeaders": "content-type;host;x-amz-date",
            "X-Amz-Signature": "mock_signature"
        },
        "auth": AWS4Auth("mock_access_key", "mock_secret_key", "us-east-1", "execute-api"),
    }

def test_put_restapi(api):
    response = api[0](*api[1:], json=api[2], auth=api[3])
    assert response.status_code == 200