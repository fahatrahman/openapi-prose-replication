import pytest
import requests

BASE_URL = "http://openapi.test"

def test_kubernetes_list_associatedResources():
    cluster_id = "bd5f5959-5e1e-4205-a714-a914373942af"
    headers = {
        "Authorization": "Bearer $DIGITALOCEAN_TOKEN",
        "Content-Type": "application/json"
    }
    response = requests.get(f"{BASE_URL}/v2/kubernetes/clusters/{cluster_id}/destroy_with_associated_resources", headers=headers)
    
    assert response.status_code == 200
    assert "load_balancers" in response.json()
    assert "volume_snapshots" in response.json()
    assert "volumes" in response.json()

    ratelimit_limit = int(response.headers["ratelimit-limit"])
    ratelimit_remaining = int(response.headers["ratelimit-remaining"])
    ratelimit_reset = int(response.headers["ratelimit-reset"])

    assert ratelimit_limit > 0
    assert ratelimit_remaining >= 0
    assert ratelimit_reset > 0