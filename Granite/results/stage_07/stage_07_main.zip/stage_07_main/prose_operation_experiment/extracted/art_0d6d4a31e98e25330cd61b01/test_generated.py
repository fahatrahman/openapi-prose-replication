import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.exceptions import Retry

BASE_URL = "http://openapi.test"

# Create a session with retry strategy for handling transient errors
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

# API key for authentication
API_KEY = os.environ.get("OPENAPI_TEST_API_KEY")
headers = {"X-API-KEY": API_KEY} if API_KEY else {}

@pytest.mark.parametrize("chain, address, include_exposure", [
    ("ETH", "0x123...", True),
    ("BTC", "bc1qw508d6qkjnyce4aw4aw4aw4aw4aw4aw4aw4aw4", False),
])
def test_risk_address(chain, address, include_exposure):
    url = f"{BASE_URL}/risk/address"

    params = {
        "chain": chain,
        "address": address,
        "include_exposure": include_exposure,
    }

    response = session.get(url, headers=headers, params=params)

    assert response.status_code == 200, response.text

    risk_exposure_response = response.json()
    assert all(key in risk_exposure_response for key in [
        "closest_incoming_exposure",
        "closest_outgoing_exposure",
        "entity_tags",
        "risk_score"])

    assert isinstance(risk_exposure_response["closest_incoming_exposure"], dict)
    assert isinstance(risk_exposure_response["closest_outgoing_exposure"], dict)
    assert isinstance(risk_exposure_response["entity_tags"], list)
    assert isinstance(risk_exposure_response["risk_score"], str)

def test_unauthorized():
    url = f"{BASE_URL}/risk/address"

    # Simulate an unauthorized request by not providing the required API key
    headers = {}

    response = session.get(url, headers=headers)

    assert response.status_code == 401, response.text

    error_response = response.json()
    assert "error" in error_response and "status" in error_response
    assert error_response["status"] == 401

def test_unprocessable():
    url = f"{BASE_URL}/risk/address"

    # Simulate an invalid chain value
    params = {
        "chain": "INVALID",
        "address": "0x123...",
        "include_exposure": True,
    }

    response = session.get(url, headers=headers, params=params)

    assert response.status_code == 422, response.text

    error_response = response.json()
    assert "error" in error_response and "status" in error_response
    assert error_response["status"] == 422