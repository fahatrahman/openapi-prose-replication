import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retry mechanism
session = requests.Session()
retries = Retry(total=3, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

# Set API key header
os.environ["OPENAPI_TEST_KEY"] = "your_api_key"
headers = {"x-api-key": os.getenv("OPENAPI_TEST_KEY")}

@pytest.fixture
def get_aliases():
    def _get_aliases(*args, **kwargs):
        url = f"{BASE_URL}/aliases/all"
        params = {
            "domainName": kwargs.pop("domainName", "short.fyi"),
            "continueFrom": kwargs.pop("continueFrom", None),
            "limit": kwargs.pop("limit", 1000)
        }
        response = session.get(url, headers=headers, params=params)
        response.raise_for_status()
        return response.json()
    return _get_aliases

def test_get_aliases(get_aliases):
    response = get_aliases(domainName="your.domain.com")
    assert isinstance(response, dict)
    assert "aliases" in response
    assert isinstance(response["aliases"], list)
    assert "lastId" in response