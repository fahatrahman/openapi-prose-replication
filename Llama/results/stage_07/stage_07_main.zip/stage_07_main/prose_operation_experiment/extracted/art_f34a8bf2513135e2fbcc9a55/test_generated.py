# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_reset_snow_monkey():
    response = requests.delete(
        urljoin(BASE_URL, "/api/snowmonkey/outages"),
        auth=("client_id", "client_secret")
    )
    assert response.status_code == 200
    assert response.json() == {"done": True}