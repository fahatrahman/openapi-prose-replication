import os
import pytest
import requests
from requests.exceptions import HTTPError
BASE_URL = "http://openapi.test"


def get_issue_list_blocks(owner, repo, index, page=1, limit=20):
    """Get list of issues blocked by an issue"""

    url = f"{BASE_URL}/repos/{owner}/{repo}/issues/{index}/blocks"

    headers = {
        'accept': 'application/json, text/html'
    }

    params = {
        'page': page,
        'limit': limit
    }

    try:
        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()

        # Assuming the response is in JSON format
        return response.json()

    except HTTPError as http_err:
        print(f'HTTP error occurred: {http_err}')
    except Exception as err:
        print(f'Other error occurred: {err}')

    return None


@pytest.mark.parametrize("owner, repo, index", [
    ("test_user", "test_repo", "1")
])
def test_get_issue_list_blocks(owner, repo, index):
    result = get_issue_list_blocks(owner, repo, index)
    assert result is not None, "Unexpectedly received None"