import pytest
import requests

BASE_URL = "http://openapi.test"

def test_update_comment_threads():
    url = f"{BASE_URL}/youtube/v3/commentThreads"
    headers = {
        "Content-Type": "application/json",
    }
    payload = {
        "part": ["snippet"],
        "commentThread": {
            "snippet": {
                "topLevelComment": {
                    "snippet": {
                        "textOriginal": "Updated comment text"
                    }
                }
            }
        }
    }
    response = requests.put(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert "kind" in response.json()
    assert response.json()["kind"] == "youtube#commentThread"