import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

# Custom session with retry logic
session = requests.Session()
retry_strategy = HTTPAdapter(max_retries=3)
session.mount("https://", retry_strategy)
session.mount("http://", retry_strategy)

@pytest.fixture
def base_url():
    return urljoin(BASE_URL, "")

@pytest.mark.parametrize("id", ["your_vnic_id"])
def test_get_vnic(base_url, id):
    endpoint = f"{base_url}/entities/vnics/{id}"
    response = session.get(endpoint)

    if response.status_code == 200:
        assert response.json().get("@context") == "https://schema.org/"
        assert response.json()["entity_type"] == "Vnic"
        assert isinstance(response.json()["ip_addresses"], list)
        assert response.json()["layer2_network"] is None or response.json()["layer2_network"].get("entity_id") is not None
        assert response.json()["name"] != ""
        assert isinstance(response.json()["vlan"], dict)
        assert response.json()["vm"]["entity_id"] != ""
    elif response.status_code == 400:
        assert response.json().get("code") > 0
    elif response.status_code == 401:
        assert response.status_code == 401
    elif response.status_code == 404:
        assert response.status_code == 404
    elif response.status_code == 500:
        assert response.status_code == 500
    else:
        raise Exception(f"Unexpected status code: {response.status_code}")