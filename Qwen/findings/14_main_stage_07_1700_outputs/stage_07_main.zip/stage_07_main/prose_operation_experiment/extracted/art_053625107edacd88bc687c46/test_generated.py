import pytest
import requests

BASE_URL = "http://openapi.test"

def test_discoveryengine_projects_locations_dataStores_schemas_list():
    url = f"{BASE_URL}/v1beta/projects/location/dataStores/schemas"
    params = {
        "_xgafv": "2",
        "access_token": "your_access_token",
        "alt": "json",
        "callback": "your_callback",
        "fields": "*",
        "key": "your_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": False,
        "quotaUser": "your_quota_user",
        "uploadType": "multipart/form-data",
        "upload_protocol": "raw",
        "parent": "projects/location/dataStores",
        "pageSize": 100,
        "pageToken": ""
    }
    headers = {
        "Authorization": "Bearer your_access_token"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()