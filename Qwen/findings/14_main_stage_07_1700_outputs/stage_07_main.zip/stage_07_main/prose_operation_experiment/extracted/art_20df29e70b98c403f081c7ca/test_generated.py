import pytest
import requests

BASE_URL = "http://openapi.test"

def test_tag_resource():
    url = f"{BASE_URL}/2017-08-29/tags"
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "YOUR_CREDENTIALS",
        "X-Amz-Date": "CURRENT_DATE_TIME",
        "X-Amz-Security-Token": "YOUR_SECURITY_TOKEN",
        "X-Amz-Signature": "YOUR_SIGNATURE",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-security-token;x-amz-signature"
    }
    payload = {
        "arn": "arn:aws:s3:::example-bucket",
        "tags": {
            "Project": "Example Project",
            "Environment": "Production"
        }
    }
    response = requests.post(url, json=payload, headers=headers)
    
    assert response.status_code == 200
    assert "application/json" in response.headers["Content-Type"]
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()