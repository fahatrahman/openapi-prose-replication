import pytest
import requests

BASE_URL = "http://openapi.test"

def test_apps_get_instance_size():
    url = f"{BASE_URL}/v2/apps/tiers/instance_sizes/basic-xxs"
    headers = {"Authorization": "Bearer YOUR_OAUTH_TOKEN"}
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert 'instance_size' in data
    assert data['instance_size']['cpu_type'] == 'SHARED'
    assert data['instance_size']['cpus'] == 1
    assert data['instance_size']['memory_bytes'] == 536870912
    assert data['instance_size']['name'] == 'Basic XXS'
    assert data['instance_size']['slug'] == 'basic-xxs'
    assert data['instance_size']['tier_slug'] == 'basic'
    assert data['instance_size']['tier_upgrade_to'] == 'professional-xs'
    assert data['instance_size']['usd_per_month'] == 5.00
    assert data['instance_size']['usd_per_second'] == 0.000002066799

def test_apps_get_instance_size_unauthorized():
    url = f"{BASE_URL}/v2/apps/tiers/instance_sizes/basic-xxs"
    response = requests.get(url)
    assert response.status_code == 401

def test_apps_get_instance_size_not_found():
    url = f"{BASE_URL}/v2/apps/tiers/instance_sizes/non-existent-size"
    response = requests.get(url)
    assert response.status_code == 404

def test_apps_get_instance_size_rate_limit_exceeded():
    url = f"{BASE_URL}/v2/apps/tiers/instance_sizes/basic-xxs"
    for _ in range(500):
        response = requests.get(url)
        if response.status_code != 429:
            break
    else:
        assert False, "Rate limit exceeded"

def test_apps_get_instance_size_server_error():
    url = f"{BASE_URL}/v2/apps/tiers/instance_sizes/basic-xxs"
    response = requests.get(url)
    assert response.status_code == 500