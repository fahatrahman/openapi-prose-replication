import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

def test_list_product_modules():
    response = requests.get(
        f"{BASE_URL}/productmodule",
        auth=HTTPBasicAuth("username", "password"),
        headers={"Accept": "application/json"}
    )
    assert response.status_code == 200
    assert response.json() is not None

def test_list_product_modules_xml():
    response = requests.get(
        f"{BASE_URL}/productmodule",
        auth=HTTPBasicAuth("username", "password"),
        headers={"Accept": "application/xml"}
    )
    assert response.status_code == 200
    assert response.content is not None

def test_invalid_request():
    response = requests.get(f"{BASE_URL}/productmodule")
    assert response.status_code in [400, 403, 404, 500]

@pytest.mark.parametrize("status_code", [400, 403, 404, 500])
def test_status_codes(status_code):
    response = requests.get(f"{BASE_URL}/productmodule")
    assert response.status_code == status_code