# -*- coding: utf-8 -*-
"""Tests for /v1/{customer}/reports:findInstalledAppDevices."""
import pytest
import requests


BASE_URL = "http://openapi.test"


def test_chromemanagement_customers_reports_find_installed_app_devices():
    """Test chromemanagement.customers.reports.findInstalledAppDevices."""
    url = f"{BASE_URL}/v1/{'customer'}"
    params = {
        'access_token': '',
        'alt': 'json',
        'callback': '',
        'fields': '',
        'key': '',
        'oauth_token': '',
        'prettyPrint': True,
        'quotaUser': '',
        'upload_protocol': 'auto',
        'uploadType': 'media',
        'customer': 'customer',
        'appId': '',
        'appType': 'APP_TYPE_UNSPECIFIED',
        'filter': '',
        'orderBy': 'lmprawf',
        'orgUnitId': '',
        'pageSize': 10,
        'pageToken': ''
    }
    headers = {}
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200