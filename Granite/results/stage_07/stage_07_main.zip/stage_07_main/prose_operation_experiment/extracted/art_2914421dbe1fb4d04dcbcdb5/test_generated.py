import pytest
import requests
from requests.auth import HTTPBasicAuth
BASE_URL = "http://openapi.test"

@pytest.fixture
def modify_labels():
    endpoint = f"{BASE_URL}/files/{'FILE_ID'}/modifyLabels"
    headers = {
        'Content-Type': 'application/json',
    }

    # Replace with actual values
    file_id = 'FILE_ID'
    label_modifications = [
        {
            "kind": "drive#xkktoVffhzgzjokcy",
            "labelId": "LABEL_ID",
            "removeLabel": True,
            "fieldModifications": []
        }
    ]

    request_body = {
        "kind": "drive#cuvtjtTqxqjgQptfryc",
        "labelModifications": label_modifications
    }

    response = requests.post(endpoint, headers=headers, json=request_body)
    response.raise_for_status()

    return response.json()

def test_modify_labels(modify_labels):
    assert modify_labels['kind'] == 'drive#hasvppDxzhzlNaghkfvb'
    for label in modify_labels['modifiedLabels']:
        assert label['kind'] == 'drive#jmlhr'