import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_domain():
    url = f"{BASE_URL}/domains/b30a91ae-e3c1-4f73-a81e-c270bff27c39"
    headers = {
        "Training-Key": "your_training_key_here"
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert response.headers["Content-Type"].startswith("application/json")
    data = response.json()
    assert isinstance(data, dict)
    assert "enabled" in data
    assert "exportable" in data
    assert "id" in data
    assert "name" in data
    assert "type" in data
    assert data["type"] in ["Classification", "ObjectDetection"]