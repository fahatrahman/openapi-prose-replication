# pytest test module for get-storedPaymentMethods operation
import pytest
import requests
from jsonschema import validate
import json

BASE_URL = "http://openapi.test"

def test_get_stored_payment_methods():
    # Construct API request
    headers = {"Content-Type": "application/json"}
    params = {
        "shopperReference": "YOUR_SHOPPER_REFERENCE",
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT"
    }
    
    # Send GET request
    response = requests.get(f"{BASE_URL}/storedPaymentMethods", headers=headers, params=params)
    
    # Validate status code
    assert response.status_code == 200
    
    # Parse JSON response
    try:
        response_json = response.json()
    except ValueError as e:
        print(f"Failed to parse JSON response: {e}")
        pytest.fail("Invalid JSON response")
    
    # Validate JSON schema
    schema_path = "#/components/schemas/ListStoredPaymentMethodsResponse"
    schema = json.loads(open('openapi.json').read())['components']['schemas'][schema_path]
    validate(instance=response_json, schema=schema)
