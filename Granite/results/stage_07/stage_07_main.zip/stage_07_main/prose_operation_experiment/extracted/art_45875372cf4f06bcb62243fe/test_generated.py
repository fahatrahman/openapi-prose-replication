import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retry logic
session = requests.Session()
retries = Retry(total=3, backoff_factor=0.1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

# Set the API key header
api_key = "YOUR_API_KEY"
session.headers.update({"Ocp-Apim-Subscription-Key": api_key})

@pytest.mark.parametrize("format_, roundid, playerid", [
    ("json", "1", "90026231"),
    ("xml", "2", "90026232")
])
def test_player_season_stats_by_player(format_, roundid, playerid):
    url = f"{BASE_URL}/{format_/}{roundid}/{playerid}"
    response = session.get(url)

    assert response.status_code == 200
    assert isinstance(response.json(), list) if format_ == "json" else True