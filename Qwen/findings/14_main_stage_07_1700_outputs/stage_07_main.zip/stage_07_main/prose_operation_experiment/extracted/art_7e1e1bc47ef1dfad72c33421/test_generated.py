import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_content_release():
    content_release_id = 123  # Replace with actual ContentReleaseId
    url = f"{BASE_URL}/api/v2/ContentReleases/{content_release_id}"
    response = requests.get(url)
    
    assert response.status_code == 200
    assert 'ContentReleaseVersion' in response.json()
    
    content_release_version = response.json()['ContentReleaseVersion']
    assert 'ContentDefinitionID' in content_release_version
    assert 'ContentReleaseID' in content_release_version
    assert 'Deleted' in content_release_version
    assert 'PublisherUserID' in content_release_version
    assert 'ReleaseID' in content_release_version
    assert 'TestReportUrl' in content_release_version
    assert 'UpdatedDate' in content_release_version
    assert 'Version' in content_release_version

if __name__ == "__main__":
    pytest.main()