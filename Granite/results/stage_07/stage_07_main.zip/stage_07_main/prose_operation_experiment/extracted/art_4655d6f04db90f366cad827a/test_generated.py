import os
import pytest
import requests
from googleapiclient.discovery import build

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def setup():
    # Initialize authenticated Google Cloud client
    credentials = os.environ["GOOGLE_APPLICATION_CREDENTIALS"]
    google_cloud_service = build('serviceusage', 'v1beta1', credentials=credentials)
    return google_cloud_service

def test_patch_consumer_quota_override(setup):
    name = "your_service_name/your_consumer_quota_metric_id"
    force = True
    update_mask = "quota_metrics"

    quota_override = {
        "adminOverrideAncestor": "project_number",
        "dimensions": {"dimension1": "value1"},
        "metric": "compute.googleapis.com/cpu/utilization",
        "name": name,
        "overrideValue": -1,
        "unit": "1/{autfnhu}/{htsfnp}"
    }

    response = setup.services().consumerQuotaMetrics().limits().consumerOverrides().patch(
        name=name,
        force=force,
        updateMask=update_mask,
        body=quota_override
    ).execute()

    assert response['done'] is True
    assert response['error'] is None
    assert response['response']['quotaMetrics'][0]['name'] == name