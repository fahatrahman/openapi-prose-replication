# -*- coding: utf-8 -*-

import pytest
from requests import Session
from jsonschema import validate
import json

BASE_URL = "http://openapi.test"

def test_get_ticket_messages():
    session = Session()
    
    headers = {
        'Authorization': 'your_authorization_header'
    }
    
    response = session.get(
        f"{BASE_URL}/ticket/{'your_ticket_id'}",
        params={
            'offset': 0,
            'limit': 10
        },
        headers=headers
    )
    
    assert response.status_code == 200
    
    try:
        schema = json.loads('''
{
    "$schema": "https://json-schema.org/draft-07/schema#",
    "type": "object",
    "properties": {
        "messages": {
            "type": "array",
            "items": {
                "$ref": "#/components/schemas/TicketMessage"
            }
        },
        "metadata": {
            "type": "array",
            "items": {
                "$ref": "#/components/schemas/Metadata"
            }
        }
    },
    "required": [
        "metadata"
    ]
}
''')
        
        validate(instance=response.json(), schema=schema)
    except json.JSONDecodeError:
        pass
    
    # Test for other possible status codes
    response_400 = session.get(
        f"{BASE_URL}/ticket/{'invalid_ticket_id'}",
        params={
            'offset': 0,
            'limit': 10
        },
        headers=headers
    )
    assert response_400.status_code in [400]
    
    response_401 = session.get(
        f"{BASE_URL}/ticket/{'your_ticket_id'}",
        params={
            'offset': 0,
            'limit': 10
        }
    )
    assert response_401.status_code == 401
    
    response_403 = session.get(
        f"{BASE_URL}/ticket/{'your_ticket_id'}",
        params={
            'offset': 10000000,
            'limit': 10
        },
        headers=headers
    )
    assert response_403.status_code == 403