import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_application_versions():
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20130320/us-east-1/ec2/aws4_request",
        "X-Amz-Date": "20130320T120000Z",
        "X-Amz-Security-Token": "AQoDYXdzEPT//////////wEXAMPLEtc7rz7Md99le+STjo+vY3vjnrypBtK+VGUDNOqICiQkjnc4QwRdsGNIm68FhSLciLIT时",
        "X-Amz-Signature": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-SignedHeaders": "host"
    }
    params = {
        "applicationId": "example-app-id",
        "maxItems": 10,
        "nextToken": None,
        "MaxItems": None,
        "NextToken": None
    }
    response = requests.get(f"{BASE_URL}/applications/{params['applicationId']}/versions", headers=headers, params=params)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "Versions" in response.json()
    assert "NextToken" in response.json()

if __name__ == "__main__":
    pytest.main([__file__])