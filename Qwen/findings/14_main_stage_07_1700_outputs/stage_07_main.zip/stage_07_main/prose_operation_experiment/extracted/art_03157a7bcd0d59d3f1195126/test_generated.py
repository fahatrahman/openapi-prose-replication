import pytest
import requests

BASE_URL = "http://openapi.test"

def test_patch_pension():
    url = f"{BASE_URL}/Employer/ER001/Pension/PEN001"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    payload = {
        "Pension": {
            "AECompatible": True,
            "Certification": "Set1",
            "Code": "PEN001",
            "ContributionDeductionDay": 1,
            "EffectiveDate": "2023-01-01",
            "EmployeeContributionCash": 1000.0,
            "EmployeeContributionPercent": 5.0,
            "EmployerContributionCash": 2000.0,
            "EmployerContributionPercent": 10.0,
            "EmployerNiSaving": False,
            "EmployerNiSavingPercentage": 1.0,
            "Group": "GroupA",
            "LowerThreshold": 10000.0,
            "MetaData": {},
            "NextRevisionDate": "2024-01-01",
            "PensionablePayCodes": {
                "PayCode": ["PC001", "PC002"]
            },
            "ProRataMethod": "Annual260Days",
            "ProviderEmployerRef": "PRO001",
            "ProviderName": "ProviderX",
            "QualifyingPayCodes": {
                "PayCode": ["QC001", "QC002"]
            },
            "RasRoundingOverride": "PennyUp",
            "Revision": 1,
            "RoundingOption": "PennyDown",
            "SalarySacrifice": True,
            "SchemeName": "SchemeY",
            "SubGroup": "SubGroupB",
            "TaxationMethod": "NetBased",
            "UpperThreshold": 50000.0,
            "UseAEThresholds": True
        }
    }

    response = requests.patch(url, json=payload, headers=headers)

    assert response.status_code == 200
    assert "Pension" in response.json()