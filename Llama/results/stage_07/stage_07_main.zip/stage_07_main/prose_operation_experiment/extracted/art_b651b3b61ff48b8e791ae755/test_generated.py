import pytest
import requests
from datetime import datetime
import json
import hashlib
import hmac
import base64
import os

BASE_URL = "http://openapi.test"

def get_timestamp():
    return datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')

def get_signature(key, date_string, method, scope, host, payload):
    message = f'{method}\n{host}\n{date_string}\n{scope}\n{hashlib.sha256(payload.encode()).hexdigest()}'
    return hmac.new(key, message.encode(), hashlib.sha256).digest()

def get_auth_header(api_key, api_secret, date_string, method, scope, host):
    signature = base64.b64encode(get_signature(api_key.encode(), date_string, method, scope, host, b''))
    return f'AWS4-HMAC-SHA256 Credential={api_key}/{date_string}, SignedHeaders=host;x-amz-date, Signature={signature.decode()}'

def test_put_rest_api():
    restapi_id = 'test-id'
    mode = 'merge'
    fail_on_warnings = False
    parameters = {}
    
    headers = {
        'X-Amz-Algorithm': 'AWS4-HMAC-SHA256',
        'X-Amz-Content-Sha256': hashlib.sha256(b'').hexdigest(),
        'X-Amz-Credential': 'test-key/20151229/us-east-1/apigateway/aws4_request',
        'X-Amz-Date': get_timestamp(),
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': '',
        'X-Amz-SignedHeaders': 'host;x-amz-date',
        'Authorization': ''
    }
    
    auth_key = 'test-key'
    auth_secret = 'test-secret'
    
    headers['Authorization'] = get_auth_header(auth_key, auth_secret, headers['X-Amz-Date'], 'PUT', '/restapis/' + restapi_id, BASE_URL)
    
    response = requests.put(
        f'{BASE_URL}/restapis/{restapi_id}',
        params={
            'mode': mode,
            'failonwarnings': str(fail_on_warnings).lower()
        },
        headers=headers,
        data=json.dumps({
            'body': '''
                {
                    "swagger": "2.0",
                    "info": {
                        "title": "Test API"
                    },
                    "paths": {
                        "/test": {
                            "get": {
                                "summary": "Test endpoint",
                                "responses": {
                                    "200": {
                                        "description": "OK"
                                    }
                                }
                            }
                        }
                    }
                }
            '''
        }),
        verify=False
    )
    
    assert response.status_code == 200
    
    try:
        response.raise_for_status()
    except requests.RequestException as e:
        pytest.fail(str(e))