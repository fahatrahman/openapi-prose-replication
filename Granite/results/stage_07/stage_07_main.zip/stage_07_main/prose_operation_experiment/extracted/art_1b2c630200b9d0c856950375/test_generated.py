import os
import json
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Retry mechanism for requests
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

@pytest.fixture
def server_reset():
    url = f"{BASE_URL}/servers/{1}/actions/reset"

    headers = {
        'Content-Type': 'application/json'
    }

    response = session.post(url, headers=headers)

    assert response.status_code == 201

    return response.json()

def test_server_reset(server_reset):
    action_response = server_reset['action']

    # Asserting the structure of the response based on provided schema
    assert 'command' in action_response
    assert 'error' in action_response
    assert 'finished' not in action_response
    assert isinstance(action_response['id'], int)
    assert 'progress' in action_response
    assert 'resources' in action_response
    assert 'started' in action_response
    assert 'status' in action_response

    if 'error' in action_response:
        assert 'code' in action_response['error']
        assert 'message' in action_response['error']

    if 'resources' in action_response:
        assert isinstance(action_response['resources'], list)
        resource = action_response['resources'][0]
        assert 'id' in resource
        assert 'type' in resource