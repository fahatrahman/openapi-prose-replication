# -*- coding: utf-8 -*-

import pytest
import requests
from pydantic import BaseModel

class Response(BaseModel):
    code: int
    data: dict
    message: str

def pad_users_using_post(base_url: str, api_key: str, pad_id: str) -> Response:
    headers = {"X-API-Key": api_key}
    params = {"padID": pad_id}
    response = requests.post(f"{base_url}/padUsers", headers=headers, params=params)
    response.raise_for_status()
    return Response.parse_raw(response.content)

@pytest.fixture
def base_url():
    return "http://openapi.test"

@pytest.mark.parametrize("api_key,pad_id,expected_code", [
    ("test_api_key", "test_pad_id", 0),
    ("wrong_api_key", "", 4),
])
def test_pad_users_using_post(base_url, api_key, pad_id, expected_code):
    try:
        pad_users_using_post(base_url, api_key, pad_id)
        assert False, f"Expected code {expected_code} but got success"
    except requests.RequestException as e:
        if e.response.status_code == expected_code:
            pass
        else:
            raise