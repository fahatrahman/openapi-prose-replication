import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_losing_bids():
    filter_set_name = 'test_filter_set'
    params = {
        'filterSetName': filter_set_name,
        'pageSize': 10,
        'pageToken': ''
    }
    
    headers = {'Accept': 'application/json'}
    
    url = f"{BASE_URL}/v2beta1/{params['filterSetName']}/losingBids"
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 200
    
    try:
        response_json = response.json()
        assert isinstance(response_json, dict)
        
        required_keys = ['creativeStatusRows', 'nextPageToken']
        for key in required_keys:
            assert key in response_json
        
        creative_status_rows = response_json['creativeStatusRows']
        assert isinstance(creative_status_rows, list)
        
        for row in creative_status_rows:
            assert isinstance(row, dict)
            
            required_row_keys = ['bidCount', 'creativeStatusId', 'rowDimensions']
            for key in required_row_keys:
                assert key in row
                
            bid_count = row['bidCount']
            assert isinstance(bid_count, str)
            
            creative_status_id = row['creativeStatusId']
            assert isinstance(creative_status_id, int)
            
            row_dimensions = row['rowDimensions']
            assert isinstance(row_dimensions, dict)
            
            required_row_dimension_keys = ['publisherIdentifier', 'timeInterval']
            for key in required_row_dimension_keys:
                assert key in row_dimensions
                
            publisher_identifier = row_dimensions['publisherIdentifier']
            assert isinstance(publisher_identifier, str)
            
            time_interval = row_dimensions['timeInterval']
            assert isinstance(time_interval, dict)
            
            required_time_interval_keys = ['endTime', 'startTime']
            for key in required_time_interval_keys:
                assert key in time_interval
                
            end_time = time_interval['endTime']
            assert isinstance(end_time, str)
            
            start_time = time_interval['startTime']
            assert isinstance(start_time, str)
            
            # Validate date formats
            end_time_date = datetime.strptime(end_time, '%Y-%m-%dT%H:%M:%SZ')
            start_time_date = datetime.strptime(start_time, '%Y-%m-%dT%H:%M:%SZ')
            
            assert end_time_date > start_time_date
    except ValueError:
        pytest.fail("Invalid JSON response")