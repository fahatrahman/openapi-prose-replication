import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"

@pytest.fixture
def firestore_list_collection_ids():
    credentials = service_account.Credentials.from_service_account_file('path/to/credentials.json')
    api_service_name = 'firestore.googleapis.com'
    scope = ['https://www.googleapis.com/auth/cloud-platform', 'https://www.googleapis.com/auth/datastore']
    http_authorized = credentials.authorize(requests)

    def _request(method, path, json=None):
        url = f"{BASE_URL}{path}"
        headers = {
            'Content-Type': 'application/json'
        }

        response = http_authorized.request(method, url, headers=headers, json=json)
        response.raise_for_status()
        return response.json()

    # Replace 'your-project-id' with your actual project id
    parent = f"projects/your-project-id"
    
    request_body = {
        "pageSize": 10,
        "pageToken": None,
        "readTime": "2022-09-12T07:22:00Z"
    }

    response = _request("POST", f"/v1/{parent}:listCollectionIds", json=request_body)

    assert response["collectionIds"]
    assert isinstance(response["nextPageToken"], str) or response["nextPageToken"] is None