import pytest
import requests
from urllib.parse import urlencode

BASE_URL = "http://openapi.test"

def test_get_multiple_artists():
    ids = ",".join(["2CIMQHirSU0MQqyYHq0eOx", "57dN52uHvrHOxijzpIgu3E", "1vCWHaC5f2uS3yhpwWbIA6"])
    params = {"ids": ids}

    response = requests.get(f"{BASE_URL}/artists?", params=urlencode(params))
    assert response.status_code == 200
    assert response.json()["artists"]