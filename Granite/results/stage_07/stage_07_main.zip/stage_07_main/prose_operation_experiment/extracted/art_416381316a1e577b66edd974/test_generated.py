import os
import requests
import pytest
BASE_URL = "http://openapi.test"

@pytest.fixture
def webhook():
    url = f"{BASE_URL}/webhooks"
    headers = {"Authorization": "Bearer YOUR_ACCESS_TOKEN", "Content-Type": "application/json"}
    params = {
        "limit": 1000,
        "marker": None
    }

    def get_webhooks(request):
        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()
        return response.json()

    yield get_webhooks

def test_get_webhooks(webhook):
    response = webhook({})
    assert isinstance(response, list)
    assert all("id" in item and "target" in item for item in response)

def test_get_webhooks_with_marker(webhook):
    marker = "1234567890"
    response = webhook({"marker": marker})["webhooks"][0]["target"]["id"]
    new_marker = response
    new_response = webhook({"marker": new_marker})["webhooks"][0]["target"]["id"]
    assert new_marker != new_response

def test_get_webhooks_permission_error():
    url = f"{BASE_URL}/webhooks"
    headers = {"Authorization": "Bearer NO_ACCESS_TOKEN", "Content-Type": "application/json"}
    params = {
        "limit": 1000,
        "marker": None
    }

    def get_webhooks(request):
        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()
        return response.json()

    with pytest.raises(requests.exceptions.HTTPError) as e:
        get_webhooks({})
    assert e.value.response.status_code == 403