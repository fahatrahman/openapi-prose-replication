import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_endpoints():
    url = f"{BASE_URL}/?openapi=true"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Accept": "application/vnd.vimeo.endpoint+json"
    }
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    assert response.headers["Content-Type"] == "application/vnd.vimeo.endpoint+json"
    assert isinstance(response.json(), dict)
    assert "methods" in response.json()
    assert "path" in response.json()

if __name__ == "__main__":
    pytest.main([__file__])