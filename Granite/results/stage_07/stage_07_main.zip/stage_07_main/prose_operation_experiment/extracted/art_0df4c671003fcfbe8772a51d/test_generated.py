import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retry strategy for handling transient errors
session = requests.Session()
retry_strategy = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def delete_image():
    def _delete_image(image_digest, force=False):
        url = f"{BASE_URL}/images/{image_digest}"
        headers = {"x-anchore-account": "your_account_name"}

        params = {
            "force": force
        }

        response = session.delete(url, headers=headers, params=params)
        response.raise_for_status()

        return response.json()

    yield _delete_image

def test_delete_image(delete_image):
    image_digest = "your_image_digest"
    result = delete_image(image_digest, force=True)

    assert result["status"] == "deleting"
    assert isinstance(result["digest"], str)