import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_streaming_sessions():
    url = f"{BASE_URL}/2020-08-01/studios/test-studio/streaming-sessions"
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Credential": "test-credential",
        "X-Amz-Date": "20230401T120000Z",
        "X-Amz-Security-Token": "test-token",
        "X-Amz-Signature": "test-signature",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-algorithm;x-amz-credential;x-amz-security-token;x-amz-signedheaders"
    }
    params = {
        "createdBy": "test-user",
        "nextToken": None,
        "ownedBy": "test-owner",
        "sessionIds": "test-session-id"
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    assert "sessions" in response.json()

if __name__ == "__main__":
    pytest.main()