import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_photos():
    short_name = "test_short_name"
    offset = 0
    count = 10

    url = f"{BASE_URL}/v2/tier2/{short_name}/photo/photos"
    params = {
        "offset": offset,
        "count": count
    }

    response = requests.get(url, params=params)

    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "Count" in response.json()
    assert "Data" in response.json()
    assert isinstance(response.json()["Data"], list)