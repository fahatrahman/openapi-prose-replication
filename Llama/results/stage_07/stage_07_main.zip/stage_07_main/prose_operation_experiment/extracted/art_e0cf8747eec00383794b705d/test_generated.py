# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_typeahead():
    headers = {
        'X-ListenAPI-Key': 'YOUR_API_KEY'
    }
    params = {
        'q': 'star wars',
        'show_podcasts': 1,
        'show_genres': 1,
        'safe_mode': 0
    }

    response = requests.get(BASE_URL + '/typeahead', headers=headers, params=params)
    assert response.status_code == 200
    assert response.headers['X-ListenAPI-FreeQuota'] > 0
    assert response.headers['X-ListenAPI-NextBillingDate'] >= datetime.now().isoformat() + '+00:00'
    assert response.headers['X-ListenAPI-Usage'] >= 0
    assert isinstance(float(response.headers['X-listenAPI-Latency-Seconds']), float)

    typeahead_response = response.json()
    assert isinstance(typeahead_response, dict)
    assert 'terms' in typeahead_response
    assert isinstance(typeahead_response['terms'], list)
    assert len(typeahead_response['terms']) > 0

    if 'podcasts' in typeahead_response:
        assert isinstance(typeahead_response['podcasts'], list)
        assert len(typeahead_response['podcasts']) <= 5
        assert all(isinstance(podcast, dict) for podcast in typeahead_response['podcasts'])

    if 'genres' in typeahead_response:
        assert isinstance(typeahead_response['genres'], list)
        assert all(isinstance(genre, dict) for genre in typeahead_response['genres'])