import os
import pytest
import requests
from urllib3.exception import InsecureRequestWarning

# Ignore warnings from urllib3
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

BASE_URL = "http://openapi.test"

@pytest.fixture
def cloud_function_generate_url():
    url = f"{BASE_URL}/v2beta/your_function_name:generateDownloadUrl"

    headers = {
        "Content-Type": "application/json",
    }

    request_body = {
        # Add your GenerateDownloadUrlRequest properties here if needed
    }

    response = requests.post(url, headers=headers, json=request_body)

    assert response.status_code == 200

    return response.json()