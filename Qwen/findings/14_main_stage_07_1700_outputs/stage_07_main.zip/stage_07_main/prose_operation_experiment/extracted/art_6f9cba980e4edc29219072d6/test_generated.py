import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_project():
    url = f"{BASE_URL}/v1alpha1/projects/location/targetProject"
    params = {
        "_xgafv": "1",
        "access_token": "example_access_token",
        "alt": "json",
        "callback": "example_callback",
        "fields": "name,status.done",
        "key": "example_key",
        "oauth_token": "example_oauth_token",
        "prettyPrint": False,
        "quotaUser": "example_quota_user",
        "uploadType": "multipart/form-data",
        "upload_protocol": "raw",
        "name": "projects/location/targetProject",
        "requestId": "unique_request_id"
    }
    headers = {
        "Authorization": "Bearer example_bearer_token"
    }
    response = requests.delete(url, params=params, headers=headers)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert 'name' in response.json()
    assert 'status' in response.json()
    assert 'done' in response.json()['status']