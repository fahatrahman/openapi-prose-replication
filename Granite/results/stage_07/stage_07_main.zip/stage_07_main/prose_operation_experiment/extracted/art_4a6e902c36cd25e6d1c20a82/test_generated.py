import os
import pytest
import requests
BASE_URL = "http://openapi.test"

def get_tracking_snippet(domain):
    url = f"{BASE_URL}/tracking/snippet"
    headers = {"Content-Type": "application/json"}
    response = requests.get(url, headers=headers, params={"domain": domain})

    if response.status_code == 200:
        return response.json()
    elif response.status_code == 400:
        raise Exception("Bad request")
    elif response.status_code == 401:
        raise Exception("Unauthorized")
    elif response.status_code == 403:
        raise Exception("Forbidden")
    elif response.status_code == 404:
        raise Exception("Not found")
    elif response.status_code == 429:
        raise Exception("Too many requests")
    else:
        raise Exception(f"Unexpected status code: {response.status_code}")

def test_get_tracking_snippet():
    domain = "example.com"
    try:
        result = get_tracking_snippet(domain)
        assert 'data' in result
        snippet = result['data']['snippet']
        domain_from_result = result['data']['domain']

        assert isinstance(snippet, str)
        assert isinstance(domain_from_result, str)
        assert domain_from_result == domain
    except Exception as e:
        pytest.fail(str(e))