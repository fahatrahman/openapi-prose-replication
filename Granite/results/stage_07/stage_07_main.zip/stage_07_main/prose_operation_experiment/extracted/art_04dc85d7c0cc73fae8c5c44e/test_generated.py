import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def client():
    return requests.Session()

def get_section_overview(client, reference):
    url = f"{BASE_URL}/api/Search/Paragraph/{reference}"
    response = client.get(url)

    if response.status_code == 200:
        return response.json()
    elif response.status_code == 400:
        raise ValueError("Bad Request")
    elif response.status_code == 404:
        raise Exception("Not Found")
    else:
        raise Exception(f"Unexpected status code: {response.status_code}")