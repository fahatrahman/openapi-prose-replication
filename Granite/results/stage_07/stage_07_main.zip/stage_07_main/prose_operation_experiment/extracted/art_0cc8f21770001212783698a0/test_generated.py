import os
import pytest
import requests
from requests_aws_sigv4 import AWSRequestsAuthV4

BASE_URL = "http://openapi.test"

@pytest.fixture
def auth():
    return AWSRequestsAuthV4(
        access_key=os.environ["AWS_ACCESS_KEY_ID"],
        secret_key=os.environ["AWS_SECRET_ACCESS_KEY"]
    )

def test_list_application_versions(auth):
    application_id = "example_app_id"
    response = requests.get(
        f"{BASE_URL}/applications/{application_id}/versions",
        headers={"Authorization": f"AWS4-HMAC-SHA256 Credential={os.environ['AWS_ACCESS_KEY_ID']}/{os.environ['AWS_DEFAULT_REGION']}:{os.environ['AWS_REQUEST_TIME']}"}
        # Add other required headers based on the actual HMAC signature generation
        # auth=auth  # Uncomment if you are using auth in the request
    )

    assert response.status_code == 200
    assert isinstance(response.json(), dict)