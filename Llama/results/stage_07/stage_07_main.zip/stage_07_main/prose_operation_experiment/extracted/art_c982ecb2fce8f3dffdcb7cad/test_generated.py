# -*- coding: utf-8 -*-
import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_cloudsupport_cases_comments_list():
    url = f"{BASE_URL}/v2beta/comments"
    params = {
        "parent": "zynntaco/xexg-autfnhu/zdpti/43595344",
        "pageSize": 10,
        "pageToken": ""
    }
    headers = {"X-Google-Fn-AF-Tags": "s2"}

    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    response.raise_for_status()

    data = response.json()
    assert isinstance(data, dict)

    comments = data["comments"]
    assert isinstance(comments, list)

    for comment in comments:
        assert isinstance(comment, dict)
        assert "body" in comment
        assert "createTime" in comment
        assert "creator" in comment
        assert "name" in comment
        assert "plainTextBody" in comment

    next_page_token = data.get("nextPageToken")
    if next_page_token:
        params["pageToken"] = next_page_token
        response = requests.get(url, headers=headers, params=params)
        assert response.status_code == 200
        response.raise_for_status()
        data = response.json()
        comments = data["comments"]
        # ... repeat process ...