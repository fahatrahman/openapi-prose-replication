# -*- coding: utf-8 -*-

import pytest
import json
import requests

BASE_URL = "http://openapi.test"

def test_GetTagsFromCisInstruction():
    url = f"{BASE_URL}/Employer/{EmployerId}/SubContractor/{SubContractorId}/CisInstruction/{CisInstructionId}/Tags"
    headers = {
        'Authorization': 'Auto',
        'Api-Version': 'default'
    }
    
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    
    try:
        link_collection = response.json()
        assert isinstance(link_collection, dict)
        assert 'Links' in link_collection
        
        links = link_collection['Links']
        assert isinstance(links, list)
        
        for link in links:
            assert '@href' in link
            assert '@rel' in link
            assert '@title' in link
            
            href = link['@href']
            rel = link['@rel']
            title = link['@title']
            
            print(f"HREF: {href}, REL: {rel}, TITLE: {title}")
    except json.JSONDecodeError:
        error_model = response.json()
        assert isinstance(error_model, dict)
        assert 'Description' in error_model
        assert 'ErrorCategory' in error_model
        assert 'Errors' in error_model
        
        description = error_model['Description']
        error_category = error_model['ErrorCategory']
        errors = error_model['Errors']
        
        print(f"DESCRIPTION: {description}, ERROR_CATEGORY: {error_category}, ERRORS: {errors}")

class TestGetTagsFromCisInstruction:
    @pytest.mark.parametrize("EmployerId, SubContractorId, CisInstructionId", [
        ('GD001', 'VVZ001', 'QXG001')
    ])
    def test_GetTagsFromCisInstruction_invalid_employer_id(self, EmployerId, SubContractorId, CisInstructionId):
        url = f"{BASE_URL}/Employer/{EmployerId}/SubContractor/{SubContractorId}/CisInstruction/{CisInstructionId}/Tags"
        headers = {
            'Authorization': 'Auto',
            'Api-Version': 'default'
        }
        
        response = requests.get(url, headers=headers)
        assert response.status_code != 200
        
        try:
            error_model = response.json()
            assert isinstance(error_model, dict)
            assert 'Description' in error_model
            assert 'ErrorCategory' in error_model
            assert 'Errors' in error_model
            
            description = error_model['Description']
            error_category = error_model['ErrorCategory']
            errors = error_model['Errors']
            
            print(f"DESCRIPTION: {description}, ERROR_CATEGORY: {error_category}, ERRORS: {errors}")
        except json.JSONDecodeError:
            pass

    @pytest.mark.parametrize("EmployerId, SubContractorId, CisInstructionId", [
        ('GD001', 'VVZ002', 'QXG001')
    ])
    def test_GetTagsFromCisInstruction_invalid_sub_contractor_id(self, EmployerId, SubContractorId, CisInstructionId):
        url = f"{BASE_URL}/Employer/{EmployerId}/SubContractor/{SubContractorId}/CisInstruction/{CisInstructionId}/Tags"
        headers = {
            'Authorization': 'Auto',
            'Api-Version': 'default'
        }
        
        response = requests.get(url, headers=headers)
        assert response.status_code != 200
        
        try:
            error_model = response.json()
            assert isinstance(error_model, dict)
            assert 'Description' in error_model
            assert 'ErrorCategory' in error_model
            assert 'Errors' in error_model
            
            description = error_model['Description']
            error_category = error_model['ErrorCategory']
            errors = error_model['Errors']
            
            print(f"DESCRIPTION: {description}, ERROR_CATEGORY: {error_category}, ERRORS: {errors}")
        except json.JSONDecodeError:
            pass

    @pytest.mark.parametrize("EmployerId, SubContractorId, CisInstructionId", [
        ('GD001', 'VVZ001', 'QXG002')
    ])
    def test_GetTagsFromCisInstruction_invalid_cis_instruction_id(self, EmployerId, SubContractorId, CisInstructionId):
        url = f"{BASE_URL}/Employer/{EmployerId}/SubContractor/{SubContractorId}/CisInstruction/{CisInstructionId}/Tags"
        headers = {
            'Authorization': 'Auto',
            'Api-Version': 'default'
        }
        
        response = requests.get(url, headers=headers)
        assert response.status_code != 200
        
        try:
            error_model = response.json()
            assert isinstance(error_model, dict)
            assert 'Description' in error_model
            assert 'ErrorCategory' in error_model
            assert 'Errors' in error_model
            
            description = error_model['Description']
            error_category = error_model['ErrorCategory']
            errors = error_model['Errors']
            
            print(f"DESCRIPTION: {description}, ERROR_CATEGORY: {error_category}, ERRORS: {errors}")
        except json.JSONDecodeError:
            pass

    @pytest.mark.parametrize("EmployerId, SubContractorId, CisInstructionId", [
        ('GD002', 'VVZ001', 'QXG001')
    ])
    def test_GetTagsFromCisInstruction_unauthorized(self, EmployerId, SubContractorId, CisInstructionId):
        url = f"{BASE_URL}/Employer/{EmployerId}/SubContractor/{SubContractorId}/CisInstruction/{CisInstructionId}/Tags"
        headers = {
            'Authorization': '',
            'Api-Version': 'default'
        }
        
        response = requests.get(url, headers=headers)
        assert response.status_code == 401
        
        try:
            error_model = response.json()
            assert isinstance(error_model, dict)
            assert 'Description' in error_model
            assert 'ErrorCategory' in error_model
            assert 'Errors' in error_model
            
            description = error_model['Description']
            error_category = error_model['ErrorCategory']
            errors = error_model['Errors']
            
            print(f"DESCRIPTION: {description}, ERROR_CATEGORY: {error_category}, ERRORS: {errors}")
        except json.JSONDecodeError:
            pass

    @pytest.mark.parametrize("EmployerId, SubContractorId, CisInstructionId", [
        ('GD001', 'VVZ001', 'QXG001')
    ])
    def test_GetTagsFromCisInstruction_api_version_not_supported(self, EmployerId, SubContractorId, CisInstructionId):
        url = f"{BASE_URL}/Employer/{EmployerId}/SubContractor/{SubContractorId}/CisInstruction/{CisInstructionId}/Tags"
        headers = {
            'Authorization': 'Auto',
            'Api-Version': 'unsupported-version'
        }
        
        response = requests.get(url, headers=headers)
        assert response.status_code == 500
        
        try:
            error_model = response.json()
            assert isinstance(error_model, dict)
            assert 'Description' in error_model
            assert 'ErrorCategory' in error_model
            assert 'Errors' in error_model
            
            description = error_model['Description']
            error_category = error_model['ErrorCategory']
            errors = error_model['Errors']
            
            print(f"DESCRIPTION: {description}, ERROR_CATEGORY: {error_category}, ERRORS: {errors}")
        except json.JSONDecodeError:
            pass

    @pytest.mark.parametrize("EmployerId, SubContractorId, CisInstructionId", [
        ('GD001', 'VVZ001', 'QXG001')
    ])
    def test_GetTagsFromCisInstruction_server_error(self, EmployerId, SubContractorId, CisInstructionId):
        url = f"{BASE_URL}/Employer/{EmployerId}/SubContractor/{SubContractorId}/CisInstruction/{CisInstructionId}/Tags"
        headers = {
            'Authorization': 'Auto',
            'Api-Version': 'default'
        }
        
        response = requests.get(url, headers=headers, allow_redirects=False)
        assert response.status_code == 500
        
        try:
            error_model = response.json()
            assert isinstance(error_model, dict)
            assert 'Description' in error_model
            assert 'ErrorCategory' in error_model
            assert 'Errors' in error_model
            
            description = error_model['Description']
            error_category = error_model['ErrorCategory']
            errors = error_model['Errors']
            
            print(f"DESCRIPTION: {description}, ERROR_CATEGORY: {error_category}, ERRORS: {errors}")
        except json.JSONDecodeError:
            pass