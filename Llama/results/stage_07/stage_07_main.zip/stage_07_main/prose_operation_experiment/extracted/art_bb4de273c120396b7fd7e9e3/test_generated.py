# -*- coding: utf-8 -*-
import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_jobs_projects_jobs_delete():
    name = "zynntaco/gna-pzzq-autfnhu/tdnx/1234"
    params = {
        "$.xgafv": "1",
        "access_token": "",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "",
        "oauth_token": "",
        "prettyPrint": "false",
        "quotaUser": "",
        "upload_protocol": "upload_protocol",
        "uploadType": "uploadType"
    }
    
    response = requests.request(
        method="DELETE",
        url=urljoin(BASE_URL, "/v3p1beta1/" + name),
        params=params,
        headers={},
        verify=False
    )
    assert response.status_code == 200