# -*- coding: utf-8 -*-
"""pytest tests for ServicePrincipals_ListOwners operation."""

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_ServicePrincipals_ListOwners():
    """Test ServicePrincipals_ListOwners operation."""
    
    url = f"{BASE_URL}/{{tenantID}}/servicePrincipals/{{objectId}}/owners"
    
    # Replace tenantID and objectId with actual values
    params = {
        "tenantID": "your_tenant_id",
        "objectId": "your_object_id",
        "api-version": "1.0"
    }
    
    headers = {"Content-Type": "application/json"}
    
    response = requests.get(url, params=params, headers=headers)
    
    assert response.status_code == 200
    
    try:
        response.raise_for_status()
    except requests.RequestException as err:
        pytest.fail(f"Request error: {err}")
        
    # Parse JSON response
    json_response = response.json()
    
    # Check if the response is in the expected format
    assert isinstance(json_response, dict)
    assert "@odata.context" in json_response
    assert "value" in json_response
    assert isinstance(json_response["value"], list)
    
    # Check if each item in the value array is a DirectoryObject
    for directory_object in json_response["value"]:
        assert isinstance(directory_object, dict)
        assert "id" in directory_object
        assert "displayName" in directory_object
        assert "type" in directory_object
        
    print("ServicePrincipals_ListOwners test passed.")