import pytest
import requests

BASE_URL = "http://openapi.test"

def test_errors_errorGroupsSearch():
    url = f"{BASE_URL}/v0.1/apps/owner_name/app_name/errors/errorGroups/search"
    headers = {
        "X-API-Token": "your_api_token_here"
    }
    params = {
        "$top": 10,
        "$skip": 0,
        "order": "desc",
        "sort": "matchingReportsCount",
        "filter": "",
        "q": ""
    }
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "errorGroups" in response.json()
    assert isinstance(response.json()["errorGroups"], list)

if __name__ == "__main__":
    pytest.main([__file__])