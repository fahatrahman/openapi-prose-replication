import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

@pytest.fixture
def headers():
    return {
        'Authorization': 'Bearer <your_access_token>',
        'Content-Type': 'application/json'
    }

def test_get_instance_size(headers):
    slug = "basic-xxs"
    url = f"{BASE_URL}/v2/apps/tiers/instance_sizes/{slug}"

    response = session.get(url, headers=headers)

    assert response.status_code == 200
    assert response.json()['instance_size']['slug'] == 'basic-xxs'