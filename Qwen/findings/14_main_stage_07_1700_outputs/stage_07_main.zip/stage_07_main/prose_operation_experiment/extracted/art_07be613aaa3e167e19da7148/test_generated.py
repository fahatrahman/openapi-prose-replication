import pytest
import requests

BASE_URL = "http://openapi.test"

def test_erc20_options():
    url = f"{BASE_URL}/erc20/{'some_address'}"
    response = requests.options(url)
    
    assert response.status_code == 200
    assert 'Access-Control-Allow-Headers' in response.headers
    assert 'Access-Control-Allow-Methods' in response.headers
    assert 'Access-Control-Allow-Origin' in response.headers