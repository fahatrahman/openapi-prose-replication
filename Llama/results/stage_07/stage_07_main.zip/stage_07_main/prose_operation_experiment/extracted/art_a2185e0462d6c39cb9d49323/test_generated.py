# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urljoin
from typing import Dict

BASE_URL = "http://openapi.test"

def test_cloudresourcemanager_organizations_get():
    name = "seztsxhbkkrag/[buhlhldxbmaaZp]"
    params: Dict[str, str] = {
        "$.xgafv": "1",
        "access_token": "",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "",
        "oauth_token": "",
        "prettyPrint": "false",
        "quotaUser": "",
        "upload_protocol": "",
        "uploadType": ""
    }
    
    response = requests.get(
        urljoin(BASE_URL, "/v1/" + name),
        params=params,
        headers={
            "Authorization": f"Bearer {params['access_token']}",
            "Content-Type": "application/json"
        }
    )
    
    assert response.status_code == 200
    
    # Add assertions about the JSON content here if needed