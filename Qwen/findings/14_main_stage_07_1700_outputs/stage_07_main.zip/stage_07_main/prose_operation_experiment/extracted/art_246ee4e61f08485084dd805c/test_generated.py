import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_packages():
    url = f"{BASE_URL}/api/patch/v1/packages/"
    params = {
        "limit": 10,
        "offset": 0,
        "sort": "name",
        "search": "example",
        "filter[name]": "package_name",
        "filter[systems_installed]": "5",
        "filter[systems_updatable]": "2",
        "filter[summary]": "summary_text",
        "tags": ["tag1", "tag2"],
        "filter[system_profile][sap_system]": "yes",
        "filter[system_profile][sap_sids][in]": ["SID1", "SID2"]
    }
    headers = {
        "x-rh-identity": "your_identity_token"
    }

    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert "data" in data
    assert "links" in data
    assert "meta" in data
    assert isinstance(data["data"], list)
    assert "first" in data["links"]
    assert "last" in data["links"]
    assert "next" in data["links"]
    assert "previous" in data["links"]
    assert "filter" in data["meta"]
    assert "limit" in data["meta"]
    assert "offset" in data["meta"]
    assert "search" in data["meta"]
    assert "sort" in data["meta"]
    assert "subtotals" in data["meta"]
    assert "total_items" in data["meta"]

if __name__ == "__main__":
    pytest.main()