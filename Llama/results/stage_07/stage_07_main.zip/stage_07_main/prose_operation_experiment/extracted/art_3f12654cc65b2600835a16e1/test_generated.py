# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime
from json import JSONDecodeError

BASE_URL = "http://openapi.test"

def test_update_an_api_version():
    api_id = "test-api-id"
    api_version_id = "test-api-version-id"
    
    url = f"{BASE_URL}/apis/{api_id}/versions/{api_version_id}"
    headers = {"Content-Type": "application/json"}
    body = {
        "version": {
            "name": "2.0"
        }
    }

    response = requests.put(url, headers=headers, json=body)

    assert response.status_code == 200
    try:
        response_json = response.json()
        expected_response = {
            "version": {
                "api": "2b95d07c-8379-4bd1-924f-e7e1af185284",
                "createdAt": datetime(2019, 7, 26, 11, 24, 15).isoformat() + "Z",
                "createdBy": "12",
                "id": "d71cf403-c549-4c7c-9dc6-a6a105acf67c",
                "name": "2.0",
                "updatedAt": datetime(2019, 8, 9, 9, 27, 36).isoformat() + "Z",
                "updatedBy": "5665"
            }
        }
        assert response_json == expected_response
    except JSONDecodeError:
        pytest.fail("Failed to parse JSON response")