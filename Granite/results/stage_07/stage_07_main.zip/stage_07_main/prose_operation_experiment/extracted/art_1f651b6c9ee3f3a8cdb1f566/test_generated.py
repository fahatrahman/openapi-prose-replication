import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retry strategy for handling transient errors
session = requests.Session()
retry_strategy = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

# Set up authentication headers
account_sid = os.getenv("ACCOUNT_SID")
auth_token = os.getenv("AUTH_TOKEN")
headers = {
    "Authorization": f"Basic {account_sid}:{auth_token}",
}

@pytest.fixture
def fetch_dialing_permissions_country():
    def _fetch_dialing_permissions_country(iso_code):
        url = f"{BASE_URL}/v1/DialingPermissions/Countries/{iso_code}"
        response = session.get(url, headers=headers)

        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to fetch dialing permissions for country {iso_code}: {response.text}")

    return _fetch_dialing_permissions_country

def test_fetch_dialing_permissions_country(fetch_dialing_permissions_country):
    iso_code = "US"  # Replace with actual ISO code you want to test
    result = fetch_dialing_permissions_country(iso_code)
    
    assert isinstance(result, dict)
    assert all(key in result for key in ["iso_code", "name", "continent"])