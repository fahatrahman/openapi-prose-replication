import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session for retry on failure
session = requests.Session()
retries = Retry(total=3, backoff_factor=0.1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

@pytest.fixture
def cis_line_types_tags():
    employer_id = "example_employer_id"
    api_version = "default"

    url = f"{BASE_URL}/Employer/{employer_id}/CisLineTypes/Tags"

    headers = {
        "Authorization": "Auto",
        "Api-Version": api_version
    }

    response = session.get(url, headers=headers)

    if response.status_code == 200:
        return response.json()
    else:
        error_model = response.json()
        assert error_model["Description"] == "Bad Request" if response.status_code == 400 else \
            "Unauthorized" if response.status_code == 401 else \
            "Not Found" if response.status_code == 404 else "Internal Server Error", \
            f"Unexpected error: {error_model['Description']}"
        raise Exception(f"Request failed with status code {response.status_code}: {error_model}")