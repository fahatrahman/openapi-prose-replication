import pytest
import requests

BASE_URL = "http://openapi.test"

def test_check_if_show_is_followed():
    show_id = 123  # Replace with actual show ID for testing
    url = f"{BASE_URL}/user/follows/shows/{show_id}"
    headers = {
        'Authorization': 'Basic your_base64_encoded_token'  # Replace with actual token
    }
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert response.json().get('_embedded', {}).get('show') is not None

def test_check_if_show_not_followed():
    show_id = 456  # Replace with actual show ID for testing
    url = f"{BASE_URL}/user/follows/shows/{show_id}"
    headers = {
        'Authorization': 'Basic your_base64_encoded_token'  # Replace with actual token
    }
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 404