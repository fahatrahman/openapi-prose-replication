# -*- coding: utf-8 -*-
"""
pytest module for testing API endpoints defined in the OpenAPI specification.
"""

import pytest
import requests
from pydantic import BaseModel
from typing import Dict

class AppPost(BaseModel):
    apns_certificate: str = None
    apns_private_key: str = None
    apns_use_sandbox_endpoint: bool = None
    fcm_key: str = None
    name: str
    status: str = None
    tls_only: bool = None

class ErrorResponse(BaseModel):
    code: int
    details: Dict = None
    href: str
    message: str
    status_code: int

class AppResponse(BaseModel):
    _links: Dict = None
    account_id: str
    apns_use_sandbox_endpoint: bool = None
    created: int
    id: str
    modified: int
    name: str
    status: str
    tls_only: bool = None

BASE_URL = "http://openapi.test"

def test_create_app():
    """
    Test creating a new app.

    :return: None
    """

    # Define the app to create
    app_data = {"name": "My New App"}

    # Convert the app data into a JSON payload
    json_payload = AppPost(**app_data).json()

    # Send a POST request to the endpoint
    response = requests.post(
        f"{BASE_URL}/accounts/{pytest.config.getoption('account_id')}/apps",
        headers={"Authorization": f"Bearer {pytest.config.getoption('token')}"},
        json=json_payload,
    )

    # Check if the response was successful
    assert response.status_code == 201

    # Parse the response content as JSON
    app_response = AppResponse.parse_raw(response.content)

    # Check if the app was created successfully
    assert app_response.name == app_data["name"]
    assert app_response.id is not None
    assert app_response.account_id == pytest.config.getoption("account_id")

def test_create_app_invalid_name(caplog):
    """
    Test creating a new app with an invalid name.

    :return: None
    """

    # Define the app to create with an invalid name
    app_data = {"name": ""}

    # Convert the app data into a JSON payload
    json_payload = AppPost(**app_data).json()

    # Send a POST request to the endpoint
    response = requests.post(
        f"{BASE_URL}/accounts/{pytest.config.getoption('account_id')}/apps",
        headers={"Authorization": f"Bearer {pytest.config.getoption('token')}"},
        json=json_payload,
    )

    # Check if the response was unsuccessful
    assert response.status_code != 201

    # Check if the correct error message was logged
    assert "Validation failed" in caplog.text

def test_create_app_no_token(caplog):
    """
    Test creating a new app without authentication.

    :return: None
    """

    # Define the app to create
    app_data = {"name": "My New App"}

    # Convert the app data into a JSON payload
    json_payload = AppPost(**app_data).json()

    # Send a POST request to the endpoint
    response = requests.post(
        f"{BASE_URL}/accounts/{pytest.config.getoption('account_id')}/apps",
        json=json_payload,
    )

    # Check if the response was unsuccessful
    assert response.status_code != 201

    # Check if the correct error message was logged
    assert "Unauthorized" in caplog.text

if __name__ == "__main__":
    pytest.main([__file__, "-s", "--account_id=my_account", "--token=my_token"])