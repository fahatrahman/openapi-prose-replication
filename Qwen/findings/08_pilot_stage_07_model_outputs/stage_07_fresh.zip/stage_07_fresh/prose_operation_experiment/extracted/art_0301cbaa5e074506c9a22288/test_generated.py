import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_time_off_types():
    params = {
        "limit": 2,
        "offset": 0
    }
    response = requests.get(f"{BASE_URL}/company/time-off-types", params=params)
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert isinstance(data["data"], list)
    for item in data["data"]:
        assert "attributes" in item
        assert "name" in item["attributes"]
        assert isinstance(item["attributes"]["name"], str)
        assert "id" in item
        assert isinstance(item["id"], int)
        assert "type" in item
        assert item["type"] == "TimeOffType"