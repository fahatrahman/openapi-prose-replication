import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_organization():
    name = "seztsxhbkkrag/1234"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token_here",
        "alt": "json",
        "prettyPrint": True,
        "quotaUser": "your_quota_user_here"
    }
    response = requests.get(f"{BASE_URL}/v1/{name}", params=params)
    assert response.status_code == 200
    organization = response.json()
    assert "name" in organization
    assert "displayName" in organization
    assert "lifecycleState" in organization
    assert "creationTime" in organization
    assert "owner" in organization
    assert "directoryCustomerId" in organization["owner"]