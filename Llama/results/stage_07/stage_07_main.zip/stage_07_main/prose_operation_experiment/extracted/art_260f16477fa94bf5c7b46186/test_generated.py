import pytest
import requests
from jsonschema import ValidationError

BASE_URL = "http://openapi.test"

def test_get_authentication_result():
    url = f"{BASE_URL}/getAuthenticationResult"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Basic your_basic_auth_credentials_here"
    }
    data = {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "pspReference": "9935272408535455"
    }

    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
    except requests.exceptions.HTTPError as e:
        assert False, f"Expected success, got {e.response.status_code}"
    except requests.exceptions.RequestException as e:
        assert False, str(e)

def test_get_authentication_result_unauthorized():
    url = f"{BASE_URL}/getAuthenticationResult"
    headers = {
        "Content-Type": "application/json"
    }
    data = {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "pspReference": "9935272408535455"
    }

    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
    except requests.exceptions.HTTPError as e:
        assert e.response.status_code == 401
    except requests.exceptions.RequestException as e:
        assert False, str(e)

def test_get_authentication_result_bad_request():
    url = f"{BASE_URL}/getAuthenticationResult"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Basic your_basic_auth_credentials_here"
    }
    data = {
        "merchantAccount": None,
        "pspReference": "9935272408535455"
    }

    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
    except requests.exceptions.HTTPError as e:
        assert e.response.status_code == 400
    except requests.exceptions.RequestException as e:
        assert False, str(e)

def test_get_authentication_result_internal_server_error():
    url = f"{BASE_URL}/getAuthenticationResult"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Basic your_basic_auth_credentials_here"
    }
    data = {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "pspReference": "invalid_psp_reference"
    }

    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
    except requests.exceptions.HTTPError as e:
        assert e.response.status_code == 500
    except requests.exceptions.RequestException as e:
        assert False, str(e)