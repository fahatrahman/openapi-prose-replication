# -*- coding: utf-8 -*-

import pytest
import json
from requests.auth import HTTPBasicAuth
import requests

BASE_URL = "http://openapi.test"

def test_attributes_computed_post():
    url = f"{BASE_URL}/attributes/computed"
    
    # Create a basic auth object
    auth = HTTPBasicAuth("username", "password")
    
    # Define the attribute schema
    attribute_schema = {
        "attribute": "example_attribute",
        "description": "Example description",
        "expression": "example_expression",
        "id": 123,
        "type": "Njvrxe"  # Replace with actual type
    }
    
    # Serialize the attribute schema into JSON
    body = json.dumps(attribute_schema)
    
    # Send the POST request
    response = requests.post(url, headers={"Content-Type": "application/json"}, 
                             auth=auth, data=body)
    
    # Assert that the response was successful
    assert response.status_code == 200
    
    # Parse the response content as JSON
    response_body = json.loads(response.content)
    
    # Assert that the response matches the expected schema
    assert response_body["attribute"] == attribute_schema["attribute"]
    assert response_body["description"] == attribute_schema["description"]
    assert response_body["expression"] == attribute_schema["expression"]
    assert response_body["id"] == attribute_schema["id"]
    assert response_body["type"] == attribute_schema["type"]

if __name__ == "__main__":
    pytest.main([__file__])