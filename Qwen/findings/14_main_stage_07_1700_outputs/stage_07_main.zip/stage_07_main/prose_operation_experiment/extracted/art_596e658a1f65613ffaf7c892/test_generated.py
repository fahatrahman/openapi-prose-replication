import pytest
import requests

BASE_URL = "http://openapi.test"

def test_erc20_get():
    response = requests.get(f"{BASE_URL}/erc20")
    assert response.status_code == 200
    assert response.json() == {}