import pytest
import requests

BASE_URL = "http://openapi.test"

def test_divisions_search_total_results():
    url = f"{BASE_URL}/data/divisions.json/searchTotalResults"
    params = {
        "format": "json",
        "queryParameters.searchTerm": "example",
        "queryParameters.memberId": 123,
        "queryParameters.includeWhenMemberWasTeller": True,
        "queryParameters.startDate": "2023-01-01T00:00:00Z",
        "queryParameters.endDate": "2023-12-31T23:59:59Z",
        "queryParameters.divisionNumber": 456
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    assert isinstance(response.json(), int)

if __name__ == "__main__":
    pytest.main()