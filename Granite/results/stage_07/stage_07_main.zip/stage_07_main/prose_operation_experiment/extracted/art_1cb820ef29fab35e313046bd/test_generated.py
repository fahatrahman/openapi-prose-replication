import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retry strategy
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
session.mount("https://", adapter)
session.mount("http://", adapter)

# Define headers
headers = {
    "Authorization": "Auto",
    "Api-Version": "default",
}

# Pension ID and Employer ID
pension_id = "VQR001"
employer_id = "GD001"

@pytest.mark.parametrize("employer_id, pension_id", [(employer_id, pension_id)])
def test_get_pension(employer_id, pension_id):
    url = f"{BASE_URL}/Employer/{employer_id}/Pension/{pension_id}"
    
    response = session.get(url, headers=headers)

    if response.status_code == 200:
        pension_data = response.json()
        assert isinstance(pension_data, dict)
        print("Pension retrieved successfully.")
    elif response.status_code == 400:
        error_model = response.json()
        assert isinstance(error_model, dict)
        print(f"Error: {error_model['Description']}")
    elif response.status_code == 401:
        error_model = response.json()
        assert isinstance(error_model, dict)
        print(f"Unauthorized: {error_model['Description']}")
    elif response.status_code == 404:
        error_model = response.json()
        assert isinstance(error_model, dict)
        print(f"Not Found: {error_model['Description']}")
    else:
        error_model = response.json()
        assert isinstance(error_model, dict)
        print(f"Unexpected Error: {error_model['Description']}")
