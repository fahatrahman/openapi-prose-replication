import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
session.mount("http://", adapter)

@pytest.mark.parametrize("npm_name", ["peertube-plugin-auth-ldap"])
def test_get_plugin(npm_name):
    url = f"{BASE_URL}/api/v1/plugins/{npm_name}"

    response = session.get(url, verify=False, headers={"Authorization": "Bearer your_access_token"})

    if response.status_code == 200:
        plugin = response.json()
        assert isinstance(plugin, dict)
        assert plugin.get("name") == npm_name
    elif response.status_code == 404:
        assert False, f"Plugin {npm_name} not found."
    else:
        assert False, f"Unexpected status code: {response.status_code}"