import pytest
import requests

BASE_URL = "http://openapi.test"

def test_skill_normalization():
    skill_name = "example_skill"
    response = requests.get(f"{BASE_URL}/skills/normalize", params={"skill_name": skill_name})
    assert response.status_code == 200
    normalized_skills = response.json()
    assert isinstance(normalized_skills, list)
    for skill in normalized_skills:
        assert isinstance(skill, dict)
        assert "skill_name" in skill
        assert "uuid" in skill
        assert isinstance(skill["skill_name"], str)
        assert isinstance(skill["uuid"], str)

if __name__ == "__main__":
    pytest.main()