import pytest
import requests

BASE_URL = "http://openapi.test"

def test_add_text_broadcast_batch():
    url = f"{BASE_URL}/texts/broadcasts/{123}/batches"
    headers = {"Authorization": "Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=="}
    body = {
        "contactListId": 456,
        "name": "Test Broadcast",
        "recipients": [
            {"attributes": {"key": "value"}, "contactId": 789, "fromNumber": "+1-123-456-7890", "phoneNumber": "+1-987-654-3210"}
        ],
        "scrubDuplicates": True
    }

    response = requests.post(url, headers=headers, json=body)

    assert response.status_code == 201
    resource_id = response.json()["id"]
    assert isinstance(resource_id, int)