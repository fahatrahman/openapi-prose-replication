import pytest
import requests

BASE_URL = "http://openapi.test"

def test_upcoming_schedule_by_player():
    url = f"{BASE_URL}/json/UpcomingScheduleByPlayer/90026231"
    headers = {
        "Ocp-Apim-Subscription-Key": "your_subscription_key_here"
    }
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    for game in data:
        assert isinstance(game, dict)
        assert 'GameId' in game
        assert 'HomeTeamName' in game
        assert 'AwayTeamName' in game
        assert 'DateTime' in game
        if 'Attendance' in game:
            assert isinstance(game['Attendance'], int) or game['Attendance'] is None
        if 'DrawMoneyLine' in game:
            assert isinstance(game['DrawMoneyLine'], int) or game['DrawMoneyLine'] is None
        # Add more assertions based on the schema if needed