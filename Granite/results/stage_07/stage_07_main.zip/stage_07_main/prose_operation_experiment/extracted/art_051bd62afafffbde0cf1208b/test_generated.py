import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.fixture
def header():
    return {"Authorization": f"Bearer {os.environ['DIGITALOCEAN_TOKEN']}"}

def test_apps_list_instance_sizes():
    url = f"{BASE_URL}/v2/apps/tiers/instance_sizes"
    response = SESSION.get(url, headers=header())

    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "instance_sizes" in response.json()
    assert isinstance(response.json()["instance_sizes"], list)