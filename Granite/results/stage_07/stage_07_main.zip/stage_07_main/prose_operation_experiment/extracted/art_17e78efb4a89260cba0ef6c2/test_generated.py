import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
SESSION.mount("https://", HTTPAdapter(max_retries=3))
SESSION.mount("http://", HTTPAdapter(max_retries=3))

@pytest.fixture
def competition_list():
    for format in ["xml", "json"]:
        response = SESSION.get(urljoin(BASE_URL, f"/{format}/Competitions"))
        response.raise_for_status()
        if format == "json":
            yield response.json()["value"]
        else:
            # Assuming XML response can be parsed using dict comprehension
            import xmltodict
            response_dict = xmltodict.parse(response.content)
            yield [Competition(**comp) for comp in response_dict["competitions"]["competition"]]

class Competition:
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

class Round:
    pass  # Implement as needed based on schema

class Season:
    pass  # Implement as needed based on schema