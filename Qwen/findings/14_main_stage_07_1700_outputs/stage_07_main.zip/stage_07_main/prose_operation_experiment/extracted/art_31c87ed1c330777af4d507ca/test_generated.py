import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_images_from_predictions():
    url = f"{BASE_URL}/projects/{project_id}/images/predictions"
    headers = {
        "Training-Key": "{API Key}",
        "Content-Type": "application/json"
    }
    payload = {
        "images": [
            {
                "id": "4d6eb844-42ee-42bc-bd6f-c32455ef07c9",
                "regions": [
                    {
                        "tagId": "b607964f-7bd6-4a3b-a869-6791fb6aab87",
                        "left": 10,
                        "top": 20,
                        "width": 30,
                        "height": 40
                    }
                ],
                "tagIds": [
                    "b607964f-7bd6-4a3b-a869-6791fb6aab87"
                ]
            }
        ],
        "tagIds": [
            "b607964f-7bd6-4a3b-a869-6791fb6aab87"
        ]
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 200
    assert response.json()["isBatchSuccessful"]