import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_an_external_account():
    headers = {
        'Authorization': 'Bearer your_access_token_here',
        'Content-Type': 'application/json'
    }
    payload = {
        "account_number": "987654321",
        "description": "Landlord",
        "routing_number": "101050001"
    }
    response = requests.post(f"{BASE_URL}/external_accounts", headers=headers, json=payload)
    
    assert response.status_code == 200
    assert 'external_account' in response.json()
    assert 'id' in response.json()['external_account']
    assert 'created_at' in response.json()['external_account']
    assert 'description' in response.json()['external_account']
    assert 'status' in response.json()['external_account']
    assert 'routing_number' in response.json()['external_account']
    assert 'account_number' in response.json()['external_account']
    assert 'funding' in response.json()['external_account']
    assert 'verification_status' in response.json()['external_account']

if __name__ == "__main__":
    pytest.main()