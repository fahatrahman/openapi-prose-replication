import pytest
import requests

BASE_URL = "http://openapi.test"

def test_schedule():
    url = f"{BASE_URL}/json/Schedule/1"
    headers = {
        "Ocp-Apim-Subscription-Key": "your_subscription_key_here"
    }
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    for game in data:
        assert isinstance(game, dict)
        assert 'GameId' in game
        assert isinstance(game['GameId'], int)
        assert 'HomeTeamName' in game
        assert isinstance(game['HomeTeamName'], str)
        assert 'AwayTeamName' in game
        assert isinstance(game['AwayTeamName'], str)
        assert 'Status' in game
        assert isinstance(game['Status'], str)

if __name__ == "__main__":
    pytest.main()