import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

# Custom session for handling retries
class OpenapiSession(requests.Session):
    def __init__(self):
        super().__init__()
        self.mount("https://", HTTPAdapter(max_retries=3))

session = OpenapiSession()

def test_create_cis_instruction():
    employer_id = "ER001"
    subcontractor_id = "SUB001"
    authorization = "Auto"
    api_version = "default"

    cis_instruction = {
        "CisLineTag": "TEST_TAG",
        "CisLineType": "TEST_TYPE",
        "Description": "Test Description",
        "PayFrequency": "Monthly",
        "PeriodEnd": 20230630,
        "PeriodStart": 20230101,
        "TaxYearEnd": 2023,
        "TaxYearStart": 2023,
        "UOM": "Month",
        "Units": 100.0,
        "VAT": 20.0,
        "Value": 1000.0
    }

    endpoint = urljoin(BASE_URL, f"/Employer/{employer_id}/SubContractor/{subcontractor_id}/CisInstructions")

    response = session.post(endpoint, json=cis_instruction, headers={"Authorization": authorization, "Api-Version": api_version})

    assert response.status_code == 201, f"Request failed with status code {response.status_code}: {response.json()}"