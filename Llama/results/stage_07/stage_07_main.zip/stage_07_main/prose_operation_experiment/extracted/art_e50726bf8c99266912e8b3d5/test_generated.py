import pytest
import requests
from jsonschema import ValidationError, SchemaError
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_patch_pension():
    url = urljoin(BASE_URL, "/Employer/{EmployerId}/Pension/{PensionId}")
    headers = {
        'Authorization': 'Auto',
        'Api-Version': 'default'
    }

    pension = {
        'AECompatible': True,
        'Certification': 'Set1',
        'Code': 'test_code',
        'ContributionDeductionDay': 10,
        'EffectiveDate': '2022-01-01',
        'EmployeeContributionCash': 100.00,
        'EmployeeContributionPercent': 5.00,
        'EmployerContributionCash': 50.00,
        'EmployerContributionPercent': 10.00,
        'EmployerNiSaving': False,
        'EmployerNiSavingPercentage': 20.00,
        'Group': 'group_test',
        'LowerThreshold': 3000.00,
        'MetaData': {},
        'NextRevisionDate': '2023-01-01',
        'PensionablePayCodes': ['pay_code_1', 'pay_code_2'],
        'ProRataMethod': 'Annual260Days',
        'ProviderEmployerRef': 'provider_ref_test',
        'ProviderName': 'provider_name_test',
        'QualifyingPayCodes': ['qualifying_pay_code_1', 'qualifying_pay_code_2'],
        'RasRoundingOverride': 'PennyUp',
        'Revision': 1,
        'RoundingOption': 'PennyUp',
        'SalarySacrifice': False,
        'SchemeName': 'scheme_name_test',
        'SubGroup': 'sub_group_test',
        'TaxationMethod': 'NetBased',
        'UpperThreshold': 4500.00,
        'UseAEThresholds': True
    }

    response = requests.patch(url.format(EmployerId='ER001', PensionId='PEN001'), headers=headers, json=pension)
    assert response.status_code == 200
    try:
        response.json()
    except ValueError:
        pytest.fail("Response is not valid JSON")

def test_patch_pension_invalid_request():
    url = urljoin(BASE_URL, "/Employer/{EmployerId}/Pension/{PensionId}")
    headers = {
        'Authorization': 'Auto',
        'Api-Version': 'default'
    }

    pension = {}

    response = requests.patch(url.format(EmployerId='ER001', PensionId='PEN001'), headers=headers, json=pension)
    assert response.status_code == 400
    try:
        response.json()
    except ValueError:
        pytest.fail("Response is not valid JSON")

def test_patch_pension_unauthorized():
    url = urljoin(BASE_URL, "/Employer/{EmployerId}/Pension/{PensionId}")
    headers = {
        'Authorization': '',
        'Api-Version': 'default'
    }

    pension = {
        'AECompatible': True,
        'Certification': 'Set1',
        'Code': 'test_code',
        'ContributionDeductionDay': 10,
        'EffectiveDate': '2022-01-01',
        'EmployeeContributionCash': 100.00,
        'EmployeeContributionPercent': 5.00,
        'EmployerContributionCash': 50.00,
        'EmployerContributionPercent': 10.00,
        'EmployerNiSaving': False,
        'EmployerNiSavingPercentage': 20.00,
        'Group': 'group_test',
        'LowerThreshold': 3000.00,
        'MetaData': {},
        'NextRevisionDate': '2023-01-01',
        'PensionablePayCodes': ['pay_code_1', 'pay_code_2'],
        'ProRataMethod': 'Annual260Days',
        'ProviderEmployerRef': 'provider_ref_test',
        'ProviderName': 'provider_name_test',
        'QualifyingPayCodes': ['qualifying_pay_code_1', 'qualifying_pay_code_2'],
        'RasRoundingOverride': 'PennyUp',
        'Revision': 1,
        'RoundingOption': 'PennyUp',
        'SalarySacrifice': False,
        'SchemeName': 'scheme_name_test',
        'SubGroup': 'sub_group_test',
        'TaxationMethod': 'NetBased',
        'UpperThreshold': 4500.00,
        'UseAEThresholds': True
    }

    response = requests.patch(url.format(EmployerId='ER001', PensionId='PEN001'), headers=headers, json=pension)
    assert response.status_code == 401
    try:
        response.json()
    except ValueError:
        pytest.fail("Response is not valid JSON")

def test_patch_pension_not_found():
    url = urljoin(BASE_URL, "/Employer/{EmployerId}/Pension/{PensionId}")
    headers = {
        'Authorization': 'Auto',
        'Api-Version': 'default'
    }

    pension = {
        'AECompatible': True,
        'Certification': 'Set1',
        'Code': 'test_code',
        'ContributionDeductionDay': 10,
        'EffectiveDate': '2022-01-01',
        'EmployeeContributionCash': 100.00,
        'EmployeeContributionPercent': 5.00,
        'EmployerContributionCash': 50.00,
        'EmployerContributionPercent': 10.00,
        'EmployerNiSaving': False,
        'EmployerNiSavingPercentage': 20.00,
        'Group': 'group_test',
        'LowerThreshold': 3000.00,
        'MetaData': {},
        'NextRevisionDate': '2023-01-01',
        'PensionablePayCodes': ['pay_code_1', 'pay_code_2'],
        'ProRataMethod': 'Annual260Days',
        'ProviderEmployerRef': 'provider_ref_test',
        'ProviderName': 'provider_name_test',
        'QualifyingPayCodes': ['qualifying_pay_code_1', 'qualifying_pay_code_2'],
        'RasRoundingOverride': 'PennyUp',
        'Revision': 1,
        'RoundingOption': 'PennyUp',
        'SalarySacrifice': False,
        'SchemeName': 'scheme_name_test',
        'SubGroup': 'sub_group_test',
        'TaxationMethod': 'NetBased',
        'UpperThreshold': 4500.00,
        'UseAEThresholds': True
    }

    response = requests.patch(url.format(EmployerId='ER002', PensionId='PEN002'), headers=headers, json=pension)
    assert response.status_code == 404
    try:
        response.json()
    except ValueError:
        pytest.fail("Response is not valid JSON")