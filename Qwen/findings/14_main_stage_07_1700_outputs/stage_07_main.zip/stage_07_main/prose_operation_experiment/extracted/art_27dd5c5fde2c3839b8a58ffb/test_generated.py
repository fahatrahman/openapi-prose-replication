import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_multiple_artists():
    ids = "2CIMQHirSU0MQqyYHq0eOx,57dN52uHvrHOxijzpIgu3E,1vCWHaC5f2uS3yhpwWbIA6"
    url = f"{BASE_URL}/artists?ids={ids}"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert "artists" in response.json()
    assert len(response.json()["artists"]) == 3

@pytest.mark.parametrize("status_code, expected_error_message", [
    (401, "Bad or expired token"),
    (403, "Bad OAuth request"),
    (429, "The app has exceeded its rate limits")
])
def test_error_responses(status_code, expected_error_message):
    ids = "invalid_id"
    url = f"{BASE_URL}/artists?ids={ids}"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == status_code
    assert "error" in response.json()
    assert response.json()["error"]["message"] == expected_error_message