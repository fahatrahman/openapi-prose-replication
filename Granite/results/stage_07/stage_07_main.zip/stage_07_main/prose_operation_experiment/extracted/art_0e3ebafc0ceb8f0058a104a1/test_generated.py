import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session for retries on connection errors
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

@pytest.fixture
def username():
    return "your_username"  # Replace with actual username

def create_dashboard(session, username):
    endpoint = f"{BASE_URL}/{username}/dashboards"

    dashboard_data = {
        "description": "Test Dashboard",
        "key": "test_key",
        "name": "Test Name"
    }
    
    response = session.post(endpoint, json=dashboard_data)
    assert response.status_code == 200
    return response.json()

def test_create_dashboard(session, username):
    dashboard = create_dashboard(session, username)
    assert dashboard["description"] == "Test Dashboard"
    assert dashboard["key"] == "test_key"
    assert dashboard["name"] == "Test Name"