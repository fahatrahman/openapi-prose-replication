# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_alloydb_projects_locations_operations_delete():
    url = f"{BASE_URL}/v1beta/{'operations'}"
    params = {
        "$.xgafv": "1",
        "access_token": None,
        "alt": "json",
        "callback": None,
        "fields": None,
        "key": None,
        "oauth_token": None,
        "prettyPrint": "false",
        "quotaUser": None,
        "upload_protocol": "raw",
        "uploadType": "media",
        "name": "operations",
        "validateOnly": False
    }
    headers = {}
    response = requests.request(
        "DELETE", 
        url, 
        params=params, 
        headers=headers
    )
    assert response.status_code == 200