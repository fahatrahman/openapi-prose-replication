# pylint: disable=invalid-name,too-many-arguments
import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_runtimeconfig_operations_delete():
    """Test runtimeconfig operations delete."""
    name = "test_name"
    url = urljoin(BASE_URL, "/v1/" + name)
    headers = {"accept": "application/json"}
    params = {
        "$.xgafv": "1",
        "access_token": "",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "",
        "oauth_token": "",
        "prettyPrint": "false",
        "quotaUser": "",
        "upload_protocol": "",
        "uploadType": ""
    }
    security = [
        {"Oauth2": ["https://www.googleapis.com/auth/cloud-platform"]},
        {"Oauth2c": ["https://www.googleapis.com/auth/cloud-platform"]}
    ]

    response = requests.delete(url, headers=headers, params=params)

    assert response.status_code == 200
    assert response.json() is None