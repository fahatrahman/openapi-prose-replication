import pytest
import requests

BASE_URL = "http://openapi.test"

def test_operating_systems_list():
    url = f"{BASE_URL}/userprofiles/{profileId}/operatingSystems"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token",
        "alt": "json",
        "callback": "your_callback",
        "fields": "kind,operatingSystems(dartId,name)",
        "key": "your_api_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": True,
        "quotaUser": "your_quota_user",
        "uploadType": "media",
        "upload_protocol": "raw"
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    assert response.json()["kind"] == "dfareporting#operatingSystemsListResponse"
    assert isinstance(response.json()["operatingSystems"], list)

if __name__ == "__main__":
    pytest.main()