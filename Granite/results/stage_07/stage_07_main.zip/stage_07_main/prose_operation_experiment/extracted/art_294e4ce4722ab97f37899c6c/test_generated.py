import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retry strategy for handling transient errors
session = requests.Session()
retry_strategy = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def api_key():
    return os.environ["API_KEY"]

@pytest.mark.parametrize("project_id", ["bc3f7dad-5544-468c-8573-3ef04d55463e"])
def test_get_project(project_id, api_key):
    endpoint = f"{BASE_URL}/projects/{project_id}"

    headers = {
        "ApiKey": api_key
    }

    response = session.get(endpoint, headers=headers)

    assert response.status_code == 200
    project = response.json()

    # Add additional assertions based on expected values from examples
    assert project["created"] == "2017-12-18T05:43:18.08Z"
    assert project["description"] == "A test project"
    assert project["id"] == project_id
    assert project["lastModified"] == "2017-12-18T05:43:18.0962423Z"
    assert project["name"] == "My New Project"
    assert project["settings"]["domainId"] == "ee85a74c-405e-4adc-bb47-ffa8ca0c9f31"