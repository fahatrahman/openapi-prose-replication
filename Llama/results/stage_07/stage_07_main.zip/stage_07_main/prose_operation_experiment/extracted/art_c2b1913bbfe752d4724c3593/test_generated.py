# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_domain():
    response = requests.get(f"{BASE_URL}/domain/{'48cf1c9b-f027-4223-b405-d48018ffb900'}")
    assert response.status_code == 200
    response.raise_for_status()
    domain_result = response.json()
    assert isinstance(domain_result, dict)
    assert 'result' in domain_result
    assert isinstance(domain_result['result'], dict)

def test_default_response():
    for status_code in [404, 500]:
        response = requests.get(f"{BASE_URL}/domain/{'non-existent-domain-key'}", allow_redirects=False)
        assert response.status_code == status_code
        error_response = response.json()
        assert isinstance(error_response, dict)
        assert 'message' in error_response
        assert isinstance(error_response['message'], str)
        assert 'fields' in error_response
        assert isinstance(error_response['fields'], str)
        assert 'code' in error_response
        assert isinstance(error_response['code'], int)