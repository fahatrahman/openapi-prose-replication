import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_origin_token():
    url = f"{BASE_URL}/v1/origin_token/new"
    headers = {
        "Authorization": "Bearer <your_access_token>"
    }
    payload = {
        "origin": "https://example.com"
    }

    response = requests.post(url, json=payload, headers=headers)

    assert response.status_code == 200
    data = response.json()
    assert "self" in data
    assert "region_id" in data
    assert "origin" in data
    assert "status" in data
    assert "created_at" in data
    assert "updated_at" in data
    assert data["status"] in ["ENABLED", "DISABLED"]

if __name__ == "__main__":
    pytest.main(["-v", __file__])