import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_leaderboard_configuration():
    leaderboard_id = "example_leaderboard_id"
    params = {
        "access_token": "your_access_token",
        "prettyPrint": True,
    }
    headers = {
        "Authorization": "Bearer your_oauth_token",
    }
    response = requests.get(f"{BASE_URL}/games/v1configuration/leaderboards/{leaderboard_id}", params=params, headers=headers)
    assert response.status_code == 200
    assert "leaderboardId" in response.json()