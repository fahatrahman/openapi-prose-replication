import pytest
import requests

BASE_URL = "http://openapi.test"

def test_aiplatform_projects_locations_tensorboards_experiments_runs_time_series_patch():
    url = f"{BASE_URL}/v1/my-name"
    headers = {"Content-Type": "application/json"}
    params = {
        "$.xgafv": "1",
        "access_token": "",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "",
        "oauth_token": "",
        "prettyPrint": "false",
        "quotaUser": "",
        "upload_protocol": "rjpug",
        "uploadType": "media",
    }
    body = {
        "createTime": "2022-01-01T00:00:00Z",
        "description": "My description",
        "displayName": "My display name",
        "etag": "my_etag",
        "metadata": {},
        "name": "my_name",
        "pluginData": "my_plugin_data",
        "pluginName": "my_plugin_name",
        "updateTime": "2022-01-01T00:00:00Z",
        "valueType": "SCALAR",
    }

    response = requests.request(
        method="PATCH",
        url=url,
        headers=headers,
        params=params,
        json=body,
    )
    assert response.status_code == 200