# -*- coding: utf-8 -*-

import pytest
import requests
from requests.auth import HTTPBasicAuth
from urllib.parse import urlencode

BASE_URL = "http://openapi.test"

def test_get_revision_changeset():
    url = f"{BASE_URL}/getRevisionChangeset"
    params = {"apikey": "your_api_key", "padID": "your_pad_id", "rev": "your_rev"}

    response = requests.get(url, auth=HTTPBasicAuth(None, None), params=params)

    assert response.status_code == 200
    response_data = response.json()

    assert isinstance(response_data["code"], int)
    assert isinstance(response_data["data"], dict)
    assert isinstance(response_data["message"], str)

@pytest.mark.parametrize("status_code, expected_status_code", [
    (400, 400),
    (401, 401),
    (500, 500)
])
def test_get_revision_changeset_invalid(status_code, expected_status_code):
    url = f"{BASE_URL}/getRevisionChangeset"
    params = {"apikey": "your_api_key", "padID": "your_pad_id", "rev": "your_rev"}

    response = requests.get(url, auth=HTTPBasicAuth(None, None), params=params)

    assert response.status_code == expected_status_code