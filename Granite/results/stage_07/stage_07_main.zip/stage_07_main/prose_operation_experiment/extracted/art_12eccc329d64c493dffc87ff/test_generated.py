import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
SESSION.mount("https://", HTTPAdapter(max_retries=3))
SESSION.mount("http://", HTTPAdapter(max_retries=3))

# Security credentials for basic authentication
USERNAME = "your_username"
PASSWORD = "your_password"

@pytest.fixture
def auth():
    return (USERNAME, PASSWORD)

def test_followed_show(auth):
    show_id = 123  # Replace this with the actual show ID you want to test
    endpoint = urljoin(BASE_URL, "/user/follows/shows/{}".format(show_id))

    response = SESSION.get(endpoint, auth=auth, headers={"Content-Type": "application/json"})

    assert response.status_code == 200, "Failed to get followed show: {}".format(response.text)

    try:
        data = response.json()
        assert isinstance(data, dict)
        assert data["show_id"] == show_id
    except ValueError:
        assert False, "Invalid JSON format in response: {}".format(response.text)