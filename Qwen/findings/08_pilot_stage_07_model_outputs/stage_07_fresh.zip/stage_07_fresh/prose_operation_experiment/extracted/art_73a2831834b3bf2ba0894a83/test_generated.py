import pytest
import requests

BASE_URL = "http://openapi.test"

def test_cancel_operation():
    url = f"{BASE_URL}/v1alpha/projects/locations/operations/cancel"
    params = {
        "_xgafv": "2",
        "access_token": "your_access_token",
        "alt": "json",
        "callback": "your_callback_url",
        "fields": "your_fields",
        "key": "your_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": True,
        "quotaUser": "your_quota_user",
        "uploadType": "multipart",
        "upload_protocol": "raw",
        "name": "your_operation_name"
    }
    headers = {
        "Authorization": "Bearer your_access_token"
    }
    response = requests.post(url, json={"name": "your_operation_name"}, params=params, headers=headers)
    assert response.status_code == 200
    assert response.json() == {}