import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_backup_schedule():
    url = f"{BASE_URL}/v1/projects/my-project/databases/(default)/backupSchedules"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "createTime": "2023-04-01T00:00:00Z",
        "dailyRecurrence": {},
        "retention": "7d"
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert "name" in response.json()