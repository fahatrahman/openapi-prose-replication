import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"

# Set up service account credentials
credentials = service_account.Credentials.from_service_account_file(
    'path/to/your/service_account.json'
)

@pytest.fixture
def api_client():
    session = requests.Session()
    session.auth = (credentials.service_account_email, credentials.id_token)
    return session

def get_deployment(api_client, org, env, sharedflow, rev):
    url = f"{BASE_URL}/v1/{org}/{env}/sharedflows/{sharedflow}/revisions/{rev}/deployments"
    headers = {
        "x-goog-api-client": "gl-python",
        "x-goog-api-version": "v1",
    }
    response = api_client.get(url, headers=headers)
    response.raise_for_status()
    return response.json()

def test_get_deployment(api_client, org, env, sharedflow, rev):
    deployment = get_deployment(api_client, org, env, sharedflow, rev)
    assert deployment["state"] in ["READY", "PROGRESSING", "ERROR"]
    assert isinstance(deployment["deployStartTime"], int)
    assert deployment["apiProxy"]
    assert deployment["environment"]
    assert deployment["revision"]