import pytest
import requests

BASE_URL = "http://openapi.test"

def test_user_create_token():
    url = f"{BASE_URL}/users/testuser/tokens"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer your_access_token_here"
    }
    payload = {
        "name": "test_token",
        "scopes": ["repo", "admin:org"]
    }

    response = requests.post(url, json=payload, headers=headers)

    assert response.status_code == 201
    assert 'id' in response.json()
    assert 'name' in response.json()
    assert 'scopes' in response.json()
    assert 'sha1' in response.json()
    assert 'token_last_eight' in response.json()

if __name__ == "__main__":
    pytest.main(["-v"])