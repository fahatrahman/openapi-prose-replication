import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Define custom retry strategy for requests
retries = Retry(
    total=5,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
adapter = HTTPAdapter(max_retries=retries)
http = requests.Session()
http.mount("https://", adapter)
http.mount("http://", adapter)
requests.adapters.HTTPAdapter.max_retries = retries

@pytest.fixture
def skill_jobs():
    skill_id = "your_skill_id_here"  # Replace with actual skill ID
    url = f"{BASE_URL}/skills/{skill_id}/related_jobs"

    response = http.get(url)
    response.raise_for_status()

    return response.json()

def test_skill_jobs(skill_jobs):
    assert isinstance(skill_jobs, dict)
    assert set(skill_jobs.keys()) == {"jobs", "normalized_job_title", "skill_name", "skill_uuid"}

    jobs = skill_jobs["jobs"]
    assert isinstance(jobs, list)
    for job in jobs:
        assert isinstance(job, dict)
        assert set(job.keys()).issubset({"importance", "job_title", "job_uuid", "level", "normalized_job_title"})
