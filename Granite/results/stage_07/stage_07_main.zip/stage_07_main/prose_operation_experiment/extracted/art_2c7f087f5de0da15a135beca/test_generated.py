import os
import pytest
import requests
from requests.exceptions import HTTPError

BASE_URL = "http://openapi.test"
HEADERS = {"Content-Type": "application/json", "Accept": "application/json"}

def test_folder_update():
    folder_data = {
        "id": "test_folder_id",
        "name": "Test Folder",
        "parentFolderId": 123
    }

    url = f"{BASE_URL}/files/v3/folders/update/async"

    try:
        response = requests.post(url, headers=HEADERS, json=folder_data)

        # Check if the request was successful
        response.raise_for_status()

        expected_response_code = 202
        assert response.status_code == expected_response_code, \
            f"Received unexpected status code: {response.status_code}"

        # Parse and validate the response
        task_locator = response.json()
        assert isinstance(task_locator, dict)
        assert all(key in task_locator for key in ("id", "links"))
        assert isinstance(task_locator["id"], str)
        assert isinstance(task_locator["links"], dict)

    except HTTPError as http_err:
        print(f"HTTP error occurred: {http_err}")
    except Exception as err:
        print(f"An error occurred: {err}")