import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_tag_from_pay_schedule():
    employer_id = "GD001"
    pay_schedule_id = "KFM001"
    tag_id = "DpFoa"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    
    response = requests.get(
        f"{BASE_URL}/Employer/{employer_id}/PaySchedule/{pay_schedule_id}/Tag/{tag_id}",
        headers=headers
    )
    
    assert response.status_code == 200
    assert "Content-Type" in response.headers and response.headers["Content-Type"].startswith("application/json")
    assert "Tag" in response.json()

def test_get_tag_from_pay_schedule_400():
    employer_id = "invalid"
    pay_schedule_id = "KFM001"
    tag_id = "DpFoa"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    
    response = requests.get(
        f"{BASE_URL}/Employer/{employer_id}/PaySchedule/{pay_schedule_id}/Tag/{tag_id}",
        headers=headers
    )
    
    assert response.status_code == 400
    assert "Content-Type" in response.headers and response.headers["Content-Type"].startswith("application/json")
    assert "ErrorModel" in response.json()
    assert response.json()["ErrorModel"]["ErrorCategory"] == "ValidationFailure"

def test_get_tag_from_pay_schedule_401():
    employer_id = "GD001"
    pay_schedule_id = "KFM001"
    tag_id = "DpFoa"
    headers = {
        "Authorization": "InvalidToken",
        "Api-Version": "default"
    }
    
    response = requests.get(
        f"{BASE_URL}/Employer/{employer_id}/PaySchedule/{pay_schedule_id}/Tag/{tag_id}",
        headers=headers
    )
    
    assert response.status_code == 401
    assert "Content-Type" in response.headers and response.headers["Content-Type"].startswith("application/json")
    assert "ErrorModel" in response.json()
    assert response.json()["ErrorModel"]["ErrorCategory"] == "NotAuthorised"

def test_get_tag_from_pay_schedule_404():
    employer_id = "GD001"
    pay_schedule_id = "NonExistent"
    tag_id = "DpFoa"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    
    response = requests.get(
        f"{BASE_URL}/Employer/{employer_id}/PaySchedule/{pay_schedule_id}/Tag/{tag_id}",
        headers=headers
    )
    
    assert response.status_code == 404
    assert "Content-Type" in response.headers and response.headers["Content-Type"].startswith("application/json")
    assert "ErrorModel" in response.json()
    assert response.json()["ErrorModel"]["ErrorCategory"] == "NotFound"

def test_get_tag_from_pay_schedule_500():
    employer_id = "GD001"
    pay_schedule_id = "KFM001"
    tag_id = "DpFoa"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "broken"
    }
    
    response = requests.get(
        f"{BASE_URL}/Employer/{employer_id}/PaySchedule/{pay_schedule_id}/Tag/{tag_id}",
        headers=headers
    )
    
    assert response.status_code == 500
    assert "Content-Type" in response.headers and response.headers["Content-Type"].startswith("application/json")
    assert "ErrorModel" in response.json()
    assert response.json()["ErrorModel"]["ErrorCategory"] == "General"