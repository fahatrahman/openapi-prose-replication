import pytest
import requests

BASE_URL = "http://openapi.test"

def test_published_early_day_motion_get():
    id = 123  # Replace with actual ID for testing
    url = f"{BASE_URL}/EarlyDayMotion/{id}"
    
    response = requests.get(url)
    
    assert response.status_code == 200
    assert response.json()['Success'] is True
    
    data = response.json()['Response']
    assert 'Answer' in data
    assert 'AnsweredWhen' in data
    assert 'AnsweringBody' in data
    assert 'AnsweringMinister' in data
    assert 'AskingMember' in data
    assert 'DueForAnswer' in data
    assert 'Id' in data
    assert 'QuestionText' in data
    assert 'QuestionType' in data
    assert 'TabledWhen' in data
    assert 'UIN' in data

if __name__ == "__main__":
    pytest.main()