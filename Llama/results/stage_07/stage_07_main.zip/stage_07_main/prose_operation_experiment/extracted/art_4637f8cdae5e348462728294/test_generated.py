# pytest_module.py
import pytest
import json
import requests

BASE_URL = "http://openapi.test"

def test_ContentDefinitions_PostContentDefinition():
    url = f"{BASE_URL}/api/v2/ContentDefinitions"
    
    content_definition = {
        "ContentDefinitionID": 123,
        "Description": "Test content definition",
        "Name": "Test name",
        "PackageTypeID": "test-package-type-id",
        "TypeID": 456,
        "Attributes": [
            {"ContentDefinitionID": 123, "ID": 1, "Name": "attribute1", "Value": "value1"},
            {"ContentDefinitionID": 123, "ID": 2, "Name": "attribute2", "Value": "value2"}
        ]
    }

    response = requests.post(url, headers={"Content-Type": "application/json"}, data=json.dumps(content_definition))
    
    assert response.status_code == 200
    
    try:
        response.raise_for_status()
    except requests.RequestException as e:
        print(f"Request failed: {e}")
        assert False
    
    # Check if the server returned an integer in JSON format
    assert response.json() >= 0