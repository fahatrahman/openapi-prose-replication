# -*- coding: utf-8 -*-
import pytest
import requests
from datetime import datetime
import hmac
import hashlib
import base64

BASE_URL = "http://openapi.test"

def get_signing_key(datestamp, region_name, service_name):
    k_date = hmac.new(b'AWS4' + region_name.encode(), datestamp.encode(), hashlib.sha256).digest()
    k_region = hmac.new(k_date, region_name.encode(), hashlib.sha256).digest()
    k_service = hmac.new(k_region, service_name.encode(), hashlib.sha256).digest()
    return hmac.new(k_service, b'', hashlib.sha256).digest()

def calculate_signature(method, url, datestamp, region_name, service_name, secret_access_key, signed_headers):
    payload_hash = hashlib.sha256(b'').digest()
    signing_key = get_signing_key(datestamp, region_name, service_name)
    signature = hmac.new(signing_key, method.encode() + b'\n' + url.encode() + b'\n' + signed_headers.encode() + b'\n' + payload_hash.hex().encode(), hashlib.sha256).hexdigest()
    return signature

@pytest.mark.parametrize("detector_id, threat_intel_set_id, activate, location, name", [
    ("detector_123", "threat_intel_set_456", True, "location_789", "name_012"),
])
def test_UpdateThreatIntelSet(detector_id, threat_intel_set_id, activate, location, name):
    timestamp = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    headers = {
        'X-Amz-Algorithm': 'AWS4-HMAC-SHA256',
        'X-Amz-Content-Sha256': 'UNSIGNED-PAYLOAD',
        'X-Amz-Credential': f'{BASE_URL}/20181212/us-west-2/ec2/aws4_request',
        'X-Amz-Date': timestamp,
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': calculate_signature('POST', f'{BASE_URL}/detector/{detector_id}/threatintelset/{threat_intel_set_id}', timestamp[:8], 'us-west-2', 'ec2', 'SECRET_ACCESS_KEY', 'host;x-amz-date'),
        'X-Amz-SignedHeaders': 'host;x-amz-date'
    }
    response = requests.post(f'{BASE_URL}/detector/{detector_id}/threatintelset/{threat_intel_set_id}',
                             json={'activate': activate, 'location': location, 'name': name},
                             headers=headers)
    assert response.status_code == 200