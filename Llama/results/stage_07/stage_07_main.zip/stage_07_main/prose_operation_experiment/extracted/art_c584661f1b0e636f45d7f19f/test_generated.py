# -*- coding: utf-8 -*-

import pytest
import requests
from json import JSONDecodeError

BASE_URL = "http://openapi.test"

def test_get_amendment():
    bill_id = 12345
    bill_stage_id = 67890
    amendment_id = 11111

    url = f"{BASE_URL}/api/v1/Bills/{bill_id}/Stages/{bill_stage_id}/Amendments/{amendment_id}"
    response = requests.get(url)

    assert response.status_code == 200, f"Unexpected status code {response.status_code}"

    try:
        response.json()
    except JSONDecodeError as e:
        assert False, f"Failed to parse JSON response: {e}"

def test_get_amendment_not_found():
    bill_id = 12345
    bill_stage_id = 67890
    amendment_id = 99999

    url = f"{BASE_URL}/api/v1/Bills/{bill_id}/Stages/{bill_stage_id}/Amendments/{amendment_id}"
    response = requests.get(url)

    assert response.status_code in [400, 404], f"Unexpected status code {response.status_code}"

    try:
        response.json()
    except JSONDecodeError as e:
        assert False, f"Failed to parse JSON response: {e}"

def test_get_amendment_bad_request():
    bill_id = None
    bill_stage_id = 67890
    amendment_id = 11111

    url = f"{BASE_URL}/api/v1/Bills/{bill_id}/Stages/{bill_stage_id}/Amendments/{amendment_id}"
    response = requests.get(url)

    assert response.status_code == 400, f"Unexpected status code {response.status_code}"

    try:
        response.json()
    except JSONDecodeError as e:
        assert False, f"Failed to parse JSON response: {e}"