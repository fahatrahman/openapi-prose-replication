import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retry logic
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def delete_alarms_and_timers():
    """Test case for DeleteAlarmsandTimers"""

    # Define test parameters
    ids = ["timer/xxx", "alarm/xxx"]

    # Prepare request payload
    payload = {"ids": ids}

    # Send POST request
    response = session.post(
        f"{BASE_URL}/assistant/alarms/delete", json=payload, headers={"cast-local-authorization-token": ""}
    )

    # Check if the response status code is 200 (OK)
    assert response.status_code == 200

    # Check if the response body matches expected success response schema
    assert response.json() == {"success": True}