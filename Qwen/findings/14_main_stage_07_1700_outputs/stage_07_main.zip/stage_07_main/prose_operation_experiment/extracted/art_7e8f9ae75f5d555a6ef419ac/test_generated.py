import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_conversation():
    url = f"{BASE_URL}/v1/Conversations"
    params = {
        "StartDate": "2023-01-01T00:00:00Z",
        "EndDate": "2023-01-31T23:59:59Z",
        "State": "active",
        "PageSize": 50,
        "Page": 0,
        "PageToken": None
    }
    headers = {
        "Authorization": "Basic <base64-encoded-account-sid-auth-token>"
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    data = response.json()
    assert "conversations" in data
    assert isinstance(data["conversations"], list)
    for conversation in data["conversations"]:
        assert "sid" in conversation
        assert "chat_service_sid" in conversation
        assert "friendly_name" in conversation
        assert "date_created" in conversation
        assert "state" in conversation