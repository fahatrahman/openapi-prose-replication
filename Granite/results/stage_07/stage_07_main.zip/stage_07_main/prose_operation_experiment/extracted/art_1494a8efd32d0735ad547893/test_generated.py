import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup retry strategy for requests
retries = Retry(
    total=5,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
adapter = HTTPAdapter(max_retries=retries)
http = requests.Session()
http.mount("https://", adapter)
http.mount("http://", adapter)
requests.adapters.HTTPAdapter.max_retries = retries

@pytest.fixture
def changelog_route_graph():
    """Test getting all changes related to a specific route."""
    route_key = "9cd24183-f848-48f8-6f55-0f0724070000"

    def _test(request):
        params = {
            "start": None,
            "end": None,
            "max_results": None,
            "ref_id": None,
            "direction": None,
        }

        # Customize parameters if needed
        # params["start"] = 1633027200000000  # Example start time
        # params["end"] = 1633304000000000   # Example end time
        # params["max_results"] = 10          # Limit results
        # params["ref_id"] = "some_ref_id"    # Reference ID
        # params["direction"] = "before"     # Direction

        url = f"{BASE_URL}/changelog/route-graph/{route_key}"
        response = http.get(url, headers={"Authorization": "api_key your_api_key"}, params=params)
        response.raise_for_status()
        return response.json()

    return _test