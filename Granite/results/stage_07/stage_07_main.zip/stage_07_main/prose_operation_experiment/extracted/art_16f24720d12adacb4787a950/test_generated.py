import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Define retry strategy for requests
retries = Retry(
    total=5,  # number of retries
    backoff_factor=1,  # factor to apply between attempts
    status_forcelist=[429, 500, 502, 503, 504],  # list of status codes to force a retry
)
adapter = HTTPAdapter(max_retries=retries)
http = requests.Session()
http.mount("https://", adapter)
http.mount("http://", adapter)
requests.adapters.HTTPAdapter.max_retries = retries

@pytest.fixture
def client():
    return http

def test_events_options(client):
    url = f"{BASE_URL}/events"

    response = client.options(url)
    
    assert response.status_code == 200, \
        f'Expected status code 200, got {response.status_code}'

    # Assuming RealtimeServers schema matches the structure returned by the endpoint
    assert isinstance(response.json(), dict)
    assert 'entries' in response.json()
    assert isinstance(response.json()['entries'], list)
    assert all(isinstance(entry, dict) for entry in response.json()['entries'])