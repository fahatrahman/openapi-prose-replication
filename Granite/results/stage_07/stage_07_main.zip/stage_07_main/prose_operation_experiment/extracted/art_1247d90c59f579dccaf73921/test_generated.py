import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"

# Load credentials from a file
credentials = service_account.Credentials.from_service_account_file('path/to/your/credentials.json')

# Create an authenticated requests session
session = requests.Session()
session.auth = (credentials.client_email, credentials.private_key)
headers = {"Content-Type": "application/json"}

@pytest.fixture
def batch_delete_printers():
    parent = "customers/your-customer-id"  # Replace with your customer ID
    request_body = {
        "printerIds": ["printer-id-1", "printer-id-2"]  # Replace with actual printer IDs
    }

    url = f"{BASE_URL}/admin/directory/v1/{parent}/chrome/printers:batchDeletePrinters"
    response = session.post(url, json=request_body, headers=headers)

    response.raise_for_status()
    return response.json()

def test_batch_delete_printers(batch_delete_printers):
    assert len(batch_delete_printers["printerIds"]) > 0
    assert all("printerId" in info for info in batch_delete_printers["failedPrinters"])