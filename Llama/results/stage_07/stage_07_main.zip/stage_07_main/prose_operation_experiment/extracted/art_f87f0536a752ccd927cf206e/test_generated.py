# -*- coding: utf-8 -*-

import pytest
import requests
from typing import Dict, List

BASE_URL = "http://openapi.test"

def test_read_float_table():
    # Define basic auth credentials
    username = "fgvlh"
    password = "lcknolcj"

    # Generate URLs for different query parameters
    url_base = f"{BASE_URL}/device/strategy/tables/floats/{username}"
    urls: List[str] = [
        url_base,
        f"{url_base}?ordvhVxupn=5",
        f"{url_base}?ordvhVxupn=10&ykeKevvkaox=3",
    ]

    # Send GET requests to each URL
    responses = []
    for url in urls:
        response = requests.get(url, auth=(username, password))
        responses.append(response)

    # Check status codes and contents
    expected_status_codes = [200, 200, 200]
    for i, response in enumerate(responses):
        assert response.status_code == expected_status_codes[i], (
            f"Expected status code {expected_status_codes[i]} but got "
            f"{response.status_code} instead."
        )

    # Check JSON content type
    for response in responses:
        assert response.headers["Content-Type"].startswith("application/json")

# Run tests using pytest
pytest.main([__file__, "-v"])