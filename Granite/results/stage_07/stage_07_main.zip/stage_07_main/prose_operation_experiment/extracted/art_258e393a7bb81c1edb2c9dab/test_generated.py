import os
import pytest
import requests
from google.auth import default
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

BASE_URL = "http://openapi.test"

# Authenticate using service account credentials
credentials, project = default()
service = build('cloudsupport', 'v2beta', credentials=credentials)

@pytest.mark.parametrize("case_id", ["zynntaco/xexg-autfnhu/zdpti/43595344"])
def test_list_comments(case_id):
    try:
        request = service.cases().comments().list(
            parent=case_id,
            pageSize=10,
            pageToken="",
        ).execute()

        comments = request.get('comments', [])
        next_page_token = request.get('nextPageToken')

        assert len(comments) > 0
        print(f"Found {len(comments)} comments.")

        while next_page_token:
            request = service.cases().comments().list(
                parent=case_id,
                pageSize=10,
                pageToken=next_page_token,
            ).execute()

            new_comments = request.get('comments', [])
            next_page_token = request.get('nextPageToken')
            comments.extend(new_comments)

            assert len(new_comments) > 0
            print(f"Found additional {len(new_comments)} comments.")

    except HttpError as error:
        print(f"An HTTP error {error.resp.status} occurred:\n{error}")
    except Exception as e:
        print(f"An unexpected error occurred: {str(e)}")