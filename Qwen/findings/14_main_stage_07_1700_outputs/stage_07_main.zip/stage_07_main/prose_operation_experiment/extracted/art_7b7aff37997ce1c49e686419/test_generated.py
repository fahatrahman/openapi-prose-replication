import pytest
import requests

BASE_URL = "http://openapi.test"

def test_add_video_tags():
    video_id = 258684937
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/vnd.vimeo.tag+json"
    }
    payload = {
        "name": "awesome",
        "page": 1,
        "per_page": 10
    }

    response = requests.put(f"{BASE_URL}/videos/{video_id}/tags", json=payload, headers=headers)

    assert response.status_code == 200
    assert isinstance(response.json(), list)
    assert all(isinstance(item, dict) for item in response.json())
    assert all("name" in item for item in response.json())

if __name__ == "__main__":
    pytest.main()