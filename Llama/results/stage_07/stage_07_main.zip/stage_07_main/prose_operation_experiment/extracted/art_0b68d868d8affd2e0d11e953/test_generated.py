# -*- coding: utf-8 -*-
import pytest
import requests
from jsonschema import validate

BASE_URL = "http://openapi.test"

def test_tilejson_v2_locations_tiles_tiles_json_get():
    response = requests.get(f"{BASE_URL}/v2/locations/tiles/tiles.json")
    assert response.status_code == 200
    
    try:
        tilejson_schema = {
            "type": "object",
            "properties": {
                "attribution": {"type": "string"},
                "bounds": {"type": "array", "items": {"type": "number"}},
                "data": {"type": "array", "items": {"type": "string"}},
                "description": {"type": "string"},
                "grids": {"type": "array", "items": {"type": "string"}},
                "legend": {"type": "string"},
                "maxzoom": {"type": "integer"},
                "minzoom": {"type": "integer"},
                "name": {"type": "string"},
                "scheme": {"type": "string"},
                "template": {"type": "string"},
                "tilejson": {"type": "string"},
                "tiles": {"type": "array", "items": {"type": "string"}},
                "version": {"type": "string"}
            },
            "required": ["tiles"]
        }
        
        validate(instance=response.json(), schema=tilejson_schema)
    except requests.exceptions.RequestException as e:
        assert False, f"Request failed: {e}"