# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime
from jsonschema import ValidationError, validate

BASE_URL = "http://openapi.test"

def test_update_an_api_version():
    api_id = 'your_api_id'
    api_version_id = 'your_api_version_id'

    url = f"{BASE_URL}/apis/{api_id}/versions/{api_version_id}"
    headers = {"Content-Type": "application/json", "X-Api-Key": "your_api_key"}
    params = {'apikey': 'your_api_key'}
    
    payload = {
        "version": {
            "name": "2.0"
        }
    }

    response = requests.put(url, headers=headers, params=params, json=payload)

    assert response.status_code == 200
    try:
        schema = {
            "type": "object",
            "properties": {
                "version": {
                    "type": "object",
                    "properties": {
                        "api": {"type": "string"},
                        "createdAt": {"type": "string", "format": "date-time"},
                        "createdBy": {"type": "integer"},
                        "id": {"type": "string"},
                        "name": {"type": "string"},
                        "updatedAt": {"type": "string", "format": "date-time"},
                        "updatedBy": {"type": "integer"}
                    },
                    "required": ["api", "createdAt", "createdBy", "id", "name", "updatedAt", "updatedBy"]
                }
            },
            "required": ["version"]
        }
        
        validate(instance=response.json(), schema=schema)
    except ValidationError as e:
        print(f"Validation error: {e}")
        assert False