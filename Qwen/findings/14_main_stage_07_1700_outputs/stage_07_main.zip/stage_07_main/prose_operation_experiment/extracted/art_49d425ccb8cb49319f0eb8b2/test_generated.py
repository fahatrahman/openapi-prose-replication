import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_instance_config_operations():
    url = f"{BASE_URL}/v1/projects/example-instance-config/instanceConfigOperations"
    params = {
        "_xgafv": "1",
        "access_token": "example_access_token",
        "alt": "json",
        "callback": "callback_function",
        "fields": "fields_value",
        "key": "example_key",
        "oauth_token": "example_oauth_token",
        "prettyPrint": True,
        "quotaUser": "example_quota_user",
        "uploadType": "multipart/form-data",
        "upload_protocol": "raw",
        "filter": "status.done=true",
        "pageSize": 10,
        "pageToken": "example_page_token"
    }
    headers = {
        "Authorization": "Bearer example_bearer_token"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()