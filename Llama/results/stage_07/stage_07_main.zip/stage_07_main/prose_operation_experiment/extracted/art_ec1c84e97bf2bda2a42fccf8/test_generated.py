import pytest
import requests

BASE_URL = "http://openapi.test"

def test_dataplex_projects_locations_lakes_content_list():
    url = f"{BASE_URL}/v1/{'projects/%s/locations/%s/lakes/%s/content'}"
    params = {
        'parent': 'test-project/test-location/test-lake',
        'filter': '',
        'pageSize': 10,
        'pageToken': ''
    }
    headers = {}
    
    response = requests.get(url % ('test-project', 'test-location', 'test-lake'), 
                            headers=headers, params=params)
    assert response.status_code == 200
    
    data = response.json()
    assert isinstance(data, dict)
    assert 'content' in data
    assert isinstance(data['content'], list)
    assert 'nextPageToken' in data
    assert isinstance(data['nextPageToken'], str)

if __name__ == "__main__":
    pytest.main([__file__])