# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_get_monatsbelege():
    """Test get monatsbelege endpoint"""
    
    # Get current year and month
    now = datetime.now()
    year = now.year
    month = now.month
    
    response = requests.get(
        f"{BASE_URL}/registrierkassen/{'your-registrierkasseUuid'}"
        f"?year={year}&month={month}",
        headers={"Authorization": "Bearer your-jwt-token"},
    )
    
    assert response.status_code == 200
    response_json = response.json()
    
    assert isinstance(response_json, list)
    for monatsbeleg in response_json:
        assert isinstance(monatsbeleg, dict)
        required_keys = ["Beleg-UUID", "FON-Geprueft-Datum-Uhrzeit", "FON-Geprueft-Erfolgreich", "Jahr", "Monat"]
        assert all(key in monatsbeleg for key in required_keys)

if __name__ == "__main__":
    pytest.main([__file__])