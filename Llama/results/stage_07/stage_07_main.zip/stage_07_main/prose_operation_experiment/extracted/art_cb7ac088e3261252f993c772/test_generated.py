# -*- coding: utf-8 -*-

import pytest
import requests
from requests.auth import HTTPBasicAuth
from typing import Dict

BASE_URL = "http://openapi.test"

def delete_image(image_digest: str, force: bool = False, x_anchore_account: str = None) -> Dict:
    """Delete an image.

    Args:
        image_digest (str): The digest of the image to delete.
        force (bool, optional): Whether to force deletion. Defaults to False.
        x_anchore_account (str, optional): The account to delete the image for. Defaults to None.

    Returns:
        Dict: A dictionary containing the response from the server.
    """
    url = f"{BASE_URL}/images/{image_digest}"
    params = {"force": force}
    headers = {}
    if x_anchore_account is not None:
        headers["x-anchore-account"] = x_anchore_account
    response = requests.delete(url, params=params, headers=headers)
    response.raise_for_status()
    return response.json()

def test_delete_image():
    """Test deleting an image."""
    # Replace 'image_digest' with your actual image digest
    image_digest = "your-image-digest"
    try:
        delete_image(image_digest)
    except requests.exceptions.HTTPError as e:
        assert e.response.status_code == 404

def test_delete_image_force():
    """Test deleting an image with force parameter."""
    # Replace 'image_digest' with your actual image digest
    image_digest = "your-image-digest"
    try:
        delete_image(image_digest, force=True)
    except requests.exceptions.HTTPError as e:
        assert e.response.status_code in [200, 400]

def test_delete_image_with_account():
    """Test deleting an image with account parameter."""
    # Replace 'image_digest' with your actual image digest
    image_digest = "your-image-digest"
    x_anchore_account = "your-account"
    try:
        delete_image(image_digest, x_anchore_account=x_anchore_account)
    except requests.exceptions.HTTPError as e:
        assert e.response.status_code in [200, 401]