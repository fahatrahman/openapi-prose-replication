import pytest
import requests

BASE_URL = "http://openapi.test"

def test_options_events():
    url = f"{BASE_URL}/events"
    headers = {
        "Authorization": "Bearer your_access_token_here",
        "Content-Type": "application/json"
    }
    response = requests.options(url, headers=headers)
    assert response.status_code == 200
    assert response.json()["chunk_size"] > 0
    assert isinstance(response.json()["entries"], list)

if __name__ == "__main__":
    pytest.main()