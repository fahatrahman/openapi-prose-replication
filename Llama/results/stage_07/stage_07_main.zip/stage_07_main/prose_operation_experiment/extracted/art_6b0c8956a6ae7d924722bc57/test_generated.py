# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_games_by_date():
    format = "json"
    date = "2017-ZQD-31"
    url = f"{BASE_URL}/{format}/GamesByDate/{date}"
    headers = {"Ocp-Apim-Subscription-Key": "your_api_key"}
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    assert response.json()