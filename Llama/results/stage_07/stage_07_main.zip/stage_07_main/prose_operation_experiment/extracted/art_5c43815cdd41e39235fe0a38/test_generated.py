# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_MaintenanceController_CreateMaintenanceJob():
    url = f"{BASE_URL}/v3/maintenance/{'shortName'}"
    branch_id = 'branchID'
    maintenance_issue_model = {
        "Documents": [],
        "ExternalID": "",
        "IssueFault": "",
        "IssueNotes": "",
        "IssuePriority": "Low",
        "IssueTitle": "",
        "PropertyAddress1": "",
        "PropertyAddress2": "",
        "PropertyAddress3": "",
        "PropertyAddress4": "",
        "PropertyCountry": "",
        "PropertyPostcode": "",
        "ReportedAt": "",
        "TenantEMailAddress": "",
        "TenantForename": "",
        "TenantPhonePrimary": "",
        "TenantPhoneSecondary": "",
        "TenantPresenceRequested": False,
        "TenantSurname": "",
        "TenantTitle": ""
    }

    response = requests.post(
        url=f"{url}/{branch_id}/createmaintenancejob", 
        json=maintenance_issue_model, 
        headers={"Content-Type": "application/json"}
    )

    assert response.status_code == 200