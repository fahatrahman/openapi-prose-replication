import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_instance():
    url = f"{BASE_URL}/v1/apps/{'your_apps_id'}/services/{'your_services_id'}/versions/{'your_versions_id'}/instances/{'your_instances_id'}"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token",
        "alt": "json",
        "prettyPrint": False,
        "quotaUser": "your_quota_user"
    }
    headers = {
        "Authorization": "Bearer your_oauth_token"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    instance_data = response.json()
    assert isinstance(instance_data, dict)
    assert "appEngineRelease" in instance_data
    assert "availability" in instance_data
    assert "averageLatency" in instance_data
    assert "errors" in instance_data
    assert "id" in instance_data
    assert "memoryUsage" in instance_data
    assert "name" in instance_data
    assert "qps" in instance_data
    assert "requests" in instance_data
    assert "startTime" in instance_data
    assert "vmDebugEnabled" in instance_data
    assert "vmId" in instance_data
    assert "vmIp" in instance_data
    assert "vmLiveness" in instance_data
    assert "vmName" in instance_data
    assert "vmStatus" in instance_data
    assert "vmZoneName" in instance_data