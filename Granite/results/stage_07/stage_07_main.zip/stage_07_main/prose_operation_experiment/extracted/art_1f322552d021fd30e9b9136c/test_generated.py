import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["GET", "OPTIONS"],
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)


def test_top_by_country():
    project = "example_project"
    access = "all-access"
    year = "2022"
    month = "January"

    url = f"{BASE_URL}/metrics/pageviews/top-by-country/{project}/{access}/{year}/{month}"

    response = SESSION.get(url)

    if response.status_code == 200:
        data = response.json()
        assert isinstance(data, dict)
        assert "items" in data
        assert isinstance(data["items"], list)

        for item in data["items"]:
            assert "countries" in item
            assert isinstance(item["countries"], list)

            for country in item["countries"]:
                assert "country" in country
                assert "rank" in country
                assert "views" in country
                assert "month" in country
                assert "project" in country

    else:
        problem = response.json()
        assert isinstance(problem, dict)
        assert "type" in problem
        assert problem["type"] == "about:blank"
        assert "title" in problem
        assert "detail" in problem
        assert "status" in problem
        assert "uri" in problem