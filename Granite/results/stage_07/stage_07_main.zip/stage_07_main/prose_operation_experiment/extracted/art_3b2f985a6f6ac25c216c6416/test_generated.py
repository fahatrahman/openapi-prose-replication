import pytest
import requests
BASE_URL = "http://openapi.test"

@pytest.mark.parametrize("body", [
    {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "pspReference": "9935272408535455"
    }
])
def test_get_authentication_result(body):
    endpoint = f"{BASE_URL}/getAuthenticationResult"
    response = requests.post(endpoint, json=body)

    assert response.status_code == 200, response.text

    # Add more assertions based on the response schema if needed.
    # For example:
    # assert response.json()["threeDS1Result"]["eci"] == "GWR"