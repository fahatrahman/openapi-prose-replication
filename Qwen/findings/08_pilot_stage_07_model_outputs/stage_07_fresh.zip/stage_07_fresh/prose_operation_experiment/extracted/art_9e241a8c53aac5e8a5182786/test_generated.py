import pytest
import requests

BASE_URL = "http://openapi.test"

def test_all_monitors():
    headers = {
        "X-Api-Key": "your_api_key_here"
    }
    response = requests.get(f"{BASE_URL}/monitors", headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert "monitors" in data
    assert isinstance(data["monitors"], list)
    for monitor in data["monitors"]:
        assert "id" in monitor
        assert "name" in monitor
        assert "owner" in monitor
        assert "uid" in monitor