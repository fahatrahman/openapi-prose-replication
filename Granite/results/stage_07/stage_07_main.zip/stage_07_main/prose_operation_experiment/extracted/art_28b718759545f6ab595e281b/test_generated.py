import os
import pytest
import requests
from base64 import b64encode
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"
AUTH_CREDENTIALS = ("ACCOUNT_SID", "AUTH_TOKEN")

@pytest.fixture(scope="function")
def wireless_v1_sim_data_sessions_list():
    sim_sid = "SIM_SID"
    page_size = 2
    page = 0
    page_token = None

    headers = {}

    params = {
        "PageSize": page_size,
        "Page": page,
        "PageToken": page_token,
    }

    response = requests.get(
        f"{BASE_URL}/v1/Sims/{sim_sid}/DataSessions",
        headers=headers,
        auth=HTTPBasicAuth(*AUTH_CREDENTIALS),
        params=params,
    )

    response.raise_for_status()

    return response.json()

def test_list_data_sessions(wireless_v1_sim_data_sessions_list):
    assert "data_sessions" in wireless_v1_sim_data_sessions_list
    assert isinstance(wireless_v1_sim_data_sessions_list["data_sessions"], list)
    for data_session in wireless_v1_sim_data_sessions_list["data_sessions"]:
        assert all(key in data_session for key in ["account_sid", "cell_id", "cell_location_estimate", "end", "imei", "last_updated", "operator_country", "operator_mcc", "operator_mnc", "operator_name", "packets_downloaded", "packets_uploaded", "radio_link", "sid", "sim_sid", "start"])