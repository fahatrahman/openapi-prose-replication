import os
import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def api_client():
    return requests.Client()

def test_check_domain(api_client):
    domain = "example.com"  # replace with actual domain
    response = api_client.get(
        f"{BASE_URL}/domains/{domain}/check",
        headers={"X-API-KEY": "your_api_key"},  # replace with actual API key
    )

    assert response.status_code == 200
    assert response.json()["isAvailable"] is True  # replace with expected availability