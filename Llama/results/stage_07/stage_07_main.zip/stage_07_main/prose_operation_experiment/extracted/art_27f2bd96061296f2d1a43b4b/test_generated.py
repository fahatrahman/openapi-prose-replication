# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_control_panels():
    headers = {
        'X-Amz-Algorithm': '',
        'X-Amz-Content-Sha256': '',
        'X-Amz-Credential': '',
        'X-Amz-Date': '',
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': '',
        'X-Amz-SignedHeaders': ''
    }
    
    params = {
        'ClusterArn': '',
        'MaxResults': 1,
        'NextToken': ''
    }

    response = requests.get(f"{BASE_URL}/controlpanels", headers=headers, params=params)
    assert response.status_code == 200
    
    try:
        response.raise_for_status()
    except requests.RequestException as err:
        pytest.fail(err)

    response_json = response.json()
    assert isinstance(response_json, dict)
    assert 'ControlPanels' in response_json
    assert isinstance(response_json['ControlPanels'], list)