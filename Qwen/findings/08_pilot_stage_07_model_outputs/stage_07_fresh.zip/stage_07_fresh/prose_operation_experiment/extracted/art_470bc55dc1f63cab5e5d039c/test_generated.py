import pytest
import requests

BASE_URL = "http://openapi.test"

def update_oauth2_application(id, options):
    url = f"{BASE_URL}/user/applications/oauth2/{id}"
    headers = {
        "Content-Type": "application/json"
    }
    response = requests.patch(url, json=options, headers=headers)
    return response.json()

@pytest.fixture
def oauth2_app_options():
    return {
        "name": "TestApp",
        "redirect_uris": ["https://example.com/callback"],
        "confidential_client": True
    }

def test_update_oauth2_application(oauth2_app_options):
    response = update_oauth2_application(1, oauth2_app_options)
    assert response["name"] == oauth2_app_options["name"]
    assert response["redirect_uris"] == oauth2_app_options["redirect_uris"]
    assert response["confidential_client"] == oauth2_app_options["confidential_client"]

def test_update_oauth2_application_not_found():
    response = update_oauth2_application(999999, {})
    assert response == {}