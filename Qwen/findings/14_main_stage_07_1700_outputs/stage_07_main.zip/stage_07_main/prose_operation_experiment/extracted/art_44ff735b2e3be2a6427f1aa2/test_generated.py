import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_app_screenshot():
    headers = {
        "Authorization": "Bearer your_access_token_here",
        "Content-Type": "application/json"
    }
    payload = {
        "data": {
            "type": "appScreenshots",
            "attributes": {
                "fileName": "screenshot.png",
                "fileSize": 123456
            },
            "relationships": {
                "appScreenshotSet": {
                    "data": {
                        "id": "set_id_here",
                        "type": "appScreenshotSets"
                    }
                }
            }
        }
    }

    response = requests.post(f"{BASE_URL}/v1/appScreenshots", headers=headers, json=payload)

    assert response.status_code == 201
    assert "data" in response.json()
    assert "id" in response.json()["data"]
    assert "type" in response.json()["data"] and response.json()["data"]["type"] == "appScreenshots"