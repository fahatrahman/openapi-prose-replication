import pytest
import requests

BASE_URL = "http://openapi.test"

def test_app_blocklogs():
    url = f"{BASE_URL}/v0.1/apps/owner_name/app_name/devices/block_logs"
    headers = {
        "X-API-Token": "your_api_token_here"
    }
    response = requests.put(url, headers=headers)
    assert response.status_code == 200
    assert isinstance(response.json(), str)

if __name__ == "__main__":
    pytest.main()