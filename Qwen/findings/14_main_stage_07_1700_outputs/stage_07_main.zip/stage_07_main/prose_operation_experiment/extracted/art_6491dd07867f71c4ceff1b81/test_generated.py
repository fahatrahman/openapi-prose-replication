import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_analysis_archive():
    url = f"{BASE_URL}/archives/images"
    response = requests.get(url)
    
    assert response.status_code == 200, f"Expected status code 200, got {response.status_code}"
    data = response.json()
    assert isinstance(data, list), "Response should be a list of archived analyses"
    for item in data:
        assert isinstance(item, dict), "Each item in the list should be a dictionary"
        assert "analyzed_at" in item, "Missing 'analyzed_at' field"
        assert "annotations" in item, "Missing 'annotations' field"
        assert "archive_size_bytes" in item, "Missing 'archive_size_bytes' field"
        assert "created_at" in item, "Missing 'created_at' field"
        assert "imageDigest" in item, "Missing 'imageDigest' field"
        assert "image_detail" in item, "Missing 'image_detail' field"
        assert "last_updated" in item, "Missing 'last_updated' field"
        assert "parentDigest" in item, "Missing 'parentDigest' field"
        assert "status" in item, "Missing 'status' field"
        assert item["status"] in ["archiving", "archived", "deleting", "deleted"], "Invalid status value"

if __name__ == "__main__":
    pytest.main()