import os
import pytest
import requests
from requests_toolbelt.multipart.encoder import MultipartEncoder

BASE_URL = "http://openapi.test"

# Set headers
headers = {
    "Content-Type": "application/json",
}

@pytest.fixture(scope="session")
def auth():
    return ("AWS_ACCESS_KEY", "AWS_SECRET_KEY")

@pytest.fixture(scope="session")
def update_studio_data():
    return {
        "adminRoleArn": "arn:aws:iam::123456789012:role/admin",
        "displayName": "NewStudioName",
        "userRoleArn": "arn:aws:iam::123456789012:role/user"
    }

def test_update_studio(auth, update_studio_data):
    studio_id = "studio-123"

    # Create the required signature
    # Assuming hmac signature generation logic here for brevity

    url = f"{BASE_URL}/2020-08-01/studios/{studio_id}"

    response = requests.patch(url, headers=headers, json=update_studio_data, verify=False)

    assert response.status_code == 200
    assert response.json()["studio"]["displayName"] == update_studio_data["displayName"]