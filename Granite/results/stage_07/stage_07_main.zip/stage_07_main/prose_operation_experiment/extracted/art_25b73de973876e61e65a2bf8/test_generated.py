import pytest
import requests
BASE_URL = "http://openapi.test"

@pytest.fixture
def channel_section():
    return {
        "id": "sample_id",
        "snippet": {"channelId": "UC_x5XG1OV2P6uZZ5FSM9Ttw", "title": "Sample Title", "type": "singlePlaylist"},
        "contentDetails": {"channels": ["UC_x5XG1OV2P6uZZ5FSM9Ttw"]}
    }

def test_update_channel_section(channel_section):
    url = f"{BASE_URL}/youtube/v3/channelSections"
    headers = {
        "_.xgafv": "1",
        "access_token": "sample_token",
        "alt": "json",
        "prettyPrint": "false"
    }
    part = ["id", "snippet", "contentDetails"]
    onBehalfOfContentOwner = "onBehalfOfContentOwner_value"

    response = requests.put(url, headers=headers, json=channel_section, params={"part": part, "onBehalfOfContentOwner": onBehalfOfContentOwner})
    assert response.status_code == 200
    updated_channel_section = response.json()
    # Further assertions can be added here if needed