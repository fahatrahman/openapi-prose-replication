import pytest
import requests

BASE_URL = "http://openapi.test"

def test_post_new_dps_job():
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    payload = {
        "DpsJobInstruction": {
            "Apply": True,
            "Employer": {
                "@href": "/employer/123",
                "@rel": "employer",
                "@title": "Test Employer"
            },
            "FromDate": "2023-01-01",
            "HoldingDate": "2023-01-01T12:00:00Z",
            "MessageTypes": {
                "Type": [
                    {"@href": "/message-type/1", "@rel": "message-type", "@title": "Type 1"},
                    {"@href": "/message-type/2", "@rel": "message-type", "@title": "Type 2"}
                ]
            },
            "MessagesToProcess": {
                "Message": [
                    {"@href": "/message/1", "@rel": "message", "@title": "Message 1"},
                    {"@href": "/message/2", "@rel": "message", "@title": "Message 2"}
                ]
            },
            "Retrieve": False
        }
    }
    
    response = requests.post(f"{BASE_URL}/Jobs/Dps", headers=headers, json=payload)
    
    assert response.status_code == 201
    assert "Location" in response.headers

def test_post_new_dps_job_bad_request():
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    payload = {}
    
    response = requests.post(f"{BASE_URL}/Jobs/Dps", headers=headers, json=payload)
    
    assert response.status_code == 400
    assert response.json()["ErrorModel"]["ErrorCategory"] == "ValidationFailure"

def test_post_new_dps_job_unauthorized():
    headers = {
        "Authorization": "Invalid",
        "Api-Version": "default"
    }
    payload = {
        "DpsJobInstruction": {
            "Apply": True,
            "Employer": {
                "@href": "/employer/123",
                "@rel": "employer",
                "@title": "Test Employer"
            },
            "FromDate": "2023-01-01",
            "HoldingDate": "2023-01-01T12:00:00Z",
            "MessageTypes": {
                "Type": [
                    {"@href": "/message-type/1", "@rel": "message-type", "@title": "Type 1"},
                    {"@href": "/message-type/2", "@rel": "message-type", "@title": "Type 2"}
                ]
            },
            "MessagesToProcess": {
                "Message": [
                    {"@href": "/message/1", "@rel": "message", "@title": "Message 1"},
                    {"@href": "/message/2", "@rel": "message", "@title": "Message 2"}
                ]
            },
            "Retrieve": False
        }
    }
    
    response = requests.post(f"{BASE_URL}/Jobs/Dps", headers=headers, json=payload)
    
    assert response.status_code == 401
    assert response.json()["ErrorModel"]["ErrorCategory"] == "NotAuthorised"

def test_post_new_dps_job_not_found():
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    payload = {
        "DpsJobInstruction": {
            "Apply": True,
            "Employer": {
                "@href": "/nonexistent/employer",
                "@rel": "employer",
                "@title": "Nonexistent Employer"
            },
            "FromDate": "2023-01-01",
            "HoldingDate": "2023-01-01T12:00:00Z",
            "MessageTypes": {
                "Type": [
                    {"@href": "/message-type/1", "@rel": "message-type", "@title": "Type 1"},
                    {"@href": "/message-type/2", "@rel": "message-type", "@title": "Type 2"}
                ]
            },
            "MessagesToProcess": {
                "Message": [
                    {"@href": "/message/1", "@rel": "message", "@title": "Message 1"},
                    {"@href": "/message/2", "@rel": "message", "@title": "Message 2"}
                ]
            },
            "Retrieve": False
        }
    }
    
    response = requests.post(f"{BASE_URL}/Jobs/Dps", headers=headers, json=payload)
    
    assert response.status_code == 404
    assert response.json()["ErrorModel"]["ErrorCategory"] == "NotFound"

def test_post_new_dps_job_internal_server_error():
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    payload = {
        "DpsJobInstruction": {
            "Apply": True,
            "Employer": {
                "@href": "/internal/server/error",
                "@rel": "employer",
                "@title": "Server Error Employer"
            },
            "FromDate": "2023-01-01",
            "HoldingDate": "2023-01-01T12:00:00Z",
            "MessageTypes": {
                "Type": [
                    {"@href": "/message-type/1", "@rel": "message-type", "@title": "Type 1"},
                    {"@href": "/message-type/2", "@rel": "message-type", "@title": "Type 2"}
                ]
            },
            "MessagesToProcess": {
                "Message": [
                    {"@href": "/message/1", "@rel": "message", "@title": "Message 1"},
                    {"@href": "/message/2", "@rel": "message", "@title": "Message 2"}
                ]
            },
            "Retrieve": False
        }
    }
    
    response = requests.post(f"{BASE_URL}/Jobs/Dps", headers=headers, json=payload)
    
    assert response.status_code == 500
    assert response.json()["ErrorModel"]["ErrorCategory"] == "General"