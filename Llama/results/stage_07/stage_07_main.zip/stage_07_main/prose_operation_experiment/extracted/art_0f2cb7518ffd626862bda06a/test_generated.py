# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urlencode

BASE_URL = "http://openapi.test"

def test_retrieve_all_hooks():
    authtoken_param = "your_oauth_token"
    login_param = "your_oauth_login"
    
    params = {
        "authtoken": authtoken_param,
        "login": login_param,
        "limit": 50,
        "page": 1
    }
    
    query_string = urlencode(params)
    url = f"{BASE_URL}/hooks.json?{query_string}"
    
    response = requests.get(url)
    assert response.status_code == 200
    
    hooks = response.json()
    assert isinstance(hooks, list)
    for hook in hooks:
        assert isinstance(hook, dict)
        required_keys = ["id", "name", "event", "url", "created_at"]
        assert all(key in hook for key in required_keys)

if __name__ == "__main__":
    pytest.main([__file__])