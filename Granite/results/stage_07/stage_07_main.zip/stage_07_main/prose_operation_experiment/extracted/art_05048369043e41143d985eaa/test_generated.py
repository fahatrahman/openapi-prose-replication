import os
import pytest
import requests
from googleapiclient.discovery import build

BASE_URL = "http://openapi.test"

@pytest.fixture
def display_video_service():
    """Build the Display Video v3 service."""
    api_service_name = "displayvideo"
    api_version = "v3"
    credentials = None  # Replace with appropriate credentials loading

    service = build(
        api_service_name,
        api_version,
        developerKey="YOUR_API_KEY",  # Replace with actual API key
        cache_discovery=False,
    )

    return service

def test_list_assigned_locations(display_video_service):
    """Test listing assigned locations for a location list."""
    advertiser_id = "ADVERTISER_ID"  # Replace with actual advertiser ID
    location_list_id = "LOCATION_LIST_ID"  # Replace with actual location list ID

    request = display_video_service.advertisers().locationLists().assignedLocations(
        advertiserId=advertiser_id,
        locationListId=location_list_id,
    ).list()

    response = request.execute()

    assert isinstance(response, dict)
    assert "assignedLocations" in response
    assert isinstance(response["assignedLocations"], list)

if __name__ == "__main__":
    pytest.main([__file__])