# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def get_current_date():
    return datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")

class TestListApplications:
    def test_list_applications(self):
        max_results = 10
        next_token = ""
        account_id = "123456789012"
        
        headers = {
            'X-Amz-Algorithm': 'AWS4-HMAC-SHA256',
            'X-Amz-Content-Sha256': self.get_content_sha256(),
            'X-Amz-Credential': self.get_credential(),
            'X-Amz-Date': get_current_date(),
            'X-Amz-Security-Token': '',
            'X-Amz-Signature': self.get_signature(),
            'X-Amz-SignedHeaders': 'host;x-amz-date'
        }
        
        response = requests.post(
            f"{BASE_URL}/ListApplications",
            headers=headers,
            json={
                "accountID": account_id,
                "filters": {
                    "applicationIDs": [],
                    "isArchived": False,
                    "waveIDs": []
                },
                "maxResults": max_results,
                "nextToken": next_token
            }
        )
        
        assert response.status_code == 200
        
    def get_content_sha256(self):
        # This method should return the SHA-256 hash of the request body
        # For simplicity, we'll just return a fixed string
        return "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    
    def get_credential(self):
        # This method should return the AWS credential in the format 'AWS4-ACCESS_KEY_ID/DATE/REGION/SERVICE'
        # For simplicity, we'll just return a fixed string
        return "AKIAIOSFODNN7EXAMPLE/20230215/us-east-1/ec2/aws4_request"
    
    def get_signature(self):
        # This method should return the signature for the request using the AWS signing process
        # For simplicity, we'll just return a fixed string
        return "93e9bcb02ef64fd7186feeb12937f3bc1edfb7f5509693ad26024161e294fe7"