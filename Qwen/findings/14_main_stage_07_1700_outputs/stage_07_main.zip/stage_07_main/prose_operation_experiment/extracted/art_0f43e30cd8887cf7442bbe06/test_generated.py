import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_activities():
    url = f"{BASE_URL}/activities"
    params = {
        "alt": "json",
        "fields": "activities(nextPageToken,singleEvents(eventTimeMillis,target(name,id,mimeType))),nextPageToken",
        "key": "your_api_key_here",  # Replace with actual API key
        "prettyPrint": False,
        "quotaUser": "user@example.com",  # Replace with actual quota user
        "source": "drive.google.com",
        "userId": "me"
    }
    headers = {
        "Authorization": "Bearer your_oauth_token_here"  # Replace with actual OAuth token
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert "activities" in data
    assert "nextPageToken" in data
    for activity in data["activities"]:
        assert "eventTimeMillis" in activity["combinedEvent"]
        assert "target" in activity["combinedEvent"]

if __name__ == "__main__":
    pytest.main([__file__])