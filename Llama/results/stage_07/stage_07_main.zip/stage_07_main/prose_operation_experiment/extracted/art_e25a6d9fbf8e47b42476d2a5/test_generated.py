import pytest
import requests

BASE_URL = "http://openapi.test"

def test_datastore_projects_export():
    url = f"{BASE_URL}/v1beta1/projects/my-project:export"
    headers = {"Content-Type": "application/json"}
    body = {
        "entityFilter": {"kinds": ["Kind1", "Kind2"], "namespaceIds": ["Namespace1", "Namespace2"]},
        "labels": {"label1": "value1"},
        "outputUrlPrefix": "gs://my-bucket/output",
    }
    response = requests.post(url, json=body, headers=headers)
    assert response.status_code == 200
    operation = response.json()
    assert operation["done"]
    assert operation["metadata"]["@type"]

def test_datastore_projects_export_with_oauth():
    url = f"{BASE_URL}/v1beta1/projects/my-project:export"
    headers = {"Content-Type": "application/json"}
    body = {
        "entityFilter": {"kinds": ["Kind1", "Kind2"], "namespaceIds": ["Namespace1", "Namespace2"]},
        "labels": {"label1": "value1"},
        "outputUrlPrefix": "gs://my-bucket/output",
    }
    response = requests.post(
        url,
        json=body,
        headers=headers,
        auth=("my-email@gmail.com", "my-password"),
    )
    assert response.status_code == 401
    # Add more tests here...