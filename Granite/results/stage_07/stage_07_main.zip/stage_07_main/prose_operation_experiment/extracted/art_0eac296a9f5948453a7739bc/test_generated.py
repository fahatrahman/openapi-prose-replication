import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_PATH = "path/to/credentials.json"

@pytest.fixture
def auth():
    credentials = service_account.Credentials.from_service_account_file(
        CREDENTIALS_PATH, scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )
    return credentials

def test_list_contacts(auth):
    headers = {"Authorization": f"Bearer {auth.token}"}

    parent = "seztsxhbkkrag/123" # Replace with actual value
    params = {"pageSize": 10, "pageToken": "abc123"}

    url = f"{BASE_URL}/v1/{parent}/contacts"
    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 200

    contacts_response = response.json()
    assert isinstance(contacts_response, dict)
    assert "contacts" in contacts_response
    assert isinstance(contacts_response["contacts"], list)