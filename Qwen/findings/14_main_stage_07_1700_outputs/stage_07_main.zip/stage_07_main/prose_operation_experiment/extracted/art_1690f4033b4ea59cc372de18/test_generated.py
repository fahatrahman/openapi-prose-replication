import pytest
import requests

BASE_URL = "http://openapi.test"

def get_video_desc(id):
    url = f"{BASE_URL}/api/v1/videos/{id}/description"
    response = requests.get(url)
    return response.json()

@pytest.mark.parametrize("id", [
    42,
    "9c9de5e8-0a1e-484a-b099-e80766180a6d",
    "2y84q2MQUMWPbiEcxNXMgC"
])
def test_get_video_desc(id):
    result = get_video_desc(id)
    assert isinstance(result, str)
    assert len(result) >= 3
    assert len(result) <= 10000