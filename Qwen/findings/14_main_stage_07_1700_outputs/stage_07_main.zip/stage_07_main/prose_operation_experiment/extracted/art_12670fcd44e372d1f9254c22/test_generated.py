import pytest
import requests

BASE_URL = "http://openapi.test"

def test_new_address():
    url = f"{BASE_URL}/v2/ethereum/addresses"
    payload = {
        "password": "test123"
    }
    headers = {
        "Content-Type": "application/json"
    }
    response = requests.post(url, json=payload, headers=headers)
    
    assert response.status_code == 200
    assert response.json()["ok"]
    assert response.json()["message"] == "Success! Ethereum Address was successfully created."
    assert isinstance(response.json()["data"]["ethereumaddress"], str)

if __name__ == "__main__":
    pytest.main()