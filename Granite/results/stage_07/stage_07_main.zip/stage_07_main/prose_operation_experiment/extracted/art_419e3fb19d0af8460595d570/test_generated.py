import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Retry mechanism for requests
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

# Sample DpsJobInstruction object for testing
sample_dps_job_instruction = {
    "Apply": True,
    "Employer": {"@href": "/Employers/1"},
    "FromDate": "2022-01-01",
    "HoldingDate": "2022-01-02T12:00:00",
    "MessageTypes": {"Type": []},
    "MessagesToProcess": {"Message": []},
    "Retrieve": True,
}

@pytest.mark.parametrize("authorization, api_version", [
    ("Auto", "default"),
    # Add more test cases here if needed
])
def test_post_new_dps_job(authorization, api_version):
    url = f"{BASE_URL}/Jobs/Dps"

    headers = {
        "Authorization": authorization,
        "Api-Version": api_version,
    }

    response = session.post(url, json=sample_dps_job_instruction, headers=headers)

    assert response.status_code == 201, f"Expected 201, got {response.status_code}"

    link = response.json()["Link"]
    assert "@href" in link, "Link object is missing @href"