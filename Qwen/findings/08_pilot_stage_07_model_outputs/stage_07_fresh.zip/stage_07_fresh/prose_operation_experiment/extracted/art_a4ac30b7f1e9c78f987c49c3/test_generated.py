import pytest
import requests

BASE_URL = "http://openapi.test"

def test_apps_list():
    headers = {
        "X-API-Token": "your_api_token_here"
    }
    params = {
        "$orderBy": "display_name"
    }
    response = requests.get(f"{BASE_URL}/v0.1/apps", headers=headers, params=params)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    if data:
        first_app = data[0]
        assert "id" in first_app
        assert "display_name" in first_app
        assert "name" in first_app
        assert "os" in first_app
        assert "owner" in first_app
        assert "release_type" in first_app
        assert "app_secret" in first_app
        assert "azure_subscription" in first_app
        assert "created_at" in first_app
        assert "member_permissions" in first_app
        assert "origin" in first_app
        assert "platform" in first_app
        assert "updated_at" in first_app
        assert isinstance(first_app["owner"], dict)
        assert "id" in first_app["owner"]
        assert "display_name" in first_app["owner"]
        assert "name" in first_app["owner"]
        assert "type" in first_app["owner"]
        assert isinstance(first_app["azure_subscription"], dict)
        assert "subscription_id" in first_app["azure_subscription"]
        assert "tenant_id" in first_app["azure_subscription"]
        assert "subscription_name" in first_app["azure_subscription"]
        assert isinstance(first_app["member_permissions"], list)

if __name__ == "__main__":
    pytest.main([__file__])