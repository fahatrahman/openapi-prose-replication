import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_traces():
    url = f"{BASE_URL}/v1/projects/{PROJECT_ID}/traces"
    params = {
        "access_token": ACCESS_TOKEN,
        "prettyPrint": True,
        "quotaUser": QUOTA_USER,
        "view": "VIEW_TYPE_UNSPECIFIED",
        "endTime": END_TIME,
        "startTime": START_TIME,
        "pageSize": PAGE_SIZE,
        "pageToken": PAGE_TOKEN,
        "filter": FILTER,
        "orderBy": ORDER_BY
    }
    headers = {
        "Authorization": f"Bearer {ACCESS_TOKEN}"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    assert "traces" in response.json()
    assert "nextPageToken" in response.json()

# Replace the following constants with actual values before running the tests
PROJECT_ID = "your_project_id"
ACCESS_TOKEN = "your_access_token"
QUOTA_USER = "your_quota_user"
END_TIME = "your_end_time"
START_TIME = "your_start_time"
PAGE_SIZE = 10
PAGE_TOKEN = ""
FILTER = ""
ORDER_BY = ""

pytest.main(["-v", __file__])