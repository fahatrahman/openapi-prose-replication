import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_sentences():
    url = f"{BASE_URL}/sentences"
    params = {"limit": 1}
    response = requests.get(url, params=params)
    assert response.status_code == 200
    data = response.json()
    assert "data" in data
    assert isinstance(data["data"], list)
    for item in data["data"]:
        assert "id" in item
        assert "sentence" in item
        assert "book" in item
        book = item["book"]
        assert "id" in book
        assert "name" in book
        assert "year" in book

if __name__ == "__main__":
    pytest.main()