import pytest
import requests
BASE_URL = "http://openapi.test"

@pytest.fixture
def test_compile():
    url = f"{BASE_URL}/v1/compile"
    payload = {
        "query": "data.example.allow == true",
        "input": {"subject": {"clearance_level": 4}},
        "unknowns": ["data.reports"],
    }
    headers = {
        "Content-Type": "application/json",
        "accept": "application/json",
    }

    def _test_compile():
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        return response.json()

    return _test_compile

def test_compile_response(test_compile):
    result = test_compile()
    assert result["result"]
    assert len(result["metrics"]) > 0
    assert "explanation" in result