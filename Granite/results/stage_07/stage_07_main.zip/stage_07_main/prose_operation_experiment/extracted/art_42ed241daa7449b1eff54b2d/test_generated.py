import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Configure session for retry on failure
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["GET", "OPTIONS"],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

# Add Bearer token authentication
session.auth = (os.getenv("OPENAPI_BEARER_TOKEN"), "")

def test_get_task():
    task_id = "your_task_id_here"  # Replace with actual task ID
    endpoint = f"{BASE_URL}/org/tasks/{task_id}"

    response = session.get(endpoint)

    if response.status_code == 200:
        task = response.json()
        assert isinstance(task, dict)
        assert task.get("id") is not None
        print("Test passed: Task retrieved successfully.")
    elif response.status_code == 401:
        print("Test passed: Unauthorized access (expected)")
    else:
        print(f"Test failed: Unexpected status code - {response.status_code}")