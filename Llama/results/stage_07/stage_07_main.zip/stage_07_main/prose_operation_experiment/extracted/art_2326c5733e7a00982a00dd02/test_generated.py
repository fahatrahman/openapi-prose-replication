import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_apps_get_instance_size():
    slug = "basic-xxs"
    headers = {
        "Authorization": "Bearer token",
        "Content-Type": "application/json"
    }
    response = requests.get(urljoin(BASE_URL, f"/v2/apps/tiers/instance_sizes/{slug}"), headers=headers)
    assert response.status_code == 200
    response.raise_for_status()
    instance_size = response.json()["instance_size"]
    assert instance_size["cpu_type"] == "SHARED"
    assert instance_size["cpus"] == 1
    assert instance_size["memory_bytes"] == 536870912
    assert instance_size["name"] == "Basic XXS"
    assert instance_size["slug"] == slug
    assert instance_size["tier_slug"] == "basic"
    assert instance_size["tier_upgrade_to"] == "professional-xs"
    assert instance_size["usd_per_month"] == 5.00
    assert instance_size["usd_per_second"] == 0.000002066799

@pytest.mark.parametrize("status_code", [401, 404, 429, 500])
def test_apps_get_instance_size_unexpected(status_code):
    slug = "basic-xxs"
    headers = {
        "Authorization": "Bearer token",
        "Content-Type": "application/json"
    }
    response = requests.get(urljoin(BASE_URL, f"/v2/apps/tiers/instance_sizes/{slug}"), headers=headers)
    assert response.status_code == status_code