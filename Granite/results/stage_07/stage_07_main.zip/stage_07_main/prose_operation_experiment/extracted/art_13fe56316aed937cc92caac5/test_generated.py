import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

@pytest.fixture
def divisions_search_total_results():
    url = f"{BASE_URL}/data/divisions.json/searchTotalResults"

    # Define query parameters
    params = {
        "queryParameters.searchTerm": "sample_search_term",
        "queryParameters.memberId": 123,
        "queryParameters.includeWhenMemberWasTeller": True,
        "queryParameters.startDate": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
        "queryParameters.endDate": (datetime.now() + timedelta).strftime("%Y-%m-%dT%H:%M:%S"),
        "queryParameters.divisionNumber": 456,
    }

    response = requests.get(url, params=params)

    assert response.status_code == 200
    return response.json()

def test_divisions_search_total_results(divisions_search_total_results):
    result = divisions_search_total_results
    assert isinstance(result, int)