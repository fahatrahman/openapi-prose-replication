# -*- coding: utf-8 -*-
import pytest
import requests
from jsonschema import ValidationError

BASE_URL = "http://openapi.test"

@pytest.fixture
def api_key():
    # Replace with your actual API key
    return "your_api_key_here"

def test_defend_dispute(api_key):
    url = f"{BASE_URL}/defendDispute"
    headers = {"Authorization": f"Basic {api_key}"}
    data = {
        "defenseReasonCode": "SupplyDefenseMaterial",
        "disputePspReference": "DZ4DPSHB4WD2WN82",
        "merchantAccountCode": "YOUR_MERCHANT_ACCOUNT"
    }
    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
        assert response.json()["disputeServiceResult"]["success"]
    except requests.exceptions.RequestException as e:
        print(e)
        raise
    except ValidationError as e:
        print(e)
        raise