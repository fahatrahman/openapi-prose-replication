import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_live_source():
    url = f"{BASE_URL}/sourceLocation/example/source/liveSource/example"
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Credential": "example/aws/region/service/aws4_request",
        "X-Amz-Date": "20230401T000000Z",
        "X-Amz-Security-Token": "example-security-token",
        "X-Amz-Signature": "example-signature",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-algorithm;x-amz-credential;x-amz-security-token;x-amz-signedheaders"
    }
    response = requests.delete(url, headers=headers)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)