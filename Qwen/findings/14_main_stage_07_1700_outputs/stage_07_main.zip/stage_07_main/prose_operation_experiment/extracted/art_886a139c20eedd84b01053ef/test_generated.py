import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_hidden_players():
    params = {
        "applicationId": "test_application_id",
        "maxResults": 10,
        "pageToken": None
    }
    headers = {
        "Authorization": "Bearer test_access_token"
    }
    response = requests.get(f"{BASE_URL}/games/v1management/applications/{params['applicationId']}/players/hidden", headers=headers, params=params)
    assert response.status_code == 200
    assert "items" in response.json()
    assert "kind" in response.json() and response.json()["kind"] == "gamesManagement#hiddenPlayerList"
    assert "nextPageToken" in response.json()

if __name__ == "__main__":
    pytest.main([__file__])