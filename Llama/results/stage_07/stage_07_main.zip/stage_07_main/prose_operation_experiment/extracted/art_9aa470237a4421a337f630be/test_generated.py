import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_drive_properties_update():
    file_id = "your_file_id"
    property_key = "your_property_key"
    visibility = "your_visibility_value"
    headers = {"Content-Type": "application/json"}
    body = {
        "key": property_key,
        "value": "your_value",
        "visibility": visibility
    }

    response = requests.put(
        urljoin(BASE_URL, f"/files/{file_id}/properties/{property_key}"),
        headers=headers,
        json=body
    )

    assert response.status_code == 200
    assert response.json()["key"] == property_key
    assert response.json()["value"] == "your_value"
    assert response.json()["visibility"] == visibility

if __name__ == "__main__":
    pytest.main([__file__])