import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_business_account_location_question():
    name = "your_business_name"
    response = requests.delete(
        f"{BASE_URL}/v4/{name}",
        params={
            "$.xgafv": "1",
            "access_token": "your_access_token",
            "alt": "json",
            "callback": "",
            "fields": "",
            "key": "your_key",
            "oauth_token": "your_oauth_token",
            "prettyPrint": "false",
            "quotaUser": "your_quota_user",
            "upload_protocol": "upload_protocol",
            "uploadType": "resumable"
        }
    )
    assert response.status_code == 200