import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Configure session for retries on request failures
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["GET", "OPTIONS"],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def api():
    return session

def test_get_endpoints(api):
    query_params = {"openapi": True}
    response = api.get("/?{}".format("&".join([f"{k}={v}" for k, v in query_params.items()])), verify=False)
    assert response.status_code == 200
    endpoint = response.json()

    # Add assertions based on expected endpoint structure here
    assert endpoint["methods"] is not None
    assert endpoint["path"] is not None