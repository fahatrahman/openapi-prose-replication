# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import date

BASE_URL = "http://openapi.test"

def test_get_media_items_for_tag():
    url = f"{BASE_URL}/resources/tags/{{id}}/media.json"
    params = {
        "id": 123,
        "sort": "name",
        "max": 10,
        "offset": 5
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    media_items = response.json()
    assert isinstance(media_items, list)
    for item in media_items:
        assert isinstance(item, dict)

def test_get_media_items_for_tag_invalid_id():
    url = f"{BASE_URL}/resources/tags/{{id}}/media.json"
    params = {
        "id": "not-an-id",
        "sort": "name",
        "max": 10,
        "offset": 5
    }
    response = requests.get(url, params=params)
    assert response.status_code == 400

def test_get_media_items_for_tag_internal_server_error():
    url = f"{BASE_URL}/resources/tags/{{id}}/media.json"
    params = {
        "id": 123,
        "sort": "name",
        "max": 10000000,
        "offset": 5
    }
    response = requests.get(url, params=params)
    assert response.status_code == 500