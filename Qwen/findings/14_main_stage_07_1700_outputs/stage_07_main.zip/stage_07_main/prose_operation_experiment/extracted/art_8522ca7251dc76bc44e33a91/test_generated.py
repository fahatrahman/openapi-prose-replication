import pytest
import requests

BASE_URL = "http://openapi.test"

def test_move_file():
    url = f"{BASE_URL}/v1beta1/workspace:moveFile"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "path": "/old/path/to/file.txt",
        "newPath": "/new/path/to/file.txt"
    }
    params = {
        "_xgafv": "1",
        "access_token": "YOUR_ACCESS_TOKEN",
        "alt": "json",
        "prettyPrint": True,
        "quotaUser": "user@example.com"
    }

    response = requests.post(url, headers=headers, json=payload, params=params)

    assert response.status_code == 200
    assert "application/json" in response.headers["Content-Type"]
    assert "MoveFileResponse" in response.json()