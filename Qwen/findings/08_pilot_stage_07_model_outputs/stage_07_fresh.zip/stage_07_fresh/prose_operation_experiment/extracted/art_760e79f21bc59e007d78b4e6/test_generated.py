import pytest
import requests

BASE_URL = "http://openapi.test"

def test_player_game_stats_by_player():
    format_param = "JSON"
    date_param = "2017-ZQD-31"
    playerid_param = "10000507"
    headers = {
        "Ocp-Apim-Subscription-Key": "your_subscription_key_here"
    }
    params = {
        "key": "your_api_key_here"
    }
    url = f"{BASE_URL}/{format_param}/PlayerGameStatsByPlayer/{date_param}/{playerid_param}"
    
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 200
    assert response.headers['Content-Type'] == 'application/json'
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()