import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

def test_add_image():
    image_data = {
        "source": {
            "archive": {
                "digest": "sha256:1234567890abcdef1234567890abcdef12345678"
            }
        }
    }

    response = SESSION.post(
        f"{BASE_URL}/images", json=image_data, headers={"x-anchore-account": "test_account"}
    )

    assert response.status_code == 200
    result = response.json()
    # Add assertions here based on expected output

if __name__ == "__main__":
    pytest.main([__file__])