import pytest
import requests
from datetime import datetime
import json

BASE_URL = "http://openapi.test"

def get_timestamp():
    return datetime.utcnow().isoformat() + 'Z'

def get_signature(key, method, scope, headers, payload):
    # AWS SigV4 implementation is complex, this is a simplified version
    # See https://docs.aws.amazon.com/general/latest/gr/signature-version-4.html
    algorithm = "AWS4-HMAC-SHA256"
    credential = f"{key}/{scope}"
    hashed_date = hmac.new(key.encode(), get_timestamp()[:8].encode(), hashlib.sha256).hexdigest()
    hashed_region = hmac.new(hashed_date.encode(), "us-east-1".encode(), hashlib.sha256).hexdigest()
    hashed_service = hmac.new(hashed_region.encode(), "ec2".encode(), hashlib.sha256).hexdigest()
    signature = hmac.new(hashed_service.encode(), (method.upper() + "\n" +
        get_timestamp() + "\n" + hashed_service + "\n" + hashlib.sha256(payload.encode()).hexdigest()).encode(),
        hashlib.sha256).hexdigest()
    return algorithm, credential, hashed_service, signature

@pytest.fixture
def auth_headers():
    key = "my_secret_key"
    credentials = {
        "X-Amz-Algorithm": "",
        "X-Amz-Credential": "",
        "X-Amz-Date": get_timestamp(),
        "X-Amz-Security-Token": "",
        "X-Amz-Signature": "",
        "X-Amz-SignedHeaders": ""
    }
    algorithm, credential, _, signature = get_signature(key, "POST", "/ec2/", {}, "")
    credentials["X-Amz-Algorithm"] = algorithm
    credentials["X-Amz-Credential"] = credential
    credentials["X-Amz-Signature"] = signature
    return credentials

def test_DisassociateUser(auth_headers):
    url = f"{BASE_URL}/user/DisassociateUser"
    data = {
        "Domain": "example.com",
        "IdentityProvider": {"ActiveDirectoryIdentityProvider": {"DirectoryId": "123456789012"}},
        "InstanceId": "i-12345678",
        "Username": "username"
    }
    response = requests.post(url, headers=auth_headers, data=json.dumps(data))
    assert response.status_code == 200