import os
import pytest
import requests
from requests_aws_sigv4 import AWSSignersV4

BASE_URL = "http://openapi.test"

# Signing related parameters
AWS_ACCESS_KEY = os.environ["AWS_ACCESS_KEY"]
AWS_SECRET_KEY = os.environ["AWS_SECRET_KEY"]
REGION = "us-east-1"
SERVICE = "ses"

def put_configuration_set_suppression_options(
    ConfigurationSetName, SuppressedReasons
):
    url = f"{BASE_URL}/v2/email/configuration-sets/{ConfigurationSetName}/suppression-options"

    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": f"{AWS_ACCESS_KEY}:{AWS_SECRET_KEY}",
        "X-Amz-Date": requests.utils.default_timeout_secs,
        "X-Amz-Expires": 3600,
        "X-Amz-SignedHeaders": "/location/to/sign",
        "X-Amz-Security-Token": "",  # If applicable
        "X-Amz-Signature": "",  # Will be computed
    }

    payload = {"SuppressedReasons": SuppressedReasons}

    response = requests.put(
        url=url,
        headers=headers,
        json=payload,
        verify=False,  # Disable SSL verification for testing
    )

    assert response.status_code == 200

    return response.json()


@pytest.mark.parametrize(
    "ConfigurationSetName, SuppressedReasons",
    [
        ("example-set", ["COMPLAINT", "BOUNCE"]),
        ("another-example-set", ["VGQLXM"]),
    ],
)
def test_put_configuration_set_suppression_options(
    ConfigurationSetName, SuppressedReasons
):
    result = put_configuration_set_suppression_options(
        ConfigurationSetName, SuppressedReasons
    )
    assert result is not None
    assert result["__all__"] is None  # Assuming PutConfigurationSetSuppressionOptionsResponse has __all__ property