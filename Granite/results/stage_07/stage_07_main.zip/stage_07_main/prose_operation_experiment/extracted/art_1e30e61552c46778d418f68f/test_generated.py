import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def get_bep20_balance(contract, token_id):
    endpoint = "/v2/bsc/balances/{}/{}/bep20".format(contract, token_id)
    response = requests.get(urljoin(BASE_URL, endpoint), verify=False)

    assert response.status_code == 200

    expected_response = {
        "data": {"balance": ""},
        "message": "Token Balance has been successfully parsed.",
        "ok": True,
        "status": 200,
    }

    assert response.json() == expected_response


@pytest.mark.parametrize("contract, token_id", [
    ("0x1dDB2C0897daF18632662E71fdD2dbDC0eB3a9Ec", "0x9dB475371B5cC2913D3219f72e16a3F101339a05"),
])
def test_get_bep20_balance(contract, token_id):
    get_bep20_balance(contract, token_id)