BASE_URL = "http://openapi.test"
import pytest
import requests

def test_get_tracking_snippet():
    url = f"{BASE_URL}/tracking/snippet"
    headers = {}
    params = {"domain": "example.com"}

    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200

    data = response.json()
    meta = data["meta"]
    assert meta["requestId"]
    assert meta["status"] == 200
    assert isinstance(data["data"], dict)
    assert "domain" in data["data"]
    assert "snippet" in data["data"]
    assert data["data"]["domain"] == "example.com"