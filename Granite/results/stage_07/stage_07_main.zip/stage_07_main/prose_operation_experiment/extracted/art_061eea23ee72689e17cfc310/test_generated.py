import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.fixture
def classification():
    """Fixture to add classification to a file"""

    def _classification(file_id, classification_key):
        url = f"{BASE_URL}/files/{file_id}/metadata/enterprise/securityClassification-6VMVochwUWo"
        payload = {"Box__Security__Classification__Key": classification_key}

        SESSION.post(url, json=payload)

    yield _classification

    # No cleanup needed for this fixture

# Example usage of the fixture
def test_add_classification(classification):
    file_id = "your_file_id"
    classification_key = "Sensitive"
    classification(file_id, classification_key)