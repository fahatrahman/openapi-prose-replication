import pytest
import requests

BASE_URL = "http://openapi.test"

def test_androidpublisher_edits_images_deleteall():
    url = f"{BASE_URL}/androidpublisher/v3/applications/packageName/edits/editId/listings/language/imageType"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token_here",
        "alt": "json",
        "callback": "your_callback_here",
        "fields": "deleted(id,sha1,sha256,url)",
        "key": "your_key_here",
        "oauth_token": "your_oauth_token_here",
        "prettyPrint": True,
        "quotaUser": "your_quota_user_here",
        "uploadType": "multipart",
        "upload_protocol": "raw"
    }
    headers = {
        "Authorization": "Bearer your_access_token_here"
    }
    response = requests.delete(url, params=params, headers=headers)
    assert response.status_code == 200
    assert "deleted" in response.json()