# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_patch_source():
    url = f"{BASE_URL}/v1/{'source_name'}"
    headers = {
        'Content-Type': 'application/json'
    }
    data = {
        "field1": "value1",
        "field2": "value2"
    }

    response = requests.request(
        "PATCH",
        url,
        headers=headers,
        json=data,
        params={
            "$.xgafv": "1",
            "access_token": None,
            "alt": "json",
            "callback": None,
            "fields": "*",
            "key": None,
            "oauth_token": None,
            "prettyPrint": "true",
            "quotaUser": None,
            "upload_protocol": None,
            "uploadType": None,
            "requestId": "uuid",
            "updateMask": "field1,field2"
        }
    )

    assert response.status_code == 200
    assert response.json()["done"]