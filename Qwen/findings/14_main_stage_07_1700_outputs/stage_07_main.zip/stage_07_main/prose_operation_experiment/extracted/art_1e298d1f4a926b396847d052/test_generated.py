import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_mock():
    mock_uid = "test-mock-uid"
    url = f"{BASE_URL}/mocks/{mock_uid}"
    
    response = requests.delete(url)
    
    assert response.status_code == 200
    assert 'mock' in response.json()
    assert 'id' in response.json()['mock']
    assert 'uid' in response.json()['mock']
    assert response.json()['mock']['id'] == mock_uid
    assert response.json()['mock']['uid'] == mock_uid