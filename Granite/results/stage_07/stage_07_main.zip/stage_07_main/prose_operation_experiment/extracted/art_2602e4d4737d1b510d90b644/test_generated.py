import os
import requests
import pytest
BASE_URL = "http://openapi.test"

@pytest.fixture
def api_key():
    return os.environ["API_KEY"]

def test_create_images_from_files(api_key):
    url = f"{BASE_URL}/projects/64b822c5-8082-4b36-a426-27225f4aa18c/images/files"
    headers = {"ApiKey": api_key}
    response = requests.post(url, headers=headers)
    assert response.status_code == 200
    data = response.json()
    print(data)