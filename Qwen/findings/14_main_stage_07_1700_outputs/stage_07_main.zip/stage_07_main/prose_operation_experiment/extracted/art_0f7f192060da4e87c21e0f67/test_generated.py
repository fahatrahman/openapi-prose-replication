import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_tracking_snippet():
    url = f"{BASE_URL}/tracking/snippet"
    params = {
        "domain": "example.com"
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 200
    assert 'application/json' in response.headers['Content-Type']
    
    data = response.json()
    meta = data['meta']
    assert 'requestId' in meta
    assert 'status' in meta
    
    assert 'data' in data
    snippet_data = data['data']
    assert 'domain' in snippet_data
    assert 'snippet' in snippet_data
    
    rate_limit_limit = response.headers.get('X-RateLimit-Limit')
    rate_limit_remaining = response.headers.get('X-RateLimit-Remaining')
    assert rate_limit_limit is not None
    assert rate_limit_remaining is not None

@pytest.mark.parametrize("domain,expected_status", [
    ("invalid-domain", 400),
    ("unauthorized-domain", 401),
    ("forbidden-domain", 403),
    ("not-found-domain", 404),
    ("rate-limited-domain", 429),
    ("internal-error-domain", 500)
])
def test_error_responses(domain, expected_status):
    url = f"{BASE_URL}/tracking/snippet"
    params = {
        "domain": domain
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == expected_status
    assert 'application/json' in response.headers['Content-Type']
    
    if expected_status == 400:
        errors = response.json()['errors']
        assert 'fields' in errors
        assert 'parameters' in errors
    elif expected_status == 401 or expected_status == 403 or expected_status == 404 or expected_status == 500:
        message = response.json()['message']
        assert isinstance(message, str)
    
    rate_limit_limit = response.headers.get('X-RateLimit-Limit')
    rate_limit_remaining = response.headers.get('X-RateLimit-Remaining')
    assert rate_limit_limit is not None
    assert rate_limit_remaining is not None