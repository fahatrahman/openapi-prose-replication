import os
import requests
import pytest

BASE_URL = "http://openapi.test"

@pytest.fixture
def custom_vision_client():
    return requests.Client()

def get_domain(custom_vision_client, domain_id):
    url = f"{BASE_URL}/domains/{domain_id}"
    headers = {}

    response = custom_vision_client.get(url, headers=headers)

    if response.status_code == 200:
        return response.json()
    else:
        error_data = response.json()
        raise Exception(f"Error: {error_data['code']}: {error_data['message']}")

def test_get_domain(custom_vision_client):
    domain_id = "b30a91ae-e3c1-4f73-a81e-c270bff27c39"
    try:
        result = get_domain(custom_vision_client, domain_id)
        assert result["name"] == "Retail"
        assert result["type"] == "Classification"
        assert result["enabled"] is True
        assert result["exportable"] is False
    except Exception as e:
        pytest.fail(str(e))