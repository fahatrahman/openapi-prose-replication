import pytest
import requests

BASE_URL = "http://openapi.test"

def test_read_string_var():
    string_name = "test_string"
    url = f"{BASE_URL}/device/strategy/vars/strings/{string_name}"
    headers = {
        "Authorization": "Basic YWRtaW46cGFzc3dvcmQ="  # Replace with actual credentials
    }
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert "value" in response.json()

def test_read_string_var_400():
    string_name = "invalid_string"
    url = f"{BASE_URL}/device/strategy/vars/strings/{string_name}"
    headers = {
        "Authorization": "Basic YWRtaW46cGFzc3dvcmQ="  # Replace with actual credentials
    }
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 400
    error_response = response.json()
    assert "errorCode" in error_response
    assert error_response["errorCode"] in [-1, -3, -8, -12, -13, -17, -20, -36, -109, -13019, 400]

def test_read_string_var_401():
    string_name = "test_string"
    url = f"{BASE_URL}/device/strategy/vars/strings/{string_name}"
    headers = {
        "Authorization": "Basic invalid_credentials"  # Invalid credentials
    }
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 401
    error_response = response.json()
    assert "errorCode" in error_response
    assert error_response["errorCode"] == -104

def test_read_string_var_404():
    string_name = "nonexistent_string"
    url = f"{BASE_URL}/device/strategy/vars/strings/{string_name}"
    headers = {
        "Authorization": "Basic YWRtaW46cGFzc3dvcmQ="  # Replace with actual credentials
    }
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 404
    error_response = response.json()
    assert "errorCode" in error_response
    assert error_response["errorCode"] in [-29, -28, 404]