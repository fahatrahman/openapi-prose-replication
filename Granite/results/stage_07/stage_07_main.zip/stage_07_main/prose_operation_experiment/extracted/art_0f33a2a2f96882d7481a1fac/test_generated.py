import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"

# Set up service account credentials
credentials = service_account.Credentials.from_service_account_file(
    'path/to/your/service_account.json')

headers = {
    'Authorization': f'Bearer {credentials.token}'
}

@pytest.fixture
def api_client():
    session = requests.Session()
    session.headers.update(headers)
    return session

def test_get_deployments(api_client):
    name = 'seztsxhbkkrag/nhx/ktjspqitzpup/aef/oqkhfcgtqud/nubemlvnrn/vbereeqgk/lil'
    response = api_client.get(f'{BASE_URL}/v1/{name}/deployments', headers=headers)

    assert response.status_code == 200
    deployment = response.json()
    # Add more assertions based on expected data structure