import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_webhooks():
    url = f"{BASE_URL}/webhooks"
    params = {
        "marker": "JV9IRGZmieiBasejOG9yDCRNgd2ymoZIbjsxbJMjIs3kioVii",
        "limit": 1000
    }
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 200
    assert "entries" in response.json()

def test_get_webhooks_with_invalid_token():
    url = f"{BASE_URL}/webhooks"
    params = {
        "marker": "JV9IRGZmieiBasejOG9yDCRNgd2ymoZIbjsxbJMjIs3kioVii",
        "limit": 1000
    }
    headers = {
        "Authorization": "Bearer INVALID_ACCESS_TOKEN"
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 403
    assert response.json()["type"] == "error"
    assert response.json()["message"] == "Forbidden"
    assert response.json()["code"] == "forbidden"