import pytest
import requests
BASE_URL = "http://openapi.test"

def test_add_subnet():
    id = 123  # Replace with actual ID
    payload = {
        "ip_range": "10.0.1.0/24",
        "network_zone": "eu-central",
        "type": "vswitch",
        "vswitch_id": 1000
    }

    url = f"{BASE_URL}/networks/{id}/actions/add_subnet"
    response = requests.post(url, json=payload)

    assert response.status_code == 201
    action_response = response.json()
    assert action_response["action"]["command"] == "add_subnet"
    assert action_response["action"]["status"] == "running"
    assert len(action_response["action"]["resources"]) > 0