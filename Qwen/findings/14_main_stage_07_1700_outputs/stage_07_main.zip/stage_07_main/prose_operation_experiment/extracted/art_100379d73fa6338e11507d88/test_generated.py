import pytest
import requests

BASE_URL = "http://openapi.test"

def test_sign_ssh_public_key():
    url = f"{BASE_URL}/v1beta/projects/your-project/zones/your-zone:signSshPublicKey"
    headers = {
        "Authorization": "Bearer your-access-token",
        "Content-Type": "application/json"
    }
    payload = {
        "sshPublicKey": "your-ssh-public-key"
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert "signedSshPublicKey" in response.json()