import pytest
import requests

BASE_URL = "http://openapi.test"

def test_update_studio():
    headers = {
        "X-Amz-Algorithm": "HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "ACCESS_KEY_ID/DATE/REGION/NIMBLESTUDIO/aws4_request",
        "X-Amz-Date": "DATE",
        "X-Amz-Security-Token": "SESSION_TOKEN",
        "X-Amz-Signature": "SIGNATURE",
        "X-Amz-SignedHeaders": "host;x-amz-date;x-amz-content-sha256"
    }
    payload = {
        "displayName": "Updated Studio Name"
    }
    response = requests.patch(f"{BASE_URL}/2020-08-01/studios/studio-id", headers=headers, json=payload)
    assert response.status_code == 200
    assert response.json()["studio"]["displayName"] == "Updated Studio Name"