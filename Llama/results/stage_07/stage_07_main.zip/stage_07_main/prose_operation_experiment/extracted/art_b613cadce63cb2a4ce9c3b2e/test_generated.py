# -*- coding: utf-8 -*-
"""
pytest tests for Operation slice
"""

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_publishers_list():
    """
    Test /publishers endpoint
    """
    params = {
        'page': 1,
        'page_size': 10
    }
    response = requests.get(f"{BASE_URL}/publishers", params=params)
    assert response.status_code == 200
    data = response.json()
    assert 'count' in data
    assert 'results' in data
    assert isinstance(data['count'], int)
    assert all(isinstance(publisher, dict) for publisher in data['results'])
    for publisher in data['results']:
        assert 'id' in publisher
        assert 'name' in publisher
        assert 'slug' in publisher
        assert 'image_background' in publisher
        assert 'games_count' in publisher
        assert isinstance(publisher['id'], int)
        assert isinstance(publisher['name'], str)
        assert isinstance(publisher['slug'], str)
        assert isinstance(publisher['image_background'], str)
        assert isinstance(publisher['games_count'], int)

if __name__ == '__main__':
    pytest.main([__file__])