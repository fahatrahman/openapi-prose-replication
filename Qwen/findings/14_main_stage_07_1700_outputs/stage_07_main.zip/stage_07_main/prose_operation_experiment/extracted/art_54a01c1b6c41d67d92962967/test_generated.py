import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_bidders():
    url = f"{BASE_URL}/v1/bidders"
    params = {
        "pageSize": 10,
        "pageToken": ""
    }
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()