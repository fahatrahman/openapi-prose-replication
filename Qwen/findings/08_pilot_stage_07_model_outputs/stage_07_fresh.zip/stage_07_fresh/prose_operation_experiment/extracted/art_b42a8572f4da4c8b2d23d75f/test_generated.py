import pytest
import requests

BASE_URL = "http://openapi.test"

def test_all_monitors():
    response = requests.get(f"{BASE_URL}/monitors")
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert 'monitors' in data
    monitors = data['monitors']
    assert isinstance(monitors, list)
    for monitor in monitors:
        assert isinstance(monitor, dict)
        assert 'id' in monitor
        assert 'name' in monitor
        assert 'owner' in monitor
        assert 'uid' in monitor