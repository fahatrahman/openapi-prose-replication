import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = "path/to/your/service_account.json"

@pytest.fixture
def auth():
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )
    return credentials

def test_list_backup_runs(auth):
    headers = {
        "Authorization": f"Bearer {auth.token}"
    }

    params = {
        "maxResults": 10,
        "pageToken": "some_page_token",
    }

    url = f"{BASE_URL}/v1/projects/your_project_id/instances/your_instance_id/backupRuns"

    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 200

    backup_runs_response = response.json()
    assert "items" in backup_runs_response
    assert "kind" in backup_runs_response
    assert "nextPageToken" in backup_runs_response

    for item in backup_runs_response["items"]:
        assert isinstance(item, dict)
        # Add more assertions based on expected properties of BackupRun