# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urljoin
from jsonschema import ValidationError, validate

BASE_URL = "http://openapi.test"

def test_sign_ssh_public_key():
    # Define the request body
    parent = "/v1beta/users/projects/zones"
    ssh_public_key_request = {
        "sshPublicKey": "your_ssh_public_key_here"
    }

    try:
        # Validate the request body against the schema
        schema = {
            "type": "object",
            "properties": {
                "sshPublicKey": {"type": "string"}
            },
            "required": ["sshPublicKey"]
        }
        validate(instance=ssh_public_key_request, schema=schema)
    except ValidationError as e:
        pytest.fail(f"Invalid request body: {str(e)}")

    # Send the POST request
    response = requests.post(
        urljoin(BASE_URL, parent),
        headers={"Content-Type": "application/json"},
        json=ssh_public_key_request,
    )

    # Check if the response was successful
    assert response.status_code == 200

    # Parse the JSON response
    signed_ssh_public_key_response = response.json()

    # Check if the response matches the expected schema
    schema = {
        "type": "object",
        "properties": {
            "signedSshPublicKey": {"type": "string"}
        },
        "required": ["signedSshPublicKey"]
    }
    try:
        validate(instance=signed_ssh_public_key_response, schema=schema)
    except ValidationError as e:
        pytest.fail(f"Invalid response: {str(e)}")