import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_update_group_subscriptions():
    params = {
        "UpdateGroupID": "test_update_group_id",
        "PackageTypeID": "test_package_type_id",
        "ClientID": "test_client_id",
        "limit": 10,
        "offset": 0
    }
    response = requests.get(f"{BASE_URL}/api/v2/UpdateGroupSubscriptions", params=params)
    assert response.status_code == 200
    data = response.json()
    assert "Entities" in data
    assert "Metadata" in data
    assert "TotalCount" in data["Metadata"]
    assert "Limit" in data["Metadata"]
    assert "Offset" in data["Metadata"]

if __name__ == "__main__":
    pytest.main()