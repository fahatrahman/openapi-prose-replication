import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from typing import List

BASE_URL = "http://openapi.test"

# Session with retry for transient errors
session = requests.Session()
retry_strategy = HTTPAdapter(max_retries=3)
session.mount("http://", retry_strategy)
session.mount("https://", retry_strategy)

@pytest.fixture
def service_principal_owners():
    tenant_id = "your_tenant_id"  # Replace this with actual value
    object_id = "your_object_id"  # Replace this with actual value

    url = f"{BASE_URL}/{tenant_id}/servicePrincipals/{object_id}/owners"
    
    headers = {
        "Content-Type": "application/json",
    }

    response = session.get(url, headers=headers)
    response.raise_for_status()

    yield response.json()

def test_list_owners(service_principal_owners):
    assert isinstance(service_principal_owners, dict)
    assert "value" in service_principal_owners
    assert all(isinstance(owner, dict) for owner in service_principal_owners["value"])