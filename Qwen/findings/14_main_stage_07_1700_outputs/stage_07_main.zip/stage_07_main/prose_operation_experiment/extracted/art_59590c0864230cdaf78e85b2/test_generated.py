import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_gateways():
    url = f"{BASE_URL}/v1/projects/location/gateways"
    params = {
        "pageSize": 10,
        "pageToken": ""
    }
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    assert "gateways" in response.json()

if __name__ == "__main__":
    pytest.main()