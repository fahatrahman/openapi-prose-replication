import pytest
import requests

BASE_URL = "http://openapi.test"

def test_service_principals_list_owners():
    tenant_id = "your_tenant_id"
    object_id = "your_object_id"
    api_version = "your_api_version"
    
    url = f"{BASE_URL}/{tenant_id}/servicePrincipals/{object_id}/owners"
    params = {
        "api-version": api_version,
        "tenantID": tenant_id
    }
    
    response = requests.get(url, params=params)
    
    assert response.status_code == 200
    assert "value" in response.json()
    assert isinstance(response.json()["value"], list)

if __name__ == "__main__":
    pytest.main(["-v", __file__])