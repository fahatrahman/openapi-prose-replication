import os
import pytest
import requests
from googleapiclient.discovery import build

BASE_URL = "http://openapi.test"

# Assuming you have a service account key JSON file named 'keyfile.json'
KEYFILE_PATH = 'keyfile.json'
SCOPES = ['https://www.googleapis.com/auth/cloud-platform']

def get_authenticated_service():
    credentials = None
    if KEYFILE_PATH:
        credentials = os.path.expanduser(KEYFILE_PATH)

    service = build('composer', 'v1beta1', credentials=credentials,
                    host=BASE_URL, scopes=SCOPES)
    return service

def test_list_user_workload_secrets():
    service = get_authenticated_service()

    parent = "zynntaco/xodbbxeUz/yzvrewumc/ywxkgongTr/ktjspqitzpup/ixjlnsfdooeHp" # Replace with actual value
    request = service.projects().locations().environments().userWorkloadsSecrets(name=parent).list()

    response = request.execute()
    assert 'userWorkloadsSecrets' in response
    assert 'nextPageToken' in response

if __name__ == '__main__':
    pytest.main([__file__])