import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.exceptions import Retry

BASE_URL = "http://openapi.test"

# Define headers for authorization and api version
HEADERS = {
    "Authorization": os.environ.get("AUTHORIZATION", "Auto"),
    "Api-Version": os.environ.get("API_VERSION", "default")
}

# Define retry strategy for handling transient errors
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["GET", "OPTIONS"],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def client():
    return session

def test_get_holiday_balance_report(client):
    url = f"{BASE_URL}/Report/HOLBAL/run"

    # Prepare parameters for the GET request
    params = {
        "EmployerKey": "GD001",
        "HolidayYearEnd": "2018-12-31",
        "EmployeeCodes": "VNS001,VNS002",
        "StartIndex": "1",
        "MaxIndex": "100"
    }

    response = client.get(url, headers=HEADERS, params=params)

    assert response.status_code == 200, \
        f"Request failed with status code {response.status_code}. Body: {response.text}"