import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_tag_languages():
    url = f"{BASE_URL}/resources/tags/tagLanguages.json"
    response = requests.get(url)
    
    assert response.status_code == 200
    data = response.json()
    
    assert isinstance(data, list)
    for item in data:
        assert 'id' in item
        assert 'isActive' in item
        assert 'isoCode' in item
        assert 'name' in item

if __name__ == "__main__":
    pytest.main()