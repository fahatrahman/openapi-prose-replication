import pytest
import requests
from datetime import datetime
import hmac
import hashlib
import os

BASE_URL = "http://openapi.test"

def get_amz_date():
    """Get AWS date string"""
    return datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')

def get_amz_algorithm():
    """Get AWS algorithm string"""
    return 'AWS4-HMAC-SHA256'

def get_amz_signed_headers(headers):
    """Get signed headers string"""
    return ','.join(sorted([key for key in headers if key.startswith('x-amz-')]))

def get_amz_credentials(aws_access_key_id, aws_secret_access_key, region_name):
    """Get AWS credentials string"""
    return f'{aws_access_key_id}/{region_name}/amazonaws/com'

def get_amz_signature(key, date_string, method, canonical_uri, query_string, payload_hash):
    """Calculate AWS signature"""
    # See https://docs.aws.amazon.com/general/latest/gr/signature-v4-overview.html
    k_date = hmac.new(key, date_string.encode(), hashlib.sha256)
    k_region = hmac.new(k_date.digest(), region_name.encode(), hashlib.sha256)
    k_service = hmac.new(k_region.digest(), b'amazonaws', hashlib.sha256)
    k_signing = hmac.new(k_service.digest(), method.encode() + canonical_uri.encode() + query_string.encode() + payload_hash.encode(), hashlib.sha256)

    return hmac.new(k_signing.digest(), digestmod=hashlib.sha256)

def get_auth_header(aws_access_key_id, aws_secret_access_key, region_name, headers):
    """Generate auth header"""
    date_string = get_amz_date()
    amz_algorithm = get_amz_algorithm()

    # Calculate signing key
    signing_key = hmac.new(aws_secret_access_key.encode(), date_string.encode(), hashlib.sha256).digest()

    # Sign the request
    payload_hash = hashlib.sha256('').hexdigest()
    canonical_request = f'GET\n{canonical_uri}\n{query_string}\n{payload_hash}'
    signature = get_amz_signature(signing_key, date_string, method, canonical_uri, query_string, payload_hash).hexdigest()

    # Create auth header
    amz_security_token = ''
    amz_credential = get_amz_credentials(aws_access_key_id, aws_secret_access_key, region_name)
    amz_signedheaders = get_amz_signed_headers(headers)
    amz_date = get_amz_date()
    amz_signature = signature

    return (
        f"{amz_algorithm} Credential={amz_credential},SignedHeaders={amz_signedheaders},Signature={amz_signature}"
    )

@pytest.fixture
def client():
    return requests.Session()

def test_DescribeCopyJob(client):
    """Test DescribeCopyJob endpoint"""

    # Generate AWS credentials
    aws_access_key_id = os.environ.get("AWS_ACCESS_KEY_ID")
    aws_secret_access_key = os.environ.get("AWS_SECRET_ACCESS_KEY")
    region_name = 'us-east-1'
    
    # Construct path and query parameters
    path_params = {'copyJobId': 'test_copy_job'}
    query_params = {}
    headers = {
        'X-Amz-Algorithm': '',
        'X-Amz-Content-Sha256': '',
        'X-Amz-Credential': '',
        'X-Amz-Date': '',
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': '',
        'X-Amz-SignedHeaders': '',
    }

    # Add auth header
    auth_header = get_auth_header(aws_access_key_id, aws_secret_access_key, region_name, headers)
    headers['Authorization'] = auth_header

    # Send GET request
    response = client.get(
        url=f'{BASE_URL}/copy-jobs/{path_params["copyJobId"]}',
        params=query_params,
        headers=headers,
    )

    # Check response status code and content
    assert response.status_code == 200
    assert response.json()['CopyJob']