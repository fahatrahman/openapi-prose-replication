import pytest
import requests
from urllib.parse import urlencode

BASE_URL = "http://openapi.test"

def test_list_services():
    params = {
        "PageSize": 10,
        "Page": 0,
    }
    query_string = urlencode(params)
    response = requests.get(f"{BASE_URL}/v1/Services?{query_string}")
    assert response.status_code == 200
    response_json = response.json()
    assert response_json["status"] == "success"
    services = response_json["data"]["services"]
    assert isinstance(services, list)
    assert len(services) > 0
    for service in services:
        assert "sid" in service
        assert "friendly_name" in service
        assert "date_created" in service