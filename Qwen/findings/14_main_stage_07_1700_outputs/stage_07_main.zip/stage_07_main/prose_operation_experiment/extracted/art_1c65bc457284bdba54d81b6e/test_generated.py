import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.mark.parametrize("format", ["xml", "json"])
def test_memberships_active(format):
    url = f"{BASE_URL}/{format}/ActiveMemberships"
    headers = {
        "Ocp-Apim-Subscription-Key": "your_subscription_key_here",
    }
    params = {
        "key": "your_api_key_here",
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    assert isinstance(response.json(), list)
    for item in response.json():
        assert isinstance(item, dict)
        assert "Active" in item
        assert isinstance(item["Active"], bool)
        if "EndDate" in item:
            assert isinstance(item["EndDate"], str)
        if "Jersey" in item:
            assert isinstance(item["Jersey"], int)
        assert "MembershipId" in item
        assert isinstance(item["MembershipId"], int)
        assert "PlayerId" in item
        assert isinstance(item["PlayerId"], int)
        if "PlayerName" in item:
            assert isinstance(item["PlayerName"], str)
        if "StartDate" in item:
            assert isinstance(item["StartDate"], str)
        if "TeamArea" in item:
            assert isinstance(item["TeamArea"], str)
        assert "TeamId" in item
        assert isinstance(item["TeamId"], int)
        if "TeamName" in item:
            assert isinstance(item["TeamName"], str)
        if "Updated" in item:
            assert isinstance(item["Updated"], str)