import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"

@pytest.fixture
def auth():
    credentials = service_account.Credentials.from_service_account_file(
        "path/to/credentials.json"
    )
    return credentials

def test_import_mapping_rules(auth):
    parent = "projects/my-project/locations/us-central1/conversionWorkspaces/my-workspace"
    import_mapping_rules_request = {
        "autoCommit": True,
        "rulesFiles": [
            {
                "rulesContent": "sample_rules_content",
                "rulesSourceFilename": "sample_rules_file.txt"
            }
        ],
        "rulesFormat": "IMPORT_RULES_FILE_FORMAT_HARBOUR_BRIDGE_SESSION_FILE"
    }

    url = f"{BASE_URL}/{parent}/mappingRules:import"
    headers = {"Content-Type": "application/json"}

    response = requests.post(url, json=import_mapping_rules_request, headers=headers, verify=False, auth=auth)

    assert response.status_code == 200
    assert "operation" in response.json()