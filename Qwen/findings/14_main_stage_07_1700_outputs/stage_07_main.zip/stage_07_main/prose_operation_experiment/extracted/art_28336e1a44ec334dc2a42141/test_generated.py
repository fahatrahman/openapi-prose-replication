import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_api():
    headers = {
        "Authorization": "Bearer YOUR_API_KEY",
        "x-apideck-app-id": "YOUR_APP_ID"
    }
    params = {
        "id": "id_example"
    }
    url = f"{BASE_URL}/connector/apis/{params['id']}"
    
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 200
    assert response.json().get("status") == "OK"
    assert "data" in response.json()