import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_featurestores():
    url = f"{BASE_URL}/v1/projects/your-project/locations/your-location/featurestores"
    params = {
        "filter": "create_time > \"2020-01-01\"",
        "orderBy": "create_time desc",
        "pageSize": 10,
        "pageToken": "",
        "readMask": ""
    }
    headers = {
        "Authorization": "Bearer your-access-token"
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "featurestores" in data
    assert isinstance(data["featurestores"], list)

if __name__ == "__main__":
    pytest.main()