import pytest
import requests
from requests.auth import HTTPBasicAuth
BASE_URL = "http://openapi.test"

@pytest.fixture
def get_product_status():
    def _get_product_status(merchant_id, product_id):
        url = f"{BASE_URL}/{merchant_id}/productstatuses/{product_id}"
        headers = {
            "_._xgafv": "1",  # Example value, replace with actual requirement if known
        }
        response = requests.get(url, headers=headers, verify=False)  # Disable SSL verification for local testing
        response.raise_for_status()  # Raise exception for HTTP errors
        return response.json()

    yield _get_product_status

def test_get_product_status(get_product_status):
    merchant_id = "test_merchant_id"
    product_id = "test_product_id"
    product_status = get_product_status(merchant_id, product_id)
    
    assert isinstance(product_status, dict)
    assert "creationDate" in product_status
    assert "destinationStatuses" in product_status
    assert "googleExpirationDate" in product_status
    assert "itemLevelIssues" in product_status
    assert "kind" in product_status
    assert "lastUpdateDate" in product_status
    assert "link" in product_status
    assert "productId" in product_status
    assert "title" in product_status