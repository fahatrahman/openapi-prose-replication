# -*- coding: utf-8 -*-
"""Test module for StopDiscoverer endpoint."""

import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def get_amz_date():
    """Returns the current date in Amazon signature format."""
    return datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")

@pytest.fixture
def api_key():
    """Returns a dummy AWS API key for testing purposes."""
    return "dummy_api_key"

def test_StopDiscoverer(api_key):
    """Tests the StopDiscoverer endpoint."""
    
    # Set up request headers
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "d41d8cd98f00b204e9800998ecf8427e",
        "X-Amz-Credential": f"{api_key}/20181225/eu-west-1/ec2/aws4_request",
        "X-Amz-Date": get_amz_date(),
        "X-Amz-Security-Token": "",
        "X-Amz-Signature": "1234567890abcdef",
        "X-Amz-SignedHeaders": "host;x-amz-date",
        "Authorization": "hmac"
    }
    
    # Construct the full URL
    url = f"{BASE_URL}/v1/discoverers/id/{'some_discoverer_id'}/stop"
    
    try:
        response = requests.post(url, headers=headers)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        assert False, f"Request failed with error {e}"