import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_options_events():
    url = urljoin(BASE_URL, "/events")
    headers = {}
    params = {}

    response = requests.options(url, headers=headers, params=params)

    assert response.status_code == 200
    assert response.json()["chunk_size"] > 0
    assert len(response.json()["entries"]) > 0
    for entry in response.json()["entries"]:
        assert entry["type"] == "realtime_server"
        assert isinstance(entry["max_retries"], int)
        assert isinstance(entry["retry_timeout"], int)
        assert isinstance(entry["ttl"], int)
        assert isinstance(entry["url"], str)

def test_options_events_default():
    url = urljoin(BASE_URL, "/events")
    headers = {}
    params = {"foo": "bar"}

    response = requests.options(url, headers=headers, params=params)

    assert response.status_code >= 400
    assert response.json()["type"] == "error"
    assert isinstance(response.json()["status"], int)
    assert isinstance(response.json()["message"], str)
    assert isinstance(response.json()["request_id"], str)
    assert isinstance(response.json()["help_url"], str)