import os
import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"
HEADERS = {"Content-Type": "application/json"}

def test_get_team_members():
    team_id = "your_team_id"
    auth_token = "your_auth_token"

    url = f"{BASE_URL}/v2/teams/{team_id}/members"
    response = requests.get(url, headers=HEADERS, auth=HTTPBasicAuth("Bearer", auth_token))

    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "emailInviteCodes" in response.json()
    assert "members" in response.json()
    assert isinstance(response.json()["members"], list)
    assert all(isinstance(member, dict) for member in response.json()["members"])