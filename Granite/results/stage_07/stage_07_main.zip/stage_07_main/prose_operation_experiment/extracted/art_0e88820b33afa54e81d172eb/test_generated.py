import pytest
import requests
from requests_toolbelt import MultipartEncoder

BASE_URL = "http://openapi.test"

@pytest.fixture
def test_grant_flow_entitlements():
    payload = {
        "entitlements": [
            {
                "Subscribers": ["arn:aws:iam::111122223333:root"],
                "Name": "Test Entitlement",
                "Description": "This is a test entitlement.",
                "Encryption": {
                    "Algorithm": "aes128",
                    "ConstantInitializationVector": "000112233445566778901122",
                    "DeviceId": "device-id-123",
                    "KeyType": "speke",
                    "Region": "us-east-1",
                    "ResourceId": "resource-id-456",
                    "RoleArn": "arn:aws:iam::111122223333:role/MediaConnectRole",
                    "SecretArn": "arn:aws:secretsmanager:us-east-1:111122223333:secret:my-secret-ABC123DEF",
                    "Url": "https://example.com/api",
                },
                "EntitlementStatus": "ENABLED",
            }
        ]
    }

    headers = {
        "Authorization": "hmac",
        "Content-Type": "application/json",
        # Add other headers if necessary
    }

    url = f"{BASE_URL}/v1/flows/{'some_flow_arn'}/entitlements"

    response = requests.post(url, json=payload, headers=headers)

    assert response.status_code == 200, f"Request failed with status code {response.status_code}"

    return response.json()