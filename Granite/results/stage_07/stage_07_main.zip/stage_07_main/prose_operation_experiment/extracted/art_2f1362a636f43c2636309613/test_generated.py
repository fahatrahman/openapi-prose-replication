import os
import pytest
import requests
from requests.auth import HTTPBasicAuth
BASE_URL = "http://openapi.test"

@pytest.fixture
def test_item():
    return {
        "featuredPart": True,
        "gaia": "1234567890",
        "id": "test_item_id",
        "snippet": {}
    }

def test_create_test_item(test_item):
    url = f"{BASE_URL}/youtube/v3/tests"
    headers = {"Content-Type": "application/json"}
    response = requests.post(url, json=test_item, headers=headers)

    assert response.status_code == 200
    created_test_item = response.json()
    assert all(created_test_item[k] == v for k, v in test_item.items())