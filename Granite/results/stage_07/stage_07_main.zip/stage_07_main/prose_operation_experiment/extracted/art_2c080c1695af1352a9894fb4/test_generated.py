import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Define request session with retry strategy
session = requests.Session()
retries = Retry(total=3, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
session.mount("http://", adapter)
session.mount("https://", adapter)

@pytest.fixture
def webrisk_submission():
    url = f"{BASE_URL}/v1/{parent}/submissions"
    headers = {
        "_": "1",
    }

    submission = {
        "uri": "https://example.com/malicious_file"
    }

    response = session.post(url, json=submission, headers=headers)
    response.raise_for_status()

    return response.json()