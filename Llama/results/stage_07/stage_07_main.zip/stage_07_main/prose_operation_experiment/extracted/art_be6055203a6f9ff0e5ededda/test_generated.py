# -*- coding: utf-8 -*-
"""Test suite for projects."""

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_gkehub_projects_locations_scopes_rbacrolebindings_list():
    """Tests gkehub.projects.locations.scopes.rbacrolebindings.list."""
    
    url = f"{BASE_URL}/v1/{'parent'}"
    headers = {}
    params = {
        "fields": "",
        "quotaUser": "",
        "upload_protocol": "",
        "uploadType": "",
        "$.xgafv": "1",
        "access_token": "",
        "alt": "json",
        "callback": "",
        "key": "",
        "oauth_token": "",
        "prettyPrint": "false",
        "pageSize": "10",
        "pageToken": ""
    }
    
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    