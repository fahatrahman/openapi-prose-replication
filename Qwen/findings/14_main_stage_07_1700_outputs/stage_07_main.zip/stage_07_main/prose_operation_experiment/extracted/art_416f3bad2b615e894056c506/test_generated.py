import pytest
import requests

BASE_URL = "http://openapi.test"

def test_set_line_item_metadata():
    url = f"{BASE_URL}/12345/orders/67890/setLineItemMetadata"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "lineItemId": "abc123",
        "operationId": "def456",
        "productId": "ghi789",
        "annotations": [
            {"key": "exampleKey", "value": "exampleValue"}
        ]
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert response.json()["kind"] == "content#ordersSetLineItemMetadataResponse"
    assert response.json()["executionStatus"] in ["jtfaaqohf", "icqwtmzw"]

if __name__ == "__main__":
    pytest.main()