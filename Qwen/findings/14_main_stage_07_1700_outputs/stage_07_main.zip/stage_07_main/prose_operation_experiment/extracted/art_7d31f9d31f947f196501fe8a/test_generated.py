import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_media_items_for_tag():
    tag_id = 123  # Replace with actual tag ID
    sort_param = "name"
    max_records = 10
    offset_value = 0

    url = f"{BASE_URL}/resources/tags/{tag_id}/media.json"
    params = {
        "sort": sort_param,
        "max": max_records,
        "offset": offset_value
    }

    response = requests.get(url, params=params)

    assert response.status_code == 200
    media_items = response.json()
    assert isinstance(media_items, list)
    for item in media_items:
        assert "id" in item
        assert "name" in item
        assert "description" in item
        assert "source" in item
        assert "language" in item
        assert "mediaType" in item
        assert "customAttributionUrl" in item
        assert "customPreviewUrl" in item
        assert "customThumbnailUrl" in item
        assert "dateContentAuthored" in item
        assert "dateContentPublished" in item
        assert "dateContentReviewed" in item
        assert "dateContentUpdated" in item
        assert "dateSyndicationCaptured" in item
        assert "dateSyndicationUpdated" in item
        assert "dateSyndicationVisible" in item
        assert "externalGuid" in item
        assert "foreignSyndicationAPIUrl" in item
        assert "hash" in item
        assert "createdBy" in item
        assert "sourceUrl" in item
        assert "targetUrl" in item

if __name__ == "__main__":
    pytest.main([__file__])