import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_bep20_balance():
    contract = "0x1dDB2C0897daF18632662E71fdD2dbDC0eB3a9Ec"
    token_id = "0x9dB475371B5cC2913D3219f72e16a3F101339a05"
    url = f"{BASE_URL}/v2/bsc/balances/{contract}/bep20/{token_id}"
    
    response = requests.get(url)
    
    assert response.status_code == 200
    assert response.headers["Content-Type"] == "application/json"
    assert response.json()["ok"] is True
    assert response.json()["status"] == 200
    assert isinstance(response.json()["data"]["balance"], str)

if __name__ == "__main__":
    pytest.main()