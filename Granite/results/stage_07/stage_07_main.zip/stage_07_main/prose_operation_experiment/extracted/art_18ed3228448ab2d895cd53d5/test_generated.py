import pytest
import requests
from requests.exceptions import HTTPError

BASE_URL = "http://openapi.test"
HEADERS = {"X-Api-Key": "YOUR_API_KEY"}  # Replace with your actual API key

@pytest.fixture
def boundaries_query():
    return {
        "ids": ["your_uuid_1", "your_uuid_2"]  # Replace with actual UUIDs
    }

def test_fetch_boundaries(boundaries_query):
    url = f"{BASE_URL}/v4/boundaries/query"

    try:
        response = requests.post(url, json=boundaries_query, headers=HEADERS)

        # Check if the request was successful (status code 200)
        response.raise_for_status()

        result = response.json()
        assert "features" in result
        assert "type" in result

        print("Test passed: FetchBoundariesOk")

    except HTTPError as http_err:
        print(f"HTTP error occurred: {http_err}")
    except Exception as err:
        print(f"An error occurred: {err}")