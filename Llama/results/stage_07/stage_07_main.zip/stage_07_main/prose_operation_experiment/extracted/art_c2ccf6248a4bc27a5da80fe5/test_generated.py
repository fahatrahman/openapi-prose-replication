import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_get_metrics():
    id = 12345
    type = "cpu"
    start = "2017-01-01T00:00:00+00:00"
    end = "2017-01-01T23:00:00+00:00"
    step = 60
    
    url = f"{BASE_URL}/servers/{id}/metrics?type={type}&start={start}&end={end}"
    
    if step:
        url += f"&step={step}"
        
    response = requests.get(url)
    
    assert response.status_code == 200
    
    metrics = response.json()
    
    required_fields = ["start", "end", "step", "time_series"]
    
    for field in required_fields:
        assert field in metrics["metrics"]
        
    time_series = metrics["metrics"]["time_series"]
    
    assert isinstance(time_series, dict) and "values" in time_series
    
    values = time_series["values"]
    
    assert isinstance(values, list)
    
    for value in values:
        assert len(value) == 2
        
        timestamp, metric_value = value
        
        assert isinstance(timestamp, (int, float))
        
        if isinstance(metric_value, str):
            # Assuming string values are in a specific format
            try:
                metric_value_float = float(metric_value)
            except ValueError:
                pytest.fail(f"Invalid metric value: {metric_value}")
                
            assert metric_value_float == int(metric_value)
            
            # Convert to float for further comparison
            metric_value = float(metric_value)
            
        elif isinstance(metric_value, int):
            pass
            
        else:
            pytest.fail("Invalid metric value type")
            
        # Check if metric value is within expected range
        # For simplicity, let's assume the minimum and maximum values are 0 and 100 respectively
        assert 0 <= metric_value <= 100
        
        # Check if timestamps are sorted in ascending order
        assert all(timestamp < next_timestamp for timestamp, next_timestamp in zip([timestamp] + [value[0] for value in values[:-1]], values))

def test_invalid_step():
    id = 12345
    type = "cpu"
    start = "2017-01-01T00:00:00+00:00"
    end = "2017-01-01T23:00:00+00:00"
    step = None
    
    url = f"{BASE_URL}/servers/{id}/metrics?type={type}&start={start}&end={end}"
    
    response = requests.get(url)
    
    assert response.status_code == 200
    
    metrics = response.json()
    
    assert "step" not in metrics["metrics"]

def test_invalid_start():
    id = 12345
    type = "cpu"
    start = "invalid-date"
    end = "2017-01-01T23:00:00+00:00"
    step = 60
    
    url = f"{BASE_URL}/servers/{id}/metrics?type={type}&start={start}&end={end}&step={step}"
    
    response = requests.get(url)
    
    assert response.status_code == 500
    
def test_invalid_end():
    id = 12345
    type = "cpu"
    start = "2017-01-01T00:00:00+00:00"
    end = "invalid-date"
    step = 60
    
    url = f"{BASE_URL}/servers/{id}/metrics?type={type}&start={start}&end={end}&step={step}"
    
    response = requests.get(url)
    
    assert response.status_code == 500