import pytest
import requests

BASE_URL = "http://openapi.test"

def test_convert():
    url = f"{BASE_URL}/convert"
    params = {
        "from-value": "10.95",
        "from-type": "USD",
        "to-type": "EUR"
    }
    headers = {
        "api-key": "your_api_key_here",
        "user-id": "your_user_id_here"
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 200
    data = response.json()
    assert data["valid"]
    assert data["from-value"] == "10.95"
    assert data["from-type"] == "USD"
    assert data["to-type"] == "EUR"
    assert isinstance(data["result"], str)
    assert isinstance(data["result-float"], float)

def test_convert_invalid_from_value():
    url = f"{BASE_URL}/convert"
    params = {
        "from-value": "invalid_value",
        "from-type": "USD",
        "to-type": "EUR"
    }
    headers = {
        "api-key": "your_api_key_here",
        "user-id": "your_user_id_here"
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 400
    data = response.json()
    assert data["api-error"] > 0
    assert isinstance(data["api-error-msg"], str)

def test_convert_missing_headers():
    url = f"{BASE_URL}/convert"
    params = {
        "from-value": "10.95",
        "from-type": "USD",
        "to-type": "EUR"
    }

    response = requests.get(url, params=params)

    assert response.status_code == 403
    data = response.json()
    assert data["api-error"] > 0
    assert isinstance(data["api-error-msg"], str)