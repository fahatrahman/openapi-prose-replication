import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_list_operations():
    url = urljoin(BASE_URL, "/v1/{name}/operations")
    params = {
        "name": "test-name",
        "filter": "",
        "pageSize": 10,
        "pageToken": ""
    }
    headers = {}
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert 'nextPageToken' in data
    assert isinstance(data['operations'], list)
    for op in data['operations']:
        assert isinstance(op, dict)

def test_list_operations_with_oauth():
    # To run this test with OAuth, you need to obtain an OAuth access token first.
    # You can do this by visiting https://console.cloud.google.com/apis/credentials?
    # refresh=1&project=<YOUR_PROJECT_ID> and clicking on "Create Credentials"
    # > OAuth client ID". Then, replace the <ACCESS_TOKEN> placeholder with the
    # actual access token.

    url = urljoin(BASE_URL, "/v1/{name}/operations")
    params = {
        "name": "test-name",
        "filter": "",
        "pageSize": 10,
        "pageToken": ""
    }
    headers = {
        "Authorization": "Bearer <ACCESS_TOKEN>"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert 'nextPageToken' in data
    assert isinstance(data['operations'], list)
    for op in data['operations']:
        assert isinstance(op, dict)