# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_batch_delete_printers():
    url = f"{BASE_URL}/admin/directory/v1/{parent}/chrome/printers"
    headers = {
        "Accept": "application/json",
    }
    params = {
        "_xgafv": "1",
        "access_token": None,
        "alt": "json",
        "callback": None,
        "fields": "*",
        "key": None,
        "oauth_token": None,
        "prettyPrint": "false",
        "quotaUser": None,
        "upload_protocol": "multipart",
        "uploadType": "media",
    }

    body = {
        "printerIds": ["id1", "id2"],
    }

    response = requests.post(
        url,
        headers=headers,
        params=params,
        json=body,
    )

    assert response.status_code == 200
    print(response.json())

@pytest.fixture
def parent():
    return "hwjekqwev/xmcwuopy-lg"

if __name__ == "__main__":
    pytest.main([__file__])