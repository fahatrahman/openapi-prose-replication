# pytest module generated from OpenAPI specification

import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_androidenterprise_enterprises_set_store_layout():
    enterprise_id = "your-enterprise-id"
    store_layout = {
        "homepageId": "your-homepage-id",
        "storeLayoutType": "custom"
    }

    headers = {"Content-Type": "application/json"}
    params = {
        "$.xgafv": "1",
        "access_token": None,
        "alt": None,
        "callback": None,
        "fields": None,
        "key": None,
        "oauth_token": None,
        "prettyPrint": False,
        "quotaUser": None,
        "upload_protocol": None,
        "uploadType": None
    }
    url = urljoin(BASE_URL, f"/androidenterprise/v1/enterprises/{enterprise_id}/storeLayout")

    response = requests.put(url, json=store_layout, headers=headers, params=params)

    assert response.status_code == 200
    assert response.json() == store_layout