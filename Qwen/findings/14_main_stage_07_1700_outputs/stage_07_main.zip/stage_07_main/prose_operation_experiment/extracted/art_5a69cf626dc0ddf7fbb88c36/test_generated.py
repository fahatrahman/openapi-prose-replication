import pytest
import requests

BASE_URL = "http://openapi.test"

def test_clear_location_association():
    url = f"{BASE_URL}/v4/name:clearAssociation"
    params = {
        "_xgafv": "1",
        "access_token": "test_access_token",
        "alt": "json",
        "callback": "test_callback",
        "fields": "test_fields",
        "key": "test_key",
        "oauth_token": "test_oauth_token",
        "prettyPrint": True,
        "quotaUser": "test_quota_user",
        "uploadType": "test_upload_type",
        "upload_protocol": "test_upload_protocol",
        "name": "test_name"
    }
    headers = {
        "Content-Type": "application/json"
    }
    payload = {
        "property": "value"
    }
    response = requests.post(url, params=params, headers=headers, json=payload)
    assert response.status_code == 200
    assert response.json() == {}