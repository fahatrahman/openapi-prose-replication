import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_get_report_file():
    profile_id = "12345"
    report_id = "67890"
    file_id = "abcde"
    
    params = {
        "$.xgafv": "1",
        "access_token": "",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "",
        "oauth_token": "",
        "prettyPrint": "false",
        "quotaUser": "",
        "upload_protocol": "",
        "uploadType": ""
    }
    
    headers = {}
    query_string = "&".join(f"{key}={value}" for key, value in params.items() if value)
    url = f"{BASE_URL}/userprofiles/{profile_id}/reports/{report_id}/files/{file_id}?{query_string}"
    
    try:
        response = requests.get(url, headers=headers)
        assert response.status_code == 200
        assert isinstance(response.json(), dict)
    except requests.RequestException as e:
        pytest.fail(str(e))