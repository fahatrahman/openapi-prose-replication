import os
import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def api():
    return requests.Session()

def submit_third_party(api):
    endpoint = "/submitThirdParty"
    payload = {
        "amount": {"currency": "EUR", "value": 1000},
        "dateOfBirth": "1990-01-01",
        "entityType": "Company",
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "nationality": "NL",
        "recurring": {
            "contract": "PAYOUT",
            "reference": "PayoutPayment-0001",
            "selectedRecurringDetailReference": "LATEST",
        },
        "shopperEmail": "shopper@email.com",
        "shopperName": {"firstName": "Adyen", "lastName": "Test"},
        "shopperReference": "YOUR_UNIQUE_SHOPPER_ID",
    }

    response = api.post(BASE_URL + endpoint, json=payload)
    response.raise_for_status()
    return response.json()

def test_submit_third_party(api):
    result = submit_third_party(api)
    assert result["resultCode"] == "Authorised"