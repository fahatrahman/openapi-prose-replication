import pytest
import requests

BASE_URL = "http://openapi.test"

def test_bigquery_tabledata_list():
    url = f"{BASE_URL}/projects/{pytest.project_id}/datasets/{pytest.dataset_id}/tables/{pytest.table_id}/data"
    params = {
        "access_token": pytest.access_token,
        "alt": "json",
        "maxResults": 10,
        "startIndex": 0,
        "selectedFields": "f.v"
    }
    headers = {
        "Authorization": f"Bearer {pytest.access_token}"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    assert "rows" in response.json()
    assert len(response.json()["rows"]) <= params["maxResults"]