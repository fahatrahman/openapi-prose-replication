import pytest
import requests

BASE_URL = "http://openapi.test"

def test_cancel_order():
    url = f"{BASE_URL}/orders/cancel"
    headers = {
        "Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed",
        "Authorization": "Bearer YOUR_API_KEY"
    }
    payload = {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "order": {
            "orderData": "823fh892f8f18f4...148f13f9f3f",
            "pspReference": "8815517812932012"
        }
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 200
    assert response.json()["resultCode"] == "Received"
    assert "pspReference" in response.json()

def test_cancel_order_400():
    url = f"{BASE_URL}/orders/cancel"
    headers = {
        "Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed",
        "Authorization": "Bearer YOUR_API_KEY"
    }
    payload = {
        "order": {
            "orderData": "823fh892f8f18f4...148f13f9f3f",
            "pspReference": "8815517812932012"
        }
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 400
    assert response.json()["errorCode"] == "702"

def test_cancel_order_401():
    url = f"{BASE_URL}/orders/cancel"
    headers = {
        "Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed",
        "Authorization": "Bearer INVALID_API_KEY"
    }
    payload = {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "order": {
            "orderData": "823fh892f8f18f4...148f13f9f3f",
            "pspReference": "8815517812932012"
        }
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 401
    assert response.json()["errorCode"] == "000"

def test_cancel_order_403():
    url = f"{BASE_URL}/orders/cancel"
    headers = {
        "Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed",
        "Authorization": "Bearer YOUR_API_KEY"
    }
    payload = {
        "merchantAccount": "INVALID_MERCHANT_ACCOUNT",
        "order": {
            "orderData": "823fh892f8f18f4...148f13f9f3f",
            "pspReference": "8815517812932012"
        }
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 403
    assert response.json()["errorCode"] == "901"

def test_cancel_order_422():
    url = f"{BASE_URL}/orders/cancel"
    headers = {
        "Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed",
        "Authorization": "Bearer YOUR_API_KEY"
    }
    payload = {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "order": {
            "pspReference": "8815517812932012"
        }
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 422
    assert response.json()["errorCode"] == 14030

def test_cancel_order_500():
    url = f"{BASE_URL}/orders/cancel"
    headers = {
        "Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed",
        "Authorization": "Bearer YOUR_API_KEY"
    }
    payload = {
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "order": {
            "orderData": "823fh892f8f18f4...148f13f9f3f",
            "pspReference": "INVALID_PSP_REFERENCE"
        }
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 500
    assert response.json()["errorCode"] == "905"