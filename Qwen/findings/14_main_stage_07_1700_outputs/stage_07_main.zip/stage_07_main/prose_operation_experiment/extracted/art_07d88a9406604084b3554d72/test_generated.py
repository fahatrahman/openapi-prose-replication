import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_webhooks():
    url = f"{BASE_URL}/webhooks"
    params = {
        "pretty": True,
        "fields": ["id", "name"],
        "limit": 10,
        "offset": "",
        "workspace": "1331",
        "resource": "51648"
    }
    headers = {
        "Authorization": "Bearer YOUR_PERSONAL_ACCESS_TOKEN_OR_OAUTH_TOKEN"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "data" in data
    assert isinstance(data["data"], list)
    for item in data["data"]:
        assert "gid" in item
        assert "resource_type" in item
        assert item["resource_type"] == "webhook"