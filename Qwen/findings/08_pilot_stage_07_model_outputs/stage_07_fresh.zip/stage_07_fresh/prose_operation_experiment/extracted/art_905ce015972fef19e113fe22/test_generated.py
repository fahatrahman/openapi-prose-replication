import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_image_region_proposals():
    headers = {
        "Training-Key": "{API Key}"
    }
    params = {
        "projectId": "bc3f7dad-5544-468c-8573-3ef04d55463e",
        "imageId": "4d6eb844-42ee-42bc-bd6f-c32455ef07c9"
    }
    response = requests.post(f"{BASE_URL}/{params['projectId']}/images/{params['imageId']}/regionproposals", headers=headers)
    assert response.status_code == 200
    assert response.json() == {
        "imageId": "4d6eb844-42ee-42bc-bd6f-c32455ef07c9",
        "projectId": "bc3f7dad-5544-468c-8573-3ef04d55463e",
        "proposals": [
            {
                "boundingBox": {
                    "height": 0.25,
                    "left": 0.25,
                    "top": 0.25,
                    "width": 0.25
                },
                "confidence": 0.25
            }
        ]
    }