import os
import requests
import pytest

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def setup():
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",  # Replace with your actual access token
        "Content-Type": "application/json",
    }
    return headers

def test_get_webhooks(setup):
    response = requests.get(f"{BASE_URL}/webhooks", headers=setup)

    assert response.status_code == 200, f"Received status code {response.status_code} instead of 200"
    assert isinstance(response.json(), dict), "Response body is not a dictionary"
    assert "entries" in response.json(), "Response does not contain 'entries' key"

def test_get_webhooks_with_marker_and_limit(setup):
    marker = "JV9IRGZmieiBasejOG9yDCRNgd2ymoZIbjsxbJMjIs3kioVii"
    limit = 1000

    params = {
        "marker": marker,
        "limit": limit,
    }
    response = requests.get(f"{BASE_URL}/webhooks", headers=setup, params=params)

    assert response.status_code == 200, f"Received status code {response.status_code} instead of 200"
    assert isinstance(response.json(), dict), "Response body is not a dictionary"
    assert "entries" in response.json(), "Response does not contain 'entries' key"

def test_get_webhooks_unauthorized(setup):
    headers = {"Authorization": ""}  # Remove or modify authorization header to simulate unauthorized request

    response = requests.get(f"{BASE_URL}/webhooks", headers=headers)

    assert response.status_code == 403, f"Received status code {response.status_code} instead of 403"
    assert isinstance(response.json(), dict), "Response body is not a dictionary"
    assert response.json()["type"] == "error", "Response type is not 'error'"