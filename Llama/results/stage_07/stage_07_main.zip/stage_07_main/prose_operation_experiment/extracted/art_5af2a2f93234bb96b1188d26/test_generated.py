# -*- coding: utf-8 -*-
import pytest
import requests
from uuid import UUID

BASE_URL = "http://openapi.test"

def test_get_asset():
    asset_id = UUID('e77602e0-3fb8-4734-aef9-fbc6fdcb0fa8')
    response = requests.get(f"{BASE_URL}/org/assets/{asset_id}", headers={'Authorization': f'Bearer {""}'})
    assert response.status_code == 200
    assert response.json()['type'] == 'Server'

def test_get_asset_not_found():
    asset_id = UUID('12345678-1234-1234-1234-123456789012')
    response = requests.get(f"{BASE_URL}/org/assets/{asset_id}")
    assert response.status_code == 404

def test_get_asset_unauthorized():
    asset_id = UUID('e77602e0-3fb8-4734-aef9-fbc6fdcb0fa8')
    response = requests.get(f"{BASE_URL}/org/assets/{asset_id}", headers={'Authorization': f'Bearer invalid_token'})
    assert response.status_code == 401