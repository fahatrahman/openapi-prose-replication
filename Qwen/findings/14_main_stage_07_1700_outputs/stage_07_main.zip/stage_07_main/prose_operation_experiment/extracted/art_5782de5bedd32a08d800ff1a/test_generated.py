import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_journal_expression_schema():
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    response = requests.get(f"{BASE_URL}/ReferenceData/JournalExpressionDataTable", headers=headers)
    
    assert response.status_code == 200
    assert "JournalExpressionDataTable" in response.json()

def test_get_journal_expression_schema_400():
    headers = {
        "Authorization": "Invalid",
        "Api-Version": "default"
    }
    response = requests.get(f"{BASE_URL}/ReferenceData/JournalExpressionDataTable", headers=headers)
    
    assert response.status_code == 400
    assert "ErrorModel" in response.json()
    assert "BadRequest" in response.json()["ErrorCategory"]

def test_get_journal_expression_schema_401():
    headers = {
        "Authorization": "",
        "Api-Version": "default"
    }
    response = requests.get(f"{BASE_URL}/ReferenceData/JournalExpressionDataTable", headers=headers)
    
    assert response.status_code == 401
    assert "ErrorModel" in response.json()
    assert "NotAuthorised" in response.json()["ErrorCategory"]

def test_get_journal_expression_schema_404():
    headers = {
        "Authorization": "Auto",
        "Api-Version": "nonexistent"
    }
    response = requests.get(f"{BASE_URL}/ReferenceData/JournalExpressionDataTable", headers=headers)
    
    assert response.status_code == 404
    assert "ErrorModel" in response.json()
    assert "NotFound" in response.json()["ErrorCategory"]

def test_get_journal_expression_schema_500():
    # This test assumes there is some way to trigger a server error
    # For example, by modifying the API to return an internal server error intentionally
    pass

if __name__ == "__main__":
    pytest.main()