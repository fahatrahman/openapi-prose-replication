import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_an_external_account():
    headers = {
        'Authorization': 'Bearer your_access_token_here',
        'Content-Type': 'application/json'
    }
    payload = {
        "account_number": "987654321",
        "description": "Landlord",
        "routing_number": "101050001"
    }
    response = requests.post(f"{BASE_URL}/external_accounts", headers=headers, json=payload)
    
    assert response.status_code == 200
    assert 'external_account' in response.json()
    external_account = response.json()['external_account']
    assert 'id' in external_account
    assert 'created_at' in external_account
    assert 'description' in external_account
    assert 'status' in external_account
    assert 'routing_number' in external_account
    assert 'account_number' in external_account
    assert 'funding' in external_account
    assert 'verification_status' in external_account
    assert 'type' in external_account
    assert external_account['type'] == 'external_account'

def test_create_an_external_account_with_invalid_params():
    headers = {
        'Authorization': 'Bearer your_access_token_here',
        'Content-Type': 'application/json'
    }
    payload = {
        "account_number": "123",
        "description": "",
        "routing_number": "101050001"
    }
    response = requests.post(f"{BASE_URL}/external_accounts", headers=headers, json=payload)
    
    assert response.status_code == 400
    error = response.json()
    assert 'errors' in error
    assert len(error['errors']) > 0

def test_create_an_external_account_without_auth():
    headers = {}
    payload = {
        "account_number": "987654321",
        "description": "Landlord",
        "routing_number": "101050001"
    }
    response = requests.post(f"{BASE_URL}/external_accounts", headers=headers, json=payload)
    
    assert response.status_code == 401

if __name__ == "__main__":
    pytest.main()