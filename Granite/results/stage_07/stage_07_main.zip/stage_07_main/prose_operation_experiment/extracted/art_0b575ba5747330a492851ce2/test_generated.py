import os
import requests
import pytest

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def api_client():
    client_id = os.environ["CLIENT_ID"]
    secret = os.environ["API_SECRET"]

    headers = {
        "Plaid-Client-ID": client_id,
        "Plaid-Version": "2021-09-20",
        "Content-Type": "application/json",
    }

    return requests.Session(), headers

def test_transfer_refund_get(api_client):
    session, headers = api_client
    refund_id = "some_refund_id"

    transfer_refund_get_endpoint = f"{BASE_URL}/transfer/refund/get"
    payload = {"refund_id": refund_id}

    response = session.post(transfer_refund_get_endpoint, json=payload, headers=headers)

    assert response.status_code == 200, response.text
    assert "refund" in response.json()
    assert "request_id" in response.json()