import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_skill_related_jobs():
    skill_id = "example-skill-id"
    url = f"{BASE_URL}/skills/{skill_id}/related_jobs"
    
    response = requests.get(url)
    
    assert response.status_code == 200
    assert "application/json" in response.headers["Content-Type"]
    assert "jobs" in response.json()
    assert isinstance(response.json()["jobs"], list)

def test_get_skill_related_jobs_error():
    invalid_skill_id = "invalid-skill-id"
    url = f"{BASE_URL}/skills/{invalid_skill_id}/related_jobs"
    
    response = requests.get(url)
    
    assert response.status_code != 200
    assert "application/json" in response.headers["Content-Type"]
    assert "error" in response.json()

if __name__ == "__main__":
    pytest.main()