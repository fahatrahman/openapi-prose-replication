import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retries
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('https://', adapter)
session.mount('http://', adapter)

@pytest.fixture
def hmac_auth():
    # Replace with actual HMAC authentication details
    access_key = 'YOUR_ACCESS_KEY'
    secret_key = 'YOUR_SECRET_KEY'

    def authenticate(request):
        request.headers["Authorization"] = f"AWS4-HMAC-SHA256 Credential={access_key}/{date}/amazonaws/com/sns/default/SNS/default, SignedHeaders={request.headers['signed-headers']}, Signature={generate_signature(request)}"
        return request

    def generate_signature(request):
        # Implement signature generation logic here
        pass

    return authenticate

def test_delete_vod_source(open_connection):
    url = f"{BASE_URL}/sourceLocation/{source_location_name}/vodSource/{vod_source_name}"
    headers = {"X-Amz-Algorithm": "AWS4-HMAC-SHA256",
               "X-Amz-Content-Sha256": "YOUR_CONTENT_SHA256",
               "X-Amz-Date": "YOUR_DATE",
               "X-Amz-Credential": f"YOUR_CREDENTIALS",
               "X-Amz-Security-Token": "YOUR_SECURITY_TOKEN",
               "X-Amz-Signature": "YOUR_SIGNATURE",
               "X-Amz-SignedHeaders": "content-sha256;host;x-amz-algorithm;x-amz-credential;x-amz-date;x-amz-security-token;x-amz-signature",
               }
    
    response = requests.delete(url, headers=headers, verify=False, auth=hmac_auth())
    assert response.status_code == 200