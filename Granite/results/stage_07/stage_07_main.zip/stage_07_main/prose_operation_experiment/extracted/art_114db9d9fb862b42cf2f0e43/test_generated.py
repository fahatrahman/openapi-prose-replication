import pytest
import requests

BASE_URL = "http://openapi.test"

def test_convert():
    url = f"{BASE_URL}/convert"

    headers = {
        "api-key": "YOUR_API_KEY",
        "user-id": "YOUR_USER_ID",
    }

    querystring = {
        "from-value": "10.95",
        "from-type": "USD",
        "to-type": "EUR",
    }

    response = requests.request("GET", url, headers=headers, params=querystring)

    assert response.status_code == 200
    convert_response = response.json()

    assert convert_response["valid"] is True
    assert convert_response["result"] == "10.95 EUR"
    assert convert_response["result_float"] == 10.95
    assert convert_response["from_type"] == "USD"
    assert convert_response["from_value"] == "10.95"
    assert convert_response["to_type"] == "EUR"