import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_games_management_applications_list_hidden():
    application_id = "example_application_id"
    max_results = 10
    page_token = None

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json"
    }

    params = {
        "$.xgafv": "1",
        "access_token": "example_access_token",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "example_key",
        "oauth_token": "",
        "prettyPrint": "false",
        "quotaUser": "example_quota_user",
        "upload_protocol": "multipart",
        "uploadType": "media",
        "applicationId": application_id,
        "maxResults": max_results,
        "pageToken": page_token
    }

    response = requests.get(
        urljoin(BASE_URL, "/games/v1/management/applications/{}/players/hidden".format(application_id)),
        headers=headers,
        params=params
    )

    assert response.status_code == 200
    assert response.json()["kind"] == "games#hiddenPlayerList"