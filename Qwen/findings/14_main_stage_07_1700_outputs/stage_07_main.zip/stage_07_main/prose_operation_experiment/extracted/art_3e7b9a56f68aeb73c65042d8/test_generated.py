import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_dynamic_targeting_keys():
    url = f"{BASE_URL}/userprofiles/{profileId}/dynamicTargetingKeys"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token_here",
        "alt": "json",
        "callback": "your_callback_here",
        "fields": "dynamicTargetingKeys,name",
        "key": "your_key_here",
        "oauth_token": "your_oauth_token_here",
        "prettyPrint": False,
        "quotaUser": "your_quota_user_here",
        "uploadType": "multipart",
        "upload_protocol": "raw",
        "profileId": "your_profile_id_here",
        "advertiserId": "your_advertiser_id_here",
        "names": ["name1", "name2"],
        "objectId": "your_object_id_here",
        "objectType": "OBJECT_AD"
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "dynamicTargetingKeys" in response.json()
    assert "name" in response.json()

if __name__ == "__main__":
    pytest.main()