import os
import pytest
import requests
BASE_URL = "http://openapi.test"

@pytest.fixture
def client():
    return requests.Session()

def test_request_application_export(client):
    application_id = "example_app_id"
    response = client.post(
        f"{BASE_URL}/api/v2/application/{application_id}/request-export",
        params={
            "format": "csv",
            "roundType": "Current",
        },
    )

    assert response.status_code == 202

    result = response.json()
    assert "message" in result
    assert "submissions" in result
    assert "token" in result