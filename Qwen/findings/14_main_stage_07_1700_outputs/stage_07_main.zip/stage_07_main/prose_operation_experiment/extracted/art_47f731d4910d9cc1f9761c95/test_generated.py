import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_simulation_applications():
    url = f"{BASE_URL}/listSimulationApplications"
    headers = {
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Date": "20230401T120000Z",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20230401/us-east-1/sts/aws4_request",
        "X-Amz-Security-Token": "AQoDYXdzEPT//////////wEXAMPLEn8E5O4YbPbUZkugqBHAGKt7WqM1rUMSNHppvm4B7iaZLlJssVqbi9AWIaGm/JyxkTYQHFDtwR72scQZuwqrCSPYqyu4w/BzKa8hNFnzlcbuVGXsy8Igwt3Xk0XOcbInIN+v5DQTL3Sjbv0Fy3fF+uQbKsIjgBhg0+FqX8p8R0cQ==",
        "X-Amz-SignedHeaders": "host;x-amz-algorithm;x-amz-content-sha256;x-amz-credential;x-amz-date;x-amz-security-token;x-amz-signedheaders"
    }
    params = {
        "maxResults": 10,
        "nextToken": None,
        "versionQualifier": "ALL"
    }
    response = requests.post(url, headers=headers, json=params)
    assert response.status_code == 200
    assert "simulationApplicationSummaries" in response.json()
    assert isinstance(response.json()["simulationApplicationSummaries"], list)

if __name__ == "__main__":
    pytest.main([__file__])