import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_FILE = "credentials.json"

@pytest.fixture
def auth():
    credentials = service_account.Credentials.from_service_account_file(CREDENTIALS_FILE)
    return requests.AuthBase(requests.HTTPBasicAuth(*credentials.access_token))

def test_list_feature_online_stores(auth):
    path_params = {"parent": "projects/my-project/locations/us-central1"}
    query_params = {
        "filter": "create_time > \"2020-01-01\"",
        "orderBy": "create_time desc",
        "pageSize": 10,
        "pageToken": "some_page_token"
    }

    url = f"{BASE_URL}/{path_params['parent']}/featureOnlineStores"
    headers = {"Authorization": f"Bearer {auth.access_token}"}

    response = requests.get(url, headers=headers, params=query_params)
    assert response.status_code == 200

    # Assuming response contains featureOnlineStores field
    feature_online_stores = response.json()["featureOnlineStores"]
    assert len(feature_online_stores) <= query_params["pageSize"]
    assert "nextPageToken" in response.json() if len(feature_online_stores) == query_params["pageSize"] else False