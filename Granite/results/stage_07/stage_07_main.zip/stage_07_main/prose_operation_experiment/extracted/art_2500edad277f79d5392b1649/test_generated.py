import pytest
import requests
from requests.exceptions import HTTPError

BASE_URL = "http://openapi.test"

def test_get_tag_from_pay_schedule():
    employer_id = "ER001"
    pay_schedule_id = "SCH001"
    tag_id = "MyTag"
    authorization = "Auto"
    api_version = "default"

    url = f"{BASE_URL}/Employer/{employer_id}/PaySchedule/{pay_schedule_id}/Tag/{tag_id}"

    headers = {
        "Authorization": authorization,
        "Api-Version": api_version,
    }

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        tag = response.json()
        assert isinstance(tag, dict)
        assert all(key in tag for key in ("Text",))
    else:
        error_model = response.json()
        assert response.status_code == 400 or response.status_code == 401 \
                   or response.status_code == 404 or response.status_code == 500
        assert isinstance(error_model, dict)
        assert all(key in error_model for key in ("Description", "ErrorCategory", "Errors"))