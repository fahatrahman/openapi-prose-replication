# -*- coding: utf-8 -*-
"""Tests for Operation Slice."""

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_networkservices_projects_locations_list():
    """Test network services projects locations list."""
    
    url = f"{BASE_URL}/v1/{'test-project'}/locations"
    params = {
        'prettyPrint': False,
        'quotaUser': '',
        'oauth_token': '',
        'fields': '*',
        'uploadType': 'media',
        'upload_protocol': 'resumable',
        '_xgafv': '1'
    }
    headers = {}
    
    response = requests.get(url, params=params, headers=headers)
    
    assert response.status_code == 200
    
    # Check if ListLocationsResponse schema is valid
    response_json = response.json()
    assert isinstance(response_json, dict)
    assert 'locations' in response_json
    assert isinstance(response_json['locations'], list)
    
    for location in response_json['locations']:
        assert isinstance(location, dict)
        assert 'displayName' in location
        assert isinstance(location['displayName'], str)
        
        assert 'labels' in location
        assert isinstance(location['labels'], dict)
        
        assert 'locationId' in location
        assert isinstance(location['locationId'], str)
        
        assert 'metadata' in location
        assert isinstance(location['metadata'], dict)
        
        assert 'name' in location
        assert isinstance(location['name'], str)
