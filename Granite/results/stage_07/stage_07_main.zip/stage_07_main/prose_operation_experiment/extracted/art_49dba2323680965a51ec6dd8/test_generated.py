import pytest
import requests
BASE_URL = "http://openapi.test"

@pytest.fixture
def test_target_ids():
    return ["id1", "id2"]

def test_archive_targets(test_target_ids):
    url = f"{BASE_URL}/targets/archived/"
    headers = {"Authorization": "Bearer JWT_TOKEN", "Content-Type": "application/json"}
    response = requests.post(url, json={"targetIds": test_target_ids}, headers=headers)

    assert response.status_code == 200, f"Received status code {response.status_code} instead of 200"
    
    result = response.json()
    assert "length" in result, f"Missing 'length' key in response"
    assert "page" in result, f"Missing 'page' key in response"
    assert "page_total" in result, f"Missing 'page_total' key in response"
    assert "pagination_count" in result, f"Missing 'pagination_count' key in response"
    assert "results" in result, f"Missing 'results' key in response"

    for target in result["results"]:
        assert "changed" in target, f"Missing 'changed' field in target"
        assert "changed_by" in target, f"Missing 'changed_by' field in target"
        assert "cookies" in target, f"Missing 'cookies' field in target"
        assert "desc" in target, f"Missing 'desc' field in target"
        assert "headers" in target, f"Missing 'headers' field in target"
        assert "host" in target, f"Missing 'host' field in target"
        assert "id" in target, f"Missing 'id' field in target"
        assert "include" in target, f"Missing 'include' field in target"
        assert "name" in target, f"Missing 'name' field in target"
        assert "report_type" in target, f"Missing 'report_type' field in target"
        assert "scan_profile" in target, f"Missing 'scan_profile' field in target"
        assert "site" in target, f"Missing 'site' field in target"
        assert "type" in target, f"Missing 'type' field in target"