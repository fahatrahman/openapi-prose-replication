# -*- coding: utf-8 -*-

import pytest
import requests
from typing import Dict

BASE_URL = "http://openapi.test"

def test_get_nh_interior():
    api_key = "your_api_key_here"
    accept_version = "1.0.0"
    color = ["White", "Colorful"]
    thumbsize = 1

    headers = {
        'X-API-KEY': api_key,
        'Accept-Version': accept_version
    }

    params = {
        'color': color,
        'thumbsize': thumbsize
    }

    response = requests.get(
        f"{BASE_URL}/nh/interior/{'Abstract Wall'}",
        headers=headers,
        params=params
    )

    assert response.status_code == 200

    try:
        response.raise_for_status()
    except requests.RequestException as err:
        pytest.fail(f"Request failed: {err}")

    data: Dict[str, str] = response.json()

    assert isinstance(data['availability'], list)
    assert len(data['availability']) > 0
    assert isinstance(data['availability'][0], dict)

    assert isinstance(data['buy'], list)
    assert len(data['buy']) > 0
    assert isinstance(data['buy'][0], dict)

    assert isinstance(data['category'], str)
    assert data['category'] in ['Floors', 'Wallpaper', 'Rugs']

    assert isinstance(data['colors'], list)
    assert len(data['colors']) > 0
    assert isinstance(data['colors'][0], str)

    assert isinstance(data['grid_length'], float)
    assert data['grid_length'] >= 0

    assert isinstance(data['grid_width'], float)
    assert data['grid_width'] >= 0

    assert isinstance(data['hha_base'], int)
    assert data['hha_base'] >= 0

    assert isinstance(data['hha_category'], str)

    assert isinstance(data['image_url'], str)

    assert isinstance(data['item_series'], str)

    assert isinstance(data['item_set'], str)

    assert isinstance(data['name'], str)

    assert isinstance(data['notes'], str)

    assert isinstance(data['sell'], int)
    assert data['sell'] >= 0

    assert isinstance(data['tag'], str)

    assert isinstance(data['themes'], list)
    assert len(data['themes']) > 0
    assert isinstance(data['themes'][0], str)

    assert isinstance(data['unlocked'], bool)

    assert isinstance(data['url'], str)

    assert isinstance(data['version_added'], str)