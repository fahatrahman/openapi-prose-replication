import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_sip_rule():
    sip_rule_id = "example-sip-rule-id"
    headers = {
        "X-Amz-Content-Sha256": "example-content-sha256",
        "X-Amz-Date": "example-date",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "example-credential",
        "X-Amz-Security-Token": "example-security-token",
        "X-Amz-Signature": "example-signature",
        "X-Amz-SignedHeaders": "example-signed-headers"
    }
    response = requests.get(f"{BASE_URL}/sip-rules/{sip_rule_id}", headers=headers)
    assert response.status_code == 200
    assert "SipRule" in response.json()