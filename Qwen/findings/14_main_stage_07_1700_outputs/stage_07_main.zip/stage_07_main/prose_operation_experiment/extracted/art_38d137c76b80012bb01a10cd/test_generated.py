import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_target_project():
    url = f"{BASE_URL}/v1alpha1/projects/global/targetProjects/example"
    params = {
        "requestId": "12345678-1234-1234-1234-1234567890ab",
        "_xgafv": "2",
        "access_token": "your_access_token",
        "alt": "json",
        "callback": "callback_function",
        "fields": "name,status",
        "key": "your_api_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": True,
        "quotaUser": "user@example.com",
        "uploadType": "media",
        "upload_protocol": "raw"
    }
    headers = {
        "Authorization": "Bearer your_access_token"
    }
    response = requests.delete(url, params=params, headers=headers)
    assert response.status_code == 200
    assert response.json()["done"] is False or response.json()["done"] is True
    if response.json()["done"]:
        assert "error" in response.json() or "response" in response.json()