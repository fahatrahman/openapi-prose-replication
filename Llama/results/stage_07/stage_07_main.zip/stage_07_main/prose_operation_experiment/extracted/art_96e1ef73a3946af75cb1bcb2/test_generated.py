# -*- coding: utf-8 -*-
"""Test the Erc20 transfer endpoint."""

import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_transfer_tokens():
    """Test transferring tokens."""
    
    address = "0x1234567890123456789012345678901234567890"
    url = urljoin(BASE_URL, f"/erc20/{address}")
    headers = {"Content-Type": "application/json"}
    
    response = requests.post(url, headers=headers)
    assert response.status_code == 200
    
def test_empty_response():
    """Test if empty response is returned correctly."""
    
    # The response schema is defined as Empty which means it's expected to be empty
    pass  # No need for assertions here