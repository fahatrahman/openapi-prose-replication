import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retry mechanism for handling transient errors
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

@pytest.fixture
def maintenance_issue():
    return {
        "Documents": [
            {
                "MimeType": "text/plain",
                "URL": "https://example.com/document1.txt"
            }
        ],
        "ExternalID": "EXT-12345",
        "IssueFault": "Mechanical failure",
        "IssueNotes": "Detailed description of the issue.",
        "IssuePriority": "High",
        "IssueTitle": "Urgent HVAC repair needed",
        "PropertyAddress1": "123 Main St",
        "PropertyAddress2": "",
        "PropertyAddress3": "",
        "PropertyAddress4": "",
        "PropertyCountry": "USA",
        "PropertyPostcode": "12345",
        "ReportedAt": "2022-01-01T12:00:00Z",
        "TenantEMailAddress": "tenant@example.com",
        "TenantForename": "John",
        "TenantPhonePrimary": "555-1234",
        "TenantPhoneSecondary": "",
        "TenantPresenceRequested": True,
        "TenantSurname": "Doe",
        "TenantTitle": "Mr."
    }

def test_create_maintenance_job(maintenance_issue):
    url = f"{BASE_URL}/v3/maintenance/shortName/maintenance/branchID/createmaintenancejob"

    response = session.post(url, json=maintenance_issue)
    assert response.status_code == 200

    # Assuming the response object has a method called get_data(), which returns the JSON content
    result = response.get_data()
    assert isinstance(result, dict)