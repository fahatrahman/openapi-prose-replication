import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retry strategy
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

def test_get_orders_status_sent():
    headers = {"authorization": "Bearer your_token"}
    offset = 0
    limit = 10

    url = f"{BASE_URL}/orders/status/sent"
    response = session.get(url, headers=headers, params={"offset": offset, "limit": limit})

    assert response.status_code == 200
    data = response.json()
    # Add assertions based on expected GetOrders schema here
    assert isinstance(data, dict)
    assert "metadata" in data
    assert "orders" in data