import os
import pytest
import requests
from googleapiclient.discovery import build

BASE_URL = "http://openapi.test"

@pytest.fixture
def service():
    """Create authenticated Admin Directory service."""
    api_service_name = "admin"
    api_version = "directory_v1"
    scopes = [
        "https://www.googleapis.com/auth/admin.directory.rolemanagement",
    ]

    credentials = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
    if credentials:
        delegated_credentials = requests.Authorizer(
            tokenurl="https://accounts.google.com/o/oauth2/token",
            scope=" ".join(scopes),
            credentials=credentials,
            client_id=None,
            client_secret=None,
            refresh_token=None,
            audience="https://accounts.google.com/o",
            redirect_uri=None,
        )
        return build(api_service_name, api_version, authorizer=delegated_credentials)
    else:
        raise ValueError("Missing GOOGLE_APPLICATION_CREDENTIALS environment variable.")

def test_update_role(service):
    """Test updating a role in Admin Directory."""
    customer = "your_customer"
    role_id = "your_role_id"

    body = {
        "roleDescription": "Updated role description.",
        "roleName": "Updated Role Name",
        "rolePrivileges": [
            {"privilegeName": "privilege_example", "serviceId": "service_example"}
        ],
    }

    response = service.roles().update(customer=customer, roleId=role_id, body=body).execute()

    assert response["roleDescription"] == "Updated role description."
    assert response["roleName"] == "Updated Role Name"
    assert len(response["rolePrivileges"]) == 1
    assert response["rolePrivileges"][0]["privilegeName"] == "privilege_example"
    assert response["rolePrivileges"][0]["serviceId"] == "service_example"