# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_complete_query():
    url = f"{BASE_URL}/v3p1beta1/projects/api-test-project:complete"
    params = {
        '$.xgafv': '1',
        'access_token': '',
        'alt': 'json',
        'callback': '',
        'fields': '',
        'key': '',
        'oauth_token': '',
        'prettyPrint': 'false',
        'quotaUser': '',
        'upload_protocol': '',
        'uploadType': '',
        'name': 'projects/api-test-project',
        'companyName': '',
        'languageCode': '',
        'languageCodes': [],
        'pageSize': 10,
        'query': 'test',
        'scope': 'PUBLIC',
        'type': 'COMBINED'
    }
    headers = {}
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200