# pylint: disable=unused-import
import pytest
import requests

BASE_URL = "http://openapi.test"

def test_post_files_id_metadata_enterprise_securityClassification_6VMVochwUWo():
    url = f"{BASE_URL}/files/{'12345'}/metadata/enterprise/securityClassification-6VMVochwUWo"
    headers = {'Content-Type': 'application/json'}
    payload = {"Box__Security__Classification__Key": "Sensitive"}
    
    response = requests.post(url, headers=headers, json=payload)
    
    assert response.status_code == 201
    assert response.json()["$type"] == "securityClassification-6VMVochwUWo-fd31537a-0f95-4d86-9f2b-5974a29978f8"
    assert response.json()["$scope"] == "enterprise_27335"
    assert response.json()["$template"] == "securityClassification-6VMVochwUWo"
    assert response.json()["$typeVersion"] == 5
    assert response.json()["$version"] == 1
    assert response.json()["Box__Security__Classification__Key"] == "Sensitive"

def test_post_files_id_metadata_enterprise_securityClassification_6VMVochwUWo_with_invalid_payload():
    url = f"{BASE_URL}/files/{'12345'}/metadata/enterprise/securityClassification-6VMVochwUWo"
    headers = {'Content-Type': 'application/json'}
    payload = {}
    
    response = requests.post(url, headers=headers, json=payload)
    
    assert response.status_code == 400
    
def test_post_files_id_metadata_enterprise_securityClassification_6VMVochwUWo_file_not_found():
    url = f"{BASE_URL}/files/{'non_existent_file_id'}/metadata/enterprise/securityClassification-6VMVochwUWo"
    headers = {'Content-Type': 'application/json'}
    payload = {"Box__Security__Classification__Key": "Sensitive"}
    
    response = requests.post(url, headers=headers, json=payload)
    
    assert response.status_code == 404
    
def test_post_files_id_metadata_enterprise_securityClassification_6VMVochwUWo_instance_already_exists():
    url = f"{BASE_URL}/files/{'12345'}/metadata/enterprise/securityClassification-6VMVochwUWo"
    headers = {'Content-Type': 'application/json'}
    payload = {"Box__Security__Classification__Key": "Sensitive"}
    
    # Simulate existing instance
    previous_response = requests.post(url, headers=headers, json=payload)
    
    response = requests.post(url, headers=headers, json=payload)
    
    assert response.status_code == 409