import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_item():
    url = f"{BASE_URL}/v1/indexing/{datasource_id}/items/{item_id}"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token",
        "alt": "json",
        "callback": "your_callback",
        "fields": "your_fields",
        "key": "your_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": False,
        "quotaUser": "your_quota_user",
        "uploadType": "your_upload_type",
        "upload_protocol": "your_upload_protocol",
        "connectorName": "your_connector_name",
        "debugOptions.enableDebugging": True,
        "mode": "SYNCHRONOUS",
        "version": "your_version"
    }
    headers = {
        "Authorization": "Bearer your_bearer_token"
    }
    response = requests.delete(url, params=params, headers=headers)
    assert response.status_code == 200
    assert response.json().get("done") is True