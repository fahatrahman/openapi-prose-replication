import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def headers():
    return {
        "X-API-Token": "your_api_token_here"
    }

def test_teams_getTeam(headers):
    org_name = "example_org"
    team_name = "example_team"
    url = f"{BASE_URL}/v0.1/orgs/{org_name}/teams/{team_name}"
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    data = response.json()
    assert "id" in data
    assert "name" in data
    assert "display_name" in data
    assert "description" in data

def test_teams_getTeam_not_found(headers):
    org_name = "nonexistent_org"
    team_name = "nonexistent_team"
    url = f"{BASE_URL}/v0.1/orgs/{org_name}/teams/{team_name}"
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 404
    error_data = response.json()
    assert "error" in error_data
    assert "code" in error_data["error"]
    assert error_data["error"]["code"] == "NotFound"
    assert "message" in error_data["error"]