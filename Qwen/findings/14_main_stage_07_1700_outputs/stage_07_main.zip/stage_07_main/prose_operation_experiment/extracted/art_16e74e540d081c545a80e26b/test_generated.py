import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_simulation_applications():
    url = f"{BASE_URL}/listSimulationApplications"
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "YOUR_CREDENTIALS",
        "X-Amz-Date": "YOUR_DATE",
        "X-Amz-Security-Token": "YOUR_SECURITY_TOKEN",
        "X-Amz-Signature": "YOUR_SIGNATURE",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-algorithm;x-amz-credential;x-amz-security-token;x-amz-signedheaders"
    }
    params = {
        "maxResults": "10",
        "nextToken": ""
    }
    payload = {
        "filters": [
            {
                "name": "exampleFilterName",
                "values": ["value1", "value2"]
            }
        ],
        "maxResults": 10,
        "nextToken": "",
        "versionQualifier": "ALL"
    }
    response = requests.post(url, headers=headers, params=params, json=payload)
    
    assert response.status_code == 200
    assert "simulationApplicationSummaries" in response.json()