# -*- coding: utf-8 -*-
"""Tests for Operation slice API."""

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_areas():
    """Test getting a collection of all areas for a company."""
    url = f"{BASE_URL}/v2/tier1/{'test_short_name'}/area/areas"
    params = {"offset": 0, "count": 10}
    response = requests.get(url, params=params)
    assert response.status_code == 200
    assert response.headers["Content-Type"].startswith("application/")
    result = response.json()
    assert isinstance(result, dict)
    assert "Count" in result
    assert "Data" in result
    assert isinstance(result["Count"], int)
    assert isinstance(result["Data"], list)

if __name__ == "__main__":
    pytest.main([__file__])