import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_endpoints():
    params = {"openapi": True}
    response = requests.get(f"{BASE_URL}/", params=params)
    assert response.status_code == 200
    endpoint_data = response.json()
    assert isinstance(endpoint_data, dict)
    assert "methods" in endpoint_data and isinstance(endpoint_data["methods"], list)
    assert "path" in endpoint_data and isinstance(endpoint_data["path"], str)

if __name__ == "__main__":
    pytest.main()