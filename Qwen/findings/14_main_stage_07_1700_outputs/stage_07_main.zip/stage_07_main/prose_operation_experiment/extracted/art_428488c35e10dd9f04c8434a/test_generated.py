import pytest
import requests

BASE_URL = "http://openapi.test"

def test_batter_vs_pitcher_stats():
    url = f"{BASE_URL}/JSON/HitterVsPitcher/10000031/10000618"
    headers = {
        "Ocp-Apim-Subscription-Key": "your_subscription_key_here"
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert isinstance(response.json(), list)
    assert all(isinstance(item, dict) for item in response.json())
    assert 'AtBats' in response.json()[0]
    assert 'AuctionValue' in response.json()[0]
    # Add more assertions based on expected schema properties

if __name__ == "__main__":
    pytest.main()