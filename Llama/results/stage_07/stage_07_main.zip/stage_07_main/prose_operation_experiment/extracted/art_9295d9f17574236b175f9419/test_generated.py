# -*- coding: utf-8 -*-

import pytest
import requests
from typing import Dict, List

BASE_URL = "http://openapi.test"

def test_get_list_users():
    headers = {
        "Content-Type": "application/json"
    }
    params = {
        "numItems": 10,
        "pageNumber": 1,
        "sort": "name",
        "sortType": "ASC"
    }

    response = requests.get(
        f"{BASE_URL}/api/license-manager/site/pvt/logins/list/paged",
        headers=headers,
        params=params
    )

    assert response.status_code == 200

    data: Dict[str, List[Dict]] = response.json()
    items = data["items"]
    paging = data["paging"]

    assert len(items) > 0
    assert isinstance(paging, dict)
    assert "page" in paging
    assert "pages" in paging
    assert "perPage" in paging
    assert "total" in paging