import pytest
import requests

BASE_URL = "http://openapi.test"

def test_update_glossary_entry():
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    url = f"{BASE_URL}/v3/projects/your-project-id/locations/your-location/glossaries/your-glossary-id/glossaryEntries/your-entry-id"
    payload = {
        "displayName": "Updated Display Name",
        "inputConfig": {
            "gcsSource": {
                "uri": "gs://your-bucket/path/to/input.json"
            }
        }
    }
    params = {
        "updateMask": "display_name,input_config"
    }

    response = requests.patch(url, json=payload, headers=headers, params=params)

    assert response.status_code == 200
    assert response.json()["displayName"] == "Updated Display Name"