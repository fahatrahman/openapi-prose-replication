# -*- coding: utf-8 -*-
"""Tests for Authorization Codes."""

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_authorization_codes_post():
    """Test POST /api/v2/AuthorizationCodes."""
    url = f"{BASE_URL}/api/v2/AuthorizationCodes"
    headers = {"Content-Type": "application/json"}
    params = {
        "Name": "Parameter Name",
        "Value": "Parameter Value"
    }
    response = requests.post(url, headers=headers, json=params)
    assert response.status_code == 200
    assert isinstance(response.json(), int)

def test_authorization_codes_post_invalid():
    """Test POST /api/v2/AuthorizationCodes with invalid request body."""
    url = f"{BASE_URL}/api/v2/AuthorizationCodes"
    headers = {"Content-Type": "application/json"}
    params = {}
    response = requests.post(url, headers=headers, json=params)
    assert response.status_code != 200
    assert isinstance(response.json().ErrorCode, int)