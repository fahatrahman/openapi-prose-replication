import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_diary_allocation():
    short_name = "example_short_name"
    diary_allocation_id = "example_diary_allocation_id"
    url = f"{BASE_URL}/v2/tier1/{short_name}/diary/allocations/{diary_allocation_id}"
    
    response = requests.get(url)
    
    assert response.status_code == 200
    assert "Content-Type" in response.headers
    content_type = response.headers["Content-Type"]
    assert content_type.startswith("application/")
    
    if "json" in content_type:
        data = response.json()
        assert isinstance(data, dict)
        assert "AppointmentType" in data
        assert "ETag" in data
        assert "End" in data
        assert "OID" in data
        assert "Staff" in data
        assert "Start" in data
    elif "xml" in content_type:
        # Simple XML validation can be done using xml.etree.ElementTree
        import xml.etree.ElementTree as ET
        try:
            root = ET.fromstring(response.content)
        except ET.ParseError:
            pytest.fail("Response is not valid XML")
        
        assert "DiaryAllocationModel" in root.tag
        
        for field in ["AppointmentType", "ETag", "End", "OID", "Staff", "Start"]:
            assert any(elem.tag == field for elem in root.iter())
    else:
        pytest.fail(f"Unsupported Content-Type: {content_type}")