import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_connections():
    """Test the connections endpoint"""
    
    # Prepare the request body
    headers = {"Content-Type": "application/json"}
    data = {}
    
    # Send the POST request
    response = requests.post(f"{BASE_URL}/net/connections", headers=headers, json=data)
    
    # Check the status code
    assert response.status_code == 200
    
    # Parse the JSON response
    try:
        response_json = response.json()
    except ValueError:
        print(response.text)
        pytest.fail("Failed to parse JSON")
    
    # Check that the response is an array
    assert isinstance(response_json, list), f"Expected an array, got {type(response_json)}"
    
    # Iterate over each item in the array
    for item in response_json:
        
        # Check that each item has the expected properties
        assert isinstance(item, dict), f"Expected a dictionary, got {type(item)}"
        
        # Check the 'connecting' property
        assert isinstance(item.get('connecting'), bool), f"Expected boolean, got {type(item.get('connecting'))}"
        
        # Check the 'last_handshake' property
        last_handshake = item.get('last_handshake')
        assert isinstance(last_handshake, dict), f"Expected a dictionary, got {type(last_handshake)}"
        
        # Check the 'agent' property
        agent = last_handshake.get('agent')
        assert isinstance(agent, str), f"Expected a string, got {type(agent)}"
        
        # Check the 'chain_id' property
        chain_id = last_handshake.get('chain_id')
        assert isinstance(chain_id, str), f"Expected a string, got {type(chain_id)}"
        
        # Check the 'generation' property
        generation = last_handshake.get('generation')
        assert isinstance(generation, int), f"Expected an integer, got {type(generation)}"
        
        # Check the 'head_id' property
        head_id = last_handshake.get('head_id')
        assert isinstance(head_id, str), f"Expected a string, got {type(head_id)}"
        
        # Check the 'head_num' property
        head_num = last_handshake.get('head_num')
        assert isinstance(head_num, int), f"Expected an integer, got {type(head_num)}"
        
        # Check the 'key' property
        key = last_handshake.get('key')
        assert isinstance(key, str), f"Expected a string, got {type(key)}"
        
        # Check the 'last_irreversible_block_id' property
        last_irreversible_block_id = last_handshake.get('last_irreversible_block_id')
        assert isinstance(last_irreversible_block_id, str), f"Expected a string, got {type(last_irreversible_block_id)}"
        
        # Check the 'last_irreversible_block_num' property
        last_irreversible_block_num = last_handshake.get('last_irreversible_block_num')
        assert isinstance(last_irreversible_block_num, int), f"Expected an integer, got {type(last_irreversible_block_num)}"
        
        # Check the 'network_version' property
        network_version = last_handshake.get('network_version')
        assert isinstance(network_version, int), f"Expected an integer, got {type(network_version)}"
        
        # Check the 'node_id' property
        node_id = last_handshake.get('node_id')
        assert isinstance(node_id, str), f"Expected a string, got {type(node_id)}"
        
        # Check the 'os' property
        os = last_handshake.get('os')
        assert isinstance(os, str), f"Expected a string, got {type(os)}"
        
        # Check the 'p2p_address' property
        p2p_address = last_handshake.get('p2p_address')
        assert isinstance(p2p_address, str), f"Expected a string, got {type(p2p_address)}"
        
        # Check the 'sig' property
        sig = last_handshake.get('sig')
        assert isinstance(sig, str), f"Expected a string, got {type(sig)}"
        
        # Check the 'time' property
        time_str = last_handshake.get('time')
        assert isinstance(time_str, str), f"Expected a string, got {type(time_str)}"
        try:
            time_obj = datetime.fromisoformat(time_str[:-3])
        except ValueError:
            print(f"Invalid date/time string: {time_str}")
            pytest.fail("Invalid date/time string")
        
        # Check the 'token' property
        token = last_handshake.get('token')
        assert isinstance(token, str), f"Expected a string, got {type(token)}"

# Run the test function
test_connections()