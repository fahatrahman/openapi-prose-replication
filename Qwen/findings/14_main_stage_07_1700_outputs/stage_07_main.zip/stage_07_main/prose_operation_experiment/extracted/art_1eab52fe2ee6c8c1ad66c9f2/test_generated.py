import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_legal_hold_policy():
    url = f"{BASE_URL}/legal_hold_policies"
    payload = {
        "policy_name": "Test Policy",
        "description": "A test legal hold policy",
        "is_ongoing": True,
        "filter_started_at": None,
        "filter_ended_at": None
    }
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    response = requests.post(url, json=payload, headers=headers)
    
    assert response.status_code == 201
    assert response.json()["policy_name"] == "Test Policy"
    assert response.json()["description"] == "A test legal hold policy"
    assert response.json()["is_ongoing"] == True
    assert response.json()["filter_started_at"] is None
    assert response.json()["filter_ended_at"] is None

if __name__ == "__main__":
    pytest.main()