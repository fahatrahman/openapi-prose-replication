import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = "path/to/service_account.json"

@pytest.fixture
def auth():
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )
    return credentials

def test_cancel_operation(auth):
    operation_name = "your_operation_name"
    url = f"{BASE_URL}/v1beta1/{operation_name}:cancel"

    response = requests.post(
        url,
        headers={"Authorization": f"Bearer {auth.token}"},
    )

    assert response.status_code == 200
    assert response.json() == {"": {}}