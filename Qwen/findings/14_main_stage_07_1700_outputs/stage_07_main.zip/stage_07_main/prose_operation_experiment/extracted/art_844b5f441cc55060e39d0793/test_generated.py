import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_issuer():
    resource_id = "test_resource_id"
    params = {
        "_xgafv": "1",
        "access_token": "test_access_token",
        "alt": "json",
        "callback": "test_callback",
        "fields": "test_fields",
        "key": "test_key",
        "oauth_token": "test_oauth_token",
        "prettyPrint": True,
        "quotaUser": "test_quota_user",
        "uploadProtocol": "test_upload_protocol",
        "uploadType": "test_upload_type"
    }
    headers = {
        "Authorization": "Bearer test_access_token"
    }
    response = requests.get(f"{BASE_URL}/walletobjects/v1/issuer/{resource_id}", params=params, headers=headers)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "issuerId" in response.json()