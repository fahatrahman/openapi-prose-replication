import pytest
import requests

BASE_URL = "http://openapi.test"

def get_account_keys(access_token):
    headers = {
        'Authorization': f'Bearer {access_token}'
    }
    response = requests.get(f'{BASE_URL}/account/keys', headers=headers)
    return response.json()

@pytest.mark.parametrize("access_token", [
    "valid_access_token",
    "invalid_access_token"
])
def test_get_account_keys(access_token):
    response = get_account_keys(access_token)
    if access_token == "valid_access_token":
        assert response.status_code == 200
        assert isinstance(response.json(), list)
    else:
        assert response.status_code == 401
        assert response.json() == {"error": "UnauthorizedError"}