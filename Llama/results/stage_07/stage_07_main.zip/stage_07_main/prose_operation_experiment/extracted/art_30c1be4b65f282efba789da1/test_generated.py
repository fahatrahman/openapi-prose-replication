# -*- coding: utf-8 -*-

import pytest
import requests
from typing import Dict, List

BASE_URL = "http://openapi.test"

def test_get_playback_info():
    # Construct request parameters
    itemId = "your_item_id"
    userId = "your_user_id"

    # Construct request headers
    auth_header = {"X-Emby-Authorization": "your_api_key"}

    # Send GET request to /Items/{itemId}/PlaybackInfo endpoint
    response = requests.get(
        f"{BASE_URL}/Items/{itemId}/PlaybackInfo",
        params={"userId": userId},
        headers=auth_header,
    )

    # Assert response status code
    assert response.status_code == 200

    # Parse JSON response content
    response_json = response.json()

    # Assert response JSON structure
    assert isinstance(response_json, dict)
    assert "MediaSources" in response_json
    assert isinstance(response_json["MediaSources"], list)

    # Extract MediaSourceInfo objects from response JSON
    media_sources = response_json["MediaSources"]

    # Validate each MediaSourceInfo object
    for media_source in media_sources:
        assert isinstance(media_source, dict)
        assert "AnalyzeDurationMs" in media_source
        assert "Bitrate" in media_source
        assert "BufferMs" in media_source
        assert "Container" in media_source
        assert "DefaultAudioStreamIndex" in media_source
        assert "DefaultSubtitleStreamIndex" in media_source
        assert "ETag" in media_source
        assert "EncoderPath" in media_source
        assert "EncoderProtocol" in media_source
        assert "Formats" in media_source
        assert "GenPtsInput" in media_source
        assert "Id" in media_source
        assert "IgnoreDts" in media_source
        assert "IgnoreIndex" in media_source
        assert "IsInfiniteStream" in media_source
        assert "IsRemote" in media_source
        assert "IsoType" in media_source
        assert "LiveStreamId" in media_source
        assert "MediaAttachments" in media_source
        assert "MediaStreams" in media_source
        assert "Name" in media_source
        assert "OpenToken" in media_source
        assert "Path" in media_source
        assert "Protocol" in media_source
        assert "ReadAtNativeFramerate" in media_source
        assert "RequiredHttpHeaders" in media_source
        assert "RequiresClosing" in media_source
        assert "RequiresLooping" in media_source
        assert "RequiresOpening" in media_source
        assert "RunTimeTicks" in media_source
        assert "Size" in media_source
        assert "SupportsDirectPlay" in media_source
        assert "SupportsDirectStream" in media_source
        assert "SupportsProbing" in media_source
        assert "SupportsTranscoding" in media_source
        assert "Timestamp" in media_source
        assert "TranscodingContainer" in media_source
        assert "TranscodingSubProtocol" in media_source
        assert "TranscodingUrl" in media_source
        assert "Type" in media_source
        assert "Video3DFormat" in media_source
        assert "VideoType" in media_source