import pytest
import requests

BASE_URL = "http://openapi.test"

def test_start_pipe():
    headers = {
        "X-Amz-Content-Sha256": "example-sha256",
        "X-Amz-Date": "20230401T123456Z",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "example-credential",
        "X-Amz-Security-Token": "example-token",
        "X-Amz-Signature": "example-signature",
        "X-Amz-SignedHeaders": "host"
    }
    params = {
        "Name": "example-pipe-name"
    }
    response = requests.post(f"{BASE_URL}/v1/pipes/{params['Name']}/start", headers=headers)
    
    assert response.status_code == 200
    assert "Arn" in response.json()
    assert "CreationTime" in response.json()
    assert "CurrentState" in response.json()
    assert "DesiredState" in response.json()
    assert "LastModifiedTime" in response.json()
    assert "Name" in response.json()

def test_start_pipe_not_found():
    headers = {
        "X-Amz-Content-Sha256": "example-sha256",
        "X-Amz-Date": "20230401T123456Z",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "example-credential",
        "X-Amz-Security-Token": "example-token",
        "X-Amz-Signature": "example-signature",
        "X-Amz-SignedHeaders": "host"
    }
    params = {
        "Name": "nonexistent-pipe-name"
    }
    response = requests.post(f"{BASE_URL}/v1/pipes/{params['Name']}/start", headers=headers)
    
    assert response.status_code == 483
    assert "Code" in response.json()
    assert response.json()["Code"] == "NotFoundException"

if __name__ == "__main__":
    pytest.main()