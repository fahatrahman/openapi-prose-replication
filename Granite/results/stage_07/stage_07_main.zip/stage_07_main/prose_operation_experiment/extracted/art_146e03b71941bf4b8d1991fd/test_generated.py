import os
import pytest
import requests
from urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
BASE_URL = "http://openapi.test"
HEADERS = {
    "Accept": "application/json",
}


@pytest.fixture
def youtube_members_list():
    url = f"{BASE_URL}/youtube/v3/members"

    params = {
        "_": "1.1.0",
        # "access_token": "YOUR_ACCESS_TOKEN",
        # "alt": "json",
        # "callback": "YOUR_CALLBACK",
        # "fields": "YOUR_FIELDS",
        # "key": "YOUR_KEY",
        # "oauth_token": "YOUR_OAUTH_TOKEN",
        # "prettyPrint": "TRUE",
        # "quotaUser": "YOUR_QUOTA_USER",
        # "uploadType": "MEDIA",
        # "upload_protocol": "RAW",
        "part": "snippet",
        # "filterByMemberChannelId": "YOUR_CHANNEL_ID",
        # "hasAccessToLevel": "YOUR_LEVEL_ID",
        # "maxResults": 1000,
        # "mode": "updates",
        # "pageToken": "YOUR_PAGE_TOKEN",
    }

    response = requests.get(url, headers=HEADERS, params=params)

    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Failed to get members list: {response.text}")