import pytest
import requests

BASE_URL = "http://openapi.test"

def test_walletobjects_issuer_insert():
    # Define the request payload
    payload = {
        "issuerId": 12345,
        "name": "Test Issuer",
        "homepageUrl": "http://testissuer.com",
        "contactInfo": {
            "email": "contact@testissuer.com",
            "name": "Test Contact"
        },
        "smartTapMerchantData": {
            "smartTapMerchantId": 54321,
            "authenticationKeys": [
                {
                    "id": 1,
                    "publicKeyPem": "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA7..."
                }
            ]
        },
        "callbackOptions": {
            "url": "https://example.com/callback"
        }
    }

    # Send the POST request
    headers = {
        "Content-Type": "application/json"
    }
    response = requests.post(f"{BASE_URL}/walletobjects/v1/issuer", json=payload, headers=headers)

    # Check the response status code
    assert response.status_code == 200

    # Check the response content
    response_data = response.json()
    assert response_data["issuerId"] == payload["issuerId"]
    assert response_data["name"] == payload["name"]
    assert response_data["homepageUrl"] == payload["homepageUrl"]
    assert response_data["contactInfo"]["email"] == payload["contactInfo"]["email"]
    assert response_data["contactInfo"]["name"] == payload["contactInfo"]["name"]
    assert response_data["smartTapMerchantData"]["smartTapMerchantId"] == payload["smartTapMerchantData"]["smartTapMerchantId"]
    assert response_data["smartTapMerchantData"]["authenticationKeys"][0]["id"] == payload["smartTapMerchantData"]["authenticationKeys"][0]["id"]
    assert response_data["callbackOptions"]["url"] == payload["callbackOptions"]["url"]

if __name__ == "__main__":
    pytest.main()