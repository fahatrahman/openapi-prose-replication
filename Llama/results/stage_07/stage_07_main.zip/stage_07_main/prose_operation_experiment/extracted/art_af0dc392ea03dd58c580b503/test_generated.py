# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_get_photo():
    short_name = "example_short_name"
    photo_id = "example_photo_id"
    url = urljoin(BASE_URL, f"/v2/tier2/{short_name}/photo/photos/{photo_id}")
    
    response = requests.get(url)
    assert response.status_code == 200
    
    try:
        response.json()
    except ValueError:
        assert False, "Expected JSON in response body"
        
    # Validate response schema against PhotoModel
    expected_schema = {
        "type": "object",
        "properties": {
            "ETag": {"type": "string"},
            "FileName": {"type": "string"},
            "InspectionItem": {"type": "string"},
            "InterimInspection": {"type": "string"},
            "InventoryItem": {"type": "string"},
            "Name": {"type": "string"},
            "OID": {"type": "string"},
            "PhotoNumber": {"type": "integer"},
            "PhotoType": {"type": "string", "enum": ["Photo", "Map", "FloorPlan", "SiteMap", "AerialPhoto"]},
            "Property": {"type": "string"},
            "Room": {"type": "string"}
        }
    }
    for key, value in expected_schema.items():
        assert key in response.json(), f"Missing property '{key}'"
        if isinstance(value, dict):
            assert all(isinstance(k, str) and isinstance(v, type(response.json()[key])) for k, v in value.items()), f"Invalid property '{key}' type"
        else:
            assert isinstance(response.json()[key], value), f"Invalid property '{key}' type"