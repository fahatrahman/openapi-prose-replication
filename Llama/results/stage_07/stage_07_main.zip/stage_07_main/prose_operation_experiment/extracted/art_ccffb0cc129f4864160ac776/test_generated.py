# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_export_events_json():
    """Test exporting events in JSON format."""
    
    # Create a bearer auth header
    headers = {"Authorization": f"Bearer {requests.auth.HTTPBasicAuth('username', 'password').encode().decode()}"}
    
    # Define parameters for the request
    params = {
        "search": "",  # Optional search string for filtering results
        "fields": ""   # Optional list of fields to export, comma-separated
    }
    
    try:
        response = requests.get(f"{BASE_URL}/account/events.json", headers=headers, params=params)
        
        # Check if the response was successful
        assert response.status_code == 200
        
        # Parse the JSON response
        json_response = response.json()
        
        # Check if the response contains a list of Event objects
        assert isinstance(json_response, list)
        for event in json_response:
            assert isinstance(event, dict)
            
            # Check if each Event object has the required properties
            required_properties = ["action", "client_id", "created_at", "details", "id", "organization_id",
                                   "processed_at", "processor_id", "site_id", "source_id", "source_name",
                                   "source_type", "state", "success", "target_id", "target_name", "target_type"]
            assert all(property in event for property in required_properties)
            
            # Check if the created_at field is a valid timestamp
            assert isinstance(event["created_at"], int)
            assert 0 <= event["created_at"] <= (datetime.now().timestamp() * 1000)
            
            # Check if the processed_at field is either a valid timestamp or zero
            assert isinstance(event["processed_at"], int) or event["processed_at"] == 0
            
    except AssertionError as e:
        pytest.fail(str(e))