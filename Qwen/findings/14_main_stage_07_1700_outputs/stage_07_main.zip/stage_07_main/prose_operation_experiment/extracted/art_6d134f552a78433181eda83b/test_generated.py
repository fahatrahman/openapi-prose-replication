import pytest
import requests

BASE_URL = "http://openapi.test"

def test_request_application_export():
    url = f"{BASE_URL}/api/v2/application/example_app_id/request-export"
    params = {
        "format": "csv",
        "roundType": "Assigned",
        "roundName": "Round1",
        "tab.export": "all",
        "pdf.includeForms": True,
        "pdf.includeReferences": False,
        "pdf.includeMedia": True,
        "pdf.includeApplicantAttachments": False,
        "pdf.includeOrganizationAttachments": True,
        "pdf.includeRatings": False,
        "pdf.includeFullPageMedia": True,
        "pdf.includeHighlights": False,
        "pdf.includeComments": True,
        "pdf.includeCommonApp": False,
        "zip.originalMedia": False,
        "zip.includeForms": True,
        "zip.includeReferences": False,
        "zip.includeMedia": True,
        "zip.includeApplicantAttachments": False,
        "zip.includeOrganizationAttachments": True,
        "zip.includeRatings": False,
        "zip.includeComments": True,
        "zip.includeCommonApp": False,
        "delivery.account": "example_account",
        "delivery.folder": "example_folder"
    }
    response = requests.post(url, params=params)
    assert response.status_code == 202
    result = response.json()
    assert isinstance(result, dict)
    assert 'message' in result
    assert 'submissions' in result and isinstance(result['submissions'], int)
    assert 'token' in result and isinstance(result['token'], int)

if __name__ == "__main__":
    pytest.main([__file__])