import pytest
import requests
from datetime import datetime
import hmac
import hashlib

BASE_URL = "http://openapi.test"

def get_amz_date():
    return datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")

def sign_request(method, path, secret_key):
    amz_date = get_amz_date()
    payload = f"{method}\n{path}\n\n\n"
    sig_header = hmac.new(secret_key.encode(), payload.encode(), hashlib.sha256).hexdigest()
    return sig_header

def send_request(path, body=None, headers={}):
    method = 'POST'
    secret_key = 'your_secret_key_here' # replace this with your actual AWS secret key
    signature = sign_request(method, path, secret_key)
    headers['X-Amz-Algorithm'] = 'AWS4-HMAC-SHA256'
    headers['X-Amz-Content-Sha256'] = hashlib.sha256(body.encode() if body else b'').hexdigest()
    headers['X-Amz-Date'] = get_amz_date()
    headers['X-Amz-Signature'] = signature
    headers['X-Amz-SignedHeaders'] = 'host;x-amz-date'
    
    url = f"{BASE_URL}{path}"
    response = requests.post(url, json=body, headers=headers)
    return response.json()

def test_DisassociateUser():
    body = {
        "IdentityProvider": {
            "ActiveDirectoryIdentityProvider": {
                "DirectoryId": "your_directory_id_here" # replace this with your actual directory id
            }
        },
        "InstanceId": "your_instance_id_here", # replace this with your actual instance id
        "Username": "your_username_here" # replace this with your actual username
    }

    response = send_request('/user/DisassociateUser', body)
    assert response['StatusCode'] == 200

def test_DisassociateUser_ServiceQuotaExceededException():
    body = {
        "IdentityProvider": {
            "ActiveDirectoryIdentityProvider": {
                "DirectoryId": "your_directory_id_here" # replace this with your actual directory id
            }
        },
        "InstanceId": "your_instance_id_here", # replace this with your actual instance id
        "Username": "your_username_here" # replace this with your actual username
    }

    response = send_request('/user/DisassociateUser', body)
    assert response['__type'] == 'ServiceQuotaExceededException'

def test_DisassociateUser_ConflictException():
    body = {
        "IdentityProvider": {
            "ActiveDirectoryIdentityProvider": {
                "DirectoryId": "your_directory_id_here" # replace this with your actual directory id
            }
        },
        "InstanceId": "your_instance_id_here", # replace this with your actual instance id
        "Username": "your_username_here" # replace this with your actual username
    }

    response = send_request('/user/DisassociateUser', body)
    assert response['__type'] == 'ConflictException'

def test_DisassociateUser_ValidationException():
    body = {
        "IdentityProvider": {
            "ActiveDirectoryIdentityProvider": {
                "DirectoryId": "your_directory_id_here" # replace this with your actual directory id
            }
        },
        "InstanceId": "your_instance_id_here", # replace this with your actual instance id
        "Username": "your_username_here" # replace this with your actual username
    }

    response = send_request('/user/DisassociateUser', body)
    assert response['__type'] == 'ValidationException'

def test_DisassociateUser_ThrottlingException():
    body = {
        "IdentityProvider": {
            "ActiveDirectoryIdentityProvider": {
                "DirectoryId": "your_directory_id_here" # replace this with your actual directory id
            }
        },
        "InstanceId": "your_instance_id_here", # replace this with your actual instance id
        "Username": "your_username_here" # replace this with your actual username
    }

    response = send_request('/user/DisassociateUser', body)
    assert response['__type'] == 'ThrottlingException'

def test_DisassociateUser_InternalServerException():
    body = {
        "IdentityProvider": {
            "ActiveDirectoryIdentityProvider": {
                "DirectoryId": "your_directory_id_here" # replace this with your actual directory id
            }
        },
        "InstanceId": "your_instance_id_here", # replace this with your actual instance id
        "Username": "your_username_here" # replace this with your actual username
    }

    response = send_request('/user/DisassociateUser', body)
    assert response['__type'] == 'InternalServerException'

def test_DisassociateUser_ResourceNotFoundException():
    body = {
        "IdentityProvider": {
            "ActiveDirectoryIdentityProvider": {
                "DirectoryId": "your_directory_id_here" # replace this with your actual directory id
            }
        },
        "InstanceId": "your_instance_id_here", # replace this with your actual instance id
        "Username": "your_username_here" # replace this with your actual username
    }

    response = send_request('/user/DisassociateUser', body)
    assert response['__type'] == 'ResourceNotFoundException'

def test_DisassociateUser_AccessDeniedException():
    body = {
        "IdentityProvider": {
            "ActiveDirectoryIdentityProvider": {
                "DirectoryId": "your_directory_id_here" # replace this with your actual directory id
            }
        },
        "InstanceId": "your_instance_id_here", # replace this with your actual instance id
        "Username": "your_username_here" # replace this with your actual username
    }

    response = send_request('/user/DisassociateUser', body)
    assert response['__type'] == 'AccessDeniedException'

if __name__ == "__main__":
    pytest.main([__file__, "-v"])