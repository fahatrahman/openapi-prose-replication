# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_connected_site_tag():
    url = f"{BASE_URL}/v1alpha/properties/createConnectedSiteTag"
    headers = {"Content-Type": "application/json"}
    data = {
        "connectedSiteTag": {
            "displayName": "Test Connected Site Tag",
            "tagId": "G-12345"
        },
        "property": "properties/1234"
    }

    response = requests.post(url, json=data, headers=headers)

    assert response.status_code == 200