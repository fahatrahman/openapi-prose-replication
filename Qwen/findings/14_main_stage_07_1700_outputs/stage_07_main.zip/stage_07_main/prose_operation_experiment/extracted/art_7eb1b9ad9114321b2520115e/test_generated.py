import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_show_follow():
    show_id = 123  # Replace with a valid show ID for testing
    headers = {
        "Authorization": "Basic dXNlcm5hbWU6cGFzc3dvcmQ="  # Replace with actual credentials
    }
    url = f"{BASE_URL}/user/follows/shows/{show_id}"
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "_embedded" in response.json()
    assert "show" in response.json()["_embedded"]
    assert isinstance(response.json()["_embedded"]["show"], dict)

def test_get_non_existent_show_follow():
    show_id = 999999  # Replace with a non-existent show ID for testing
    headers = {
        "Authorization": "Basic dXNlcm5hbWU6cGFzc3dvcmQ="  # Replace with actual credentials
    }
    url = f"{BASE_URL}/user/follows/shows/{show_id}"
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 404
    assert response.text == "Nrvq pyhq fj hwy ptphkdfs"