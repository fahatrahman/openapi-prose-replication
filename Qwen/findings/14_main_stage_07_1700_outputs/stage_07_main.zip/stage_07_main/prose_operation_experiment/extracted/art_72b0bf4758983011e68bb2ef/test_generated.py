import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_all_subcontractor_tags():
    employer_id = "GD001"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    url = f"{BASE_URL}/Employer/{employer_id}/SubContractors/Tags"
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert "application/json" in response.headers["Content-Type"]
    link_collection = response.json()
    assert isinstance(link_collection, dict)
    assert "LinkCollection" in link_collection
    links = link_collection["LinkCollection"]["Links"]
    assert isinstance(links, list)
    for link in links:
        assert "@href" in link
        assert "@rel" in link
        assert "@title" in link

@pytest.mark.parametrize("status_code, error_category", [
    (400, "ValidationFailure"),
    (401, "NotAuthorised"),
    (404, "NotFound"),
    (500, "General")
])
def test_error_responses(status_code, error_category):
    employer_id = "GD001"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    url = f"{BASE_URL}/Employer/{employer_id}/SubContractors/Tags"
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == status_code
    assert "application/json" in response.headers["Content-Type"]
    error_model = response.json()
    assert isinstance(error_model, dict)
    assert "ErrorModel" in error_model
    assert "ErrorCategory" in error_model["ErrorModel"]
    assert error_model["ErrorModel"]["ErrorCategory"] == error_category