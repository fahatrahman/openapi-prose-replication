import os
import pytest
import requests
from requests_oauthlib import OAuth2Session

BASE_URL = "http://openapi.test"
CLIENT_ID = "YOUR_CLIENT_ID"
CLIENT_SECRET = "YOUR_CLIENT_SECRET"
SCOPE = ["https://www.googleapis.com/auth/drive"]

def get_access_token():
    oauth = OAuth2Session(client_id=CLIENT_ID, scope=SCOPE, redirect_uri="http://localhost/")
    token = oauth.fetch_token(
        "https://accounts.google.com/o/oauth2/auth",
        client_secret=CLIENT_SECRET,
        authorization_response="dummy_authorization_response",
    )
    return token["access_token"]

@pytest.fixture
def drive_about():
    headers = {
        "Accept": "application/json",
    }

    access_token = get_access_token()
    headers["Authorization"] = f"Bearer {access_token}"

    response = requests.get(
        f"{BASE_URL}/about",
        headers=headers,
        params={
            "includeSubscribed": True,
            "maxChangeIdCount": "1000",
            "startChangeId": "1234567890",
        },
    )

    assert response.status_code == 200

    return response.json()["about"]

def test_drive_about(drive_about):
    assert isinstance(drive_about, dict)
    assert "canCreateDrives" in drive_about
    assert "domainSharingPolicy" in drive_about
    assert "driveThemes" in drive_about
    assert "etag" in drive_about
    assert "exportFormats" in drive_about
    assert "features" in drive_about
    assert "folderColorPalette" in drive_about
    assert "importFormats" in drive_about
    assert "isCurrentAppInstalled" in drive_about
    assert "kind" in drive_about
    assert "languageCode" in drive_about
    assert "largestChangeId" in drive_about
    assert "maxUploadSizes" in drive_about
    assert "name" in drive_about
    assert "permissionId" in drive_about
    assert "quotaBytesByService" in drive_about
    assert "quotaBytesTotal" in drive_about
    assert "quotaBytesUsed" in drive_about
    assert "quotaBytesUsedAggregate" in drive_about
    assert "quotaBytesUsedInTrash" in drive_about
    assert "quotaType" in drive_about
    assert "remainingChangeIds" in drive_about
    assert "rootFolderId" in drive_about
    assert "selfLink" in drive_about
    assert "teamDriveThemes" in drive_about
    assert "user" in drive_about