import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_payment_status():
    headers = {
        "x-api-key": "{{your_api_key}}"
    }
    params = {
        "payment_id": "5524759814"
    }
    response = requests.get(f"{BASE_URL}/v1/payment/{params['payment_id']}", headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert "payment_id" in data
    assert "payment_status" in data
    assert data["payment_id"] == 5524759814
    assert data["payment_status"] in ["waiting", "confirming", "confirmed", "sending", "partially_paid", "finished", "failed", "refunded", "expired"]
    assert "created_at" in data
    assert "updated_at" in data
    assert "order_description" in data
    assert "order_id" in data
    assert "price_amount" in data
    assert "price_currency" in data
    assert "pay_amount" in data
    assert "pay_currency" in data
    assert "pay_address" in data
    assert "outcome_amount" in data
    assert "outcome_currency" in data
    assert "actually_paid" in data
    assert "purchase_id" in data