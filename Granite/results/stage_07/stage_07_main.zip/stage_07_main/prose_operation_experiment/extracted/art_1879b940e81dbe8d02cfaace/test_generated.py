import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def client():
    return requests.Session()

def test_get_reverse_geocode(client):
    url = f"{BASE_URL}/reverse"
    response = client.get(url)

    # Assuming we are looking for a string response
    assert response.status_code == 200
    assert isinstance(response.json(), str)