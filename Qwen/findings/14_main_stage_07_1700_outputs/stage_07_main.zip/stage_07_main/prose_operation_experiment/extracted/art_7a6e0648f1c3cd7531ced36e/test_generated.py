import pytest
import requests

BASE_URL = "http://openapi.test"

def test_apps_list_instance_sizes():
    url = f"{BASE_URL}/v2/apps/tiers/instance_sizes"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer $DIGITALOCEAN_TOKEN"
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    data = response.json()
    assert "instance_sizes" in data
    for instance_size in data["instance_sizes"]:
        assert "cpu_type" in instance_size
        assert "cpus" in instance_size
        assert "memory_bytes" in instance_size
        assert "name" in instance_size
        assert "slug" in instance_size
        assert "tier_slug" in instance_size
        assert "tier_upgrade_to" in instance_size
        assert "usd_per_month" in instance_size
        assert "usd_per_second" in instance_size

def test_apps_list_instance_sizes_unauthorized():
    url = f"{BASE_URL}/v2/apps/tiers/instance_sizes"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer invalid_token"
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 401
    data = response.json()
    assert "id" in data
    assert data["id"] == "unauthorized"
    assert "message" in data
    assert "request_id" in data

def test_apps_list_instance_sizes_rate_limit_exceeded():
    # This test assumes there is a way to trigger rate limiting, which might involve setting up mock responses or using a testing environment.
    pass

def test_apps_list_instance_sizes_server_error():
    # This test assumes there is a way to trigger server errors, which might involve setting up mock responses or using a testing environment.
    pass