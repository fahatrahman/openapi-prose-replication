import pytest
import requests

BASE_URL = "http://openapi.test"

def test_pubsub_projects_subscriptions_acknowledge():
    url = f"{BASE_URL}/v1/zynntaco/{autfnhu}/bbrizkvvbtwqh/{vvz}:acknowledge"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    payload = {
        "ackIds": ["ACK_ID_1", "ACK_ID_2"]
    }
    response = requests.post(url, headers=headers, json=payload)
    
    assert response.status_code == 200
    assert response.json() == {}