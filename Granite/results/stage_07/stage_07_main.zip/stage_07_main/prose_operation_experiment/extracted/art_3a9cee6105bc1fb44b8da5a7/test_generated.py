import pytest
import requests
BASE_URL = "http://openapi.test"

@pytest.fixture
def test_app():
    response = requests.get(
        f"{BASE_URL}",
        params={"page_size": 10, "page": 1},
        headers={
            "Authorization": "Basic YWxhZGRpbjpvcGVuc2VzYW1l",
        },
    )

    assert response.status_code == 200, f"Received {response.status_code}"
    return response.json()

def test_list_application(test_app):
    assert isinstance(test_app, dict), "Expected response to be a dictionary"
    assert "applications" in test_app["_embedded"], "Expected 'applications' key in _embedded"