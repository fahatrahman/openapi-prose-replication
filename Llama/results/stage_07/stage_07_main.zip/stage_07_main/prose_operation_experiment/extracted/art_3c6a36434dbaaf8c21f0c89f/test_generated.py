import pytest
import requests
from datetime import datetime
import hashlib
import hmac
import json
import base64
import uuid

BASE_URL = "http://openapi.test"

def get_signature(key, timestamp):
    message = f"{timestamp}\nPOST\n/{username}/dashboards"
    signature = hmac.new(base64.b64decode(key), message.encode('utf-8'), hashlib.sha256).digest()
    return base64.b64encode(signature)

def create_dashboard(username, key, name, description):
    headers = {
        'X-AIO-Key': key,
        'X-AIO-Signature': get_signature(key, str(datetime.now().timestamp()))
    }
    
    data = {
        'name': name,
        'description': description
    }

    response = requests.post(f'{BASE_URL}/{username}/dashboards', headers=headers, json=data)
    assert response.status_code == 201
    assert response.json()['name'] == name
    assert response.json()['description'] == description

@pytest.mark.parametrize("username,key,name,description", [
    ("test_user", "test_key", "Test Dashboard", "This is a test dashboard"),
])
def test_create_dashboard(username, key, name, description):
    create_dashboard(username, key, name, description)