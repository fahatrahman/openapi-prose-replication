import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_published_early_day_motion():
    id = 123  # Replace with a valid ID
    url = f"{BASE_URL}/EarlyDayMotion/{id}"
    response = requests.get(url)
    
    assert response.status_code == 200
    data = response.json()
    assert data["Success"]
    assert "Response" in data
    assert isinstance(data["Response"], dict)

if __name__ == "__main__":
    pytest.main([__file__])