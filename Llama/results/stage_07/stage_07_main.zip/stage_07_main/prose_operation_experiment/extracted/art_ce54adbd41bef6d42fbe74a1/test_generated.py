# -*- coding: utf-8 -*-
import pytest
import requests

BASE_URL = "http://openapi.test"

def test_displayvideo_partners_channels_sites_list():
    url = f"{BASE_URL}/v1/partners/{'partnerId'} /channels/{'channelId'}/sites"
    params = {
        'access_token': '',
        'alt': '',
        'callback': '',
        'fields': '',
        'key': '',
        'oauth_token': '',
        'prettyPrint': False,
        'quotaUser': '',
        'upload_protocol': '',
        'uploadType': ''
    }
    
    response = requests.get(url, params=params)
    assert response.status_code == 200
    
    response.raise_for_status()
    
    data = response.json()
    assert isinstance(data, dict)
    assert 'nextPageToken' in data
    assert isinstance(data['nextPageToken'], str)
    assert isinstance(data['sites'], list)

if __name__ == "__main__":
    pytest.main([__file__])