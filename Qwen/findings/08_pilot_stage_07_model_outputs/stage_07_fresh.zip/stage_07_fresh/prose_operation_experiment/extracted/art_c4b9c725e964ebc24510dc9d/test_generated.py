import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_security_settings():
    url = f"{BASE_URL}/v3/zynntaco%2Fyzvrewumc%2FlcfyioliGhwemvja"
    params = {
        "_xgafv": "2",
        "access_token": "example_access_token",
        "alt": "json",
        "prettyPrint": True,
        "quotaUser": "example_quota_user",
        "uploadType": "multipart/form-data",
        "upload_protocol": "raw",
        "force": False
    }
    response = requests.delete(url, params=params)
    assert response.status_code == 200
    assert response.json() == {}