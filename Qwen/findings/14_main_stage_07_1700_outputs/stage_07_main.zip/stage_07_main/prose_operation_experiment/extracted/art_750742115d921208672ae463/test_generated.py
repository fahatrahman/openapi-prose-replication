import pytest
import requests

BASE_URL = "http://openapi.test"

def test_errors_group_model_counts():
    headers = {
        "X-API-Token": "your_api_token_here"
    }
    params = {
        "$top": 30
    }
    path = "/v0.1/apps/owner_name/app_name/errors/errorGroups/errorGroupId/models"
    url = f"{BASE_URL}{path}"
    
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert 'errorCount' in response.json()
    assert 'models' in response.json()
    assert isinstance(response.json()['models'], list)

if __name__ == "__main__":
    pytest.main([__file__])