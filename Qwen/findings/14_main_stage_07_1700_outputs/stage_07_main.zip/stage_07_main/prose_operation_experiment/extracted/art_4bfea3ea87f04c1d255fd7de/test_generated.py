import pytest
import requests

BASE_URL = "http://openapi.test"

def create_label(owner, repo, label_option):
    url = f"{BASE_URL}/repos/{owner}/{repo}/labels"
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json"
    }
    response = requests.post(url, json=label_option, headers=headers)
    return response

@pytest.mark.parametrize("owner, repo, label_option, expected_status_code", [
    ("test_owner", "test_repo", {"name": "Test Label", "color": "#ff0000"}, 201),
    ("test_owner", "test_repo", {"name": "Invalid Label", "color": "#invalid"}, 422)
])
def test_create_label(owner, repo, label_option, expected_status_code):
    response = create_label(owner, repo, label_option)
    assert response.status_code == expected_status_code
    if expected_status_code == 201:
        assert 'name' in response.json()
        assert 'color' in response.json()
    elif expected_status_code == 422:
        assert 'message' in response.headers
        assert 'url' in response.headers