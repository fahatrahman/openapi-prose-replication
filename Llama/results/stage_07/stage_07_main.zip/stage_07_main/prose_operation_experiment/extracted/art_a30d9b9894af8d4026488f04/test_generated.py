# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urlencode

BASE_URL = "http://openapi.test"

def test_redis_projects_locations_operations_cancel():
    url = f"{BASE_URL}/v1beta1/name:cancel"
    params = {
        "_xgafv": "1",
        "access_token": "",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "",
        "oauth_token": "",
        "prettyPrint": "false",
        "quotaUser": "",
        "uploadType": "media",
        "upload_protocol": "jnr",
        "name": "test_name"
    }
    headers = {}
    response = requests.post(url, headers=headers, params=urlencode(params))
    assert response.status_code == 200