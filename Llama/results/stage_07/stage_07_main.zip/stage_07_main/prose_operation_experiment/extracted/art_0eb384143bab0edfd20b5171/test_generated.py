# tests/test_upload_ephemeral_image.py
"""Test uploading ephemeral images."""

import pytest
import base64
import os
from unittest.mock import patch
import requests

BASE_URL = "http://openapi.test"

def test_upload_ephemeral_image():
    """Test uploading ephemeral images."""
    
    # Mock environment variables
    with patch.dict('os.environ', {'SHUTTERSTOCK_API_TOKEN': 'mock_api_token'}):
        
        # Encode image data
        image_data = open("test_image.jpg", "rb").read()
        encoded_image_data = base64.b64encode(image_data)
        
        # Create request body
        body = {"base64_image": encoded_image_data.decode()}
        
        # Send POST request
        response = requests.post(f"{BASE_URL}/v2/images", headers={"Authorization": f"Bearer mock_api_token"}, json=body)
        
        # Check status code
        assert response.status_code == 201
        
        # Get response JSON
        response_json = response.json()
        
        # Check response content
        assert "id" in response_json
        
        # Print response id
        print(response_json["id"])