import pytest
import requests

BASE_URL = "http://openapi.test"

def test_directory_users_aliases_insert():
    url = f"{BASE_URL}/admin/directory/v1/users/user@example.com/aliases"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    payload = {
        "alias": "new_alias@example.com"
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert "alias" in response.json()
    assert response.json()["alias"] == "new_alias@example.com"