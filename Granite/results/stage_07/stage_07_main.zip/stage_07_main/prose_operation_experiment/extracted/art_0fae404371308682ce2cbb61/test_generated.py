import os
import pytest
import requests
from requests.exceptions import HTTPError

BASE_URL = "http://openapi.test"

@pytest.mark.parametrize("show_id", [1, 2, 3])
def test_check_if_show_is_followed(show_id):
    url = f"{BASE_URL}/user/follows/shows/{show_id}"
    headers = {"Authorization": "Basic ..."}  # replace "..." with actual token

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        follow_data = response.json()
        assert isinstance(follow_data, dict)
        assert follow_data.get("_embedded")
        assert follow_data["_embedded"]["show"]
        assert follow_data["show_id"] == show_id
    elif response.status_code == 404:
        print(f"Show with ID {show_id} is not followed.")
    else:
        raise HTTPError(f"Request failed with status code {response.status_code}")