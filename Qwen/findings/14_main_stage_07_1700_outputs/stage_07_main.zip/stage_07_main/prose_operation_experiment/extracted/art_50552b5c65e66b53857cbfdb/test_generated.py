import pytest
import requests

BASE_URL = "http://openapi.test"

def test_certificate_site_seal():
    url = f"{BASE_URL}/v1/certificates/example_certificate_id/siteSeal"
    params = {
        "theme": "LIGHT",
        "locale": "en"
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 200
    assert "html" in response.json()
    assert isinstance(response.json()["html"], str)

def test_certificate_site_seal_400():
    url = f"{BASE_URL}/v1/certificates/invalid_certificate_id/siteSeal"
    params = {
        "theme": "INVALID_THEME",
        "locale": "en"
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 400
    assert "error" in response.json()
    assert isinstance(response.json()["error"]["code"], str)
    assert isinstance(response.json()["error"]["message"], str)

def test_certificate_site_seal_401():
    url = f"{BASE_URL}/v1/certificates/example_certificate_id/siteSeal"
    headers = {
        "Authorization": "Bearer invalid_token"
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 401
    assert "error" in response.json()
    assert isinstance(response.json()["error"]["code"], str)
    assert isinstance(response.json()["error"]["message"], str)

def test_certificate_site_seal_403():
    url = f"{BASE_URL}/v1/certificates/example_certificate_id/siteSeal"
    headers = {
        "Authorization": "Bearer unauthorized_token"
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 403
    assert "error" in response.json()
    assert isinstance(response.json()["error"]["code"], str)
    assert isinstance(response.json()["error"]["message"], str)

def test_certificate_site_seal_404():
    url = f"{BASE_URL}/v1/certificates/nonexistent_certificate_id/siteSeal"
    params = {
        "theme": "LIGHT",
        "locale": "en"
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 404
    assert "error" in response.json()
    assert isinstance(response.json()["error"]["code"], str)
    assert isinstance(response.json()["error"]["message"], str)

def test_certificate_site_seal_409():
    url = f"{BASE_URL}/v1/certificates/conflicting_certificate_id/siteSeal"
    params = {
        "theme": "LIGHT",
        "locale": "en"
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 409
    assert "error" in response.json()
    assert isinstance(response.json()["error"]["code"], str)
    assert isinstance(response.json()["error"]["message"], str)

def test_certificate_site_seal_422():
    url = f"{BASE_URL}/v1/certificates/example_certificate_id/siteSeal"
    params = {
        "theme": "INVALID_THEME",
        "locale": "en"
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 422
    assert "error" in response.json()
    assert isinstance(response.json()["error"]["code"], str)
    assert isinstance(response.json()["error"]["message"], str)

def test_certificate_site_seal_500():
    url = f"{BASE_URL}/v1/certificates/example_certificate_id/siteSeal"
    params = {
        "theme": "LIGHT",
        "locale": "en"
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 500
    assert "error" in response.json()
    assert isinstance(response.json()["error"]["code"], str)
    assert isinstance(response.json()["error"]["message"], str)