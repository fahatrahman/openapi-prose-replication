import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_substance_by_uuid():
    db = "nanoreg1"
    uuid = "some-uuid-value"
    params = {
        "property_uris[]": ["uri1", "uri2"],
        "page": 0,
        "pagesize": 10
    }
    response = requests.get(f"{BASE_URL}/enm/{db}/substance/{uuid}", params=params)
    
    assert response.status_code == 200
    substance_data = response.json()
    assert "substance" in substance_data

if __name__ == "__main__":
    pytest.main([__file__])