import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_apps_list_instanceSizes():
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer your_bearer_token'
    }
    response = requests.get(urljoin(BASE_URL, '/v2/apps/tiers/instance_sizes'), headers=headers)
    assert response.status_code == 200
    response.raise_for_status()
    data = response.json()
    assert isinstance(data['instance_sizes'], list)

def test_apps_list_instanceSizes_unauthorized():
    headers = {}
    response = requests.get(urljoin(BASE_URL, '/v2/apps/tiers/instance_sizes'), headers=headers)
    assert response.status_code == 401

def test_apps_list_instanceSizes_rate_limit_exceeded():
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer your_bearer_token'
    }
    for _ in range(100):
        response = requests.get(urljoin(BASE_URL, '/v2/apps/tiers/instance_sizes'), headers=headers)
        if response.status_code != 429:
            break
    else:
        assert False, "Rate limit exceeded"

def test_apps_list_instanceSizes_server_error():
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer your_bearer_token'
    }
    response = requests.get(urljoin(BASE_URL, '/v2/apps/tiers/instance_sizes'), headers=headers)
    assert response.status_code == 500
    response.raise_for_status()

def test_apps_list_instanceSizes_default_response():
    headers = {}
    response = requests.get(urljoin(BASE_URL, '/v2/apps/tiers/instance_sizes'), headers=headers)
    assert response.status_code == 200
    response.raise_for_status()
    data = response.json()
    assert isinstance(data['instance_sizes'], list)