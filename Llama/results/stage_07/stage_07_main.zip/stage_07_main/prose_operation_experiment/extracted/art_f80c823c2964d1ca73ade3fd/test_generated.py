# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime
from uuid import uuid4
from hashlib import sha256

class TestGetResources:
    @pytest.fixture(autouse=True)
    def setup(self):
        self.BASE_URL = "http://openapi.test"
        self.headers = {
            'X-Amz-Algorithm': 'AWS4-HMAC-SHA256',
            'X-Amz-Content-Sha256': self.calculate_content_sha256(),
            'X-Amz-Credential': f'AKIAIOSFODNN7EXAMPLE/20190830/us-east-1/execute-api/aws4_request',
            'X-Amz-Date': self.get_current_date(),
            'X-Amz-Security-Token': '',
            'X-Amz-SignedHeaders': 'host;x-amz-date',
            'X-Amz-Signature': self.calculate_signature()
        }
        self.params = {
            'userId': '1234567890123456789012345678901234567890',
            'collectionType': 'SHARED_WITH_ME',
            'limit': 10,
            'marker': ''
        }

    def calculate_content_sha256(self):
        return sha256(str.encode('')).hexdigest()

    def get_current_date(self):
        return datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')

    def calculate_signature(self):
        # This is a simplified implementation of AWS SigV4
        # In a real application you would need to implement the full algorithm
        key = 'AWS4' + 'YOUR_SECRET_ACCESS_KEY'
        date_key = hmac.new(key.encode(), self.get_current_date().encode(), sha256).digest()
        region_key = hmac.new(date_key, b'us-east-1', sha256).digest()
        service_key = hmac.new(region_key, b'execute-api', sha256).digest()
        signing_key = hmac.new(service_key, b'aws4_request', sha256).digest()
        message = (self.get_current_date() + '\n' +
                   'POST\n' +
                   '/api/v1/resources\n' +
                   'host:' + self.BASE_URL + '\n' +
                   'x-amz-date:' + self.get_current_date() + '\n' +
                   'host;x-amz-date\n' +
                   sha256(str.encode('')).hexdigest())
        return hmac.new(signing_key, message.encode(), sha256).hexdigest()

    def test_get_resources(self):
        response = requests.get(f'{self.BASE_URL}/api/v1/resources', headers=self.headers, params=self.params)
        assert response.status_code == 200
        assert isinstance(response.json()['Documents'], list)

def hmac(key, msg):
    import hashlib
    return hashlib.pbkdf2_hmac('sha256', msg, key, 100000)