# pytest_module.py
import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_featured_image_collection_list():
    params = {
        "type": ["photo"],
        "asset_hint": "1x",
        "embed": "share_url"
    }
    response = requests.get(f"{BASE_URL}/v2/images/collections/featured", params=params)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert 'data' in data
    assert len(data['data']) > 0
    for item in data['data']:
        assert isinstance(item, dict)
        assert 'cover_item' in item
        assert 'url' in item['cover_item']
        assert isinstance(item['cover_item']['url'], str)

def test_get_featured_image_collection_list_with_invalid_type():
    params = {
        "type": ["invalid"],
        "asset_hint": "1x",
        "embed": "share_url"
    }
    response = requests.get(f"{BASE_URL}/v2/images/collections/featured", params=params)
    assert response.status_code == 400

def test_get_featured_image_collection_list_without_auth():
    response = requests.get(f"{BASE_URL}/v2/images/collections/featured")
    assert response.status_code == 401