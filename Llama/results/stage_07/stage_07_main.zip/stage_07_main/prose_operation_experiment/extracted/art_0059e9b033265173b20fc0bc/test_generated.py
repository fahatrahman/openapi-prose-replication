import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_ship_ship_scan():
    ship_symbol = "test_ship"
    response = requests.post(
        f"{BASE_URL}/my/ships/{ship_symbol}/scan/ships",
        headers={"Authorization": "Bearer YOUR_AGENT_TOKEN"},
    )
    assert response.status_code == 201
    response.raise_for_status()
    data = response.json()["data"]
    assert isinstance(data, dict)
    assert "cooldown" in data
    assert "ships" in data
    assert isinstance(data["ships"], list)

def test_create_ship_ship_scan_negative(ship_symbol):
    response = requests.post(
        f"{BASE_URL}/my/ships/{ship_symbol}/scan/ships",
        headers={"Authorization": "Bearer INVALID_TOKEN"},
    )
    assert response.status_code == 401
    response.raise_for_status()

@pytest.fixture
def ship_symbol():
    return "test_ship"