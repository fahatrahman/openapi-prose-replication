import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_comment():
    topic_id = 12345
    comment_data = {
        "author": {"id": 67890},
        "authorName": None,
        "created": None,
        "entry": None,
        "id": None,
        "message": "Hello, world!"
    }
    
    response = requests.post(
        f"{BASE_URL}/api/discussions/topics/{topic_id}/comments",
        json=comment_data,
        headers={"Content-Type": "application/json"}
    )
    
    assert response.status_code == 200
    
    result = response.json()
    expected_schema = {
        "author": {"id": 67890},
        "authorName": None,
        "created": None,
        "entry": None,
        "id": None,
        "message": "Hello, world!"
    }
    
    for key, value in expected_schema.items():
        if isinstance(value, dict):
            assert result[key] == value
        else:
            assert result[key] is value