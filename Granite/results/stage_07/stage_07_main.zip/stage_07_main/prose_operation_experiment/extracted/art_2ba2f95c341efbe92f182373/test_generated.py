import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retry logic
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["GET", "OPTIONS"],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def app_categories():
    url = f"{BASE_URL}/v1/appCategories"

    params = {
        "filter[platforms]": ["IOS", "MAC_OS"],
        "exists[parent]": ["true"],
        "fields[appCategories]": ["parent", "platforms"],
        "limit": 10,
        "include": "parent,subcategories",
        "limit[subcategories]": 2,
    }

    response = session.get(url, params=params)
    response.raise_for_status()

    return response.json()

def test_app_categories(app_categories):
    assert isinstance(app_categories, dict)
    assert "data" in app_categories
    assert "included" in app_categories
    assert "links" in app_categories
    assert "meta" in app_categories