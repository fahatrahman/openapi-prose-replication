import pytest
import requests

BASE_URL = "http://openapi.test"

def test_add_profile_permission():
    headers = {
        "Authorization": "hmac your_access_key_id",
        "X-Amz-Algorithm": "your_algorithm",
        "X-Amz-Content-Sha256": "your_content_sha256",
        "X-Amz-Credential": "your_credential",
        "X-Amz-Date": "your_date",
        "X-Amz-Security-Token": "your_security_token",
        "X-Amz-Signature": "your_signature",
        "X-Amz-SignedHeaders": "your_signed_headers"
    }
    payload = {
        "action": "your_action",
        "principal": "your_principal",
        "profileVersion": "your_profile_version",
        "revisionId": "your_revision_id",
        "statementId": "your_statement_id"
    }
    response = requests.post(f"{BASE_URL}/signing-profiles/your_profile_name/permissions", headers=headers, json=payload)
    
    assert response.status_code == 200
    assert "revisionId" in response.json()