import pytest
import requests

BASE_URL = "http://openapi.test"

def test_reset_api_key_from_group_quotas():
    group_id = "test_group"
    client_id = "test_client"
    url = f"{BASE_URL}/api/groups/{group_id}/apikeys/{client_id}/quotas"
    
    response = requests.delete(url)
    
    assert response.status_code == 200
    assert response.json().get("currentCallsPerSec") == 0
    assert response.json().get("remainingCallsPerSec") == 123
    assert response.json().get("currentCallsPerDay") == 0
    assert response.json().get("remainingCallsPerDay") == 123
    assert response.json().get("currentCallsPerMonth") == 0
    assert response.json().get("remainingCallsPerMonth") == 123

def test_reset_api_key_from_group_quotas_invalid_group_id():
    group_id = "invalid_group"
    client_id = "test_client"
    url = f"{BASE_URL}/api/groups/{group_id}/apikeys/{client_id}/quotas"
    
    response = requests.delete(url)
    
    assert response.status_code == 404
    assert response.text == "Nbbcmoio hwy aqprs sg jxrq hwy zndtr"

def test_reset_api_key_from_group_quotas_unauthorized():
    group_id = "test_group"
    client_id = "test_client"
    url = f"{BASE_URL}/api/groups/{group_id}/apikeys/{client_id}/quotas"
    
    headers = {
        "Authorization": "Basic dGVzdFVzZXI6dGVzdFBhc3M="
    }
    
    response = requests.delete(url, headers=headers)
    
    assert response.status_code == 401
    assert response.text == "Lfz wdny wd fuznyji li Gna Brx. Gna Brx tpb tp ddpqsc hpwr 'Nxvhwzfd-Tpmakj-Lg' blo 'Nxvhwzfd-Tpmakj-Krxmdv' mszxida, sg efi jnjzx rleh psppsygwerkjbd"