import os
import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def client():
    return requests.Session()

def test_list_import_dockerfiles(client):
    operation_id = "example_operation_id"
    url = f"{BASE_URL}/imports/images/{operation_id}/dockerfile"

    response = client.get(url)

    assert response.status_code == 200, f"Expected status code 200, got {response.status_code}"

    # Assuming we can deserialize the response content to ImportContentDigestList
    # For this example, let's just check if the response content is a list
    assert isinstance(response.json(), list), "Response content should be a list"