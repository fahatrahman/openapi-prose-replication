import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_FILE = "credentials.json"

@pytest.fixture
def auth():
    credentials = service_account.Credentials.from_service_account_file(
        CREDENTIALS_FILE, scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )
    return credentials

def test_list_feature_online_stores(auth):
    path_params = {"parent": "zynntaco/your_resource/yzvrewumc/hacbpbfJamytyUvjsaf"}
    query_params = {
        "filter": "lmpkwx_ykqg > \"2020-01-01\"",
        "orderBy": "lmpkwx_ykqg",
        "pageSize": 100,
        "pageToken": "some_page_token",
    }

    headers = {
        "Authorization": f"Bearer {auth.token}",
        "Accept": "application/json",
    }

    response = requests.get(
        f"{BASE_URL}/v1/{path_params['parent']}/featureOnlineStores",
        params=query_params,
        headers=headers,
    )

    assert response.status_code == 200
    result = response.json()
    # Further assertions or processing of the result can go here