import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Set up session with retry strategy for API calls
session = requests.Session()
retries = Retry(total=3, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.mark.parametrize("image_digest, force", [
    ("example_digest", True),
    ("example_digest", False),
])
def test_delete_image(image_digest, force):
    url = f"{BASE_URL}/images/{image_digest}"

    response = session.delete(
        url,
        headers={"x-anchore-account": "your_account"},
        params={"force": force},
    )

    assert response.status_code == 200
    delete_response = response.json()
    assert "digest" in delete_response
    assert "status" in delete_response
    assert delete_response["status"] in ["not_found", "deleting", "delete_failed"]