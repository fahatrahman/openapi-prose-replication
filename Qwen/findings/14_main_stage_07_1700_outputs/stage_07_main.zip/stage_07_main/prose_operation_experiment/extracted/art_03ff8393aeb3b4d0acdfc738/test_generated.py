import pytest
import requests

BASE_URL = "http://openapi.test"

def test_texttospeech_projects_locations_operations_get():
    url = f"{BASE_URL}/v1beta1/{'projects/locations/operations/example'}"
    params = {
        "_xgafv": "1",
        "access_token": "example_access_token",
        "alt": "json",
        "callback": "example_callback",
        "fields": "name,response",
        "key": "example_key",
        "oauth_token": "example_oauth_token",
        "prettyPrint": True,
        "quotaUser": "example_quota_user",
        "uploadType": "multipart",
        "upload_protocol": "raw"
    }
    headers = {
        "Authorization": "Bearer example_bearer_token"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "name" in response.json()
    assert "response" in response.json()

if __name__ == "__main__":
    pytest.main()