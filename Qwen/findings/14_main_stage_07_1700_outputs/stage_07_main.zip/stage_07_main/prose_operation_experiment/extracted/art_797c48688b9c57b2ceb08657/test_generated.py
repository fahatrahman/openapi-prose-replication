import pytest
import requests

BASE_URL = "http://openapi.test"

def test_update_group():
    headers = {
        "X-AIO-Key": "your_api_key",
        "X-AIO-Signature": "your_signature"
    }
    url = f"{BASE_URL}/username/groups/group_key"
    payload = {
        "name": "Updated Group Name",
        "description": "Updated description for the group"
    }
    response = requests.patch(url, headers=headers, json=payload)
    
    assert response.status_code == 200
    assert "name" in response.json()
    assert response.json()["name"] == "Updated Group Name"
    assert "description" in response.json()
    assert response.json()["description"] == "Updated description for the group"