import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_dedicated_ip_pool():
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "access-key-id/20230401/us-east-1/sts/aws4_request",
        "X-Amz-Date": "20230401T000000Z",
        "X-Amz-Security-Token": "session-token",
        "X-Amz-Signature": "signature",
        "X-Amz-SignedHeaders": "host"
    }
    pool_name = "test-pool"
    url = f"{BASE_URL}/v1/email/dedicated-ip-pools/{pool_name}"
    
    response = requests.delete(url, headers=headers)
    
    assert response.status_code == 200
    assert response.json() == {"description": "Li RLEH 200 ubbiwvwr on ajh diimyfa mzmmafan, sg li phbnl qquvejv on ajh diimyfa orsno."}
    
    # Test for NotFoundException (status code 480)
    response = requests.delete(f"{BASE_URL}/v1/email/dedicated-ip-pools/nonexistent", headers=headers)
    assert response.status_code == 480
    
    # Test for TooManyRequestsException (status code 481)
    response = requests.delete(f"{BASE_URL}/v1/email/dedicated-ip-pools/{pool_name}", headers={**headers, "X-Amz-Date": "20230401T000001Z"})
    assert response.status_code == 481
    
    # Test for BadRequestException (status code 482)
    response = requests.delete(f"{BASE_URL}/v1/email/dedicated-ip-pools/{pool_name}", headers={**headers, "X-Amz-Algorithm": ""})
    assert response.status_code == 482
    
    # Test for ConcurrentModificationException (status code 483)
    response = requests.delete(f"{BASE_URL}/v1/email/dedicated-ip-pools/{pool_name}", headers={**headers, "X-Amz-Date": "20230401T000002Z"})
    assert response.status_code == 483