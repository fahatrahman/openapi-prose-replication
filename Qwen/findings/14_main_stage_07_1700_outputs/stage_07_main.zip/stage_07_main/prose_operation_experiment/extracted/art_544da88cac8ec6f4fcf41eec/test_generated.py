import pytest
import requests

BASE_URL = "http://openapi.test"

def test_health_check():
    headers = {
        "Accept-Language": "en-US",
        "exp-api-key": "your_api_key_here"
    }
    params = {
        "apiKey": "your_legacy_api_key_here"
    }
    response = requests.get(f"{BASE_URL}/health/check", headers=headers, params=params)
    assert response.status_code == 200
    assert response.json() == {
        "allGood": True,
        "capiOk": True,
        "dbOk": True,
        "memcachedOk": True,
        "message": "pas"
    }

if __name__ == "__main__":
    pytest.main()