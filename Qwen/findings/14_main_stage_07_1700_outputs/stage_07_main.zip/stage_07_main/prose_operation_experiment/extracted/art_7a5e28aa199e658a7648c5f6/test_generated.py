import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def create_backup_selection(backup_plan_id, backup_selection):
    url = f"{BASE_URL}/backup/plans/{backup_plan_id}/selections/"
    headers = {
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Date": datetime.utcnow().strftime("%Y%m%dT%H%M%SZ"),
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "YOUR_CREDENTIALS",
        "X-Amz-Security-Token": "YOUR_SECURITY_TOKEN",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-algorithm;x-amz-credential;x-amz-security-token"
    }
    response = requests.put(url, json=backup_selection, headers=headers)
    return response.json()

@pytest.mark.parametrize("backup_plan_id, backup_selection", [
    ("plan-id-1", {"BackupSelection": {"SelectionName": "test-selection", "IamRoleArn": "arn:aws:iam::123456789012:role/S3Access", "Conditions": {"StringEquals": [{"ConditionKey": "aws:ResourceTag/CreatedByCryo", "ConditionValue": "true"}]}}}),
])
def test_create_backup_selection(backup_plan_id, backup_selection):
    response = create_backup_selection(backup_plan_id, backup_selection)
    assert response["ResponseMetadata"]["HTTPStatusCode"] == 200
    assert "BackupPlanId" in response
    assert "CreationDate" in response
    assert "SelectionId" in response