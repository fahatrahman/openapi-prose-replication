import pytest
import requests

BASE_URL = "http://openapi.test"

def test_builds_appEncryptionDeclaration_get_to_one_relationship():
    id_value = "example_id"
    url = f"{BASE_URL}/v1/builds/{id_value}/relationships/appEncryptionDeclaration"
    headers = {
        "Authorization": "Bearer your_access_token_here"
    }
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert "data" in response.json()
    assert "id" in response.json()["data"]
    assert response.json()["data"]["type"] == "appEncryptionDeclarations"
    assert "links" in response.json()
    assert "self" in response.json()["links"]

@pytest.mark.parametrize("status_code", [400, 403, 404])
def test_builds_appEncryptionDeclaration_get_to_one_relationship_error(status_code):
    id_value = "example_id"
    url = f"{BASE_URL}/v1/builds/{id_value}/relationships/appEncryptionDeclaration"
    headers = {
        "Authorization": "Bearer your_access_token_here"
    }
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == status_code
    assert "errors" in response.json()
    assert isinstance(response.json()["errors"], list)
    for error in response.json()["errors"]:
        assert "code" in error
        assert "detail" in error
        assert "title" in error
        assert "status" in error