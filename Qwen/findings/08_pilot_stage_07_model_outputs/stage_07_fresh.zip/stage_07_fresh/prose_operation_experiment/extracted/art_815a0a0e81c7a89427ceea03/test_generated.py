import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_resources():
    url = f"{BASE_URL}/consumer/v1/resources"
    params = {
        "locationId": "primary",
        "resourceGroupId": 1,
        "email": "example@example.com",
        "name": "John Doe",
        "sortOrder": "asc",
        "offset": 0,
        "limit": 20
    }
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()