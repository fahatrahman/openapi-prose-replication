import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_recipe():
    url = f"{BASE_URL}/recipes"
    headers = {
        "Content-Type": "application/json",
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Date": "20230401T000000Z",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20230401/us-east-1/sts/aws4_request",
        "X-Amz-Security-Token": "AQoEXAMPLEHILTVKLEKLTRQ==",
        "X-Amz-Signature": "EXAMPLESIGNATURE",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-algorithm;x-amz-credential;x-amz-security-token;x-amz-signedheaders"
    }
    payload = {
        "Name": "test_recipe",
        "Description": "A test recipe",
        "Steps": [
            {
                "Action": {
                    "Operation": "ADD_COLUMN",
                    "Parameters": {
                        "NEW_COLUMN_NAME": "new_column",
                        "VALUE": "default_value"
                    }
                },
                "ConditionExpressions": []
            }
        ],
        "Tags": {
            "key1": "value1"
        }
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert "Name" in response.json()
    assert response.json()["Name"] == "test_recipe"