import pytest
import requests

BASE_URL = "http://openapi.test"

def test_describe_scheduling_policies():
    url = f"{BASE_URL}/v1/describeschedulingpolicies"
    headers = {
        "X-Amz-Content-Sha256": "example-sha256",
        "X-Amz-Date": "20230401T123456Z",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "example-credential",
        "X-Amz-Security-Token": "example-token",
        "X-Amz-Signature": "example-signature",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-algorithm;x-amz-credential;x-amz-security-token"
    }
    payload = {
        "arns": [
            "arn:aws:batch:us-east-1:123456789012:scheduling-policy/HighPriority"
        ]
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "schedulingPolicies" in data
    assert isinstance(data["schedulingPolicies"], list)

if __name__ == "__main__":
    pytest.main()