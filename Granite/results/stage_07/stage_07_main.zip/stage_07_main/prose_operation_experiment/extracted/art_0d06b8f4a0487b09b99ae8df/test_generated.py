import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retry logic
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

# Define test function
@pytest.fixture
def get_payees_invitation_status():
    def _get_payees_invitation_status(
        payor_id,
        payee_id=None,
        invitation_status=None,
        page=1,
        page_size=25,
    ):
        params = {"page": page, "pageSize": page_size}
        if payee_id:
            params["payeeId"] = payee_id
        if invitation_status:
            params["invitationStatus"] = invitation_status

        url = f"{BASE_URL}/v4/payees/payors/{payor_id}/invitationStatus"
        response = session.get(url, params=params)

        response.raise_for_status()
        return response

    return _get_payees_invitation_status

# Example test case using the fixture
def test_get_payees_invitation_status(get_payees_invitation_status):
    payor_id = "f20b038b-e841-4d80-9175-b47c6cf19bc1"
    accepted_invitation = get_payees_invitation_status(
        payor_id, payee_id="c3d60e1f-a4d0-4273-b501-bfa81c70d56b", invitation_status="ACCEPTED"
    )
    assert accepted_invitation.status_code == 200
    result = accepted_invitation.json()
    assert len(result.content) == 1
    assert result.content[0]["payeeId"] == "c3d60e1f-a4d0-4273-b501-bfa81c70d56b"