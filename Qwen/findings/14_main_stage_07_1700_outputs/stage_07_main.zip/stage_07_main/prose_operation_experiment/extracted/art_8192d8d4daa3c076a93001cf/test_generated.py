import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_replication_cycles():
    url = f"{BASE_URL}/v1alpha1/projects/sources/migratingVms.replicationCycles"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token_here",
        "alt": "json",
        "callback": "your_callback_url_here",
        "fields": "*",
        "key": "your_api_key_here",
        "oauth_token": "your_oauth_token_here",
        "prettyPrint": False,
        "quotaUser": "your_quota_user_here",
        "uploadType": "media",
        "upload_protocol": "raw",
        "filter": "your_filter_here",
        "orderBy": "your_order_by_here",
        "pageSize": 100,
        "pageToken": "your_page_token_here"
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    assert "replicationCycles" in response.json()