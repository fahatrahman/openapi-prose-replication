import pytest
import requests
from json import JSONDecodeError

BASE_URL = "http://openapi.test"

def test_pico_load_management_group_get():
    url = f"{BASE_URL}/api/pico/loadmanagementgroup"
    response = requests.get(url)
    
    assert response.status_code == 200
    
    try:
        response_json = response.json()
        assert isinstance(response_json, list)
        
        for item in response_json:
            assert isinstance(item, dict)
            
            required_keys = ["Id", "MaxCurrent", "Name", "NumberOfStations"]
            for key in required_keys:
                assert key in item
                
    except JSONDecodeError:
        pytest.fail("Failed to parse JSON response")