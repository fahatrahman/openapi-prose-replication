import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = "path/to/your/service_account.json"

def get_authenticated_session():
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )
    return requests.Session(), credentials

@pytest.fixture
def http_client():
    session, credentials = get_authenticated_session()

    def _request(method, path, **kwargs):
        headers = {"Authorization": f"Bearer {credentials.token}"}
        url = f"{BASE_URL}{path}"

        response = session.request(method, url, headers=headers, **kwargs)
        response.raise_for_status()
        return response.json()

    yield _request

def test_list_locations(http_client):
    name = "your_resource_name"
    response = http_client("GET", f"/v1/{name}/locations")
    assert response["locations"]
    assert "nextPageToken" in response