import pytest
import requests

BASE_URL = "http://openapi.test"

def test_retrieve_a_digital_wallet_token():
    digital_wallet_token_id = "digital_wallet_token_izi62go3h51p369jrie0"
    url = f"{BASE_URL}/digital_wallet_tokens/{digital_wallet_token_id}"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert response.json()["type"] == "digital_wallet_token"
    assert "id" in response.json()
    assert "card_id" in response.json()
    assert "created_at" in response.json()
    assert "status" in response.json()
    assert "token_requestor" in response.json()
    assert "type" in response.json()

if __name__ == "__main__":
    pytest.main([__file__])