import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_FILE = "credentials.json"


@pytest.fixture
def auth():
    credentials = service_account.Credentials.from_service_account_file(
        CREDENTIALS_FILE, scopes=["https://www.googleapis.com/auth/admin.directory.resource.calendar"]
    )
    return credentials


def get_features(request):
    url = f"{BASE_URL}/admin/directory/v1/customer/my_customer/resources/features"

    headers = {
        "x-goog-api-client": "gl-python",
        "x-goog-api-version": "v1",
        "accept": "application/json",
    }

    response = request.call("GET", url, headers=headers, auth=auth)

    assert response.status_code == 200

    return response.json()


def test_get_features(request):
    features = get_features(request)

    assert isinstance(features, dict)
    assert "features" in features
    assert len(features["features"]) > 0