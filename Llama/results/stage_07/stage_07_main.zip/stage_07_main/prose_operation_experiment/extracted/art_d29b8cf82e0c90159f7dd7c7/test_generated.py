# -*- coding: utf-8 -*-
import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_publishers_list():
    params = {
        "page": 1,
        "page_size": 10,
    }
    response = requests.get(
        urljoin(BASE_URL, "/publishers"),
        params=params,
    )
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data["count"], int)
    assert "next" in data or "next" is None
    assert "previous" in data or "previous" is None
    for publisher in data["results"]:
        assert isinstance(publisher["id"], int)
        assert isinstance(publisher["name"], str)
        assert publisher["name"].isprintable() and publisher["name"].isascii()
        assert isinstance(publisher["slug"], str)
        assert publisher["slug"].isprintable() and publisher["slug"].isascii()
        assert isinstance(publisher["image_background"], str)
        assert publisher["image_background"].startswith("http")
        assert isinstance(publisher["games_count"], int)

if __name__ == "__main__":
    pytest.main([__file__])