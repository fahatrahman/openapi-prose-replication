# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import date

BASE_URL = "http://openapi.test"

def test_GetHolidayBalanceReportOutput():
    employer_key = "GD001"
    holiday_year_end = str(date(2018, 12, 31))
    employee_codes = "VNS001,VNS002"
    start_index = "1"
    max_index = "100"
    authorization_header = "Bearer Auto"
    api_version_header = "default"

    response = requests.get(
        f"{BASE_URL}/Report/HOLBAL/run",
        headers={
            "Authorization": authorization_header,
            "Api-Version": api_version_header
        },
        params={
            "EmployerKey": employer_key,
            "HolidayYearEnd": holiday_year_end,
            "EmployeeCodes": employee_codes,
            "StartIndex": start_index,
            "MaxIndex": max_index
        }
    )

    assert response.status_code == 200, f"Expected status code 200, got {response.status_code}"