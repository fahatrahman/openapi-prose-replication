# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_app_preview_get_instance():
    id = "example-id"
    fields = ["appPreviewSet", "assetDeliveryState"]
    include = ["appPreviewSet"]

    url = f"{BASE_URL}/v1/appPreviews/{id}"
    params = {
        "fields[appPreviews]": ",".join(fields),
        "include": ",".join(include)
    }

    response = requests.get(url, params=params)

    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "data" in data
    assert "links" in data
    assert "appPreviewSet" in data["data"]["relationships"]
    assert "assetDeliveryState" in data["data"]["attributes"]

def test_app_preview_get_instance_400():
    id = "invalid-id"
    fields = ["appPreviewSet", "assetDeliveryState"]
    include = ["appPreviewSet"]

    url = f"{BASE_URL}/v1/appPreviews/{id}"
    params = {
        "fields[appPreviews]": ",".join(fields),
        "include": ",".join(include)
    }

    response = requests.get(url, params=params)

    assert response.status_code == 400
    error_response = response.json()
    assert isinstance(error_response, dict)
    assert "errors" in error_response

def test_app_preview_get_instance_403():
    id = "example-id"
    fields = ["appPreviewSet", "assetDeliveryState"]
    include = ["appPreviewSet"]

    url = f"{BASE_URL}/v1/appPreviews/{id}"
    params = {
        "fields[appPreviews]": ",".join(fields),
        "include": ",".join(include)
    }
    headers = {"Authorization": "Bearer invalid-token"}

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 403
    error_response = response.json()
    assert isinstance(error_response, dict)
    assert "errors" in error_response

def test_app_preview_get_instance_404():
    id = "non-existent-id"
    fields = ["appPreviewSet", "assetDeliveryState"]
    include = ["appPreviewSet"]

    url = f"{BASE_URL}/v1/appPreviews/{id}"
    params = {
        "fields[appPreviews]": ",".join(fields),
        "include": ",".join(include)
    }

    response = requests.get(url, params=params)

    assert response.status_code == 404
    error_response = response.json()
    assert isinstance(error_response, dict)
    assert "errors" in error_response