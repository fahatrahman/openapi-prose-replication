import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Retry mechanism for requests
retries = Retry(
    total=5,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
adapter = HTTPAdapter(max_retries=retries)
http = requests.Session()
http.mount("https://", adapter)
http.mount("http://", adapter)
requests.adapters.HTTPAdapter.max_retries = retries

# Security credentials
OAUTH2_TOKEN = os.environ.get("OAUTH2_TOKEN")

@pytest.fixture
def create_history():
    payload = {
        "displayName": "Test History",
        "name": "test-history",
        "testPlatform": "android"
    }

    headers = {
        "Content-Type": "application/json"
    }

    if OAUTH2_TOKEN:
        headers["Authorization"] = f"Bearer {OAUTH2_TOKEN}"

    response = http.post(
        f"{BASE_URL}/toolresults/v1beta3/projects/your_project_id/histories",
        json=payload,
        headers=headers
    )

    assert response.status_code == 200, f"Request failed with status code {response.status_code}"

    return response.json()