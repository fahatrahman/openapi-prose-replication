import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_healthcare_projects_locations_datasets_fhir_stores_fhir_Patient_everything():
    # Given
    name = "example_name"
    _count = 100
    _page_token = None
    _since = None
    _type = None
    end = None
    start = None

    # When
    params = {
        "name": name,
        "_count": _count,
        "_page_token": _page_token,
        "_since": _since,
        "_type": _type,
        "end": end,
        "start": start,
    }
    headers = {"Accept": "application/json"}
    response = requests.get(
        f"{BASE_URL}/v1/{name}/$everything",
        headers=headers,
        params=params,
    )

    # Then
    assert response.status_code == 200
    response.raise_for_status()
    assert response.headers["Content-Type"] == "application/json"