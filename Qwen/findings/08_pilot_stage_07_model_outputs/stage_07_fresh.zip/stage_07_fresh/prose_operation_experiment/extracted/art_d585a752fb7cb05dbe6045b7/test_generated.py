import pytest
import requests

BASE_URL = "http://openapi.test"

def test_post_holiday_scheme_into_employer():
    url = f"{BASE_URL}/Employer/{pytest.EmployerId}/HolidaySchemes"
    headers = {
        "Authorization": pytest.Authorization,
        "Api-Version": pytest.Api_Version
    }
    payload = {
        "HolidayScheme": {
            "AccrualPayCodes": {
                "PayCode": ["code1", "code2"]
            },
            "AllowExceedAnnualEntitlement": True,
            "AllowNegativeBalance": False,
            "AnnualEntitlementWeeks": 52.0,
            "BankHolidayInclusive": True,
            "Code": "scheme_code",
            "EffectiveDate": "2023-01-01",
            "MaxCarryOverDays": 30.0,
            "NextRevisionDate": "2024-01-01",
            "OffsetPayment": False,
            "Revision": 1,
            "SchemeCeasedDate": None,
            "SchemeKey": "key123",
            "SchemeName": "Test Scheme",
            "YearStartDay": 1,
            "YearStartMonth": 1
        }
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 201
    assert "Location" in response.headers

@pytest.fixture(autouse=True)
def setup_teardown(request):
    pytest.EmployerId = "test_employer_id"
    pytest.Authorization = "Bearer test_token"
    pytest.Api_Version = "1.0"

    yield

    del pytest.EmployerId
    del pytest.Authorization
    del pytest.Api_Version