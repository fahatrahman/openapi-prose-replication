import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

@pytest.fixture
def headers():
    return {
        "Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed",
    }

@pytest.mark.parametrize(
    "request_body, expected_response, supported_brands",
    [
        (
            {"cardNumber": "411111", "merchantAccount": "YOUR_MERCHANT_ACCOUNT"},
            {"brands": [{"supported": True, "type": "visa"}, {"supported": False, "type": "cartebancaire"}]},
            ["visa", "mc", "amex"],
        ),
        (
            {"cardNumber": "411111", "merchantAccount": "YOUR_MERCHANT_ACCOUNT", "supportedBrands": ["visa", "mc", "amex"]},
            {"brands": [{"supported": True, "type": "visa"}, {"supported": True, "type": "mc"}, {"supported": True, "type": "amex"}]},
            ["visa", "mc", "amex"],
        ),
    ],
)
def test_card_details(request_body, expected_response, supported_brands):
    url = f"{BASE_URL}/cardDetails"

    response = requests.post(url, json=request_body, headers=headers, auth=HTTPBasicAuth("username", "password"))

    assert response.status_code == 200
    assert response.json() == expected_response
    for brand in response.json()["brands"]:
        assert brand["type"] in supported_brands