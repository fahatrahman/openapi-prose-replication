import os
import pytest
import requests
from google.rpc import Status_codes

BASE_URL = "http://openapi.test"
HEADERS = {"content-type": "application/json"}
AUTH_ SCOPES = ["https://www.googleapis.com/auth/cloud_search.indexing"]


@pytest.fixture
def setup():
    return BASE_URL


def delete_item(setup, name, connector_name=None, mode="ASYNCHRONOUS", version=None):
    endpoint = f"/v1/indexing/{name}"
    params = {
        "_": "1.1",
        "connectorName": connector_name,
        "debugOptions.enableDebugging": False,
        "mode": mode,
        "version": version,
    }

    response = requests.delete(f"{setup}{endpoint}", headers=HEADERS, params=params)
    response.raise_for_status()

    return response.json()


def test_delete_item(setup, name, connector_name=None, mode="ASYNCHRONOUS", version=None):
    result = delete_item(setup, name, connector_name, mode, version)
    assert isinstance(result, dict)
    assert result.get("done") is True
    assert result.get("error") is None
    assert result.get("response").get("@type") == "type.googleapis.com/google.cloud.cloudsearch.v1.Operation"