# -*- coding: utf-8 -*-

import pytest
import requests
from uuid import uuid4

BASE_URL = "http://openapi.test"

def test_create_file_association():
    # Generate a random Xero tenant ID
    xero_tenant_id = str(uuid4())

    # Create a new file association
    headers = {"xero-tenant-id": xero_tenant_id}
    response = requests.post(
        f"{BASE_URL}/Files/{str(uuid4())}/Associations",
        headers=headers,
        json={
            "ObjectId": str(uuid4()),
            "ObjectGroup": "Contact",
            "ObjectType": "Business"
        }
    )

    # Check if the response was successful
    assert response.status_code == 201

    # Parse the JSON response
    response_json = response.json()

    # Check if the response contains the expected fields
    assert "FileId" in response_json
    assert "ObjectId" in response_json
    assert "ObjectType" in response_json
    assert "ObjectGroup" in response_json

# Run the tests
pytest.main([__file__, "-v"])