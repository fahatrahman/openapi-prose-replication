# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime
from uuid import UUID

class TestCreateImagesFromFiles:
    @pytest.fixture(autouse=True)
    def setup(self):
        global BASE_URL
        BASE_URL = "http://openapi.test"

    def test_create_images_from_files(self):
        # Prepare API key
        api_key = "your_api_key_here"

        # Prepare project ID
        project_id = UUID("64b822c5-8082-4b36-a426-27225f4aa18c")

        # Prepare image files
        image_file_data = {
            "images": [
                {"contents": "image_data", "name": "image_name"},
                {"contents": "another_image_data", "name": "another_image_name"}
            ],
            "tagIds": []
        }

        # Send POST request
        response = requests.post(
            f"{BASE_URL}/projects/{project_id}/images/files",
            headers={"Training-Key": api_key},
            json=image_file_data,
            allow_redirects=False
        )

        # Check status code
        assert response.status_code == 200

        # Check response content
        response_content = response.json()
        assert isinstance(response_content, dict)
        assert "images" in response_content
        assert len(response_content["images"]) > 0
        for image in response_content["images"]:
            assert isinstance(image, dict)
            assert "imageUri" in image
            assert "sourceUrl" in image
            assert "status" in image
            assert image["status"] in ["OK", "OKDuplicate", "ErrorSource", "ErrorImageFormat", "ErrorImageSize", "ErrorStorage", "ErrorLimitExceed", "ErrorTagLimitExceed", "ErrorRegionLimitExceed", "ErrorUnknown"]

    def test_create_images_from_files_invalid_project_id(self):
        # Prepare API key
        api_key = "your_api_key_here"

        # Prepare invalid project ID
        project_id = "invalid_project_id"

        # Prepare image files
        image_file_data = {
            "images": [
                {"contents": "image_data", "name": "image_name"},
                {"contents": "another_image_data", "name": "another_image_name"}
            ],
            "tagIds": []
        }

        # Send POST request
        response = requests.post(
            f"{BASE_URL}/projects/{project_id}/images/files",
            headers={"Training-Key": api_key},
            json=image_file_data,
            allow_redirects=False
        )

        # Check status code
        assert response.status_code >= 400

if __name__ == "__main__":
    pytest.main([__file__])