import pytest
import requests
from datetime import datetime, timedelta

BASE_URL = "http://openapi.test"

def test_migrationcenter_projects_locations_sources_delete():
    name = "example"
    request_id = str(int(datetime.now().timestamp()))
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json; charset=utf-8"
    }
    params = {
        "$.xgafv": "1",
        "access_token": "",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "",
        "oauth_token": "",
        "prettyPrint": "false",
        "quotaUser": "",
        "uploadType": "media",
        "upload_protocol": "jnr",
        "requestId": request_id,
        "name": name
    }

    response = requests.delete(f"{BASE_URL}/v1/{name}", headers=headers, params=params)

    assert response.status_code == 200
    assert response.json()["name"] == name
    assert response.json()["done"]