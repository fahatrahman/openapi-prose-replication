import pytest
import requests
from datetime import timezone
import uuid

BASE_URL = "http://openapi.test"

def test_migrationcenter_projects_locations_sources_delete():
    name = "source_name"
    headers = {
        'Content-Type': 'application/json',
    }
    params = {
        '$.xgafv': '1',
        'access_token': None,
        'alt': 'json',
        'callback': None,
        'fields': None,
        'key': None,
        'oauth_token': None,
        'prettyPrint': 'true',
        'quotaUser': None,
        'upload_protocol': None,
        'uploadType': None,
        'requestId': str(uuid.uuid4()),
    }

    try:
        response = requests.request(
            method="DELETE",
            url=f"{BASE_URL}/v1/{name}",
            headers=headers,
            params=params,
        )
        assert response.status_code == 200
    except requests.exceptions.RequestException as e:
        print(f"Error sending request: {e}")
        raise