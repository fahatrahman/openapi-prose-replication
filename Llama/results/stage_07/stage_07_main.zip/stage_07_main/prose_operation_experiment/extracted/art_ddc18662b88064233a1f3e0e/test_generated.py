import pytest
import requests
from jsonschema import validate
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_submit_third_party():
    url = f"{BASE_URL}/submitThirdParty"
    
    body = {
        "amount": {"currency": "EUR", "value": 1000},
        "dateOfBirth": "1990-01-01",
        "entityType": "Company",
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "nationality": "NL",
        "recurring": {"contract": "PAYOUT"},
        "reference": "PayoutPayment-0001",
        "selectedRecurringDetailReference": "LATEST",
        "shopperEmail": "shopper@email.com",
        "shopperName": {"firstName": "Adyen", "lastName": "Test"},
        "shopperReference": "YOUR_UNIQUE_SHOPPER_ID"
    }
    
    headers = {'Content-Type': 'application/json'}
    response = requests.post(url, headers=headers, json=body)
    
    assert response.status_code == 200
    
    try:
        schema_url = f"{BASE_URL}/components/schemas/SubmitResponse"
        schema_response = requests.get(schema_url)
        schema = schema_response.json()
        
        validate(instance=response.json(), schema=schema)
    except Exception as e:
        pytest.fail(f"Failed to validate response against schema: {str(e)}")