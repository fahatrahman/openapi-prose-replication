import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_attributes():
    url = f"{BASE_URL}/v1/{name}"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token",
        "alt": "json",
        "callback": "your_callback",
        "fields": "your_fields",
        "key": "your_api_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": True,
        "quotaUser": "your_quota_user",
        "uploadType": "your_upload_type",
        "upload_protocol": "your_upload_protocol"
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()