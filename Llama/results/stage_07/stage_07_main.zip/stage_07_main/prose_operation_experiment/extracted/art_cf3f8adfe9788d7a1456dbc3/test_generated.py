# pylint: disable=invalid-name, unused-import
import pytest
import requests

BASE_URL = "http://openapi.test"

def test_comment_creation():
    """Test creation of comment"""
    song_id = 12345
    comment_data = {
        "author": {"id": 67890},
        "authorName": None,
        "created": None,
        "entry": {"id": song_id},
        "id": 54321,
        "message": "Hello, world!"
    }
    response = requests.post(
        f"{BASE_URL}/api/songs/{song_id}/comments",
        json=comment_data,
        headers={"Content-Type": "application/json"}
    )
    assert response.status_code == 200
    response_json = response.json()
    expected_schema = {
        "additionalProperties": False,
        "properties": {
            "author": {"$ref": "#/components/schemas/UserForApiContract"},
            "authorName": {"nullable": True, "type": "string"},
            "created": {"format": "date-time", "type": "string"},
            "entry": {"$ref": "#/components/schemas/EntryForApiContract"},
            "id": {"format": "int32", "type": "integer"},
            "message": {"nullable": True, "type": "string"}
        },
        "type": "object"
    }
    assert response_json == comment_data