import pytest
import requests

BASE_URL = "http://openapi.test"

def test_cloudfunctions_projects_locations_list():
    url = f"{BASE_URL}/v2alpha/projects/my-project/locations"
    params = {
        "_xgafv": "1",
        "access_token": "dummy_access_token",
        "alt": "json",
        "callback": "dummy_callback",
        "fields": "locations(name,displayName)",
        "key": "dummy_key",
        "oauth_token": "dummy_oauth_token",
        "prettyPrint": False,
        "quotaUser": "dummy_quota_user",
        "uploadType": "media",
        "upload_protocol": "raw",
        "name": "projects/my-project",
        "filter": "status=ACTIVE",
        "pageSize": 10,
        "pageToken": ""
    }
    headers = {
        "Authorization": "Bearer dummy_bearer_token"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()