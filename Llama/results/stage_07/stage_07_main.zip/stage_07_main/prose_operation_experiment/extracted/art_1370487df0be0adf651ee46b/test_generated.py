# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime
from uuid import UUID

BASE_URL = "http://openapi.test"

def test_get_bank_feeds():
    url = f"{BASE_URL}/companies/{UUID('8a210b68-6988-11ed-a1eb-0242ac120002')}/connections/{UUID('2e9d2c44-f675-40ba-8049-353bfcb5e171')}/connectionInfo/bankFeedAccounts"
    
    headers = {
        'Authorization': 'Basic YOUR_API_KEY'
    }
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    
    try:
        response_json = response.json()
    except ValueError:
        print(response.text)
        pytest.fail("Failed to parse JSON response")
    
    assert isinstance(response_json, list)
    for item in response_json:
        assert isinstance(item, dict)
        assert 'id' in item
        assert 'accountName' in item or 'accountNumber' in item or 'accountType' in item
        if 'accountName' in item:
            assert isinstance(item['accountName'], str) or item['accountName'] is None
        else:
            assert isinstance(item['accountNumber'], str) or item['accountNumber'] is None
        if 'accountType' in item:
            assert isinstance(item['accountType'], str) or item['accountType'] is None
        assert 'balance' in item or 'balance' not in item
        if 'balance' in item:
            assert isinstance(item['balance'], (int, float))
        assert 'currency' in item or 'currency' not in item
        if 'currency' in item:
            assert isinstance(item['currency'], str) or item['currency'] is None
        assert 'feedStartDate' in item or 'feedStartDate' not in item
        if 'feedStartDate' in item:
            assert isinstance(item['feedStartDate'], str)
            assert datetime.strptime(item['feedStartDate'], '%Y-%m-%dT%H:%M:%SZ').strftime('%Y-%m-%dT%H:%M:%SZ')
        assert 'modifiedDate' in item or 'modifiedDate' not in item
        if 'modifiedDate' in item:
            assert isinstance(item['modifiedDate'], str)
            assert datetime.strptime(item['modifiedDate'], '%Y-%m-%dT%H:%M:%SZ').strftime('%Y-%m-%dT%H:%M:%SZ')
        assert 'sortCode' in item or 'sortCode' not in item
        if 'sortCode' in item:
            assert isinstance(item['sortCode'], str) or item['sortCode'] is None
        assert 'status' in item or 'status' not in item
        if 'status' in item:
            assert isinstance(item['status'], str) or item['status'] is None