import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_TaskLogs():
    id = "c2ada9df5af8"
    details = True
    follow = False
    stdout = False
    stderr = False
    since = 0
    timestamps = False
    tail = "all"

    url = urljoin(BASE_URL, "/tasks/{}/logs".format(id))
    params = {
        "details": details,
        "follow": follow,
        "stdout": stdout,
        "stderr": stderr,
        "since": since,
        "timestamps": timestamps,
        "tail": tail
    }

    response = requests.get(url, params=params)

    assert response.status_code == 200, response.text

def test_TaskLogs_not_found():
    id = "non-existent-task-id"
    url = urljoin(BASE_URL, "/tasks/{}/logs".format(id))

    response = requests.get(url)

    assert response.status_code == 404, response.text

def test_TaskLogs_invalid_response():
    id = "c2ada9df5af8"
    url = urljoin(BASE_URL, "/tasks/{}/logs".format(id))

    response = requests.get(url, headers={"Accept": "text/plain"})

    assert response.status_code in (500, 503), response.text

def test_TaskLogs_binary_response():
    id = "c2ada9df5af8"
    url = urljoin(BASE_URL, "/tasks/{}/logs".format(id))

    response = requests.get(url, stream=True)

    assert response.status_code == 101, response.text