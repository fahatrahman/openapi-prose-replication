import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_PATH = "path/to/credentials.json"

def get_authenticated_session():
    credentials = service_account.Credentials.from_service_account_file(
        CREDENTIALS_PATH, scopes=["https://www.googleapis.com/auth/display-video-user-management"]
    )
    return requests.Session(), credentials

@pytest.fixture
def http_client():
    session, credentials = get_authenticated_session()
    return session

def test_get_user(http_client):
    user_id = "TEST_USER_ID"  # Replace with actual user ID
    url = f"{BASE_URL}/v3/users/{user_id}"

    response = http_client.get(url)
    response.raise_for_status()

    user = response.json()["data"]
    assert user["displayName"]
    assert user["email"]
    assert user["lastLoginTime"]
    assert user["name"]
    assert user["userId"]