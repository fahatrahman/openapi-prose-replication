import pytest
import requests

BASE_URL = "http://openapi.test"

def test_order_types_delete():
    url = f"{BASE_URL}/pos/order-types/{id}"
    headers = {
        "x-apideck-app-id": "dSBdXd2H6Mqwfg0atXHXYcysLJE9qyn1VwBtXHX",
        "x-apideck-consumer-id": "LGcoajhjkubpslsrukwdlfzeqcywdqibsgvrrfstzfaetu",
        "x-apideck-service-id": "Fuznyjiajhjqlxfuzlglfzeqcywdfunrhxqiodrbljawtpjkubpslsyhhvvuehcgkaijsewxpngkbsmzkykmqc"
    }
    params = {
        "raw": False
    }
    
    response = requests.delete(url, headers=headers, params=params)
    
    assert response.status_code == 200
    assert "data" in response.json()
    assert "operation" in response.json()
    assert response.json()["operation"] == "delete"
    assert "resource" in response.json()
    assert response.json()["resource"] == "OrderTypes"
    assert "service" in response.json()
    assert response.json()["service"] == "clover"
    assert "status" in response.json()
    assert response.json()["status"] == "OK"
    assert "status_code" in response.json()
    assert response.json()["status_code"] == 200