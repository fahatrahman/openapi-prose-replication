import os
import requests
import pytest
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Set up retry strategy for requests
retries = Retry(
    total=5,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
adapter = HTTPAdapter(max_retries=retries)
http = requests.Session()
http.mount("https://", adapter)
http.mount("http://", adapter)

requests.models.Request.space_separator_char = '_'

# Define security headers
headers = {
    "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
    "X-Amz-Credential": os.environ["AWS_ACCESS_KEY_ID"] + "/"os.environ["AWS_SECRET_ACCESS_KEY"],
    "X-Amz-Date": os.environ["AWS_DATE_FORMAT"],
    "X-Amz-Security-Token": os.environ["AWS_SESSION_TOKEN"] if os.environ["AWS_SESSION_TOKEN"] else "",
    "X-Amz-SignedHeaders": "host;x-amz-date",
}

@pytest.mark.parametrize("detector_id, threat_intel_set_id, active, location, name", [
    ("detector_example", "threat_intel_set_example", True, "example_location", "example_name"),
])
def test_update_threat_intel_set(detector_id, threat_intel_set_id, active, location, name):
    url = f"{BASE_URL}/detector/{detector_id}/threatintelset/{threat_intel_set_id}"

    payload = {
        "active": active,
        "location": location,
        "name": name,
    }

    response = http.post(url, json=payload, headers=headers)

    assert response.status_code == 200, f"Received status code {response.status_code} instead of 200"