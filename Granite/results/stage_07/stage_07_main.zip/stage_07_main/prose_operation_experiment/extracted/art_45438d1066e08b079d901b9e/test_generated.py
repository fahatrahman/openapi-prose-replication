import os
import pytest
import requests
from google.api_core.exceptions import GoogleAPICallError
from google.auth import default
from googleapiclient.discovery import build

BASE_URL = "http://openapi.test"

@pytest.fixture
def auth():
    credentials, _ = default()
    return credentials

@pytest.mark.parametrize("partner_id", ["your_partner_id"])
def test_claim_async(partner_id, auth):
    service = build('androiddeviceprovisioning', 'v1', credentials=auth)

    request_body = {
        "claims": [
            {
                "configurationId": 1234567890,
                "customerId": 1234567890,
                "deviceIdentifier": {
                    "chromeOsAttestedDeviceId": "example_device_id",
                    "deviceType": "DEVICE_TYPE_ANDROID",
                    "imei": "example_imei",
                    "manufacturer": "example_manufacturer",
                    "meid": "example_meid",
                    "model": "example_model",
                    "serialNumber": "example_serial_number"
                },
                "deviceMetadata": {
                    "entry1": "value1",
                    "entry2": "value2"
                },
                "googleWorkspaceCustomerId": "example_workspace_customer_id",
                "preProvisioningToken": "example_token",
                "sectionType": "SECTION_TYPE_SIM_LOCK",
                "simlockProfileId": 1234567890
            }
        ]
    }

    try:
        response = service.partners().devices().claimAsync(
            partnerId=partner_id, body=request_body).execute()

        assert response['done'] == True
        assert response['error'] is None
        print("Test successful")
    except GoogleAPICallError as error:
        print(f"An error occurred: {error}")
    except Exception as e:
        print(f"Unexpected error: {str(e)}")