import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["POST"],
)
SESSION.mount("https://", HTTPAdapter(max_retries=RETRY_STRATEGY))
SESSION.mount("http://", HTTPAdapter(max_retries=RETRY_STRATEGY))

@pytest.fixture
def headers():
    return {
        "Authorization": "Amazon Signature v4",
        "X-Amz-Content-Sha256": "sha256_hash_value",
        "X-Amz-Date": "date_timestamp",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "credential=access_key/session/region/service/20210101/s3/aws4_request",
        "X-Amz-Security-Token": "token",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date",
    }

@pytest.mark.parametrize("data", [
    {
        "filters": [
            {
                "name": "name",
                "values": ["filter_value"]
            }
        ],
        "maxResults": "10",
        "versionQualifier": "ALL"
    }
])
def test_list_simulation_applications(data):
    url = f"{BASE_URL}/listSimulationApplications"
    response = SESSION.post(url, json=data, headers=headers())

    assert response.status_code == 200, f"Received status code {response.status_code}"

    result = response.json()
    # Add assertions based on expected response structure here