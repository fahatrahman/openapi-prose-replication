import pytest
import requests

BASE_URL = "http://openapi.test"

def test_options_events():
    url = f"{BASE_URL}/events"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    response = requests.options(url, headers=headers)
    assert response.status_code == 200
    assert 'Content-Type' in response.headers
    assert response.headers['Content-Type'] == 'application/json'
    assert 'RealtimeServers' in response.json()

def test_options_events_unauthorized():
    url = f"{BASE_URL}/events"
    headers = {}
    response = requests.options(url, headers=headers)
    assert response.status_code == 401
    assert 'Content-Type' in response.headers
    assert response.headers['Content-Type'] == 'application/json'
    assert 'ClientError' in response.json()
    client_error = response.json()['ClientError']
    assert client_error['type'] == 'error'
    assert client_error['message'] == 'Unauthorized'

if __name__ == "__main__":
    pytest.main([__file__])