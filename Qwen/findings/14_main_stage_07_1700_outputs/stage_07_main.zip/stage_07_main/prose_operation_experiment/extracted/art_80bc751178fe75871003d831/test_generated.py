import pytest
import requests

BASE_URL = "http://openapi.test"

def test_query_predictions():
    headers = {
        "Training-Key": "{API Key}"
    }
    params = {
        "projectId": "bc3f7dad-5544-468c-8573-3ef04d55463e"
    }
    response = requests.post(
        f"{BASE_URL}/projects/{params['projectId']}/predictions/query",
        headers=headers,
        json={
            "application": "",
            "continuation": "",
            "maxCount": 0,
            "orderBy": "Newest",
            "session": "1:286613",
            "tags": [
                {
                    "id": "b5f7e6a2-a481-49a6-afec-a7cef1af3544",
                    "maxThreshold": 1,
                    "minThreshold": 0.9
                }
            ]
        }
    )
    assert response.status_code == 200
    data = response.json()
    assert "results" in data
    assert isinstance(data["results"], list)
    for result in data["results"]:
        assert "created" in result
        assert "domain" in result
        assert "id" in result
        assert "iteration" in result
        assert "originalImageUri" in result
        assert "predictions" in result
        assert "project" in result
        assert "resizedImageUri" in result
        assert "thumbnailUri" in result
        for prediction in result["predictions"]:
            assert "probability" in prediction
            assert "tagId" in prediction
            assert "tagName" in prediction