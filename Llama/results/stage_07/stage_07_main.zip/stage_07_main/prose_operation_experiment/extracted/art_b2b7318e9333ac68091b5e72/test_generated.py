# -*- coding: utf-8 -*-
"""Test module for Operation slice."""
import json
import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_erc20_options():
    """Test GET /erc20/{address} options response."""
    address = "example_address"
    url = urljoin(BASE_URL, f"/erc20/{address}")
    headers = {"Accept": "application/json"}
    
    response = requests.options(url, headers=headers)
    
    assert response.status_code == 200
    assert response.headers.get("Access-Control-Allow-Headers")
    assert response.headers.get("Access-Control-Allow-Methods")
    assert response.headers.get("Access-Control-Allow-Origin")

def test_erc20_options_empty_body():
    """Test if the body is empty in the options response."""
    address = "example_address"
    url = urljoin(BASE_URL, f"/erc20/{address}")
    headers = {"Accept": "application/json"}
    
    response = requests.options(url, headers=headers)
    
    assert response.json() == {}