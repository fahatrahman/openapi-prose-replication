# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_conversation():
    params = {
        'StartDate': '2022-01-01T00:00:00I',
        'EndDate': '2022-12-31T23:59:59I',
        'State': 'active',
        'PageSize': 50,
        'Page': 0,
        'PageToken': ''
    }

    response = requests.get(
        f'{BASE_URL}/v1/Conversations', 
        auth=('your_account_sid', 'your_auth_token'), 
        params=params
    )

    assert response.status_code == 200