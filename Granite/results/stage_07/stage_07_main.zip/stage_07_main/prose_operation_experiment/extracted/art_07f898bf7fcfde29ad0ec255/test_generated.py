import os
import json
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Define request session with retries
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["HEAD", "GET", "OPTIONS"],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

# Define headers for security schemes
headers = {
    "PLAID-CLIENT-ID": os.getenv("PLAID-CLIENT-ID"),
    "Plaid-Version": os.getenv("PLAID-VERSION"),
    "PLAID-SECRET": os.getenv("PLAID-SECRET"),
}

def test_credit_payroll_income_precheck():
    endpoint = "/credit/payroll_income/precheck"

    # Sample request body for CreditPayrollIncomePrecheckRequest
    request_body = {
        "access_tokens": [
            {"access_token": "sample_access_token"},
        ],
        "client_id": "sample_client_id",
        "employer": {
            "address": {"city": "New York", "country": "US", "postal_code": "10001", "region": "NY", "street": "564 Zdfx Gnapxx, ZRL 15"},
            "name": "Sample Employer",
            "tax_id": "123456789",
            "url": "https://www.sampleemployer.com",
        },
        "payroll_institution": {"name": "Sample Payroll Institution"},
        "secret": "sample_secret",
        "us_military_info": {"branch": "ARMY", "is_active_duty": True},
        "user_token": "sample_user_token",
    }

    response = session.post(
        f"{BASE_URL}{endpoint}",
        headers=headers,
        json=request_body,
    )

    assert response.status_code == 200
    result = response.json()

    # Assertions can be added here based on expected response format

if __name__ == "__main__":
    pytest.main([__file__])