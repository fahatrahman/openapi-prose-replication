# -*- coding: utf-8 -*-

import pytest
import requests
from jsonschema import ValidationError
from jsonschema.exceptions import SchemaError
import json

BASE_URL = "http://openapi.test"

def create_asset(data):
    url = f"{BASE_URL}/assets"
    headers = {
        'X-Amz-Algorithm': '',
        'X-Amz-Content-Sha256': '',
        'X-Amz-Credential': '',
        'X-Amz-Date': '',
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': '',
        'X-Amz-SignedHeaders': ''
    }
    response = requests.post(url, headers=headers, json=data)
    assert response.status_code == 200, f"Unexpected status code {response.status_code}"
    return response.json()

def test_create_asset():
    data = {
        "id": "",
        "packagingGroupId": "",
        "resourceId": "",
        "sourceArn": "",
        "sourceRoleArn": "",
        "tags": {}
    }
    try:
        create_asset(data)
    except (ValidationError, SchemaError) as e:
        pytest.fail(f"Invalid schema: {e}")

def test_create_asset_success():
    data = {
        "id": "test-id",
        "packagingGroupId": "test-packaging-group-id",
        "resourceId": "test-resource-id",
        "sourceArn": "test-source-arn",
        "sourceRoleArn": "test-source-role-arn",
        "tags": {"key": "value"}
    }
    result = create_asset(data)
    assert isinstance(result, dict), f"Unexpected type {type(result)}"
    assert all(key in result for key in ["Arn", "CreatedAt", "EgressEndpoints", "Id", "PackagingGroupId", "ResourceId", "SourceArn", "SourceRoleArn", "Tags"]), f"Missing keys {set(result.keys()) - {'Arn', 'CreatedAt', 'EgressEndpoints', 'Id', 'PackagingGroupId', 'ResourceId', 'SourceArn', 'SourceRoleArn', 'Tags'}}"

if __name__ == "__main__":
    pytest.main([__file__, "-vv"])