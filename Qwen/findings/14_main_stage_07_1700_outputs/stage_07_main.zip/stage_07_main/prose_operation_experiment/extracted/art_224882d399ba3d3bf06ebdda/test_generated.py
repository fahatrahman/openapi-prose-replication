import pytest
import requests

BASE_URL = "http://openapi.test"

def test_adsense_accounts_adclients_urlchannels_list():
    url = f"{BASE_URL}/v2/accounts/adclients/urlchannels"
    params = {
        "_xgafv": "1",
        "access_token": "example_access_token",
        "alt": "json",
        "callback": "example_callback",
        "fields": "nextPageToken,urlChannels(name,reportingDimensionId,uriPattern)",
        "key": "example_key",
        "oauth_token": "example_oauth_token",
        "prettyPrint": False,
        "quotaUser": "example_quota_user",
        "uploadType": "media",
        "upload_protocol": "raw",
        "parent": "tjnnzcqy/example_yjurfrb/xvyuycpyg/example_mkdadvrc/mkbtufsxwil/example_vujktwctaf",
        "pageSize": 10000,
        "pageToken": ""
    }
    headers = {
        "Authorization": "Bearer example_bearer_token"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    assert "nextPageToken" in response.json()
    assert "urlChannels" in response.json()

if __name__ == "__main__":
    pytest.main()