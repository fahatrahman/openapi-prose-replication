# Generated pytest module using the provided OpenAPI operation.

import pytest
import requests
from jsonschema import ValidationError, validate

BASE_URL = "http://openapi.test"

def test_get_placement_groups():
    # Test case for GET /placement_groups
    params = {
        "sort": "id",
        "name": "my Placement Group",
        "label_selector": "",
        "type": "spread"
    }
    
    try:
        response = requests.get(f"{BASE_URL}/placement_groups", params=params)
        response.raise_for_status()
        
        schema = {
            "type": "object",
            "properties": {
                "meta": {
                    "type": "object",
                    "properties": {
                        "pagination": {
                            "type": "object",
                            "properties": {
                                "last_page": {"type": "integer"},
                                "next_page": {"type": "integer"},
                                "page": {"type": "integer"},
                                "per_page": {"type": "integer"},
                                "previous_page": {"type": "integer"},
                                "total_entries": {"type": ["integer", "null"]}
                            },
                            "required": ["page", "per_page", "previous_page", "next_page", "last_page", "total_entries"]
                        }
                    },
                    "required": ["pagination"]
                },
                "placement_groups": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "created": {"type": "string"},
                            "id": {"type": "integer"},
                            "labels": {"type": "object"},
                            "name": {"type": "string"},
                            "servers": {"type": "array", "items": {"type": "integer"}},
                            "type": {"type": "string"}
                        },
                        "required": ["id", "name", "labels", "type", "created", "servers"]
                    }
                }
            },
            "required": ["meta", "placement_groups"]
        }
        
        validate(instance=response.json(), schema=schema)
        
        assert response.status_code == 200
        
    except requests.RequestException as e:
        pytest.fail(str(e))