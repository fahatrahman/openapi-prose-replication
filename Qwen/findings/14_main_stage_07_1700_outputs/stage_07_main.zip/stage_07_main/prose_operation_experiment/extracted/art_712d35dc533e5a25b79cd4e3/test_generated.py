import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_air_traffic():
    params = {
        "cityCode": "MAD",
        "period": "2017"
    }
    response = requests.get(f"{BASE_URL}/travel/analytics/air-traffic/busiest-period", params=params)
    assert response.status_code == 200
    data = response.json()
    assert "data" in data
    assert isinstance(data["data"], list)
    assert len(data["data"]) >= 1
    for item in data["data"]:
        assert "analytics" in item
        assert "travelers" in item["analytics"]
        assert "score" in item["analytics"]["travelers"]
        assert isinstance(item["analytics"]["travelers"]["score"], int)
        assert "period" in item
        assert isinstance(item["period"], str)
        assert "type" in item
        assert isinstance(item["type"], str)

def test_invalid_city_code():
    params = {
        "cityCode": "XXX",
        "period": "2017"
    }
    response = requests.get(f"{BASE_URL}/travel/analytics/air-traffic/busiest-period", params=params)
    assert response.status_code == 400
    data = response.json()
    assert "errors" in data
    assert isinstance(data["errors"], list)
    for error in data["errors"]:
        assert "code" in error
        assert error["code"] in [477, 572, 2781, 4926, 32171]
        assert "title" in error
        assert isinstance(error["title"], str)

def test_invalid_period():
    params = {
        "cityCode": "MAD",
        "period": "XXXX"
    }
    response = requests.get(f"{BASE_URL}/travel/analytics/air-traffic/busiest-period", params=params)
    assert response.status_code == 400
    data = response.json()
    assert "errors" in data
    assert isinstance(data["errors"], list)
    for error in data["errors"]:
        assert "code" in error
        assert error["code"] in [477, 572, 2781, 4926, 32171]
        assert "title" in error
        assert isinstance(error["title"], str)

def test_invalid_direction():
    params = {
        "cityCode": "MAD",
        "period": "2017",
        "direction": "INVALID"
    }
    response = requests.get(f"{BASE_URL}/travel/analytics/air-traffic/busiest-period", params=params)
    assert response.status_code == 400
    data = response.json()
    assert "errors" in data
    assert isinstance(data["errors"], list)
    for error in data["errors"]:
        assert "code" in error
        assert error["code"] in [477, 572, 2781, 4926, 32171]
        assert "title" in error
        assert isinstance(error["title"], str)