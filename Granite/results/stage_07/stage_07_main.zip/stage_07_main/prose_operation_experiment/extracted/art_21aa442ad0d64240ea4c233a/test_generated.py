import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

def test_get_all_subcontractor_tags():
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }

    response = requests.get(f"{BASE_URL}/Employer/{employer_id}/SubContractors/Tags", headers=headers)

    if response.status_code == 200:
        assert response.json()["LinkCollection"] is not None
    elif response.status_code == 400:
        assert response.json()["Description"] is not None
    elif response.status_code == 401:
        assert response.json()["Description"] is not None
    elif response.status_code == 404:
        assert response.json()["Description"] is not None
    elif response.status_code == 500:
        assert response.json()["Description"] is not None
    else:
        pytest.fail(f"Unexpected status code: {response.status_code}")

# Mocking employer_id for testing purposes
employer_id = "ER001"