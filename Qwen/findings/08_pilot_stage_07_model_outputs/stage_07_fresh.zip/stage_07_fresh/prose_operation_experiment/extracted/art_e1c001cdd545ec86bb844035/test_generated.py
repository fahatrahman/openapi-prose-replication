import pytest
import requests

BASE_URL = "http://openapi.test"

def test_content_orderreturns_get():
    url = f"{BASE_URL}/merchantId/orderId"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token",
        "alt": "json",
        "callback": "your_callback",
        "fields": "your_fields",
        "key": "your_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": False,
        "quotaUser": "your_quota_user",
        "uploadProtocol": "your_upload_protocol",
        "uploadType": "your_upload_type",
        "merchantId": "your_merchant_id",
        "returnId": "your_return_id"
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    assert response.json().get("kind") == "content#orderreturns"