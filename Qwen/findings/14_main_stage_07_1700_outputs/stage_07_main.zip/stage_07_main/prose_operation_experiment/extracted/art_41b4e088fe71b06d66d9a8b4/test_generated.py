import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_storage_policy_assignments():
    url = f"{BASE_URL}/storage_policy_assignments"
    params = {
        "marker": "JV9IRGZmieiBasejOG9yDCRNgd2ymoZIbjsxbJMjIs3kioVii",
        "resolved_for_type": "user",
        "resolved_for_id": "984322"
    }
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert "entries" in data
    for entry in data["entries"]:
        assert "storage_policy" in entry
        assert "assigned_to" in entry

def test_get_storage_policy_assignments_default_response():
    url = f"{BASE_URL}/storage_policy_assignments"
    params = {
        "marker": "INVALID_MARKER",
        "resolved_for_type": "user",
        "resolved_for_id": "984322"
    }
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code >= 400
    data = response.json()
    assert "error" in data["type"]