import pytest
import requests

BASE_URL = "http://openapi.test"

def test_generate_access_token():
    url = f"{BASE_URL}/v1/projects/serviceAccount:generateAccessToken"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "delegates": ["delegate1", "delegate2"],
        "lifetime": "3600s",
        "scope": ["https://www.googleapis.com/auth/cloud-platform"]
    }
    response = requests.post(url, headers=headers, json=payload)
    
    assert response.status_code == 200
    assert "accessToken" in response.json()
    assert "expireTime" in response.json()

if __name__ == "__main__":
    pytest.main()