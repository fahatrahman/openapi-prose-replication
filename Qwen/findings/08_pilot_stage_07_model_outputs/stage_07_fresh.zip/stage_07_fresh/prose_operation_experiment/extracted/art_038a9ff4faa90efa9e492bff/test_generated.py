import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_liasettings():
    url = f"{BASE_URL}/123/liasettings/456"
    params = {
        "_xgafv": "2",
        "access_token": "your_access_token",
        "alt": "json",
        "callback": "your_callback",
        "fields": "kind,accountId,countrySettings[].country,countrySettings[].about.url",
        "key": "your_api_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": True,
        "quotaUser": "user123",
        "uploadProtocol": "raw",
        "uploadType": "media"
    }
    headers = {
        "Authorization": "Bearer your_bearer_token"
    }
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    assert response.json()["kind"] == "content#liaSettings"
    assert isinstance(response.json()["accountId"], str)
    assert isinstance(response.json()["countrySettings"], list)
    for country_setting in response.json()["countrySettings"]:
        assert isinstance(country_setting["country"], str)
        assert isinstance(country_setting["about"]["url"], str)

if __name__ == "__main__":
    pytest.main()