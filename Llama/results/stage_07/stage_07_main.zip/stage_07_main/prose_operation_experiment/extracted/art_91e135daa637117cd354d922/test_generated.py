# -*- coding: utf-8 -*-
import pytest
import requests

BASE_URL = "http://openapi.test"

def test_FetchAccountSecret():
    response = requests.get(
        f"{BASE_URL}/v1/Secrets/{pytest.param}",
        auth=("accountSid", "authToken"),
    )
    assert response.status_code == 200
    assert response.json()["type"] == "object"
    assert "date_rotated" in response.json()
    assert "key" in response.json()
    assert "url" in response.json()

class TestFetchAccountSecret:
    @pytest.mark.parametrize("param", ["secret_key"])
    def test_valid(self, param):
        test_FetchAccountSecret()

    @pytest.mark.parametrize("param", ["invalid_key"])
    def test_invalid(self, param):
        response = requests.get(
            f"{BASE_URL}/v1/Secrets/{param}",
            auth=("accountSid", "authToken"),
        )
        assert response.status_code != 200