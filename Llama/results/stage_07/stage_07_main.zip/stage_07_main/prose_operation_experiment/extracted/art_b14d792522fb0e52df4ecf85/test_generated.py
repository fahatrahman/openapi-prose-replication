# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_get_product_status():
    # Construct the full path to the API endpoint
    path = "/{merchantId}/productstatuses/{productId}".format(
        merchantId="your_merchant_id",
        productId="your_product_id"
    )
    full_path = urljoin(BASE_URL, path)

    # Define query parameters
    params = {
        "merchantId": "your_merchant_id",
        "productId": "your_product_id",
        "destinations": ["Shopping"]
    }

    # Send GET request
    response = requests.get(full_path, params=params)

    # Assert response status code is 200
    assert response.status_code == 200

    # Parse JSON response content
    try:
        response_json = response.json()
    except ValueError:
        pytest.fail("Failed to parse JSON response")

    # Assert response content matches expected schema
    import jsonschema
    schema_url = "#/components/schemas/ProductStatus"
    schema_ref = json.loads(open(__file__, 'r').read())["components"]["schemas"][schema_url]
    jsonschema.validate(instance=response_json, schema=schema_ref)