import pytest
import requests
BASE_URL = "http://openapi.test"

@pytest.fixture
def create_notification_config():
    url = f"{BASE_URL}/v1/{parent}/notificationConfigs"
    headers = {"Content-Type": "application/json"}

    notification_config = {
        "description": "A description of the config",
        "name": "example_config",
        "pubsubTopic": "projects/<PROJECT_ID>/topics/<TOPIC>",
        "serviceAccount": "<SERVICE_ACCOUNT_EMAIL>"
    }

    response = requests.post(url, headers=headers, json=notification_config)
    response.raise_for_status()

    return response.json()