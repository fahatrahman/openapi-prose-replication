import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

def test_get_phone_number():
    phone_number_id = "example_phone_number_id"

    url = f"{BASE_URL}/phone-numbers/{phone_number_id}"
    headers = {"X-Amz-Algorithm": "AWS4-HMAC-SHA256", "X-Amz-Credential": "example_credential", "X-Amz-Date": "20220101T000000", "X-Amz-Expires": "3600", "X-Amz-SignedHeaders": "host;x-amz-algorithm;x-amz-date;x-amz-expires", "X-Amz-Signature": "example_signature"}

    response = SESSION.get(url, headers=headers)

    assert response.status_code == 200, f"Unexpected status code: {response.status_code}. Response content: {response.json()}"

    # Add additional assertions based on the expected structure of GetPhoneNumberResponse
