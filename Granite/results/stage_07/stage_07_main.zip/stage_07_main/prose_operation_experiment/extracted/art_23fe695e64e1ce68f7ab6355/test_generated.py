import os
import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

@pytest.fixture(scope='function')
def http_server():
    server = requests.Session()
    server.auth = HTTPBasicAuth('username', 'password')
    return server

def test_issue_list_blocks(http_server):
    path_params = {"owner": "owner", "repo": "repo", "index": "index"}
    query_params = {"page": 1, "limit": 10}

    response = http_server.get(
        f"{BASE_URL}/repos/{path_params['owner']}/{path_params['repo']}/issues/{path_params['index']}/blocks",
        params=query_params
    )

    assert response.status_code == 200