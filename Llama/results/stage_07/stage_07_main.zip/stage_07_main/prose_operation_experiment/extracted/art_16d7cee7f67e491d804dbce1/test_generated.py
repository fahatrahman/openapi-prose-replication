# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urljoin
from typing import Dict

BASE_URL = "http://openapi.test"

def test_delete_target_site():
    url = urljoin(BASE_URL, "/v1beta/{name}")
    params = {
        "$.xgafv": "1",
        "access_token": "",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "",
        "oauth_token": "",
        "prettyPrint": "true",
        "quotaUser": "",
        "upload_protocol": "raw",
        "uploadType": "media"
    }
    headers = {}
    data = {}

    def get_response(status_code: int):
        return requests.Response()

    get_response.status_code = status_code
    response = get_response(200)
    assert response.json()["status"]["code"] == 0
    assert response.json()["status"]["details"] == []

    # Delete target site
    response = requests.delete(url.format(name="projects/project/locations/location/collections/collection/dataStores/dataStore/siteSearchEngine/targetSites/target_site"), 
                               params=params,
                               headers=headers,
                               data=data)

    assert response.status_code == 200

    # Test response
    response.raise_for_status()
    operation = response.json()
    assert isinstance(operation, dict) and "name" in operation
    assert operation["name"].startswith("projects/")
    assert operation["metadata"]
    assert operation["done"]
    assert "error" not in operation
    assert "response" in operation

    # Test error
    response.status_code = 403
    response.raise_for_status()
    operation = response.json()
    assert isinstance(operation, dict) and "name" in operation
    assert operation["name"].startswith("projects/")
    assert operation["metadata"]
    assert operation["done"]
    assert "error" in operation
    assert "response" not in operation

    # Test non-existent target site
    response.status_code = 404
    response.raise_for_status()
    operation = response.json()
    assert isinstance(operation, dict) and "name" in operation
    assert operation["name"].startswith("projects/")
    assert operation["metadata"]
    assert operation["done"]
    assert "error" in operation
    assert "response" not in operation