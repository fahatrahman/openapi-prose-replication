import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_connection_profiles():
    url = f"{BASE_URL}/v1alpha1/projects/location/connectionProfiles"
    params = {
        "filter": "example_filter",
        "orderBy": "example_orderBy",
        "pageSize": 50,
        "pageToken": "example_pageToken"
    }
    headers = {
        "Authorization": "Bearer example_access_token"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()