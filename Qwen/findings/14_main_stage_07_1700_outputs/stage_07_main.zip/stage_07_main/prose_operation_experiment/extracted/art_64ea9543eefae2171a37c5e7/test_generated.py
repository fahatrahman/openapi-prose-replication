import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_setting():
    setting_id = 123  # Replace with actual setting ID
    headers = {
        "Authorization": "Basic YOUR_API_CREDENTIALS"
    }
    url = f"{BASE_URL}/v1/settings/{setting_id}"
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert "application/hal+json" in response.headers["Content-Type"]
    assert "application/json" in response.headers["Content-Type"]
    
    setting_data = response.json()
    assert isinstance(setting_data, dict)
    assert "configId" in setting_data
    assert "configName" in setting_data
    assert "hint" in setting_data
    assert "key" in setting_data
    assert "name" in setting_data
    assert "order" in setting_data
    assert "settingId" in setting_data
    assert "settingType" in setting_data
    
    if "_embedded" in setting_data:
        assert "tags" in setting_data["_embedded"]
        tags = setting_data["_embedded"]["tags"]
        assert isinstance(tags, list)
        for tag in tags:
            assert "color" in tag
            assert "name" in tag
            assert "product" in tag
            assert "tagId" in tag
            
            product = tag["product"]
            assert "description" in product
            assert "name" in product
            assert "order" in product
            assert "productId" in product
            assert "reasonRequired" in product
            
            organization = product["organization"]
            assert "name" in organization
            assert "organizationId" in organization
            
            members_link = organization["_links"]["members"]
            products_link = organization["_links"]["products"]
            
            assert isinstance(members_link, str)
            assert isinstance(products_link, str)
            
    if "_links" in setting_data:
        self_link = setting_data["_links"]["self"]
        assert isinstance(self_link, str)
        
    color = setting_data.get("color")
    assert color is None or isinstance(color, str)
    
    name = setting_data.get("name")
    assert name is None or isinstance(name, str)
    
    tag_id = setting_data.get("tagId")
    assert tag_id is None or isinstance(tag_id, int)

if __name__ == "__main__":
    pytest.main(["-v", __file__])