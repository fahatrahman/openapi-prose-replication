import pytest
import requests
from uuid import uuid4

BASE_URL = "http://openapi.test"

def get_product_types(organization_uuid):
    url = f"{BASE_URL}/organizations/{organization_uuid}/categories/v2"
    headers = {
        "Authorization": "Bearer <access_token>"
    }
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    return response.json()

@pytest.fixture(scope="session")
def organization_uuid():
    return str(uuid4())

def test_get_product_types(organization_uuid):
    try:
        categories_response = get_product_types(organization_uuid)
        assert isinstance(categories_response, dict)
        assert 'categories' in categories_response
        assert isinstance(categories_response['categories'], list)
        for category in categories_response['categories']:
            assert 'name' in category
            assert 'uuid' in category
            assert len(category['name']) <= 100
            assert len(category['uuid']) == 36
    except requests.RequestException as e:
        pytest.fail(f"Request failed: {e}")