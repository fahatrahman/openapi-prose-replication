import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_runtime_versions():
    url = f"{BASE_URL}/v2alpha1/projects/locations/runtimeVersions"
    params = {
        "filter": "some_filter",
        "orderBy": "some_orderBy",
        "pageSize": 10,
        "pageToken": "some_pageToken"
    }
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert "runtimeVersions" in data

if __name__ == "__main__":
    pytest.main()