import pytest
import requests

BASE_URL = "http://openapi.test"

def test_cargo_get_route_from_date_product_code_by_origin_and_destination():
    url = f"{BASE_URL}/cargo/getRoute/AMS-DUS/2023-04-01/FAN"
    headers = {
        "Accept": "application/json"
    }
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()