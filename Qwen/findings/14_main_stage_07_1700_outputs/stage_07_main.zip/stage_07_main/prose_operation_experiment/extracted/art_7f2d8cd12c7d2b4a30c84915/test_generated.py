import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_service_profile(authorization_token, service_id):
    url = f"{BASE_URL}/v0.5/hi-services/{service_id}"
    headers = {
        "Authorization": authorization_token
    }
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert response.headers["Content-Type"].startswith("application/json")
    assert "ServiceProfileResponse" in response.json()

@pytest.fixture(scope="module")
def authorization_token():
    # Replace this with actual token retrieval logic
    return "Bearer your_authorization_token_here"

@pytest.fixture(params=["valid_service_id", "invalid_service_id"])
def service_id(request):
    return request.param