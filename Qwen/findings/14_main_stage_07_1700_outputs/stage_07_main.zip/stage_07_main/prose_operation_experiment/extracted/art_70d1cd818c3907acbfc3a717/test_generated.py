import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def get_bounce_counts(server_token, tag=None, fromdate=None, todate=None):
    params = {}
    if tag:
        params['tag'] = tag
    if fromdate:
        params['fromdate'] = fromdate.strftime('%Y-%m-%d')
    if todate:
        params['todate'] = todate.strftime('%Y-%m-%d')

    headers = {
        'X-Postmark-Server-Token': server_token
    }

    response = requests.get(f"{BASE_URL}/stats/outbound/bounces", headers=headers, params=params)

    if response.status_code == 200:
        return response.json()
    elif response.status_code == 422:
        error_data = response.json()
        raise ValueError(error_data['Message'])
    elif response.status_code == 500:
        raise Exception("Internal server error")
    else:
        raise Exception(f"Unexpected status code: {response.status_code}")

@pytest.mark.parametrize("server_token, expected_error", [
    ("invalid_token", "Invalid authentication credentials"),
    ("", "Invalid authentication credentials"),
])
def test_get_bounce_counts_invalid_token(server_token, expected_error):
    with pytest.raises(ValueError) as exc_info:
        get_bounce_counts(server_token)
    assert str(exc_info.value) == expected_error

@pytest.mark.parametrize("params, expected_response", [
    ({"server_token": "valid_token"}, {"Days": [], "HardBounce": 0, "SMTPApiError": 0, "SoftBounce": 0, "Transient": 0}),
    ({"server_token": "valid_token", "tag": "test_tag"}, {"Days": [], "HardBounce": 0, "SMTPApiError": 0, "SoftBounce": 0, "Transient": 0}),
    ({"server_token": "valid_token", "fromdate": datetime(2023, 1, 1)}, {"Days": [], "HardBounce": 0, "SMTPApiError": 0, "SoftBounce": 0, "Transient": 0}),
    ({"server_token": "valid_token", "todate": datetime(2023, 1, 31)}, {"Days": [], "HardBounce": 0, "SMTPApiError": 0, "SoftBounce": 0, "Transient": 0}),
    ({"server_token": "valid_token", "fromdate": datetime(2023, 1, 1), "todate": datetime(2023, 1, 31)}, {"Days": [], "HardBounce": 0, "SMTPApiError": 0, "SoftBounce": 0, "Transient": 0}),
])
def test_get_bounce_counts_valid_params(params, expected_response):
    response = get_bounce_counts(**params)
    assert response == expected_response