import os
import pytest
import requests
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
BASE_URL = "http://openapi.test"

def test_update_policy():
    project = "test-project"
    policy = "test-policy"
    policy_data = {
        "description": "Test description",
        "enableInboundForwarding": True,
        "enableLogging": False,
        "kind": "dns#policy",
        "name": "test-name",
        "networks": [
            {
                "kind": "dns#policyNetwork",
                "networkUrl": "https://example.com"
            }
        ]
    }

    try:
        service = build('dns', 'v1')
        request = service.projects().policies().update(
            project=project, policy=policy, body=policy_data
        )
        response = request.execute()

        assert response['header']['operationId'] is not None
        assert response['policy']['description'] == policy_data['description']
        assert response['policy']['enableInboundForwarding'] == policy_data['enableInboundForwarding']
        assert response['policy']['enableLogging'] == policy_data['enableLogging']
        assert response['policy']['kind'] == policy_data['kind']
        assert response['policy']['name'] == policy_data['name']
        assert len(response['policy']['networks']) == 1
        assert response['policy']['networks'][0]['kind'] == policy_data['networks'][0]['kind']
        assert response['policy']['networks'][0]['networkUrl'] == policy_data['networks'][0]['networkUrl']

    except HttpError as error:
        print(f"An error occurred: {error}")
        pytest.fail(str(error))