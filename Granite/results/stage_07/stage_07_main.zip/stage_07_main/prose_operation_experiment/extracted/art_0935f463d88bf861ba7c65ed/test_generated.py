import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    backoff_factor=0.1,
    status_forcelist=[429, 500, 502, 503, 504],
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.fixture
def supersim_v1_fleet():
    headers = {
        "Authorization": f"Basic {os.getenv('TWILIO_ACCOUNT_SID')}:{os.getenv('TWILIO_AUTH_TOKEN)}"
    }

    def _request(method, url, **kwargs):
        kwargs.setdefault("headers", headers)
        response = SESSION.request(method, f"{BASE_URL}{url}", **kwargs)
        response.raise_for_status()
        return response.json()

    yield _request

def test_list_fleets(supersim_v1_fleet):
    response = supersim_v1_fleet(
        "GET", "/v1/Fleets?NetworkAccessProfile=some_network_access_profile&PageSize=10&Page=1"
    )
    assert response["fleets"]
    assert isinstance(response["meta"], dict)