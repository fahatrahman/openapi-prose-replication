import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_memberships_active():
    """Test Memberships Active endpoint"""
    url = urljoin(BASE_URL, "/{format}/ActiveMemberships")
    params = {"format": "json"}

    response = requests.get(url, params=params)
    assert response.status_code == 200
    json_response = response.json()
    assert isinstance(json_response, list)
    for membership in json_response:
        assert isinstance(membership, dict)
        required_fields = ["MembershipId", "PlayerId"]
        for field in required_fields:
            assert field in membership

def test_memberships_active_xml_format():
    """Test Memberships Active endpoint with XML format"""
    url = urljoin(BASE_URL, "/{format}/ActiveMemberships")
    params = {"format": "xml"}

    response = requests.get(url, params=params)
    assert response.status_code == 200
    # XML parsing is more complex, so we just check if the response is valid
    try:
        response.json()
    except ValueError:
        pass
    else:
        raise AssertionError("Expected XML response")

if __name__ == "__main__":
    pytest.main([__file__, "-v"])