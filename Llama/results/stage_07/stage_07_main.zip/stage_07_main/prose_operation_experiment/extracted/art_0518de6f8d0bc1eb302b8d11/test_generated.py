# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urlencode

BASE_URL = "http://openapi.test"

def test_app_categories_get_collection():
    params = {
        "filter[platforms]": ["IOS", "MAC_OS"],
        "fields[appCategories]": ["platforms", "parent"],
        "include": ["parent", "subcategories"],
        "limit": 10,
        "limit[subcategories]": 5
    }

    headers = {"Authorization": f"Bearer {get_bearer_token()}"}

    response = requests.get(f"{BASE_URL}/v1/appCategories", headers=headers, params=urlencode(params))

    assert response.status_code == 200
    assert response.headers["Content-Type"] == "application/json"
    response_json = response.json()

    assert isinstance(response_json, dict)
    assert "data" in response_json
    assert isinstance(response_json["data"], list)

    for category in response_json["data"]:
        assert isinstance(category, dict)
        assert "id" in category
        assert "type" in category
        assert category["type"] == "appCategories"
        assert "attributes" in category
        assert isinstance(category["attributes"], dict)
        assert "platforms" in category["attributes"]
        assert isinstance(category["attributes"]["platforms"], list)
        assert all(platform in ["IOS", "MAC_OS", "TV_OS"] for platform in category["attributes"]["platforms"])

def get_bearer_token():
    # This function should return a valid bearer token
    # For demonstration purposes, it returns a hardcoded token
    return "hardcoded_bearer_token"