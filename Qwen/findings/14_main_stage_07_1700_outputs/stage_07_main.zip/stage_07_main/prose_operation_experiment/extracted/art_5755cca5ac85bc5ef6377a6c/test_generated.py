import pytest
import requests

BASE_URL = "http://openapi.test"

def test_app_price_points_get_collection():
    url = f"{BASE_URL}/v1/appPricePoints"
    params = {
        "filter[priceTier]": ["value1", "value2"],
        "filter[territory]": ["value3", "value4"],
        "fields[appPricePoints]": ["customerPrice", "priceTier"],
        "limit": 10,
        "include": ["priceTier", "territory"],
        "fields[territories]": ["currency"]
    }
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    response = requests.get(url, params=params, headers=headers)
    
    assert response.status_code == 200
    assert "data" in response.json()
    assert "links" in response.json()

def test_app_price_points_get_collection_with_invalid_params():
    url = f"{BASE_URL}/v1/appPricePoints"
    params = {
        "filter[priceTier]": ["invalid_value"],
        "filter[territory]": ["invalid_value"],
        "fields[appPricePoints]": ["invalid_field"],
        "limit": 201,
        "include": ["invalid_relation"],
        "fields[territories]": ["invalid_field"]
    }
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    response = requests.get(url, params=params, headers=headers)
    
    assert response.status_code == 400 or response.status_code == 403