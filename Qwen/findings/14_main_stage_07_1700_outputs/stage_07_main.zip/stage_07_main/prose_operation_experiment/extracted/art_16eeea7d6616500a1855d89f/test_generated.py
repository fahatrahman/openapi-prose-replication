import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_application_attribute():
    application_id = "test_app_id"
    attribute_name = "test_attr"
    url = f"{BASE_URL}/api/v2/application/{application_id}/attributes?name={attribute_name}"
    
    response = requests.delete(url)
    
    assert response.status_code == 200
    assert response.text in ["", None]  # Assuming empty string or None is valid for successful deletion