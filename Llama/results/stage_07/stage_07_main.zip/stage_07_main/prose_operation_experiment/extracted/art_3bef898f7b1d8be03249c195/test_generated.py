# -*- coding: utf-8 -*-
"""Tests for Operation slice."""

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_document():
    """Test getDocument."""
    path = "/v1/data/opa/examples/public_servers"
    params = {
        "input": {"flag": True},
        "instrument": False,
        "metrics": False,
        "explain": "full",
        "pretty": True,
        "provenance": False
    }
    response = requests.get(
        f"{BASE_URL}{path}",
        params=params
    )
    assert response.status_code == 200

def test_get_document_invalid_path():
    """Test getDocument with invalid path."""
    path = "/v1/data/invalid_path"
    params = {}
    response = requests.get(
        f"{BASE_URL}{path}",
        params=params
    )
    assert response.status_code == 400

def test_get_document_invalid_input():
    """Test getDocument with invalid input."""
    path = "/v1/data/opa/examples/public_servers"
    params = {
        "input": {},
        "instrument": False,
        "metrics": False,
        "explain": "full",
        "pretty": True,
        "provenance": False
    }
    response = requests.get(
        f"{BASE_URL}{path}",
        params=params
    )
    assert response.status_code == 400

def test_get_document_invalid_explain():
    """Test getDocument with invalid explain."""
    path = "/v1/data/opa/examples/public_servers"
    params = {
        "input": {"flag": True},
        "instrument": False,
        "metrics": False,
        "explain": "invalid",
        "pretty": True,
        "provenance": False
    }
    response = requests.get(
        f"{BASE_URL}{path}",
        params=params
    )
    assert response.status_code == 400

def test_get_document_invalid_pretty():
    """Test getDocument with invalid pretty."""
    path = "/v1/data/opa/examples/public_servers"
    params = {
        "input": {"flag": True},
        "instrument": False,
        "metrics": False,
        "explain": "full",
        "pretty": "invalid",
        "provenance": False
    }
    response = requests.get(
        f"{BASE_URL}{path}",
        params=params
    )
    assert response.status_code == 400

def test_get_document_invalid_provenance():
    """Test getDocument with invalid provenance."""
    path = "/v1/data/opa/examples/public_servers"
    params = {
        "input": {"flag": True},
        "instrument": False,
        "metrics": False,
        "explain": "full",
        "pretty": True,
        "provenance": "invalid"
    }
    response = requests.get(
        f"{BASE_URL}{path}",
        params=params
    )
    assert response.status_code == 400

def test_get_document_invalid_metrics():
    """Test getDocument with invalid metrics."""
    path = "/v1/data/opa/examples/public_servers"
    params = {
        "input": {"flag": True},
        "instrument": False,
        "metrics": "invalid",
        "explain": "full",
        "pretty": True,
        "provenance": False
    }
    response = requests.get(
        f"{BASE_URL}{path}",
        params=params
    )
    assert response.status_code == 400

def test_get_document_invalid_instrument():
    """Test getDocument with invalid instrument."""
    path = "/v1/data/opa/examples/public_servers"
    params = {
        "input": {"flag": True},
        "instrument": "invalid",
        "metrics": False,
        "explain": "full",
        "pretty": True,
        "provenance": False
    }
    response = requests.get(
        f"{BASE_URL}{path}",
        params=params
    )
    assert response.status_code == 400