import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_sentences():
    url = f"{BASE_URL}/sentences"
    params = {"limit": 1}
    response = requests.get(url, params=params)
    assert response.status_code == 200
    data = response.json()
    assert "data" in data
    sentences = data["data"]
    assert isinstance(sentences, list)
    for sentence in sentences:
        assert "book" in sentence
        book = sentence["book"]
        assert "id" in book
        assert "name" in book
        assert "year" in book
        assert "id" in sentence
        assert "sentence" in sentence

if __name__ == "__main__":
    pytest.main()