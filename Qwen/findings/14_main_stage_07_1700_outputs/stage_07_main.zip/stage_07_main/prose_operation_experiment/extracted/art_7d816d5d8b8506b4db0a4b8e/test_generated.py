import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_import_dockerfiles():
    operation_id = "test_operation_id"
    url = f"{BASE_URL}/imports/images/{operation_id}/dockerfile"
    response = requests.get(url)
    
    assert response.status_code == 200
    assert isinstance(response.json(), list)

def test_list_import_dockerfiles_error():
    operation_id = "error_operation_id"
    url = f"{BASE_URL}/imports/images/{operation_id}/dockerfile"
    response = requests.get(url)
    
    assert response.status_code == 500