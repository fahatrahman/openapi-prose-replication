from __future__ import annotations

import ast
import base64
import hashlib
import json


CLAIMS_VERSION = "stage08-claims-v2-opcode-positions"
TRACE_MARKER = "STAGE08_REACHED_LINES_JSON="


def assertion_nodes(source):
    """Split conjunctions; keep OR, implications and other claims intact."""
    tree = ast.parse(source)
    result = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Assert):
            continue
        expressions = [node.test]
        while any(isinstance(x, ast.BoolOp) and isinstance(x.op, ast.And)
                  for x in expressions):
            next_items = []
            for expression in expressions:
                if isinstance(expression, ast.BoolOp) and isinstance(expression.op, ast.And):
                    next_items.extend(expression.values)
                else:
                    next_items.append(expression)
            expressions = next_items
        for index, expression in enumerate(expressions):
            result.append({
                "line": node.lineno,
                "expression_span": [expression.lineno, expression.col_offset,
                                    expression.end_lineno, expression.end_col_offset],
                "column": node.col_offset,
                "ordinal": index,
                "expression": ast.unparse(expression),
                "source_span": ast.get_source_segment(source, node) or "",
                "node_type": type(expression).__name__,
            })
    return sorted(result, key=lambda x: (x["line"], x["column"], x["ordinal"]))


def static_safety_warnings(source):
    tree = ast.parse(source)
    warnings = []
    banned_calls = {"eval", "exec", "__import__", "os.system", "os.popen",
                    "subprocess.run", "subprocess.Popen", "socket.socket",
                    "socket.create_connection"}
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            name = ast.unparse(node.func)
            if name in banned_calls:
                warnings.append({"line": node.lineno, "risk": "dangerous_call", "name": name})
        if isinstance(node, ast.Import):
            for item in node.names:
                if item.name in ("ctypes", "subprocess", "socket"):
                    warnings.append({"line": node.lineno, "risk": "restricted_import",
                                     "name": item.name})
    return warnings


def observation_wrapper(source):
    """Trace executed expression positions in a supplemental isolated run."""
    encoded = base64.b64encode(source.encode("utf-8")).decode("ascii")
    lines = [
        "import atexit, base64, dis, json, sys",
        "_stage08_reached = {}",
        "_stage08_instructions = {}",
        "def _stage08_trace(frame, event, arg):",
        "    if frame.f_code.co_filename != '<frozen_generated_source>':",
        "        return None",
        "    if event == 'call':",
        "        frame.f_trace_opcodes = True",
        "        frame.f_trace_lines = False",
        "    elif event == 'opcode':",
        "        code = frame.f_code",
        "        if code not in _stage08_instructions:",
        "            _stage08_instructions[code] = {i.offset: i.positions for i in dis.get_instructions(code)}",
        "        position = _stage08_instructions[code].get(frame.f_lasti)",
        "        item = getattr(sys.modules['__main__'], 'current_item_id', None)",
        "        if item is not None and position is not None and None not in position:",
        "            _stage08_reached.setdefault(item, set()).add(tuple(position))",
        "    return _stage08_trace",
        "def _stage08_emit():",
        "    print('\\nSTAGE08_REACHED_LINES_JSON=' + json.dumps({item: sorted(spans) for item, spans in _stage08_reached.items()}))",
        "atexit.register(_stage08_emit)",
        "_stage08_entry = sys._getframe()",
        "_stage08_entry.f_trace_opcodes = True",
        "sys.settrace(_stage08_trace)",
        "exec(compile(base64.b64decode('" + encoded + "').decode('utf-8'),",
        "             '<frozen_generated_source>', 'exec', dont_inherit=True), globals())",
    ]
    return "\n".join(lines) + "\n"


def parse_observed_positions(stdout):
    values = [line[len(TRACE_MARKER):] for line in stdout.splitlines()
              if line.startswith(TRACE_MARKER)]
    if len(values) != 1:
        return None
    try:
        decoded = json.loads(values[0])
    except ValueError:
        return None
    if not isinstance(decoded, dict):
        return None
    for item, positions in decoded.items():
        if not item or not isinstance(positions, list):
            return None
        if any(not isinstance(span, list) or len(span) != 4
               or any(type(x) is not int or x < 0 for x in span)
               for span in positions):
            return None
    return decoded


def reached_items(node, observed):
    line, column, end_line, end_column = node["expression_span"]
    start, end = (line, column), (end_line, end_column)
    return sorted(item for item, positions in observed.items() if any(
        start <= (first_line, first_column) < (last_line, last_column) <= end
        for first_line, last_line, first_column, last_column in positions
    ))
