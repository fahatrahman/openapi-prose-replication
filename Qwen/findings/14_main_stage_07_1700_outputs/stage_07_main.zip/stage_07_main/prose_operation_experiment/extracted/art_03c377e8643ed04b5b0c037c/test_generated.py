import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_node():
    url = f"{BASE_URL}/v1alpha1/nodes"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "displayName": "Test Node",
        "name": "projects/YOUR_PROJECT_ID/locations/global/nodes/YOUR_NODE_ID",
        "sasUserIds": ["user1", "user2"]
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert response.json()["displayName"] == "Test Node"
    assert response.json()["name"].startswith("projects/YOUR_PROJECT_ID/locations/global/nodes/")
    assert set(response.json()["sasUserIds"]) == {"user1", "user2"}

if __name__ == "__main__":
    pytest.main()