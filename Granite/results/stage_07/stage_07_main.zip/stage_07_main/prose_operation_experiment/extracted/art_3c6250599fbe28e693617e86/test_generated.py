import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

# Set up session with retries for transient errors
session = requests.Session()
session.mount("https://", HTTPAdapter(max_retries=5))

# Replace with your actual OAuth2 credentials
OAUTH2_TOKEN_URL = "https://oauth.zettle.com/token"
AUTHORIZATION_URL = "https://oauth.zettle.com/authorize"
CLIENT_ID = "your_client_id"
CLIENT_SECRET = "your_client_secret"
SCOPE = "READ:PRODUCT"

def get_oauth2_token():
    token_data = {
        "grant_type": "client_credentials",
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "scope": SCOPE,
    }

    response = requests.post(OAUTH2_TOKEN_URL, data=token_data)
    response.raise_for_status()

    return response.json()["access_token"]

@pytest.fixture
def organization_uuid():
    # Replace with the actual organization UUID you want to test against
    return "your_organization_uuid"

def test_get_product_types(organization_uuid):
    access_token = get_oauth2_token()

    headers = {"Authorization": f"Bearer {access_token}"}
    url = urljoin(BASE_URL, f"/organizations/{organization_uuid}/categories/v2")

    response = session.get(url, headers=headers)
    response.raise_for_status()

    category_response = response.json()

    assert "categories" in category_response
    assert isinstance(category_response["categories"], list)

    for category in category_response["categories"]:
        assert "name" in category
        assert "uuid" in category
        assert isinstance(category["name"], str)
        assert isinstance(category["uuid"], str)
        assert len(category["name"]) <= 100
        assert len(category["uuid"]) == 36