import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
SESSION.mount("https://", HTTPAdapter(max_retries=3))
SESSION.mount("http://", HTTPAdapter(max_retries=3))

@pytest.fixture
def edge_config_token():
    def _edge_config_token(edge_config_id, token, team_id):
        url = urljoin(BASE_URL, f"/v1/edge-config/{edge_config_id}/token/{token}")
        if team_id:
            url += f"?teamId={team_id}"

        response = SESSION.get(url)
        response.raise_for_status()

        return response.json()

    return _edge_config_token

def test_get_edge_config_token(edge_config_token):
    edge_config_id = "example_edge_config_id"
    token = "example_token"
    team_id = None  # Uncomment and set this value if needed

    result = edge_config_token(edge_config_id, token, team_id)
    assert isinstance(result, dict)
    assert all(key in result for key in ["createdAt", "edgeConfigId", "id", "label", "token"])