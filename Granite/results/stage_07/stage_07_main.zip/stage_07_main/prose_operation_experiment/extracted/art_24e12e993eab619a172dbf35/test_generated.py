import pytest
import requests
BASE_URL = "http://openapi.test"

@pytest.fixture
def headers():
    return {
        "Content-Type": "application/json",
    }

def test_store_stats(requests_mock):
    store_code = "TESTSTORECODE"
    auth_token = "TESTAUTHTOKEN"
    page = 1

    requests_mock.get(
        f"{BASE_URL}/partners/stores.json",
        json=[
            {
                "code": store_code,
                "stats": {
                    "best_sold": [
                        {"product_id": 1, "product_name": "Test Product", "total": 100.0, "count": 5},
                        {"product_id": 2, "product_name": "Another Test Product", "total": 150.0, "count": 3},
                    ],
                    "conversions": {
                        "added_to_cart": 1200.0,
                        "checkout": 800.0,
                        "paid": 600.0,
                    },
                    "currency": "USD",
                    "daily_visits": [
                        {"date": "2023-01-01", "visits": 1200},
                        {"date": "2023-01-02", "visits": 1500},
                    ],
                    "from": "2023-01-01",
                    "new_vs_returning_customers": {
                        "global": 2000,
                        "per_day": [
                            {"date": "2023-01-01", "new": 1000, "returning": 1000},
                            {"date": "2023-01-02", "new": 1200, "returning": 800},
                        ],
                    },
                    "new_vs_returning_orders": {
                        "global": 2500,
                        "per_day": [
                            {"date": "2023-01-01", "new": 1200, "returning": 1300},
                            {"date": "2023-01-02", "new": 1500, "returning": 1000},
                        ],
                    },
                    "orders": {
                        "average": 50.0,
                        "count": 5000,
                        "data": [
                            {"average": 45.0, "count": 1000, "date": "2023-01-01", "paid": 4000.0, "pending": 1000.0, "total": 5000.0},
                            {"average": 55.0, "count": 1200, "date": "2023-01-02", "paid": 6000.0, "pending": 2000.0, "total": 8000.0},
                        ],
                        "total": 13000.0,
                    },
                    "payment_methods": [
                        {"count": "100", "name": "Credit Card"},
                        {"count": "50", "name": "PayPal"},
                    ],
                    "referrers": [
                        {"count": 800, "source": "Google"},
                        {"count": 400, "source": "Facebook"},
                    ],
                    "region_orders": {
                        "display_mode": "list",
                        "regions_orders": [
                            {
                                "city": "New York",
                                "code": 1,
                                "country": "US",
                            },
                            {
                                "city": "Los Angeles",
                                "code": 2,
                                "country": "US",
                            },
                        ],
                    },
                    "search_frequencies_all": [],
                    "search_frequencies_without_results": [],
                    "shipping_methods": [
                        {"count": "150", "name": "Standard Shipping"},
                        {"count": "50", "name": "Express Shipping"},
                    ],
                    "to": "2023-01-02",
                    "traffic_type": [
                        {"count": 800, "name": "Organic"},
                        {"count": 400, "name": "Paid"},
                    ],
                    "visits": 3000,
                }
            }
        ]
    )

    response = requests.get(
        f"{BASE_URL}/partners/stores.json",
        headers=headers(),
        params={"partner_code": store_code, "auth_token": auth_token, "page": page, "from": "2023-01-01", "to": "2023-01-02"}
    )

    assert response.status_code == 200
    assert response.json() == [
        {
            "code": store_code,
            "stats": {
                "best_sold": [
                    {"product_id": 1, "product_name": "Test Product", "total": 100.0, "count": 5},
                    {"product_id": 2, "product_name": "Another Test Product", "total": 150.0, "count": 3},
                ],
                "conversions": {
                    "added_to_cart": 1200.0,
                    "checkout": 800.0,
                    "paid": 600.0,
                },
                "currency": "USD",
                "daily_visits": [
                    {"date": "2023-01-01", "visits": 1200},
                    {"date": "2023-01-02", "visits": 1500},
                ],
                "from": "2023-01-01",
                "new_vs_returning_customers": {
                    "global": 2000,
                    "per_day": [
                        {"date": "2023-01-01", "new": 1000, "returning": 1000},
                        {"date": "2023-01-02", "new": 1200, "returning": 800},
                    ],
                },
                "new_vs_returning_orders": {
                    "global": 2500,
                    "per_day": [
                        {"date": "2023-01-01", "new": 1200, "returning": 1300},
                        {"date": "2023-01-02", "new": 1500, "returning": 1000},
                    ],
                },
                "orders": {
                    "average": 50.0,
                    "count": 5000,
                    "data": [
                        {"average": 45.0, "count": 1000, "date": "2023-01-01", "paid": 4000.0, "pending": 1000.0, "total": 5000.0},
                        {"average": 55.0, "count": 1200, "date": "2023-01-02", "paid": 6000.0, "pending": 2000.0, "total": 8000.0},
                    ],
                    "total": 13000.0,
                },
                "payment_methods": [
                    {"count": "100", "name": "Credit Card"},
                    {"count": "50", "name": "PayPal"},
                ],
                "referrers": [
                    {"count": 800, "source": "Google"},
                    {"count": 400, "source": "Facebook"},
                ],
                "region_orders": {
                    "display_mode": "list",
                    "regions_orders": [
                        {
                            "city": "New York",
                            "code": 1,
                            "country": "US",
                        },
                        {
                            "city": "Los Angeles",
                            "code": 2,
                            "country": "US",
                        },
                    ],
                },
                "search_frequencies_all": [],
                "search_frequencies_without_results": [],
                "shipping_methods": [
                    {"count": "150", "name": "Standard Shipping"},
                    {"count": "50", "name": "Express Shipping"},
                ],
                "to": "2023-01-02",
                "traffic_type": [
                    {"count": 800, "name": "Organic"},
                    {"count": 400, "name": "Paid"},
                ],
                "visits": 3000,
            }
        }
    ]
}