# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_cloudresourcemanager_organizations_get():
    # Create an instance of the Organization schema
    organization = {
        "creationTime": datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "displayName": "Test Organization",
        "lifecycleState": "ACTIVE",
        "name": f"organizations/1234",
        "owner": {"directoryCustomerId": "test_customer_id"}
    }

    url = f"{BASE_URL}/v1/{organization['name']}"

    response = requests.get(url)

    assert response.status_code == 200

    organization_response = response.json()
    assert organization_response["displayName"] == organization["displayName"]
    assert organization_response["lifecycleState"] == organization["lifecycleState"]

@pytest.fixture
def setup_test_data():
    return {}

def teardown_function(function):
    pass