import pytest
import requests

BASE_URL = "http://openapi.test"

def test_post_legal_hold_policies():
    url = f"{BASE_URL}/legal_hold_policies"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "policy_name": "Sales Policy",
        "description": "A custom policy for the sales team",
        "filter_started_at": "2012-12-12T10:53:43-08:00",
        "filter_ended_at": "2012-12-18T10:53:43-08:00",
        "is_ongoing": True
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 201
    assert response.json()["policy_name"] == "Sales Policy"
    assert response.json()["description"] == "A custom policy for the sales team"

def test_post_legal_hold_policies_with_invalid_payload():
    url = f"{BASE_URL}/legal_hold_policies"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "policy_name": "Invalid Policy",
        "description": "This is an invalid description",
        "filter_started_at": "invalid_date_format",
        "filter_ended_at": "invalid_date_format",
        "is_ongoing": False
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 400
    assert response.json()["type"] == "error"
    assert response.json()["message"].startswith("Bad Request")
    assert "filter_started_at" in response.json()["context_info"]["message"]
    assert "filter_ended_at" in response.json()["context_info"]["message"]

def test_post_legal_hold_policies_conflict():
    url = f"{BASE_URL}/legal_hold_policies"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "policy_name": "Existing Policy",
        "description": "An existing policy",
        "filter_started_at": "2012-12-12T10:53:43-08:00",
        "filter_ended_at": "2012-12-18T10:53:43-08:00",
        "is_ongoing": True
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 409
    assert response.json()["type"] == "error"
    assert response.json()["message"].startswith("Conflict")
    assert "Existing Policy" in response.json()["context_info"]["message"]