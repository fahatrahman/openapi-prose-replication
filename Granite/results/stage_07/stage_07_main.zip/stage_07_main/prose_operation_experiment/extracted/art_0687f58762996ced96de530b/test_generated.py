import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = "path/to/service_account.json"

def test_create_source():
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE)

    headers = {
        "Content-Type": "application/json",
    }

    parent = "projects/<PROJECT_ID>/locations/<LOCATION>"
    source = {
        "displayName": "Test Source",
        "type": "SOURCE_TYPE_UPLOAD",
    }

    response = requests.post(
        f"{BASE_URL}/{parent}/sources",
        headers=headers,
        json=source,
        auth=credentials,
    )

    assert response.status_code == 200

    operation = response.json()
    assert operation["name"]
    assert operation["metadata"]["@type"] == "type.googleapis.com/google.cloud.migrationcenter.v1.Operation"