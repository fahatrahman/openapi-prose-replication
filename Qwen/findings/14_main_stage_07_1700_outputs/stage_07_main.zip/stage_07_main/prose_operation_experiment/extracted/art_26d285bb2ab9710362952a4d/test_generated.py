import pytest
import requests

BASE_URL = "http://openapi.test"

def test_describe_copy_job():
    copy_job_id = "example-copy-job-id"
    headers = {
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Date": "20230401T000000Z",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "example-access-key-id/example-region/aws4_request",
        "X-Amz-Security-Token": "example-security-token",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-algorithm;x-amz-credential;x-amz-security-token"
    }
    url = f"{BASE_URL}/copy-jobs/{copy_job_id}"
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert 'CopyJob' in response.json()