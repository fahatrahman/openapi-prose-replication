import pytest
import requests

BASE_URL = "http://openapi.test"

def test_update_route():
    api_id = "your_api_id"
    route_id = "your_route_id"
    headers = {
        "X-Amz-Content-Sha256": "example",
        "X-Amz-Date": "example",
        "X-Amz-Algorithm": "example",
        "X-Amz-Credential": "example",
        "X-Amz-Security-Token": "example",
        "X-Amz-Signature": "example",
        "X-Amz-SignedHeaders": "example"
    }
    payload = {
        "apiKeyRequired": False,
        "authorizationScopes": ["SCOPE_1", "SCOPE_2"],
        "authorizationType": "AWS_IAM",
        "authorizerId": "authorizer_id",
        "modelSelectionExpression": "$default",
        "operationName": "update_operation",
        "requestModels": {"application/json": "request_model"},
        "requestParameters": {},
        "routeKey": "GET /path",
        "routeResponseSelectionExpression": "$default",
        "target": "integrations/integration_id"
    }

    response = requests.patch(f"{BASE_URL}/v2/apis/{api_id}/routes/{route_id}", headers=headers, json=payload)

    assert response.status_code == 200
    assert "apiGatewayManaged" in response.json()
    assert "apiKeyRequired" in response.json()
    assert "authorizationScopes" in response.json()
    assert "authorizationType" in response.json()
    assert "authorizerId" in response.json()
    assert "modelSelectionExpression" in response.json()
    assert "operationName" in response.json()
    assert "requestModels" in response.json()
    assert "requestParameters" in response.json()
    assert "routeId" in response.json()
    assert "routeKey" in response.json()
    assert "routeResponseSelectionExpression" in response.json()
    assert "target" in response.json()

def test_update_route_not_found():
    api_id = "nonexistent_api_id"
    route_id = "nonexistent_route_id"
    headers = {
        "X-Amz-Content-Sha256": "example",
        "X-Amz-Date": "example",
        "X-Amz-Algorithm": "example",
        "X-Amz-Credential": "example",
        "X-Amz-Security-Token": "example",
        "X-Amz-Signature": "example",
        "X-Amz-SignedHeaders": "example"
    }
    payload = {
        "apiKeyRequired": False,
        "authorizationScopes": ["SCOPE_1", "SCOPE_2"],
        "authorizationType": "AWS_IAM",
        "authorizerId": "authorizer_id",
        "modelSelectionExpression": "$default",
        "operationName": "update_operation",
        "requestModels": {"application/json": "request_model"},
        "requestParameters": {},
        "routeKey": "GET /path",
        "routeResponseSelectionExpression": "$default",
        "target": "integrations/integration_id"
    }

    response = requests.patch(f"{BASE_URL}/v2/apis/{api_id}/routes/{route_id}", headers=headers, json=payload)

    assert response.status_code == 480

def test_update_route_too_many_requests():
    api_id = "your_api_id"
    route_id = "your_route_id"
    headers = {
        "X-Amz-Content-Sha256": "example",
        "X-Amz-Date": "example",
        "X-Amz-Algorithm": "example",
        "X-Amz-Credential": "example",
        "X-Amz-Security-Token": "example",
        "X-Amz-Signature": "example",
        "X-Amz-SignedHeaders": "example"
    }
    payload = {
        "apiKeyRequired": False,
        "authorizationScopes": ["SCOPE_1", "SCOPE_2"],
        "authorizationType": "AWS_IAM",
        "authorizerId": "authorizer_id",
        "modelSelectionExpression": "$default",
        "operationName": "update_operation",
        "requestModels": {"application/json": "request_model"},
        "requestParameters": {},
        "routeKey": "GET /path",
        "routeResponseSelectionExpression": "$default",
        "target": "integrations/integration_id"
    }

    # Simulate too many requests by sending multiple requests in quick succession
    for _ in range(10):
        response = requests.patch(f"{BASE_URL}/v2/apis/{api_id}/routes/{route_id}", headers=headers, json=payload)
        assert response.status_code != 481

def test_update_route_bad_request():
    api_id = "your_api_id"
    route_id = "your_route_id"
    headers = {
        "X-Amz-Content-Sha256": "example",
        "X-Amz-Date": "example",
        "X-Amz-Algorithm": "example",
        "X-Amz-Credential": "example",
        "X-Amz-Security-Token": "example",
        "X-Amz-Signature": "example",
        "X-Amz-SignedHeaders": "example"
    }
    payload = {
        "apiKeyRequired": True,
        "authorizationScopes": [],
        "authorizationType": "NONE",
        "authorizerId": "",
        "modelSelectionExpression": "",
        "operationName": "",
        "requestModels": {},
        "requestParameters": {},
        "routeKey": "",
        "routeResponseSelectionExpression": "",
        "target": ""
    }

    response = requests.patch(f"{BASE_URL}/v2/apis/{api_id}/routes/{route_id}", headers=headers, json=payload)

    assert response.status_code == 482

def test_update_route_conflict():
    api_id = "your_api_id"
    route_id = "conflicting_route_id"
    headers = {
        "X-Amz-Content-Sha256": "example",
        "X-Amz-Date": "example",
        "X-Amz-Algorithm": "example",
        "X-Amz-Credential": "example",
        "X-Amz-Security-Token": "example",
        "X-Amz-Signature": "example",
        "X-Amz-SignedHeaders": "example"
    }
    payload = {
        "apiKeyRequired": False,
        "authorizationScopes": ["SCOPE_1", "SCOPE_2"],
        "authorizationType": "AWS_IAM",
        "authorizerId": "authorizer_id",
        "modelSelectionExpression": "$default",
        "operationName": "update_operation",
        "requestModels": {"application/json": "request_model"},
        "requestParameters": {},
        "routeKey": "GET /path",
        "routeResponseSelectionExpression": "$default",
        "target": "integrations/integration_id"
    }

    response = requests.patch(f"{BASE_URL}/v2/apis/{api_id}/routes/{route_id}", headers=headers, json=payload)

    assert response.status_code == 483