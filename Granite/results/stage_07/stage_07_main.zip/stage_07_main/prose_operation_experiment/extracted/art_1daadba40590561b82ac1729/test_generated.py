import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["GET", "OPTIONS"],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def edge_config_token():
    headers = {"Authorization": f"Bearer YOUR_BEARER_TOKEN"}

    def get_edge_config_token(edgeConfigId, token, teamId):
        url = f"{BASE_URL}/v1/edge-config/{edgeConfigId}/token/{token}"
        if teamId:
            url += f"?teamId={teamId}"

        response = session.get(url, headers=headers)
        response.raise_for_status()

        return response.json()

    yield get_edge_config_token

def test_edge_config_token(edge_config_token):
    edgeConfigId = "your_edge_config_id"
    token = "your_token"
    teamId = None  # Set to your team ID if needed

    result = edge_config_token(edgeConfigId, token, teamId)

    assert isinstance(result, dict)
    assert set(result.keys()) == {"createdAt", "edgeConfigId", "id", "label", "token"}