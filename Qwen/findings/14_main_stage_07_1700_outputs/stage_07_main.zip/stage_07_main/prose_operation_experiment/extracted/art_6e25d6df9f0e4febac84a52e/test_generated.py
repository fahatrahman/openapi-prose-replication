import pytest
import requests

BASE_URL = "http://openapi.test"

def test_watchlist_screening_individual_program_list():
    headers = {
        "PLAID-CLIENT-ID": "your_client_id",
        "PLAID-SECRET": "your_secret",
        "Plaid-Version": "2020-09-17"
    }
    payload = {
        "client_id": "your_client_id",
        "secret": "your_secret"
    }
    response = requests.post(f"{BASE_URL}/watchlist_screening/individual/program/list", json=payload, headers=headers)
    assert response.status_code == 200
    assert 'next_cursor' in response.json()
    assert 'request_id' in response.json()
    assert 'watchlist_programs' in response.json()
    for program in response.json()['watchlist_programs']:
        assert 'audit_trail' in program
        assert 'created_at' in program
        assert 'id' in program
        assert 'is_archived' in program
        assert 'is_rescanning_enabled' in program
        assert 'lists_enabled' in program
        assert 'name' in program
        assert 'name_sensitivity' in program

if __name__ == "__main__":
    pytest.main([__file__])