# -*- coding: utf-8 -*-
"""Tests for App Block Logs."""

import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

def test_app_block_logs():
    """Test App Block Logs."""
    owner_name = "test_owner"
    app_name = "test_app"
    
    api_token = "your_api_token_here"  # Replace with actual API token
    
    url = f"{BASE_URL}/v0.1/apps/{owner_name}/{app_name}/devices/block_logs"
    headers = {"X-API-Token": api_token}
    response = requests.put(url, headers=headers)
    
    assert response.status_code == 200