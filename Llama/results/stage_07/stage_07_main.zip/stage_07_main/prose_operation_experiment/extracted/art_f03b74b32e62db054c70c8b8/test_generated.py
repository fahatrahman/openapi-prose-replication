import pytest
import requests
from urllib.parse import urlencode

BASE_URL = "http://openapi.test"

def test_get_charges_additional_data():
    params = {
        "order": "asc",
        "pageNumber": 1,
        "sort": "name",
        "q": "chargeAdditionalDataId:\"CHADoLU7sWaGjWtkBx\"",
    }

    response = requests.get(
        f"{BASE_URL}/masterData/chargeAdditionalData", 
        headers={"Authorization": "Bearer token"}, 
        params=urlencode(params)
    )

    assert response.status_code == 200
    response.raise_for_status()

    data = response.json()
    assert isinstance(data, dict)
    assert "chargeAdditionalDataArray" in data
    assert len(data["chargeAdditionalDataArray"]) >= 0

def test_invalid_input_query():
    params = {
        "order": "invalid",
        "pageNumber": -1,
        "sort": "invalid",
        "q": "invalid",
    }

    response = requests.get(
        f"{BASE_URL}/masterData/chargeAdditionalData", 
        headers={"Authorization": "Bearer token"}, 
        params=urlencode(params)
    )

    assert response.status_code == 400
    data = response.json()
    assert isinstance(data, dict)
    assert "code" in data
    assert "message" in data
    assert "details" in data

def test_internal_server_error():
    # Triggering internal server error might require some special setup,
    # so let's just skip this test for now.
    pytest.skip("Internal Server Error testing is skipped")