import os
import requests
import pytest

BASE_URL = "http://openapi.test"
HEADERS = {
    "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
    "X-Amz-Credential": "cred",
    "X-Amz-Date": "20220914T000000Z",
    "X-Amz-Expires": "3600",
    "X-Amz-SignedHeaders": "host",
    "X-Amz-Security-Token": "token",
}

def test_list_environments():
    path = "/applications/{ApplicationId}/environments".format(
        ApplicationId="339ohji"
    )

    response = requests.get(BASE_URL + path, headers=HEADERS)

    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "Items" in response.json()
    assert len(response.json()["Items"]) > 0