# -*- coding: utf-8 -*-

import pytest
import json
import requests
from datetime import date

BASE_URL = "http://openapi.test"

class TestPatchPayInstruction:
    def test_patch_pay_instruction(self):
        employer_id = "GD001"
        employee_id = "CT001"
        pay_instruction_id = "LSH001"
        headers = {
            "Authorization": "Bearer Auto",
            "Api-Version": "default"
        }
        payload = {
            "Description": "Test description",
            "EndDate": str(date.today()),
            "PayLineTag": "test-tag",
            "StartDate": str(date.today())
        }

        response = requests.patch(
            f"{BASE_URL}/Employer/{employer_id}/Employee/{employee_id}/PayInstruction/{pay_instruction_id}",
            headers=headers,
            json=payload
        )

        assert response.status_code == 200
        assert response.json()["Description"] == payload["Description"]
        assert response.json()["EndDate"] == payload["EndDate"]
        assert response.json()["PayLineTag"] == payload["PayLineTag"]
        assert response.json()["StartDate"] == payload["StartDate"]

    def test_patch_pay_instruction_400(self):
        employer_id = "GD001"
        employee_id = "CT001"
        pay_instruction_id = "LSH001"
        headers = {
            "Authorization": "Bearer Auto",
            "Api-Version": "default"
        }
        payload = {}

        response = requests.patch(
            f"{BASE_URL}/Employer/{employer_id}/Employee/{employee_id}/PayInstruction/{pay_instruction_id}",
            headers=headers,
            json=payload
        )

        assert response.status_code == 400

    def test_patch_pay_instruction_401(self):
        employer_id = "GD001"
        employee_id = "CT001"
        pay_instruction_id = "LSH001"
        headers = {
            "Authorization": "Bearer InvalidToken",
            "Api-Version": "default"
        }
        payload = {
            "Description": "Test description",
            "EndDate": str(date.today()),
            "PayLineTag": "test-tag",
            "StartDate": str(date.today())
        }

        response = requests.patch(
            f"{BASE_URL}/Employer/{employer_id}/Employee/{employee_id}/PayInstruction/{pay_instruction_id}",
            headers=headers,
            json=payload
        )

        assert response.status_code == 401

    def test_patch_pay_instruction_404(self):
        employer_id = "InvalidID"
        employee_id = "CT001"
        pay_instruction_id = "LSH001"
        headers = {
            "Authorization": "Bearer Auto",
            "Api-Version": "default"
        }
        payload = {
            "Description": "Test description",
            "EndDate": str(date.today()),
            "PayLineTag": "test-tag",
            "StartDate": str(date.today())
        }

        response = requests.patch(
            f"{BASE_URL}/Employer/{employer_id}/Employee/{employee_id}/PayInstruction/{pay_instruction_id}",
            headers=headers,
            json=payload
        )

        assert response.status_code == 404

    def test_patch_pay_instruction_500(self):
        employer_id = "GD001"
        employee_id = "CT001"
        pay_instruction_id = "InvalidID"
        headers = {
            "Authorization": "Bearer Auto",
            "Api-Version": "default"
        }
        payload = {
            "Description": "Test description",
            "EndDate": str(date.today()),
            "PayLineTag": "test-tag",
            "StartDate": str(date.today())
        }

        response = requests.patch(
            f"{BASE_URL}/Employer/{employer_id}/Employee/{employee_id}/PayInstruction/{pay_instruction_id}",
            headers=headers,
            json=payload
        )

        assert response.status_code == 500