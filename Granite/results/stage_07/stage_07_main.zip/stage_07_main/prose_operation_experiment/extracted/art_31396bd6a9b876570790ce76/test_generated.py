import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retry strategy
session = requests.Session()
retry_strategy = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

# Set headers for API authentication
headers = {
    "PLAID-CLIENT-ID": os.getenv("PLAID_CLIENT_ID"),
    "PLAID-SECRET": os.getenv("PLAID_SECRET"),
    "Plaid-Version": "2022-02-15",
}

@pytest.fixture
def execute_wallet_transaction():
    def _execute_wallet_transaction(
        wallet_id,
        amount,
        reference,
        counterparty,
        idempotency_key,
    ):
        url = f"{BASE_URL}/wallet/transaction/execute"

        payload = {
            "wallet_id": wallet_id,
            "amount": {"iso_currency_code": "USD", "value": amount},
            "reference": reference,
            "counterparty": counterparty,
            "idempotency_key": idempotency_key,
            "reference": reference,
        }

        response = session.post(url, json=payload, headers=headers)
        response.raise_for_status()

        return response.json()

    yield _execute_wallet_transaction

def test_execute_wallet_transaction(execute_wallet_transaction):
    wallet_id = "your_wallet_id"
    amount = 100.00
    reference = "ref-123456"
    counterparty = {
        "name": "Test Counterparty",
        "numbers": {"bacs": {"account": "12345678", "sort_code": "123456"}},
    }
    idempotency_key = "idempotent_key-123"

    response = execute_wallet_transaction(
        wallet_id=wallet_id,
        amount=amount,
        reference=reference,
        counterparty=counterparty,
        idempotency_key=idempotency_key,
    )

    assert response["status"] == "EXECUTED"
    assert isinstance(response["transaction_id"], str)
    assert isinstance(response["request_id"], str)