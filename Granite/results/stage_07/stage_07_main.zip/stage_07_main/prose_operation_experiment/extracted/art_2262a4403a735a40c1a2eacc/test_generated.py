import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = "path/to/service_account.json"
SCOPES = ["https://www.googleapis.com/auth/cloud-platform", "https://www.googleapis.com/auth/cloud-translation"]

def get_authenticated_session():
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    return requests.Session(), credentials

@pytest.fixture
def http_server():
    session, _ = get_authenticated_session()

    def request_factory(*args, **kwargs):
        kwargs["session"] = session
        return requests.Request(*args, **kwargs)

    return requests.adapters.HTTPAdapter(max_retries=0)(
        requests.Session().mount("http://openapi.test/", request_factory))

def test_glossary_entry_update(http_server):
    name = "projects/my-project/locations/us-central1/glossaries/my-glossary/glossaryEntries/my-entry"
    updated_entry = {
        "displayName": "Updated Display Name",
        "inputConfig": {
            "gcsUri": "gs://my-bucket/path/to/input_config.txt"
        }
    }

    url = f"{BASE_URL}/{name}"
    headers = {"Content-Type": "application/json"}

    response = http_server.patch(url, json=updated_entry, headers=headers)

    assert response.status_code == 200
    assert response.json() == updated_entry