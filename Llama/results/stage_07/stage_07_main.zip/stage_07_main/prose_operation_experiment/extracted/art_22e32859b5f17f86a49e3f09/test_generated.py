import pytest
import requests
from datetime import datetime
import hashlib
import hmac
import json
from urllib.parse import urlencode

BASE_URL = "http://openapi.test"

def get_amz_date():
    return datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")

def sign_request(method, url, headers, body):
    algorithm = 'AWS4-HMAC-SHA256'
    credential = f"AWS4 {get_amz_date()}/{get_amz_date()[0:8]}/{get_amz_date()[0:6]}/aws4_request"
    signature_key = hmac.new(b'AWS4' + get_amz_date()[:8].encode(), digestmod=hashlib.sha256).digest()
    signature_key = hmac.new(signature_key, b'aws4_request'.encode(), digestmod=hashlib.sha256).digest()

    if method == 'POST':
        request_body = body.encode('utf-8')
    else:
        request_body = None

    canonical_request = f"{method}\n{url}\n\n{headers['Host']}\n\n{urlencode(headers)}\n{request_body or ''}"
    hashed_canonical_request = hashlib.sha256(canonical_request.encode()).hexdigest()
    string_to_sign = f"{algorithm}\n{get_amz_date()}\n{get_amz_date()[0:8]}/{get_amz_date()[0:6]}/aws4_request\n{hashed_canonical_request}"

    signature = hmac.new(signature_key, string_to_sign.encode(), digestmod=hashlib.sha256).hexdigest()

    return {
        'X-Amz-Algorithm': algorithm,
        'X-Amz-Credential': credential,
        'X-Amz-Date': get_amz_date(),
        'X-Amz-Signature': signature,
        'X-Amz-SignedHeaders': ','.join(sorted(headers.keys()))
    }

def create_sbm_export(report_format, resource_filter_criteria, s3_destination):
    data = {
        'reportFormat': report_format,
        's3Destination': s3_destination,
        'resourceFilterCriteria': resource_filter_criteria
    }
    response = requests.post(f'{BASE_URL}/sbomexport/create', headers={'Content-Type': 'application/json'}, data=json.dumps(data), auth=('your_access_key_id', 'your_secret_access_key'))
    assert response.status_code == 200
    return response.json()

def test_create_sbom_export():
    resource_filter_criteria = {
        'accountId': [
            {'comparison': 'EQUALS', 'value': 'account-id'}
        ],
        'ec2InstanceTags': [
            {'comparison': 'EQUALS', 'value': 'tag-key'}
        ]
    }
    s3_destination = {
        'bucketName': 'bucket-name',
        'keyPrefix': 'prefix/',
        'kmsKeyArn': 'arn:aws:kms:region:account-id:key/12345678-1234-1234-1234-123456789012'
    }
    report_format = 'CYCLONEDX_1_4'

    response = create_sbm_export(report_format, resource_filter_criteria, s3_destination)
    assert response['reportId']