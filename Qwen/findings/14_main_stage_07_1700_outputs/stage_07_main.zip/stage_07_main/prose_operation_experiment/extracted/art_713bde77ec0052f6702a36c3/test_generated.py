import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_domains():
    url = f"{BASE_URL}/domains"
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "ACCESS_KEY_ID/DATE/REGION/SERVICE/aws4_request",
        "X-Amz-Date": "DATE-TIME",
        "X-Amz-Security-Token": "SESSION_TOKEN",
        "X-Amz-Signature": "SIGNATURE",
        "X-Amz-SignedHeaders": "host;x-amz-date;x-amz-security-token"
    }
    params = {
        "next-token": "PAGINATION_TOKEN",
        "max-results": 10
    }
    
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "Items" in response.json()
    assert "NextToken" in response.json()

def test_list_domains_bad_request():
    url = f"{BASE_URL}/domains"
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "ACCESS_KEY_ID/DATE/REGION/SERVICE/aws4_request",
        "X-Amz-Date": "DATE-TIME",
        "X-Amz-Security-Token": "SESSION_TOKEN",
        "X-Amz-Signature": "SIGNATURE",
        "X-Amz-SignedHeaders": "host;x-amz-date;x-amz-security-token"
    }
    params = {
        "next-token": "INVALID_TOKEN",
        "max-results": 10
    }
    
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 480
    assert isinstance(response.json(), dict)
    assert "BadRequestException" in response.json()

def test_list_domains_resource_not_found():
    url = f"{BASE_URL}/domains"
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "ACCESS_KEY_ID/DATE/REGION/SERVICE/aws4_request",
        "X-Amz-Date": "DATE-TIME",
        "X-Amz-Security-Token": "SESSION_TOKEN",
        "X-Amz-Signature": "SIGNATURE",
        "X-Amz-SignedHeaders": "host;x-amz-date;x-amz-security-token"
    }
    params = {
        "next-token": "NOT_FOUND_TOKEN",
        "max-results": 10
    }
    
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 481
    assert isinstance(response.json(), dict)
    assert "ResourceNotFoundException" in response.json()

def test_list_domains_access_denied():
    url = f"{BASE_URL}/domains"
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "ACCESS_KEY_ID/DATE/REGION/SERVICE/aws4_request",
        "X-Amz-Date": "DATE-TIME",
        "X-Amz-Security-Token": "SESSION_TOKEN",
        "X-Amz-Signature": "SIGNATURE",
        "X-Amz-SignedHeaders": "host;x-amz-date;x-amz-security-token"
    }
    params = {
        "next-token": "ACCESS_DENIED_TOKEN",
        "max-results": 10
    }
    
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 482
    assert isinstance(response.json(), dict)
    assert "AccessDeniedException" in response.json()

def test_list_domains_throttling():
    url = f"{BASE_URL}/domains"
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "ACCESS_KEY_ID/DATE/REGION/SERVICE/aws4_request",
        "X-Amz-Date": "DATE-TIME",
        "X-Amz-Security-Token": "SESSION_TOKEN",
        "X-Amz-Signature": "SIGNATURE",
        "X-Amz-SignedHeaders": "host;x-amz-date;x-amz-security-token"
    }
    params = {
        "next-token": "THROTTLING_TOKEN",
        "max-results": 10
    }
    
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 483
    assert isinstance(response.json(), dict)
    assert "ThrottlingException" in response.json()

def test_list_domains_internal_server_error():
    url = f"{BASE_URL}/domains"
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "ACCESS_KEY_ID/DATE/REGION/SERVICE/aws4_request",
        "X-Amz-Date": "DATE-TIME",
        "X-Amz-Security-Token": "SESSION_TOKEN",
        "X-Amz-Signature": "SIGNATURE",
        "X-Amz-SignedHeaders": "host;x-amz-date;x-amz-security-token"
    }
    params = {
        "next-token": "INTERNAL_SERVER_ERROR_TOKEN",
        "max-results": 10
    }
    
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 484
    assert isinstance(response.json(), dict)
    assert "InternalServerException" in response.json()