# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_get_all_risk_factors():
    params = {
        'age.value': 18,
        'age.unit': 'year',
        'enable_triage_5': True
    }
    
    response = requests.get(urljoin(BASE_URL, '/risk_factors'), params=params)
    
    assert response.status_code == 200
    
    try:
        response_json = response.json()
        
        assert isinstance(response_json, list)
        
        for risk_factor in response_json:
            assert isinstance(risk_factor, dict)
            
            required_keys = ['id', 'name', 'sex_filter']
            for key in required_keys:
                assert key in risk_factor
                
    except ValueError:
        pytest.fail("Failed to parse JSON")