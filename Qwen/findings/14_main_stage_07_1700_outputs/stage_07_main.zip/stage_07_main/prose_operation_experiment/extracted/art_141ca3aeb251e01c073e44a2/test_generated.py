import pytest
import requests
from datetime import date

BASE_URL = "http://openapi.test"

def test_get_holiday_balance_report_output():
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    params = {
        "EmployerKey": "GD001",
        "HolidayYearEnd": date(2018, 12, 31).isoformat(),
        "EmployeeCodes": "VNS001,VNS002",
        "StartIndex": "1",
        "MaxIndex": "100"
    }
    response = requests.get(f"{BASE_URL}/Report/HOLBAL/run", headers=headers, params=params)
    
    assert response.status_code == 200
    assert isinstance(response.content, bytes)

if __name__ == "__main__":
    pytest.main()