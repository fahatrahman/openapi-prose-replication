import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_default_branch():
    url = f"{BASE_URL}/v2beta/projects/locations/global/catalogs/default_catalog/getDefaultBranch"
    headers = {"Accept": "application/json"}
    params = {
        "$.xgafv": "1",
        "access_token": None,
        "alt": "json",
        "callback": None,
        "fields": None,
        "key": None,
        "oauth_token": None,
        "prettyPrint": False,
        "quotaUser": None,
        "upload_protocol": None,
        "uploadType": None,
    }
    
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    assert response.json()["branch"]
    assert response.json()["note"]
    assert response.json()["set_time"]

def test_get_default_branch_with_oauth():
    # Obtain an OAuth token first
    auth_url = "https://accounts.google.com/o/oauth2/auth"
    scopes = ["https://www.googleapis.com/auth/cloud-platform"]
    auth_response = requests.get(auth_url, params={"scope": ",".join(scopes)})
    assert auth_response.status_code == 302
    
    # Use the obtained token to make the request
    token_url = "https://accounts.google.com/o/oauth2/token"
    token_params = {"grant_type": "authorization_code", "code": auth_response.headers["Location"].split("=")[1], "redirect_uri": "urn:ietf:wg:oauth:2.0:oob", "client_id": "your_client_id"}
    token_response = requests.post(token_url, data=token_params)
    assert token_response.status_code == 200
    
    token = token_response.json()["access_token"]
    
    url = f"{BASE_URL}/v2beta/projects/locations/global/catalogs/default_catalog/getDefaultBranch"
    headers = {"Authorization": f"Bearer {token}", "Accept": "application/json"}
    params = {
        "$.xgafv": "1",
        "access_token": None,
        "alt": "json",
        "callback": None,
        "fields": None,
        "key": None,
        "oauth_token": None,
        "prettyPrint": False,
        "quotaUser": None,
        "upload_protocol": None,
        "uploadType": None,
    }
    
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    assert response.json()["branch"]
    assert response.json()["note"]
    assert response.json()["set_time"]