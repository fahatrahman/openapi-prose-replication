import os
import pytest
import requests
from googleapiclient.discovery import build

BASE_URL = "http://openapi.test"

@pytest.fixture
def cloudsupport_service():
    """Build and return the Cloud Support Service object."""
    api_service_name = "cloudsupport"
    api_version = "v2"
    discovery_url = f"{BASE_URL}/$discovery/rest?version={api_version}"

    service = build(
        api_service_name, api_version, discoveryServiceUrl=discovery_url
    )
    return service

def test_list_comments(cloudsupport_service):
    """Test listing comments for a case."""
    parent = "projects/some-project/cases/43595344"

    request = (
        cloudsupport_service.cases().comments().list(parent=parent)
    )
    response = request.execute()

    assert isinstance(response, dict)
    assert "comments" in response
    assert "nextPageToken" in response

if __name__ == "__main__":
    pytest.main([__file__])