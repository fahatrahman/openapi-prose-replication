import os
import json
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Retry mechanism for requests
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["GET", "OPTIONS"],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def custom_vision_api():
    headers = {"Training-Key": os.getenv("TRAINING_KEY")}
    return session

def test_get_domain(custom_vision_api):
    domain_id = "b30a91ae-e3c1-4f73-a81e-c270bff27c39"
    url = f"{BASE_URL}/domains/{domain_id}"

    response = custom_vision_api.get(url, headers=headers)

    if response.status_code == 200:
        domain_data = response.json()
        assert isinstance(domain_data, dict)
        assert domain_data["name"] == "Retail"
        assert domain_data["type"] == "Classification"
    else:
        error_data = response.json()
        assert error_data["code"] in [
            "NoError",
            "BadRequest",
            "BadRequestExceededBatchSize",
            "BadRequestNotSupported",
            "BadRequestInvalidIds",
            "BadRequestProjectName",
            "BadRequestProjectNameNotUnique",
            "BadRequestProjectDescription",
            "BadRequestProjectUnknownDomain",
            "BadRequestProjectUnknownClassification",
            "BadRequestProjectUnsupportedDomainTypeChange",
            "BadRequestProjectUnsupportedExportPlatform",
            "BadRequestProjectImagePreprocessingSettings",
            "BadRequestProjectDuplicated",
            "BadRequestIterationName",
            "BadRequestIterationNameNotUnique",
            "BadRequestIterationDescription",
            "BadRequestIterationIsNotTrained",
            "BadRequestIterationValidationFailed",
            "BadRequestWorkspaceCannotBeModified",
            "BadRequestWorkspaceNotDeletable",
            "BadRequestTagName",
            "BadRequestTagNameNotUnique",
            "BadRequestTagDescription",
            "BadRequestTagType",
            "BadRequestMultipleNegativeTag",
            "BadRequestImageTags",
            "BadRequestImageRegions",
            "BadRequestNegativeAndRegularTagOnSameImage",
            "BadRequestRequiredParamIsNull",
            "BadRequestIterationIsPublished",
            "BadRequestInvalidPublishName",
            "BadRequestInvalidPublishTarget",
            "BadRequestUnpublishFailed",
            "BadRequestIterationNotPublished",
            "BadRequestSubscriptionApi",
            "BadRequestExceedProjectLimit",
            "BadRequestExceedIterationPerProjectLimit",
            "BadRequestExceedTagPerProjectLimit",
            "BadRequestExceedTagPerImageLimit",
            "BadRequestExceededQuota",
            "BadRequestCannotMigrateProjectWithName",
            "BadRequestNotLimitedTrial",
            "BadRequestImageBatch",
            "BadRequestImageStream",
            "BadRequestImageUrl",
            "BadRequestImageFormat",
            "BadRequestImageSizeBytes",
            "BadRequestImageExceededCount",
            "BadRequestTrainingNotNeeded",
            "BadRequestTrainingNotNeededButTrainingPipelineUpdated",
            "BadRequestTrainingValidationFailed",
            "BadRequestClassificationTrainingValidationFailed",
            "BadRequestMultiClassClassificationTrainingValidationFailed",
            "BadRequestMultiLabelClassificationTrainingValidationFailed",
            "BadRequestDetectionTrainingValidationFailed",
            "BadRequestTrainingAlreadyInProgress",
            "BadRequestDetectionTrainingNotAllowNegativeTag",
            "BadRequestInvalidEmailAddress",
            "BadRequestDomainNotSupportedForAdvancedTraining",
            "BadRequestExportPlatformNotSupportedForAdvancedTraining",
            "BadRequestReservedBudgetInHoursNotEnoughForAdvancedTraining",
            "BadRequestExportValidationFailed",
            "BadRequestExportAlreadyInProgress",
            "BadRequestPredictionIdsMissing",
            "BadRequestPredictionIdsExceededCount",
            "BadRequestPredictionTagsExceededCount",
            "BadRequestPredictionResultsExceededCount",
            "BadRequestPredictionInvalidApplicationName",
            "BadRequestPredictionInvalidQueryParameters",
            "BadRequestInvalidImportToken",
            "BadRequestExportWhileTraining",
            "BadRequestInvalid",
            "UnsupportedMediaType",
            "Forbidden",
            "ForbiddenUser",
            "ForbiddenUserResource",
            "ForbiddenUserSignupDisabled",
            "ForbiddenUserSignupAllowanceExceeded",
            "ForbiddenUserDoesNotExist",
            "ForbiddenUserDisabled",
            "ForbiddenUserInsufficientCapability",
            "ForbiddenDRModeEnabled",
            "ForbiddenInvalid",
            "NotFound",
            "NotFoundProject",
            "NotFoundProjectDefaultIteration",
            "NotFoundIteration",
            "NotFoundIterationPerformance",
            "NotFoundTag",
            "NotFoundImage",
            "NotFoundDomain",
            "NotFoundApimSubscription",
            "NotFoundInvalid",
            "Conflict",
            "ConflictInvalid",
            "ErrorUnknown",
            "ErrorIterationCopyFailed",
            "ErrorPreparePerformanceMigrationFailed",
            "ErrorProjectInvalidWorkspace",
            "ErrorProjectInvalidPipelineConfiguration",
            "ErrorProjectInvalidDomain",
            "ErrorProjectTrainingRequestFailed",
            "ErrorProjectImportRequestFailed",
            "ErrorProjectExportRequestFailed",
            "ErrorFeaturizationServiceUnavailable",
            "ErrorFeaturizationQueueTimeout",
            "ErrorFeaturizationInvalidFeaturizer",
            "ErrorFeaturizationUnrecognizedJob",
            "ErrorFeaturizationAugmentationUnavailable",
            "ErrorFeaturizationAugmentationError",
            "ErrorExporterInvalidPlatform",
            "ErrorExporterInvalidFeaturizer",
            "ErrorExporterInvalidClassifier",
            "ErrorPredictionServiceUnavailable",
            "ErrorPredictionModelNotFound",
            "ErrorPredictionModelNotCached",
            "ErrorPrediction",
            "ErrorPredictionStorage",
            "ErrorRegionProposal",
            "ErrorInvalid"
        ]
        assert error_data["message"] is not None