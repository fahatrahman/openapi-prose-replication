import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_errors_group_counts_per_day():
    owner_name = "test_owner"
    app_name = "test_app"
    errorGroupId = "test_error_group_id"
    start = datetime.now().isoformat()
    end = (datetime.now() + timedelta(days=1)).isoformat()
    headers = {
        "X-API-Token": "your_api_token_here"
    }
    params = {
        "version": "1.0",
        "start": start,
        "end": end
    }
    response = requests.get(
        f"{BASE_URL}/v0.1/apps/{owner_name}/{app_name}/errors/errorGroups/{errorGroupId}/errorCountsPerDay",
        headers=headers,
        params=params
    )
    assert response.status_code == 200
    data = response.json()
    assert "count" in data
    assert "errors" in data
    for error in data["errors"]:
        assert "count" in error
        assert "datetime" in error