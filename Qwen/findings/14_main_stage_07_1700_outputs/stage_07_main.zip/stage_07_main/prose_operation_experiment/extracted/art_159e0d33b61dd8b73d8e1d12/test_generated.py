import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_watch():
    url = f"{BASE_URL}/v1/forms/{formId}/watches"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "createWatchRequest": {
            "watch": {
                "eventType": "RESPONSES",
                "target": {
                    "topic": {
                        "topicName": "projects/YOUR_PROJECT_ID/topics/YOUR_TOPIC_NAME"
                    }
                }
            },
            "watchId": None
        }
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert "watch" in response.json()
    assert response.json()["watch"]["eventType"] == "RESPONSES"