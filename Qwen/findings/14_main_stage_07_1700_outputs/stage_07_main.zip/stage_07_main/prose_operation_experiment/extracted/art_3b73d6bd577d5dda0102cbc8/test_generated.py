import pytest
import requests

BASE_URL = "http://openapi.test"

def test_set_line_item_metadata():
    url = f"{BASE_URL}/12345/orders/abc123/setLineItemMetadata"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "lineItemId": "item123",
        "annotations": [
            {"key": "color", "value": "red"},
            {"key": "size", "value": "large"}
        ]
    }

    response = requests.post(url, headers=headers, json=payload)

    assert response.status_code == 200
    assert response.json()["executionStatus"] == "executed"
    assert response.json()["kind"] == "content#ordersSetLineItemMetadataResponse"