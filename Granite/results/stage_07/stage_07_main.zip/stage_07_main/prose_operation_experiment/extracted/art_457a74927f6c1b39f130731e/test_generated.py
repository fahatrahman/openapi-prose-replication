import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from typing import List, Dict

BASE_URL = "http://openapi.test"

session = requests.Session()
adapter = HTTPAdapter(max_retries=3)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def album_tracks(album_id: int, fields: str = None, lang: str = None):
    url = f"{BASE_URL}/api/albums/{album_id}/tracks"
    params = {"fields": fields, "lang": lang}
    response = session.get(url, params=params)

    if response.status_code != 200:
        raise Exception(f"Failed to fetch tracks for album {album_id}: {response.text}")

    return [
        {
            "discNumber": track["discNumber"],
            "id": track["id"],
            "name": track["name"],
            "rating": track["rating"],
            "song": track["song"],
            "trackNumber": track["trackNumber"],
        }
        for track in response.json()
    ]