# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_get_members_synopsis():
    """Test getting member synopsis"""
    
    # Construct the full path for the request
    path = "/api/Members/{}/Synopsis"
    
    # Generate a random ID (in this case, we'll just use 123)
    id = 123
    
    # Create the full URL by joining the base URL and path
    url = urljoin(BASE_URL, path.format(id))
    
    # Send the GET request
    response = requests.get(url)
    
    # Check if the request was successful
    assert response.status_code == 200
    
    # Parse the JSON response
    try:
        response_json = response.json()
    except ValueError:
        pytest.fail("Invalid JSON in response")
    
    # Verify that the response matches the expected schema
    assert isinstance(response_json, dict)
    assert 'links' not in response_json or all(isinstance(link, dict) and all(key in link for key in ['href', 'method', 'rel']) for link in response_json['links'])
    assert isinstance(response_json.get('value'), str)