# -*- coding: utf-8 -*-

import pytest
import requests
from typing import List

BASE_URL = "http://openapi.test"

def get_player_season_stats_by_player(format: str, round_id: str, player_id: str) -> List[dict]:
    """
    Retrieves player season stats by player.

    Args:
        format (str): Desired response format. Valid entries are 'XML' or 'JSON'.
        round_id (str): Unique FantasyData Round ID.
        player_id (str): Unique FantasyData Player ID.

    Returns:
        List[dict]: A list of player season stats.
    """

    url = f"{BASE_URL}/{format}/PlayerSeasonStatsByPlayer/{round_id}/{player_id}"
    headers = {}
    params = {}

    # Add API key to headers or query parameters if available
    # For this example, we assume there is no API key provided

    try:
        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        pytest.fail(f"Request failed: {e}")