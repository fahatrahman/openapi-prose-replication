import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_vm_scale_set_vm_network_interfaces():
    url = f"{BASE_URL}/subscriptions/{pytest.subscription_id}/resourceGroups/{pytest.resource_group_name}/providers/microsoft.Compute/virtualMachineScaleSets/{pytest.vm_scale_set_name}/virtualMachines/{pytest.virtual_machine_index}/networkInterfaces"
    params = {
        "api-version": "2016-09-01"
    }
    headers = {
        "Authorization": f"Bearer {pytest.access_token}"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "nextLink" in data or "value" in data