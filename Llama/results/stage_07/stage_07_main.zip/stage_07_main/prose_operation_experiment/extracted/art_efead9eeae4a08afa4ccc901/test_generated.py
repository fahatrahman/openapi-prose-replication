# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_patch_pension():
    url = f"{BASE_URL}/Employer/{pytest.fixture('employer_id')}/Pension/{pytest.fixture('pension_id')}"

    headers = {
        'Authorization': 'Bearer Auto',
        'Api-Version': 'default'
    }

    response = requests.patch(url, headers=headers)

    assert response.status_code == 200
    assert response.json()['Pension']['AECompatible'] is True
    assert response.json()['Pension']['Certification'] == 'Set1'

@pytest.fixture
def employer_id():
    return 'GD001'

@pytest.fixture
def pension_id():
    return 'VQR001'