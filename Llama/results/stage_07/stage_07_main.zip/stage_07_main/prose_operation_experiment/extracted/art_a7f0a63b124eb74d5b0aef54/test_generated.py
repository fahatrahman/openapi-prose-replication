# -*- coding: utf-8 -*-
import pytest
import requests
from datetime import date

BASE_URL = "http://openapi.test"

def test_get_holiday_balance_report_output():
    """Test GetHolidayBalanceReportOutput"""
    
    # Construct GET request
    url = f"{BASE_URL}/Report/HOLBAL/run"
    params = {
        "EmployerKey": "ER001",
        "HolidayYearEnd": str(date.today()),
    }
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default",
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 200
    assert response.headers["Content-Type"] == "application/json"

def test_get_holiday_balance_report_output_employer_key_missing():
    """Test GetHolidayBalanceReportOutput with missing EmployerKey"""

    # Construct GET request
    url = f"{BASE_URL}/Report/HOLBAL/run"
    params = {}
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default",
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code in [400, 401, 404, 500]
    assert response.headers["Content-Type"] == "application/json"

def test_get_holiday_balance_report_output_employee_codes():
    """Test GetHolidayBalanceReportOutput with EmployeeCodes"""

    # Construct GET request
    url = f"{BASE_URL}/Report/HOLBAL/run"
    params = {
        "EmployerKey": "ER001",
        "HolidayYearEnd": str(date.today()),
        "EmployeeCodes": "EMP001,EMP002",
    }
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default",
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 200
    assert response.headers["Content-Type"] == "application/json"

def test_get_holiday_balance_report_output_start_index():
    """Test GetHolidayBalanceReportOutput with StartIndex"""

    # Construct GET request
    url = f"{BASE_URL}/Report/HOLBAL/run"
    params = {
        "EmployerKey": "ER001",
        "HolidayYearEnd": str(date.today()),
        "StartIndex": "1",
    }
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default",
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 200
    assert response.headers["Content-Type"] == "application/json"

def test_get_holiday_balance_report_output_max_index():
    """Test GetHolidayBalanceReportOutput with MaxIndex"""

    # Construct GET request
    url = f"{BASE_URL}/Report/HOLBAL/run"
    params = {
        "EmployerKey": "ER001",
        "HolidayYearEnd": str(date.today()),
        "MaxIndex": "100",
    }
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default",
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code == 200
    assert response.headers["Content-Type"] == "application/json"

def test_get_holiday_balance_report_output_authorization_missing():
    """Test GetHolidayBalanceReportOutput with missing Authorization"""

    # Construct GET request
    url = f"{BASE_URL}/Report/HOLBAL/run"
    params = {
        "EmployerKey": "ER001",
        "HolidayYearEnd": str(date.today()),
    }
    headers = {}

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code in [400, 401, 404, 500]
    assert response.headers["Content-Type"] == "application/json"

def test_get_holiday_balance_report_output_api_version_missing():
    """Test GetHolidayBalanceReportOutput with missing Api-Version"""

    # Construct GET request
    url = f"{BASE_URL}/Report/HOLBAL/run"
    params = {
        "EmployerKey": "ER001",
        "HolidayYearEnd": str(date.today()),
    }
    headers = {
        "Authorization": "Auto",
    }

    response = requests.get(url, params=params, headers=headers)

    assert response.status_code in [400, 401, 404, 500]
    assert response.headers["Content-Type"] == "application/json"