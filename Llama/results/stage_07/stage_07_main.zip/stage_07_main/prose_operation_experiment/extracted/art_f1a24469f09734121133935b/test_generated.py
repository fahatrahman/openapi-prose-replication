import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_apply_configuration():
    parent = "/v1/customers/123/devices"
    body = {
        "configuration": f"{BASE_URL}/customers/123/configurations/456",
        "device": {
            "deviceId": "12345",
            "deviceIdentifier": {
                "chromeOsAttestedDeviceId": "",
                "deviceType": "DEVICE_TYPE_CHROME_OS",
                "imei": "",
                "manufacturer": "",
                "meid": "",
                "model": "",
                "serialNumber": ""
            }
        }
    }

    headers = {
        'Content-Type': 'application/json',
    }

    response = requests.post(
        urljoin(BASE_URL, parent),
        json=body,
        headers=headers,
    )

    assert response.status_code == 200