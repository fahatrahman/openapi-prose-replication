import pytest
import requests

BASE_URL = "http://openapi.test"

def test_finalize_mfa_enrollment():
    url = f"{BASE_URL}/v2/accounts/mfaEnrollment:finalize"
    headers = {
        "Content-Type": "application/json",
    }
    payload = {
        "displayName": "test_user",
        "idToken": "test_id_token",
        "phoneVerificationInfo": {
            "androidVerificationProof": "test_android_verification_proof",
            "code": "test_code",
            "phoneNumber": "test_phone_number",
            "sessionInfo": "test_session_info"
        },
        "totpVerificationInfo": {
            "sessionInfo": "test_totp_session_info",
            "verificationCode": "test_totp_code"
        },
        "tenantId": "test_tenant_id",
        "totpVerificationInfo": {}
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert "idToken" in response.json()
    assert "refreshToken" in response.json()

if __name__ == "__main__":
    pytest.main()