import os
import pytest
import requests
from googleapiclient.discovery import build

BASE_URL = "http://openapi.test"

def get_operating_system(profile_id, dart_id):
    service = build('dfareporting', 'v3.1', developerKey="YOUR_DEVELOPER_KEY")
    response = service.operatingSystems().get(
        profileId=profile_id, dartId=dart_id
    ).execute()

    return response

@pytest.mark.parametrize("profile_id,dart_id", [
    ("TEST_PROFILE_ID", "TEST_DART_ID"),
])
def test_get_operating_system(profile_id, dart_id):
    response = get_operating_system(profile_id, dart_id)
    assert isinstance(response, dict)
    assert "dartId" in response
    assert "desktop" in response or "mobile" in response
    assert "kind" in response
    assert response["kind"] == "dfareporting#operatingSystem"