import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_me_allowedOrigins_originId():
    origin_id = "test_origin_id"
    url = f"{BASE_URL}/me/allowedOrigins/{origin_id}"
    
    # Test with Basic Auth
    response = requests.get(url, auth=("username", "password"))
    assert response.status_code == 200
    assert "application/json" in response.headers["Content-Type"]
    allowed_origin = response.json()
    assert isinstance(allowed_origin, dict)
    assert "_links" in allowed_origin
    assert "domain" in allowed_origin
    assert "id" in allowed_origin
    
    # Test with ApiKeyAuth
    headers = {
        "X-API-Key": "your_api_key_here"
    }
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    assert "application/json" in response.headers["Content-Type"]
    allowed_origin = response.json()
    assert isinstance(allowed_origin, dict)
    assert "_links" in allowed_origin
    assert "domain" in allowed_origin
    assert "id" in allowed_origin
    
    # Test with invalid originId
    invalid_origin_id = "invalid_origin_id"
    url = f"{BASE_URL}/me/allowedOrigins/{invalid_origin_id}"
    response = requests.get(url, auth=("username", "password"))
    assert response.status_code == 400
    assert "application/json" in response.headers["Content-Type"]
    error = response.json()
    assert isinstance(error, dict)
    assert "errorCode" in error
    assert "errorDescription" in error
    
    # Test without authentication
    response = requests.get(url)
    assert response.status_code == 401
    assert "application/json" in response.headers["Content-Type"]
    error = response.json()
    assert isinstance(error, dict)
    assert "errorCode" in error
    assert "errorDescription" in error