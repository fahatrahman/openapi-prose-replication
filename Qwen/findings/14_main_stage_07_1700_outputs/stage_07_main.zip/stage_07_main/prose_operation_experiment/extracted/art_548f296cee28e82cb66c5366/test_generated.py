import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_vendor_apps():
    url = f"{BASE_URL}/vendor/apps"
    params = {
        "offset": 0,
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    for item in data:
        assert isinstance(item, dict)
        assert "archived" in item
        assert "branch" in item
        assert "buildFlavor" in item
        assert "cancelOnPush" in item
        assert "commitId" in item
        assert "creationDate" in item
        assert "deployUrl" in item
        assert "deployment" in item
        assert "description" in item
        assert "favourite" in item
        assert "homogeneous" in item
        assert "id" in item
        assert "instance" in item
        assert "last_deploy" in item
        assert "name" in item
        assert "ownerId" in item
        assert "separateBuild" in item
        assert "state" in item
        assert "stickySessions" in item
        assert "vhosts" in item
        assert "webhookSecret" in item
        assert "webhookUrl" in item
        assert "zone" in item