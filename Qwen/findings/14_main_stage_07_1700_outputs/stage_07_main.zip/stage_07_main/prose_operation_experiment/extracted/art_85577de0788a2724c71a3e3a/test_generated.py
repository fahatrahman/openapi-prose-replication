import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_sip_media_application_logging_configuration():
    url = f"{BASE_URL}/sip-media-applications/example-sip-media-application-id/logging-configuration"
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20130529/us-east-1/sts/aws4_request",
        "X-Amz-Date": "20130529T123456Z",
        "X-Amz-Security-Token": "AQoDYXdzEPT//////////wEaDDFCQVNDRU5USUFGQUxJTkFURSBTVFUgVVNFUlQgRE9XTlRJRklMRQ==",
        "X-Amz-Signature": "d3b07384d113edec49eaa6238ad5ff00",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-algorithm;x-amz-credential;x-amz-security-token"
    }
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

if __name__ == "__main__":
    pytest.main()