import pytest
import requests

BASE_URL = "http://openapi.test"

def read_float_table(table_name, start_index=None, num_elements=None):
    url = f"{BASE_URL}/device/strategy/tables/floats/{table_name}"

    if start_index is not None:
        url += f"?ordvhVxupn={start_index}"

    if num_elements is not None:
        url += f"&ykeKevvkaox={num_elements}"

    response = requests.get(url)

    if response.status_code == 200:
        return response.json()
    elif response.status_code == 400:
        error_response = response.json()
        raise Exception(f"Error 400: {error_response['message']}. ErrorCode: {error_response['errorCode']}")
    elif response.status_code == 401:
        error_response = response.json()
        raise Exception(f"Error 401: {error_response['message']}. ErrorCode: {error_response['errorCode']}")
    elif response.status_code == 404:
        error_response = response.json()
        raise Exception(f"Error 404: {error_response['message']}. ErrorCode: {error_response['errorCode']}")
    else:
        response.raise_for_status()

@pytest.mark.parametrize("table_name", ["example_table"])
@pytest.mark.parametrize("start_index", [None, 5])
@pytest.mark.parametrize("num_elements", [None, 3])
def test_read_float_table(table_name, start_index, num_elements):
    try:
        result = read_float_table(table_name, start_index, num_elements)
        assert isinstance(result, list)
        for value in result:
            assert isinstance(value, float)
    except Exception as e:
        pytest.fail(f"Test failed with exception: {str(e)}")