import pytest
import requests

BASE_URL = "http://openapi.test"

def test_cancel_operation():
    url = f"{BASE_URL}/v1/projects/apps/releases.operations.cancel"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token",
        "alt": "json",
        "callback": "your_callback",
        "fields": "your_fields",
        "key": "your_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": False,
        "quotaUser": "your_quota_user",
        "uploadProtocol": "your_upload_protocol",
        "uploadType": "your_upload_type",
        "name": "your_operation_name"
    }
    headers = {
        "Authorization": "Bearer your_bearer_token"
    }
    response = requests.post(url, json={"name": "your_operation_name"}, params=params, headers=headers)
    assert response.status_code == 200
    assert response.json() == {"kind": "empty"}