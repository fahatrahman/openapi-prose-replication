import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_PATH = "path/to/your/credentials.json"

@pytest.fixture(scope="session")
def authenticated_session():
    credentials = service_account.Credentials.from_service_account_file(
        CREDENTIALS_PATH, scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )

    def create_authenticated_session():
        session = requests.Session()
        session.auth = (
            credentials.service_account_email,
            credentials.id_token if credentials.id_token else None,
        )
        return session

    return create_authenticated_session()

def test_get_project(authenticated_session):
    project_id = "your_project_id"
    url = f"{BASE_URL}/v1/projects/{project_id}"

    response = authenticated_session.get(url)

    assert response.status_code == 200
    assert isinstance(response.json(), dict)