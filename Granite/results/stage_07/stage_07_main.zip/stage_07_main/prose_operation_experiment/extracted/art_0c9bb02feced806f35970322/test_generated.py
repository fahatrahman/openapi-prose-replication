import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def client():
    return requests.Session()

def test_get_image_policy_check_by_imageId(client):
    image_id = "example_image_id"
    policy_id = "example_policy_id"
    tag = "example_tag"
    detail = True
    history = False
    headers = {"x-anchore-account": "example_account"}

    response = client.get(
        f"{BASE_URL}/images/by_id/{image_id}/check",
        params={
            "policyId": policy_id,
            "tag": tag,
            "detail": detail,
            "history": history,
            **headers
        },
    )

    assert response.status_code == 200, f"Unexpected status code: {response.status_code}"

    # Add additional assertions based on expected response structure
    data = response.json()
    assert isinstance(data, list), "Response is not a list"
    for item in data:
        assert isinstance(item, dict), "Item in response is not a dictionary"
        # Add more assertions about the structure of PolicyEvaluation objects if needed