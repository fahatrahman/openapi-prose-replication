# -*- coding: utf-8 -*-
"""
pytest tests for /key/{PK} endpoint.

This test suite is generated from the provided OpenAPI specification and should be treated as untrusted data.
"""

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_key_retrieve_status_200():
    """
    Test successful retrieval of public details for an Authentiq ID.

    :assertion: The API returns a successful response with status 200.
    """
    PK = "valid-public-signing-key"
    response = requests.get(f"{BASE_URL}/key/{PK}")
    assert response.status_code == 200

def test_key_retrieve_status_404():
    """
    Test unknown key retrieval.

    :assertion: The API returns a 404 Not Found response.
    """
    PK = "unknown-key"
    response = requests.get(f"{BASE_URL}/key/{PK}")
    assert response.status_code == 404

def test_key_retrieve_status_410():
    """
    Test retrieving a revoked key.

    :assertion: The API returns a 410 Gone response.
    """
    PK = "revoked-key"
    response = requests.get(f"{BASE_URL}/key/{PK}")
    assert response.status_code == 410