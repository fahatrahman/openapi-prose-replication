import os
import json
import pytest
from requests import Session
from requests_aws_sigv4 import AWSRequestsAuthV4

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def session():
    return Session()

@pytest.fixture(scope="function")
def auth(session):
    return AWSRequestsAuthV4(
        access_key="TEST", secret_key="TEST", service="TEST", region="TEST"
    )

def test_create_backup_selection(session, auth):
    backup_plan_id = "TEST"

    payload = {
        "BackupSelection": {
            "Conditions": [
                {
                    "ConditionType": "STRINGEQUALS",
                    "ConditionKey": "some-condition-key",
                    "ConditionValue": "some-condition-value",
                }
            ],
            "IamRoleArn": "arn:aws:iam::123456789012:role/test",
            "ListOfTags": [
                {"ConditionKey": "some-condition-key", "ConditionValue": "some-condition-value"},
            ],
            "Resources": ["arn:aws:s3:::test"],
            "SelectionName": "TestSelection",
        },
        "CreatorRequestId": "test-creator-request-id",
    }

    headers = {
        "Content-Type": "application/json",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credentials": "TEST:TEST/TEST+region=TEST",
        "X-Amz-Date": "20180101T000000Z",
        "X-Amz-Expires": "3600",
        "X-Amz-SignedHeaders": "host;x-amz-algorithm;x-amz-credentials;x-amz-date;x-amz-expires",
        "X-Amz-Security-Token": "TEST",
    }

    response = session.put(
        f"{BASE_URL}/backup/plans/{backup_plan_id}/selections/",
        headers=headers,
        auth=auth,
        json=payload,
    )

    assert response.status_code == 200