import pytest
import requests

BASE_URL = "http://openapi.test"

def test_teams_by_season(format, season):
    url = f"{BASE_URL}/{format}/Teams/{season}"
    headers = {
        "Ocp-Apim-Subscription-Key": "your_subscription_key"
    }
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    teams = response.json()
    assert isinstance(teams, list)
    for team in teams:
        assert isinstance(team, dict)
        assert "Name" in team
        assert "TeamID" in team
        assert isinstance(team["TeamID"], int)

if __name__ == "__main__":
    pytest.main()