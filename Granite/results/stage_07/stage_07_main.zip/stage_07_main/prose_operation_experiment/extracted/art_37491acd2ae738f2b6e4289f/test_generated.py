import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"

# Assuming service account credentials are stored in 'credentials.json'
credentials = service_account.Credentials.from_service_account_file('credentials.json')

@pytest.fixture
def api_request():
    headers = {
        "Authorization": f"Bearer {credentials.token}",
        "Content-Type": "application/json",
    }

    def _api_request(endpoint, params=None):
        url = f"{BASE_URL}/{endpoint}"
        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()
        return response.json()

    return _api_request

def test_list_security_actions(api_request):
    endpoint = "v1/environments/testEnv/securityActions"
    filter_expression = "state = 'ENABLED'"  # Example filter
    page_size = 10
    page_token = None

    params = {"filter": filter_expression, "pageSize": page_size}
    if page_token:
        params["pageToken"] = page_token

    response = api_request(endpoint, params=params)
    assert "securityActions" in response
    assert isinstance(response["securityActions"], list)
    assert len(response["securityActions"]) <= page_size