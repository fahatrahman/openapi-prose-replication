import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.fixture
def application_id():
    return "dSBdXd2H6Mqwfg0atXHXYcysLJE9qyn1VwBtXHX"

@pytest.fixture
def consumer_id():
    return "REPLACE_WITH_CONSUMER_ID"

@pytest.fixture
def service_id():
    return "REPLACE_WITH_SERVICE_ID"

@pytest.fixture
def collection_id():
    return "collection_id_example"

@pytest.fixture
def ticket_id():
    return "ticket_id_example"

@pytest.fixture
def id():
    return "id_example"

def test_update_comment(application_id, consumer_id, service_id, collection_id, ticket_id, id):
    url = f"{BASE_URL}/issue-tracking/collections/{collection_id}/tickets/{ticket_id}/comments/{id}"
    
    payload = {
        "body": "What internet provider do you use?",
        "custom_mappings": {}
    }

    headers = {
        "x-apideck-app-id": application_id,
        "x-apideck-consumer-id": consumer_id,
        "x-apideck-service-id": service_id,
    }

    response = SESSION.patch(url, json=payload, headers=headers)

    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "operation" in response.json()
    assert "status" in response.json()
    assert "service" in response.json()
    assert "resource" in response.json()
    assert "data" in response.json()