import pytest
import requests

BASE_URL = "http://openapi.test"

def test_administration_model():
    headers = {
        "Token": "your_token_here"
    }
    response = requests.get(f"{BASE_URL}/administration/model", headers=headers)
    
    assert response.status_code == 200
    assert isinstance(response.json(), list)
    for item in response.json():
        assert isinstance(item, dict)
        assert all(key in item for key in ["key", "name", "queue", "replyQueue"])