# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_issue_edit_milestone():
    owner = 'your_owner'
    repo = 'your_repo'
    id = 'your_id'

    url = f"{BASE_URL}/repos/{owner}/{repo}/milestones/{id}"
    headers = {'Content-Type': 'application/json'}
    auth = ('username', 'password') # or ('token',) for other auth types

    payload = {
        "description": "New description",
        "due_on": (datetime.now() + datetime.timedelta(days=7)).isoformat(),
        "state": "active",
        "title": "New title"
    }

    response = requests.patch(url, json=payload, headers=headers, auth=auth)

    assert response.status_code == 200
    assert response.json()["title"] == payload["title"]
    assert response.json()["description"] == payload["description"]
    assert response.json()["due_on"] == payload["due_on"]
    assert response.json()["state"] == payload["state"]

    # Additional assertions can go here...