import pytest
import requests

BASE_URL = "http://openapi.test"

def test_patch_advertiser_group():
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
    }
    params = {
        "_xgafv": "1",
        "access_token": "YOUR_ACCESS_TOKEN",
        "alt": "json",
        "callback": "YOUR_CALLBACK",
        "fields": "YOUR_FIELDS",
        "key": "YOUR_KEY",
        "oauth_token": "YOUR_OAUTH_TOKEN",
        "prettyPrint": False,
        "quotaUser": "YOUR_QUOTA_USER",
        "uploadProtocol": "YOUR_UPLOAD_PROTOCOL",
        "uploadType": "YOUR_UPLOAD_TYPE",
        "id": "ADVERTISER_GROUP_ID"
    }
    data = {
        "name": "Updated Advertiser Group Name"
    }
    response = requests.patch(f"{BASE_URL}/userprofiles/YOUR_PROFILE_ID/advertiserGroups", headers=headers, params=params, json=data)
    assert response.status_code == 200
    advertiser_group = response.json()
    assert advertiser_group["name"] == "Updated Advertiser Group Name"