import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_profile_notifications():
    url = f"{BASE_URL}/profileNotifications/"
    params = {
        "WorkloadId": "example-workload-id",
        "NextToken": None,
        "MaxResults": 10
    }
    headers = {
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Date": "20230401T123456Z",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20230401/us-east-1/wellarchitected/aws4_request",
        "X-Amz-Security-Token": "AQoEXAMPLEH4aoAHFODn8mum1Ldgkty73GAGSTfNBPjaDMOHb9jBMRKl7RQ1eBdBNCOTesIqVrDHn7u67Uqg4g7tq8hlIxOu9uxwRYqqanUpwliwFijKiQyCgxGCGBxiUXCVJYVHPORH3X9hkZ5KDYZl3PQ3p3DVs0SjbqPOEhlgwRvH+M8DkVhgFohW05kZ3UxMDAwMDAwMDAwEDOLQuyFpLZYqTKT7i8ksYRYRl531YXcQy0=",
        "X-Amz-Signature": "EXAMPLESIGNATURE",
        "X-Amz-SignedHeaders": "host;x-amz-algorithm;x-amz-content-sha256;x-amz-credential;x-amz-date;x-amz-security-token;x-amz-signedheaders"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    assert "NotificationSummaries" in response.json()

if __name__ == "__main__":
    pytest.main()