import os
import requests
import pytest

BASE_URL = "http://openapi.test"

@pytest.fixture
def hooks():
    response = requests.get(
        f"{BASE_URL}/hooks.json",
        params={
            "login": "<your_login>",
            "authtoken": "<your_token>",
            "limit": 10,  # Change limit as needed
            "page": 1
        }
    )
    if response.status_code == 200:
        return response.json()["hook"]
    else:
        raise Exception(f"Request failed with status code {response.status_code}")

def test_hooks(hooks):
    assert isinstance(hooks, list)
    for hook in hooks:
        assert all(key in hook for key in ["created_at", "event", "id", "name", "url"])