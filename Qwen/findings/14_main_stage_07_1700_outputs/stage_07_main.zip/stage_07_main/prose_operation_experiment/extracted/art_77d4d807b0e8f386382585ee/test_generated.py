import pytest
import requests

BASE_URL = "http://openapi.test"

def test_application_post_attributes_v2():
    application_id = "test_app_id"
    url = f"{BASE_URL}/api/v2/application/{application_id}/attributes"
    
    # Example data for POST request
    post_data = {
        "name1": "Value1",
        "name2": "Value2"
    }
    
    response = requests.post(url, json=post_data)
    
    assert response.status_code == 200
    assert isinstance(response.text, str)

if __name__ == "__main__":
    pytest.main()