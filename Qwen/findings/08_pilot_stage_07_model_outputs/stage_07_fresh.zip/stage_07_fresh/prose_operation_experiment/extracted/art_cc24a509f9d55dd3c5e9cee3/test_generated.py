import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_public_status():
    url = f"{BASE_URL}/getPublicStatus"
    params = {
        "padID": "test_pad_id",
        "apikey": "test_api_key"
    }
    response = requests.get(url, params=params)
    
    assert response.status_code == 200
    assert response.json()["code"] == 0
    assert isinstance(response.json()["data"]["publicStatus"], bool)
    assert response.json()["message"] == "ok"

@pytest.mark.parametrize("pad_id,status_code,message", [
    ("invalid_pad_id", 400, "error message"),
    ("", 400, "error message"),
    ("", 401, "no or wrong API key")
])
def test_get_public_status_error(pad_id, status_code, message):
    url = f"{BASE_URL}/getPublicStatus"
    params = {
        "padID": pad_id,
        "apikey": "test_api_key"
    }
    if status_code == 401:
        del params["apikey"]
    
    response = requests.get(url, params=params)
    
    assert response.status_code == status_code
    assert response.json()["code"] == status_code
    assert response.json()["message"] == message

if __name__ == "__main__":
    pytest.main()