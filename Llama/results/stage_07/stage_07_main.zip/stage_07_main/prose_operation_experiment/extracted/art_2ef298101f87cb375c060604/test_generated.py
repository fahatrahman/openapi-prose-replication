# pylint: disable=invalid-name, unused-import
import json
import pytest
import requests

BASE_URL = "http://openapi.test"

def test_set_addon_enablement():
    url = f"{BASE_URL}/v1/{'organizations/test/environments/dev/addonsConfig'}:setAddonEnablement"
    headers = {
        'Content-Type': 'application/json',
    }
    data = {
        "analyticsEnabled": True,
        "apiSecurityEnabled": False,
    }

    response = requests.post(url, headers=headers, data=json.dumps(data))
    assert response.status_code == 200
    response_data = response.json()
    assert isinstance(response_data, dict)
    assert 'done' in response_data
    assert 'name' in response_data
    assert 'response' in response_data

def test_set_addon_enablement_with_key():
    url = f"{BASE_URL}/v1/{'organizations/test/environments/dev/addonsConfig'}:setAddonEnablement"
    headers = {
        'Content-Type': 'application/json',
        'key': 'your_api_key_here',
    }
    data = {
        "analyticsEnabled": True,
        "apiSecurityEnabled": False,
    }

    response = requests.post(url, headers=headers, data=json.dumps(data))
    assert response.status_code == 200
    response_data = response.json()
    assert isinstance(response_data, dict)
    assert 'done' in response_data
    assert 'name' in response_data
    assert 'response' in response_data

def test_set_addon_enablement_without_oauth():
    url = f"{BASE_URL}/v1/{'organizations/test/environments/dev/addonsConfig'}:setAddonEnablement"
    headers = {
        'Content-Type': 'application/json',
    }
    data = {
        "analyticsEnabled": True,
        "apiSecurityEnabled": False,
    }

    response = requests.post(url, headers=headers, data=json.dumps(data))
    assert response.status_code != 401