import os
import pytest
import requests
from google.rpc import Status

BASE_URL = "http://openapi.test"

@pytest.fixture
def get_latest_state():
    def _get_latest_state(name):
        url = f"{BASE_URL}/v1beta1/{name}"
        headers = {}

        response = requests.get(url, headers=headers)
        response.raise_for_status()

        operation = response.json()["resource"]
        return operation

    yield _get_latest_state

def test_get_latest_state(get_latest_state):
    name = "your_operation_name"  # Replace with actual operation name
    operation = get_latest_state(name)

    assert isinstance(operation, dict)
    assert operation["name"] == name
    assert "done" in operation
    assert "error" not in operation or not operation["error"]
    assert "response" in operation