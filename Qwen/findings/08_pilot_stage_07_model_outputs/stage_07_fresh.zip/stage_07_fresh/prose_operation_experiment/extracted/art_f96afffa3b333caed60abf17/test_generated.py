import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_account_extensions():
    account_id = "test_account_id"
    params = {
        "page_size": 10,
        "page": 1,
        "location_id": 145214,
        "phone_number": "14155550100",
        "login_name": "jsmith",
        "email": "john.smith@example.com"
    }
    headers = {
        "Authorization": "Bearer your_access_token_here"
    }

    response = requests.get(f"{BASE_URL}/api/accounts/{account_id}/extensions", params=params, headers=headers)

    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "_embedded" in response.json()
    assert "_links" in response.json()
    assert "page" in response.json()
    assert "page_size" in response.json()
    assert "total_items" in response.json()
    assert "total_pages" in response.json()

def test_get_account_extensions_invalid_params():
    account_id = "test_account_id"
    params = {
        "page_size": -1,
        "page": 0,
        "location_id": -1,
        "phone_number": "",
        "login_name": "",
        "email": ""
    }
    headers = {
        "Authorization": "Bearer your_access_token_here"
    }

    response = requests.get(f"{BASE_URL}/api/accounts/{account_id}/extensions", params=params, headers=headers)

    assert response.status_code == 400
    assert isinstance(response.json(), dict)
    assert "instance" in response.json()
    assert "invalid_parameters" in response.json()
    assert "status" in response.json()
    assert "title" in response.json()