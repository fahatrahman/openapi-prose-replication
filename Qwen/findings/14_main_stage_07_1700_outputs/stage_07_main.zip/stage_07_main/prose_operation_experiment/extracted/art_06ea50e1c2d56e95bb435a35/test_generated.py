import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_backup_plan_templates():
    headers = {
        "X-Amz-Content-Sha256": "",
        "X-Amz-Date": "",
        "X-Amz-Algorithm": "",
        "X-Amz-Credential": "",
        "X-Amz-Security-Token": "",
        "X-Amz-Signature": "",
        "X-Amz-SignedHeaders": ""
    }
    params = {
        "nextToken": None,
        "maxResults": 10,
        "MaxResults": None,
        "NextToken": None
    }
    response = requests.get(f"{BASE_URL}/backup/template/plans", headers=headers, params=params)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "BackupPlanTemplatesList" in response.json()
    assert isinstance(response.json()["BackupPlanTemplatesList"], list)

if __name__ == "__main__":
    pytest.main([__file__])