import pytest
import requests

BASE_URL = "http://openapi.test"

def test_publish_iteration():
    project_id = "64b822c5-8082-4b36-a426-27225f4aa18c"
    iteration_id = "e31a14ab-5d78-4f7b-a267-3a1e4fd8a758"
    publish_name = "Model1"
    prediction_id = "/subscriptions/{subscription}/resourceGroups/{resource group name}/providers/Microsoft.CognitiveServices/accounts/{resource name}"
    api_key = "{API Key}"

    headers = {
        "Training-Key": api_key
    }

    params = {
        "publishName": publish_name,
        "predictionId": prediction_id
    }

    url = f"{BASE_URL}/projects/{project_id}/iterations/{iteration_id}/publish"

    response = requests.post(url, headers=headers, params=params)

    assert response.status_code == 200
    assert response.json() == True