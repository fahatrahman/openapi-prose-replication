# -*- coding: utf-8 -*-
import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

@pytest.fixture
def api_key():
    return "Your_Api_Key_Here"

def test_get_batch(api_key):
    url = f"{BASE_URL}/batch/your_id_here"
    headers = {"X-API-KEY": api_key}
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    
    batch = response.json()
    assert isinstance(batch["completed"], bool)
    assert isinstance(batch["count"], int)
    assert isinstance(batch["created_at"], str) and datetime.strptime(batch["created_at"], "%Y-%m-%dT%H:%M:%SZ") <= datetime.now()
    assert isinstance(batch["id"], str)
    assert isinstance(batch["operation"], str)
    assert isinstance(batch["results"], list)
    assert isinstance(batch["status"], str)
