import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_brand():
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "X-VTEX-API-AppKey": "your_app_key",
        "X-VTEX-API-AppToken": "your_app_token"
    }
    params = {
        "q": "tshirt",
        "from": "1",
        "to": "50",
        "orderBy": "name,asc",
        "name": "Zwilling"
    }
    response = requests.get(f"{BASE_URL}/api/catalog-seller-portal/brands", headers=headers, params=params)
    assert response.status_code == 200
    data = response.json()
    assert "_metadata" in data
    assert "data" in data
    metadata = data["_metadata"]
    assert "from" in metadata
    assert "to" in metadata
    assert "total" in metadata
    assert "orderBy" in metadata
    assert isinstance(metadata["data"], list)
    for item in metadata["data"]:
        assert "id" in item
        assert "name" in item
        assert "isActive" in item
        assert "createdAt" in item
        assert "updatedAt" in item