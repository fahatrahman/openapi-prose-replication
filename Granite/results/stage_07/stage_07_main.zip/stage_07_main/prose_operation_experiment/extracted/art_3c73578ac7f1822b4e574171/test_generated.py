import os
import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

@pytest.fixture
def test_client():
    return requests.Client()

def get_folders(account_id, container_id):
    endpoint = "/tagmanager/v1/accounts/{accountId}/containers/{containerId}/folders".format(
        accountId=account_id, containerId=container_id
    )

    response = requests.get(urljoin(BASE_URL, endpoint))

    assert response.status_code == 200

    return response.json()

def test_get_folders(test_client):
    account_id = "test_account_id"
    container_id = "test_container_id"
    
    folders = get_folders(account_id, container_id)
    assert isinstance(folders, dict)
    assert "folders" in folders
    assert isinstance(folders["folders"], list)