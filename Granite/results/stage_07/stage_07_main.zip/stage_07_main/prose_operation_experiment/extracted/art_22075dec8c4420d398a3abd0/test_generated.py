import pytest
import requests
BASE_URL = "http://openapi.test"

def test_connections():
    url = f"{BASE_URL}/net/connections"
    response = requests.post(url)

    assert response.status_code == 200
    connections = response.json()["connections"]

    for connection in connections:
        assert isinstance(connection["peer"], str)
        assert isinstance(connection["syncing"], bool)
        assert isinstance(connection["last_handshake"], dict)
            .assert_has_item("agent", str)
            .assert_has_item("chain_id", str)
            .assert_has_item("generation", int)
            .assert_has_item("head_id", str)
            .assert_has_item("head_num", int)
            .assert_has_item("key", str)
            .assert_has_item("last_irreversible_block_id", str)
            .assert_has_item("last_irreversible_block_num", int)
            .assert_has_item("network_version", int)
            .assert_has_item("node_id", str)
            .assert_has_item("os", str)
            .assert_has_item("p2p_address", str)
            .assert_has_item("sig", str)
            .assert_has_item("time", str)
            .assert_has_item("token", str)