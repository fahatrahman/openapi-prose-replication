import pytest
import requests

BASE_URL = "http://openapi.test"

def test_read_float_vars():
    url = f"{BASE_URL}/device/strategy/vars/floats"
    response = requests.get(url)
    
    assert response.status_code == 200
    assert isinstance(response.json(), list)
    for item in response.json():
        assert isinstance(item, dict)
        assert "name" in item
        assert "value" in item
        assert isinstance(item["name"], str)
        assert isinstance(item["value"], float)

def test_read_float_vars_400():
    url = f"{BASE_URL}/device/strategy/vars/floats"
    response = requests.get(url, auth=('badadmin', 'badvalue'))
    
    assert response.status_code == 400
    error_response = response.json()
    assert isinstance(error_response, dict)
    assert "errorCode" in error_response
    assert "message" in error_response
    assert error_response["errorCode"] == -1

def test_read_float_vars_401():
    url = f"{BASE_URL}/device/strategy/vars/floats"
    response = requests.get(url, auth=('badkey', 'badpassword'))
    
    assert response.status_code == 401
    error_response = response.json()
    assert isinstance(error_response, dict)
    assert "errorCode" in error_response
    assert "message" in error_response
    assert error_response["errorCode"] == -104