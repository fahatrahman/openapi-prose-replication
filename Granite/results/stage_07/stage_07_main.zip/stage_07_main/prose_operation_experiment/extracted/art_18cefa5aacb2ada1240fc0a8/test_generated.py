import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.exceptions import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.fixture
def api_key():
    return os.getenv("API_KEY")

@pytest.fixture
def listing_extra_attributes(api_key, id):
    url = f"{BASE_URL}/listing/car/{id}/extra"
    headers = {"api_key": api_key}
    response = SESSION.get(url, headers=headers)

    if response.status_code == 200:
        return response.json()
    else:
        error_data = response.json()
        raise Exception(f"Error fetching listing extra attributes: {error_data['message']}")

def test_listing_extra_attributes(api_key, listing_extra_attributes):
    assert isinstance(listing_extra_attributes, dict)