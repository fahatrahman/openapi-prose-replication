import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Configure session with retries
session = requests.Session()
retries = Retry(total=3, backoff_factor=0.1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

# Basic auth credentials
ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID")
AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN")

@pytest.fixture
def request_headers():
    return {
        "Authorization": f"Basic {ACCOUNT_SID}:{AUTH_TOKEN}",
        "Content-Type": "application/x-www-form-urlencoded",
    }

def test_list_brand_registrations(request_headers):
    url = f"{BASE_URL}/v1/a2p/BrandRegistrations"

    response = session.get(url, headers=request_headers)

    assert response.status_code == 200

    data = response.json()["data"]
    assert isinstance(data, list)
    for item in data:
        assert isinstance(item, dict)
        required_keys = ["sid", "date_created"]
        for key in required_keys:
            assert key in item