import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_accountHolders_id_balanceAccounts_success():
    url = f"{BASE_URL}/accountHolders/test_id/balanceAccounts"
    response = requests.get(url)
    assert response.status_code == 200
    assert isinstance(response.json(), dict)

def test_get_accountHolders_id_balanceAccounts_400():
    url = f"{BASE_URL}/accountHolders/test_id/balanceAccounts"
    params = {"offset": "abc"}
    response = requests.get(url, params=params)
    assert response.status_code == 400
    assert response.json()["errorCode"] == 256

def test_get_accountHolders_id_balanceAccounts_401():
    url = f"{BASE_URL}/accountHolders/test_id/balanceAccounts"
    headers = {"Authorization": "Bearer invalid_token"}
    response = requests.get(url, headers=headers)
    assert response.status_code == 401
    assert response.json()["errorCode"] == 257

def test_get_accountHolders_id_balanceAccounts_403():
    url = f"{BASE_URL}/accountHolders/test_id/balanceAccounts"
    headers = {"Authorization": "Bearer invalid_token"}
    response = requests.get(url, headers=headers)
    assert response.status_code == 403
    assert response.json()["errorCode"] == 259

def test_get_accountHolders_id_balanceAccounts_422():
    url = f"{BASE_URL}/accountHolders/test_id/balanceAccounts"
    params = {"offset": 5, "limit": 10}
    response = requests.get(url, params=params)
    assert response.status_code == 422
    assert response.json()["errorCode"] == 30031

def test_get_accountHolders_id_balanceAccounts_500():
    url = f"{BASE_URL}/accountHolders/test_id/balanceAccounts"
    response = requests.get(url)
    assert response.status_code == 500
    assert response.json()["errorCode"] == 320