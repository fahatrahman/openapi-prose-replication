import os
import pytest
import requests
from google.rpc import status_pb2

BASE_URL = "http://openapi.test"

def test_restore_volume_snapshot():
    volume_snapshot = "your_volume_snapshot_name"
    request_body = {
        # Add required fields for RestoreVolumeSnapshotRequest here
    }

    url = f"{BASE_URL}/v2/{volume_snapshot}:restoreVolumeSnapshot"
    headers = {"Content-Type": "application/json"}

    response = requests.post(url, json=request_body, headers=headers)
    response.raise_for_status()

    result = response.json()
    assert response.status_code == 200

    operation_name = result["name"]
    print(f"Operation created: {operation_name}")

    while True:
        status_url = f"{BASE_URL}/v2/{operation_name}"
        status_response = requests.get(status_url, headers=headers)
        status_response.raise_for_status()

        status = status_pb2.Status()
        status.ParseFromString(status_response.content)

        if status.code == status_pb2.Code.OK_VALUE:
            break
        elif status.code == status_pb2.Code.FAILED_PRECONDITION_VALUE:
            raise Exception("Failed precondition")
        else:
            print(f"Operation {operation_name} status: {status.message}")

    assert status.code == status_pb2.Code.OK_VALUE, status.message