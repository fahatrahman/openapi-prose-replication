import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Set up session with retry logic
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

# API key for authentication
API_KEY = os.environ.get("EMBY_API_KEY")

@pytest.fixture
def default_listing_provider():
    url = f"{BASE_URL}/LiveTv/ListingProviders/Default"
    headers = {"X-Emby-Authorization": f"Bearer {API_KEY}"}

    response = session.get(url, headers=headers)
    response.raise_for_status()

    return response.json()

def test_default_listing_provider(default_listing_provider):
    assert default_listing_provider["Id"] is not None
    assert isinstance(default_listing_provider["ChannelMappings"], list)
    assert default_listing_provider["EnabledTuners"] is None or isinstance(default_listing_provider["EnabledTuners"], list)
    assert default_listing_provider["KidsCategories"] is None or isinstance(default_listing_provider["KidsCategories"], list)
    assert default_listing_provider["MovieCategories"] is None or isinstance(default_listing_provider["MovieCategories"], list)
    assert default_listing_provider["SportsCategories"] is None or isinstance(default_listing_provider["SportsCategories"], list)
    assert default_listing_provider["NewsCategories"] is None or isinstance(default_listing_provider["NewsCategories"], list)