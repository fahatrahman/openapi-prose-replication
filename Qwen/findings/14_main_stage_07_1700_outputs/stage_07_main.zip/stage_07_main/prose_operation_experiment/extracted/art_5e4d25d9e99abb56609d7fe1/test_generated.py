import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_court_types():
    url = f"{BASE_URL}/masterData/courtType"
    params = {
        "q": "courtTypeId:COTPm8jjc2PAydpFhq",
        "pageNumber": 1,
        "sort": "name",
        "order": "asc"
    }
    headers = {
        "Authorization": "Bearer your_access_token_here"
    }

    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 200
    assert response.json()["object"] == "CourtTypeResponse"
    assert len(response.json()["courtTypeArray"]) == 1
    assert response.json()["courtTypeArray"][0]["object"] == "CourtType"
    assert response.json()["courtTypeArray"][0]["courtTypeId"] == "COTPm8jjc2PAydpFhq"
    assert response.json()["courtTypeArray"][0]["name"] == "State"
    assert response.json()["pageNumber"] == 1
    assert response.json()["totalPages"] == 1
    assert response.json()["totalCount"] == 1

def test_get_court_types_invalid_input_query():
    url = f"{BASE_URL}/masterData/courtType"
    params = {
        "q": "courtTypId:COTPm8jjc2PAydpFhq",
        "pageNumber": 1,
        "sort": "name",
        "order": "asc"
    }
    headers = {
        "Authorization": "Bearer your_access_token_here"
    }

    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 400
    assert response.json()["object"] == "Exception"
    assert response.json()["code"] == "UN400"
    assert response.json()["message"] == "INVALID_INPUT"
    assert response.json()["details"] == "The field passed is invalid."

def test_get_court_types_internal_server_error():
    url = f"{BASE_URL}/masterData/courtType"
    params = {
        "q": "courtTypeId:COTPm8jjc2PAydpFhq",
        "pageNumber": 1,
        "sort": "name",
        "order": "asc"
    }
    headers = {
        "Authorization": "Bearer your_access_token_here"
    }

    response = requests.get(url, headers=headers, params=params)

    assert response.status_code == 500
    assert response.json()["object"] == "Exception"
    assert response.json()["code"] == "UN500"
    assert response.json()["message"] == "INTERNAL_SERVER_ERROR"
    assert response.json()["details"] == "Has encountered a situation which needs to be handled."