import pytest
import requests

BASE_URL = "http://openapi.test"

def test_service_live_stats():
    url = f"{BASE_URL}/api/live/global"
    response = requests.get(url, auth=('username', 'password'))
    
    assert response.status_code == 200
    assert 'Content-Type' in response.headers and response.headers['Content-Type'] in ['application/json', 'text/event-stream']
    if response.headers['Content-Type'] == 'application/json':
        data = response.json()
        assert isinstance(data, dict)
        required_keys = ['calls', 'dataIn', 'dataOut', 'rate', 'duration', 'overhead', 'dataInRate', 'dataOutRate', 'concurrentHandledRequests']
        assert all(key in data for key in required_keys)

if __name__ == "__main__":
    pytest.main()