import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup a session with retry logic
session = requests.Session()
retry_strategy = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["GET", "OPTIONS"],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

# Define the headers for HMAC authentication
headers = {
    "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
    "X-Amz-Credential": "dummy_credential",
    "X-Amz-Date": "dummy_date",
    "X-Amz-Security-Token": "dummy_token",
}

@pytest.mark.parametrize("api_id, model_id", [("api_id", "model_id")])
def test_get_model_template(api_id, model_id):
    url = f"{BASE_URL}/v2/apis/{api_id}/models/{model_id}/template"

    response = session.get(url, headers=headers)

    assert response.status_code == 200, f"Unexpected status code: {response.status_code}"

    try:
        response_data = response.json()
        # Add assertions based on expected response structure
        assert response_data["Value"] is not None
    except ValueError:
        assert False, "Invalid JSON response received."