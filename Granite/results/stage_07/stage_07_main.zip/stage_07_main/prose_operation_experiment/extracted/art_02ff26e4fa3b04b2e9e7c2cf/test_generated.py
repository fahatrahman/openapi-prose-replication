import os
import json
import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

@pytest.fixture
def auth():
    return HTTPBasicAuth("username", "password")

def get_storage_policy_assignments(resolved_for_type, resolved_for_id):
    url = f"{BASE_URL}/storage_policy_assignments"
    params = {"resolved_for_type": resolved_for_type, "resolved_for_id": resolved_for_id}

    response = requests.get(url, auth=auth, params=params)

    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(json.loads(response.text))

def test_get_storage_policy_assignments_user(get_storage_policy_assignments):
    resolved_for_type = "user"
    resolved_for_id = "user_id"

    result = get_storage_policy_assignments(resolved_for_type, resolved_for_id)
    assert isinstance(result, dict)
    assert "entries" in result

def test_get_storage_policy_assignments_enterprise(get_storage_policy_assignments):
    resolved_for_type = "enterprise"
    resolved_for_id = "enterprise_id"

    result = get_storage_policy_assignments(resolved_for_type, resolved_for_id)
    assert isinstance(result, dict)
    assert "entries" in result