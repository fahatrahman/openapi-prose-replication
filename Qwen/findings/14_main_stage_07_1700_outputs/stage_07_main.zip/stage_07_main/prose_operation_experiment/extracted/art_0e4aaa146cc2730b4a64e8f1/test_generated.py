import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_attributes_v2():
    application_id = "test_application_id"
    name = "test_name"
    url = f"{BASE_URL}/api/v2/application/{application_id}/attributes?name={name}"
    response = requests.delete(url)
    
    assert response.status_code == 200
    assert response.json() == "CQ"