import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_PATH = "credentials.json"

@pytest.fixture
def auth():
    credentials = service_account.Credentials.from_service_account_file(
        CREDENTIALS_PATH, scopes=["https://www.googleapis.com/auth/admin.directory.user.alias"]
    )
    return credentials

def test_insert_alias(auth):
    url = f"{BASE_URL}/admin/directory/v1/users/userKey/aliases"
    headers = {
        "Content-Type": "application/json",
    }

    alias = {
        "alias": "new_alias",
        "primaryEmail": "user@example.com",
    }

    response = requests.post(url, headers=headers, json=alias, verify=False, auth=auth)

    assert response.status_code == 200
    assert response.json()["alias"] == "new_alias"