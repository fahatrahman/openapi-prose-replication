import os
import pytest
import requests
from requests.exceptions import HTTPError

BASE_URL = "http://openapi.test"

@pytest.fixture
def client():
    """Fixture for sending API requests."""
    session = requests.Session()

    def _request(method, endpoint, **kwargs):
        url = BASE_URL + endpoint
        headers = kwargs.pop("headers", {})
        headers["Authorization"] = "Auto"

        try:
            response = session.request(method, url, headers=headers, **kwargs)
            response.raise_for_status()
            return response.json()
        except HTTPError as http_err:
            print(f"HTTP error occurred: {http_err}")
            return {"error": str(http_err)}
        except Exception as err:
            print(f"Other error occurred: {err}")
            return {"error": str(err)}

    return _request

def test_get_holiday_balance_report_output(client):
    """Test GET /Report/HOLBAL/run request."""
    # Define required parameters
    params = {
        "EmployerKey": "ER001",
        "HolidayYearEnd": "2018-12-31",
        # Optional parameters can be added here if needed
    }

    response = client("get", "/Report/HOLBAL/run", headers={}, params=params)

    assert response["status_code"] == 200, response.get("error", "Unexpected status code")
    assert isinstance(response.get("result"), bytes), response.get("error", "Response is not in binary format")
