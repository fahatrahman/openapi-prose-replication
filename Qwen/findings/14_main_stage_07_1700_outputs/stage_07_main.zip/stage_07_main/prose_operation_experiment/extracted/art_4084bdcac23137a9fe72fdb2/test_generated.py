import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def access_token():
    return "your_access_token_here"

@pytest.fixture
def profile_id():
    return "your_profile_id_here"

@pytest.fixture
def account_data():
    return {
        "accountPermissionIds": [1],
        "accountProfile": "ACCOUNT_PROFILE_BASIC",
        "active": True,
        "activeAdsLimitTier": "ACTIVE_ADS_TIER_40K",
        "activeViewOptOut": False,
        "availablePermissionIds": [1],
        "countryId": 1,
        "currencyId": 1,
        "defaultCreativeSizeId": 1,
        "description": "Test Account",
        "id": 1,
        "kind": "ttjzyodfuopc#yjurfrb",
        "locale": "en",
        "maximumImageSize": 1,
        "name": "Test Account Name",
        "nielsenOcrEnabled": False,
        "reportsConfiguration": {
            "exposureToConversionEnabled": True,
            "lookbackConfiguration": {
                "clickDuration": 1,
                "postImpressionActivitiesDuration": 1
            },
            "reportGenerationTimeZoneId": 1
        },
        "shareReportsWithTwitter": False,
        "teaserSizeLimit": 1
    }

def test_update_account(access_token, profile_id, account_data):
    url = f"{BASE_URL}/userprofiles/{profile_id}/accounts"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }
    response = requests.put(url, headers=headers, json=account_data)
    assert response.status_code == 200
    assert response.json()["kind"] == "ttjzyodfuopc#yjurfrb"