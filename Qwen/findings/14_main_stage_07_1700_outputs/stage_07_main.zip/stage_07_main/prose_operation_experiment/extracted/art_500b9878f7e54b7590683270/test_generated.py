import pytest
import requests

BASE_URL = "http://openapi.test"

def test_post_compile():
    url = f"{BASE_URL}/v1/compile"
    payload = {
        "query": "data.example.allow == true",
        "input": {
            "subject": {
                "clearance_level": 4
            }
        },
        "unknowns": [
            "data.reports"
        ]
    }
    params = {
        "pretty": True,
        "explain": "full",
        "metrics": False,
        "instrument": False
    }
    response = requests.post(url, json=payload, params=params)
    
    assert response.status_code == 200
    assert 'result' in response.json()
    assert 'explanation' in response.json()
    assert 'metrics' in response.json()

def test_post_compile_bad_request():
    url = f"{BASE_URL}/v1/compile"
    payload = {
        "query": "data.example.allow == true",
        "input": {
            "subject": {
                "clearance_level": 4
            }
        },
        "unknowns": [
            "data.reports"
        ]
    }
    params = {
        "pretty": True,
        "explain": "full",
        "metrics": False,
        "instrument": "invalid_value"
    }
    response = requests.post(url, json=payload, params=params)
    
    assert response.status_code == 400
    assert 'code' in response.json()
    assert 'message' in response.json()
    assert 'errors' in response.json()

def test_post_compile_server_error():
    # Mock server error by sending a request to a non-existent endpoint
    url = f"{BASE_URL}/v1/non_existent_endpoint"
    payload = {
        "query": "data.example.allow == true",
        "input": {
            "subject": {
                "clearance_level": 4
            }
        },
        "unknowns": [
            "data.reports"
        ]
    }
    params = {
        "pretty": True,
        "explain": "full",
        "metrics": False,
        "instrument": False
    }
    response = requests.post(url, json=payload, params=params)
    
    assert response.status_code == 500
    assert 'code' in response.json()
    assert 'message' in response.json()