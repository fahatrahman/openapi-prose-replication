# -*- coding: utf-8 -*-
import pytest
import requests
from pydantic import BaseModel
from typing import List

class Book(BaseModel):
    id: str
    name: str
    year: str

class Sentence(BaseModel):
    book: Book
    id: str
    sentence: str

class Response200(BaseModel):
    data: List[Sentence]

BASE_URL = "http://openapi.test"

def test_get_sentences():
    params = {"limit": 10}
    response = requests.get(f"{BASE_URL}/sentences", params=params)
    assert response.status_code == 200
    data = Response200.parse_raw(response.content)
    assert isinstance(data.data, list)

def test_get_sentences_default_limit():
    response = requests.get(f"{BASE_URL}/sentences")
    assert response.status_code == 200
    data = Response200.parse_raw(response.content)
    assert len(data.data) == 1

if __name__ == "__main__":
    pytest.main([__file__])