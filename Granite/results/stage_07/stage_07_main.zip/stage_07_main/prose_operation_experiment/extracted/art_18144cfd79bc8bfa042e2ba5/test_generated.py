import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = 'path/to/your/service_account.json'

@pytest.fixture(scope="session")
def auth():
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=['https://www.googleapis.com/auth/cloud-platform']
    )
    return credentials

def test_list_adaptive_mt_files(auth):
    path = "zynntaco/your-location/yzvrewumc/your-model/mqjnhollLcUuzcfmmz/your-dataset"
    params = {
        "pageSize": 10,
        "pageToken": "some_page_token",
    }

    url = f"{BASE_URL}/v3/{path}/adaptiveMtFiles"
    headers = {"Authorization": f"Bearer {auth.token}"}

    response = requests.get(url, headers=headers, params=params)
    response.raise_for_status()

    adaptive_mt_files_response = response.json()
    assert 'adaptiveMtFiles' in adaptive_mt_files_response
    assert 'nextPageToken' in adaptive_mt_files_response