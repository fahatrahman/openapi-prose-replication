import pytest
import requests

BASE_URL = "http://openapi.test"

def test_batter_vs_pitcher_stats():
    format_param = "JSON"
    hitterid_param = "10000031"
    pitcherid_param = "10000618"
    headers = {
        "Ocp-Apim-Subscription-Key": "your_subscription_key_here"
    }
    params = {
        "key": "your_api_key_here"
    }
    url = f"{BASE_URL}/{format_param}/HitterVsPitcher/{hitterid_param}/{pitcherid_param}"
    response = requests.get(url, headers=headers, params=params)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    for item in data:
        assert isinstance(item, dict)
        assert "PlayerID" in item
        assert "Season" in item
        assert "Team" in item
        # Add more assertions based on the expected structure of PlayerSeason