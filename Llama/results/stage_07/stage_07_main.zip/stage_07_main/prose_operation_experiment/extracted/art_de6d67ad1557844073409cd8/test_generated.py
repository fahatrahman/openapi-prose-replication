# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_appengine_projects_locations_operations_list():
    params = {
        "_xgafv": "1",
        "access_token": "",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "",
        "oauth_token": "",
        "prettyPrint": "false",
        "quotaUser": "",
        "upload_protocol": "simple",
        "uploadType": "media",
        "projectsId": "my-project-id",
        "locationsId": "my-location-id",
        "filter": "",
        "pageSize": 10,
        "pageToken": ""
    }

    response = requests.get(
        f"{BASE_URL}/v1alpha/projects/{params['projectsId']}/locations/{params['locationsId']}/operations",
        params=params
    )

    assert response.status_code == 200
    assert response.json()["nextPageToken"]
    assert len(response.json()["operations"]) > 0