import os
import requests
import pytest
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retries for idempotent requests
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('https://', adapter)
session.mount('http://', adapter)

# Amazon Signature authorization v4
def sign_request(headers):
    return headers

@pytest.fixture
def http_client():
    return session

@pytest.mark.parametrize("identifier, wireless_device_type", [
    ("dev_id_example", None),
    ("dev_id_example", "LoRaWAN"),
    ("dev_id_example", "Sidewalk")
])
def test_deregister_wireless_device(http_client, identifier, wireless_device_type):
    url = f"{BASE_URL}/wireless-devices/{identifier}"

    if wireless_device_type:
        url += f"?WirelessDeviceType={wireless_device_type}"

    headers = sign_request({})

    response = http_client.patch(url, headers=headers)

    assert response.status_code == 200, f"Unexpected status code: {response.status_code}. Response: {response.text}"