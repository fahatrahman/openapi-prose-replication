import pytest
import requests

BASE_URL = "http://openapi.test"

def test_VirtualTariffConsumption_Get():
    folder_id = "test_folder"
    start_date = "2023-01-01T00:00:00Z"
    end_date = "2023-01-31T23:59:59Z"
    
    url = f"{BASE_URL}/api/VirtualTariffConsumption"
    params = {
        "folderId": folder_id,
        "startDate": start_date,
        "endDate": end_date
    }
    
    response = requests.get(url, params=params)
    
    assert response.status_code == 200
    assert isinstance(response.json(), list)
    for item in response.json():
        assert isinstance(item, dict)
        assert "Consumption" in item
        assert "Currency" in item
        assert "Name" in item
        assert "Price" in item
        assert "TariffType" in item
        assert item["TariffType"] in ["Battery", "Solar", "Normal"]
        assert isinstance(item["Consumption"], float)
        assert isinstance(item["Price"], float)