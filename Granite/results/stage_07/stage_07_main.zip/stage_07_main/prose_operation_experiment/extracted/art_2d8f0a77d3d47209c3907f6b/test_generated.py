import os
import pytest
import requests
from google.protobuf import json_format

BASE_URL = "http://openapi.test"
HEADERS = {}

@pytest.fixture
def patch_topic_state():
    name = "platforms/my_platform/properties/my_property/topicStates/my_topic_state"
    update_mask = "dismissed,saved"

    topic_state = {
        "dismissed": True,
        "saved": False,
        "name": name
    }

    response = requests.patch(
        f"{BASE_URL}/{name}",
        headers=HEADERS,
        json=topic_state
    )

    assert response.status_code == 200

    return response.json()