import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_vpc_access_connector_patch():
    # Define the path and query parameters
    path_params = {
        'name': '/v1beta1/projects/my-project/locations/global/connectors/my-connector'
    }
    query_params = {
        'updateMask': 'connected_projects',
        'prettyPrint': 'true'
    }

    # Construct the URL
    url = urljoin(BASE_URL, '/'.join([path for path in path_params['name'].split('/') if path]))

    # Define the JSON payload
    json_payload = {
        'updateMask': 'connected_projects',
        'connected_projects': ['project1', 'project2']
    }

    # Send the PATCH request
    response = requests.patch(url, headers={'Content-Type': 'application/json'}, params=query_params, json=json_payload)

    # Check the status code and content type
    assert response.status_code == 200
    assert response.headers.get('Content-Type') == 'application/json'

    # Parse the JSON response
    response_json = response.json()

    # Check the response
    assert response_json['status']['code'] == 0
    assert 'done' in response_json
    assert 'error' not in response_json

# Run the test
pytest.main()