# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_script_projects_get():
    url = f"{BASE_URL}/v1/projects/{'scriptId'}"
    params = {
        '_.xgafv': '1',
        'access_token': '',
        'alt': 'json',
        'callback': '',
        'fields': '',
        'key': '',
        'oauth_token': '',
        'prettyPrint': 'false',
        'quotaUser': '',
        'upload_protocol': 'uploadType',
        'uploadType': ''
    }
    
    response = requests.get(url, params=params)
    assert response.status_code == 200
    
    data = response.json()
    assert isinstance(data, dict)
    expected_schema = {"type": "object", 
                       "properties": {
                           "createTime": {"format": "google-datetime", "type": "string"}, 
                           "creator": {"$ref": "#/components/schemas/GoogleAppsScriptTypeUser"}, 
                           "lastModifyUser": {"$ref": "#/components/schemas/GoogleAppsScriptTypeUser"}, 
                           "parentId": {"type": "string"}, 
                           "scriptId": {"type": "string"}, 
                           "title": {"type": "string"}, 
                           "updateTime": {"format": "google-datetime", "type": "string"}
                        }, 
                        "type": "object"
                    }
    assert data == expected_schema