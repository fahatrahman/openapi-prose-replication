# openapi_test.py

import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_create_rollup_property():
    url = f"{BASE_URL}/v1alpha/properties/createRollupProperty"
    
    request_body = {
        "rollupProperty": {
            "name": "test_rollup_property",
            "propertyType": "PROPERTY_TYPE_ROLLUP",
            "serviceLevel": "GOOGLE_ANALYTICS_STANDARD",
            "createTime": str(datetime.now()),
            "updateTime": str(datetime.now()),
            "deleteTime": None,
            "expireTime": None,
            "parent": "tjnnzcqy/123",
            "display_name": "Test Rollup Property",
            "industry_category": "INDUSTRY_CATEGORY_UNSPECIFIED",
            "currency_code": "USD",
            "timezone": "America/New_York",
            "account": "123456789"
        },
        "sourceProperties": ["rdwuhiczdu/789"]
    }
    
    headers = {"Content-Type": "application/json"}
    response = requests.post(url, json=request_body, headers=headers)
    
    assert response.status_code == 200
    
    # Check if the response body is valid JSON
    try:
        response.json()
    except ValueError:
        pytest.fail("Invalid JSON in response")