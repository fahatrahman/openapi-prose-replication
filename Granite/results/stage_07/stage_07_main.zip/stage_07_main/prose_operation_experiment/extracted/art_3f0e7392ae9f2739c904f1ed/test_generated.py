import os
import pytest
import requests
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def cloudscheduler():
    api_service_name = "cloudscheduler"
    api_version = "v1beta1"
    credentials = None

    if credentials is None:
        # TODO: set up proper OAuth2 flow
        credentials = os.environ["GOOGLE_APPLICATION_CREDENTIALS"]

    service = build(api_service_name, api_version, credentials=credentials)
    return service

def test_list_locations(cloudscheduler):
    project_name = "your_project_name"
    try:
        response = cloudscheduler.projects().locations().list(
            name=project_name, filter="some_filter", pageSize=10, pageToken="some_page_token"
        ).execute()
        
        assert isinstance(response, dict)
        assert "locations" in response
        assert isinstance(response["locations"], list)
        assert "nextPageToken" in response
        
    except HttpError as error:
        print(f"An error occurred: {error}")