import pytest
import requests

BASE_URL = "http://openapi.test"

def test_distribution_groups_details_for_org():
    api_token = "your_api_token_here"
    org_name = "your_organization_name_here"
    
    headers = {"X-API-Token": api_token}
    params = {"apps_limit": 10}

    response = requests.get(f"{BASE_URL}/v0.1/orgs/{org_name}/distribution_groups_details", headers=headers, params=params)

    assert response.status_code == 200
    response.raise_for_status()

    data = response.json()
    assert isinstance(data, list)
    assert all(isinstance(item, dict) for item in data)
    assert all("id" in item and "name" in item and "origin" in item and "is_public" in item for item in data)
    assert all(has_key("apps") and has_key("total_apps_count") and has_key("total_users_count") for item in data)

def has_key(d, key):
    return key in d