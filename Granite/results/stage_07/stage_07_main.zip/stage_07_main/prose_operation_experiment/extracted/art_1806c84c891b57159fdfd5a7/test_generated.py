import os
import pytest
import requests
from google.auth import default
from googleapiclient.discovery import build

BASE_URL = "http://openapi.test"

@pytest.fixture
def auth_service():
    creds, _ = default()
    service = build('networkservices', 'v1', credentials=creds)
    return service

def test_list_service_lb_policies(auth_service):
    parent = "zynntaco/your_project_id/yzvrewumc/your_location_id"
    request_params = {
        'pageSize': 10,
        'pageToken': 'your_page_token'
    }

    response = auth_service.projects().locations().serviceLbPolicies().list(parent=parent, **request_params).execute()

    assert response.get('serviceLbPolicies')
    assert isinstance(response['serviceLbPolicies'], list)
    assert response.get('nextPageToken')