import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retry strategy
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount("https://", adapter)
session.mount("http://", adapter)

# Security credentials
OAUTH2_TOKEN = os.environ.get("OAUTH2_TOKEN")
API_KEY = os.environ.get("API_KEY")

@pytest.fixture
def headers():
    return {
        "Accept-Language": "en-US",
        "Api-Key": API_KEY,
        "Authorization": f"Bearer {OAUTH2_TOKEN}" if OAUTH2_TOKEN else None
    }

def test_video_download_history(headers):
    response = session.get(f"{BASE_URL}/v3/videos/{'video_id'}/downloadhistory", headers=headers)

    assert response.status_code == 200, f"Received non-200 status code: {response.status_code}"
    assert isinstance(response.json(), dict), "Response content type should be application/json"

    # Further assertions based on the schema can be added here
    # For example, checking if 'downloads' and 'id' keys are present
    assert 'downloads' in response.json() or 'id' in response.json(), "Missing expected keys in response"