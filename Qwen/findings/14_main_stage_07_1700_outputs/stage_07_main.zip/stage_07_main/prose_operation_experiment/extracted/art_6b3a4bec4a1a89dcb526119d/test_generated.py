import pytest
import requests

BASE_URL = "http://openapi.test"

def test_cancel_job():
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20130801/us-east-1/s3/aws4_request",
        "X-Amz-Date": "20130801T120000Z",
        "X-Amz-Security-Token": "AQoDYXdzEPT//////////wEaHiqKfYRvFrQlOqkqJm5VDMnVLj8GgWxu0BtUdF8Mg==",
        "X-Amz-Signature": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-algorithm;x-amz-credential;x-amz-security-token"
    }
    response = requests.delete(f"{BASE_URL}/2017-08-29/jobs/example_id", headers=headers)
    assert response.status_code == 202
    assert response.json() == {}

if __name__ == "__main__":
    pytest.main()