import os
import requests
import pytest
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.fixture
def client():
    return SESSION

def test_list_schemas(client):
    registry_name = "example_registry"
    limit = 10
    next_token = None

    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "STRING",
        "X-Amz-Date": "DATE",
        "X-Amz-Credential": "CREDENTIAL",
        "X-Amz-Security-Token": "TOKEN",
        "X-Amz-Signature": "SIGNATURE",
        "X-Amz-SignedHeaders": "SIGNED_HEADERS",
    }

    params = {
        "limit": limit,
        "nextToken": next_token,
        "registryName": registry_name,
    }

    response = client.get(
        f"{BASE_URL}/v1/registries/{registry_name}/schemas", headers=headers, params=params
    )

    assert response.status_code == 200