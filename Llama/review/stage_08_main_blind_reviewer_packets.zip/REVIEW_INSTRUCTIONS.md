# Independent assertion-claim review

Reviewer 1 labels all assigned claims. Reviewer 2 labels only the frozen sample, independently. Reviewer 3 adjudicates only label disagreements using the two prior decisions and the blinded evidence.

For each blind_claim_id, find the matching row in context_bundle.jsonl. Read the assertion and the source location. Use test_context_id to look up the test in test_context.jsonl and spec_context_id to look up the OpenAPI specification in specification_context.jsonl. Each JSONL line contains one JSON object. Check the applicable scenario, test inputs and expected value. For reached assertions, use reached_case_evidence to join the pytest case to its recorded scenario and response. For other assertions, judge the documented contract against the scenario inferable from the test and record any uncertainty. Reachability is recorded independently from the semantic label.

- supported — the applicable specification justifies the expectation.
- contradicted — applicable evidence conflicts with the expectation.
- undocumented_or_unsupported — the expectation is clear but the applicable specification does not establish it.
- ambiguous_or_unverifiable — a necessary value, scenario, or rule cannot be resolved from the evidence.

Fill in label and reasoning for every assigned row. For supported and contradicted, copy requirement_id and source_pointer from the same candidate evidence entry, using evidence_pointer for the source pointer. For the other labels, leave both fields blank or cite a matching pair. Keep the headers, blind IDs and reviewer ID intact. Reviewer 1 and 2 keep NOT_REQUIRED. Reviewer 3 marks every final decision COMPLETED, including ambiguous decisions. Return the CSV as reviewer_1_completed.csv, reviewer_2_completed.csv or reviewer_3_completed.csv, according to your assigned role.
