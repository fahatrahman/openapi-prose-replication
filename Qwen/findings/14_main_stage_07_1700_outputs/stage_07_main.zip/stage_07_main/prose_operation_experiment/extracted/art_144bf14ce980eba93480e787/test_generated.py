import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_pico_loadmanagementgroup():
    response = requests.get(f"{BASE_URL}/api/pico/loadmanagementgroup")
    assert response.status_code == 200
    assert isinstance(response.json(), list)
    for item in response.json():
        assert 'Id' in item
        assert 'MaxCurrent' in item
        assert 'Name' in item
        assert 'NumberOfStations' in item
        assert isinstance(item['Id'], str)
        assert isinstance(item['MaxCurrent'], float)
        assert isinstance(item['Name'], str)
        assert isinstance(item['NumberOfStations'], int)

if __name__ == "__main__":
    pytest.main()