import pytest
import requests
from urllib.parse import urlencode

BASE_URL = "http://openapi.test"

def test_floodlight_configurations():
    url = f"{BASE_URL}/userprofiles/{profile_id}/floodlightConfigurations"
    headers = {
        "$.xgafv": "1",
        "Content-Type": "application/json; charset=UTF-8"
    }
    params = {
        "key": "YOUR_API_KEY",
        "prettyPrint": True,
        "quotaUser": "YOUR_QUOTA_USER"
    }

    data = {
        "accountId": "1234567890",
        "advertiserId": "9876543210",
        "analyticsDataSharingEnabled": False,
        "customViewabilityMetric": {
            "configuration": {
                "audible": False,
                "timeMillis": 30000,
                "timePercent": 50,
                "viewabilityPercent": 25
            },
            "id": "metric_1",
            "name": "My Custom Viewability Metric"
        },
        "exposureToConversionEnabled": True,
        "firstDayOfWeek": "MONDAY",
        "id": "config_1",
        "inAppAttributionTrackingEnabled": False,
        "kind": "dfareporting#floodlightConfiguration",
        "lookbackConfiguration": {
            "clickDuration": 30,
            "postImpressionActivitiesDuration": 60
        },
        "naturalSearchConversionAttributionOption": "INCLUDE_NATURAL_SEARCH_CONVERSION_ATTRIBUTION",
        "omnitureSettings": {
            "omnitureCostDataEnabled": True,
            "omnitureIntegrationEnabled": True
        },
        "subaccountId": "2345678901",
        "tagSettings": {
            "dynamicTagEnabled": True,
            "imageTagEnabled": False
        },
        "thirdPartyAuthenticationTokens": [
            {"name": "token_1", "value": "value_1"}
        ],
        "userDefinedVariableConfigurations": []
    }

    response = requests.request(
        "PATCH",
        url,
        headers=headers,
        params=urlencode(params),
        json=data
    )

    assert response.status_code == 200
    assert response.json() == data

@pytest.fixture
def profile_id():
    return "profile_1"