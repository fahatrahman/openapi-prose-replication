import pytest
import requests

BASE_URL = "http://openapi.test"

def test_update_account_tax():
    url = f"{BASE_URL}/12345/accounttax/67890"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "accountId": "67890",
        "kind": "content#accountTax",
        "rules": [
            {
                "country": "US",
                "locationId": "123456",
                "ratePercent": "8.25",
                "shippingTaxed": False,
                "useGlobalRate": False
            }
        ]
    }
    params = {
        "dryRun": True
    }

    response = requests.put(url, headers=headers, json=payload, params=params)

    assert response.status_code == 200
    assert "accountId" in response.json()
    assert response.json()["kind"] == "content#accountTax"
    assert len(response.json()["rules"]) == 1
    assert response.json()["rules"][0]["country"] == "US"
    assert response.json()["rules"][0]["locationId"] == "123456"
    assert response.json()["rules"][0]["ratePercent"] == "8.25"
    assert response.json()["rules"][0]["shippingTaxed"] == False
    assert response.json()["rules"][0]["useGlobalRate"] == False