import os
import pytest
import requests
from googleapiclient.discovery import build

BASE_URL = "http://openapi.test"

# Authenticate with Google using OAuth2
def authenticate():
    flow = build("service_management", "v1").new_project_access()
    credentials = flow.step1_get_user_consent()
    credentials = flow.step2_exchange(credentials)
    return credentials

@pytest.fixture
def tpu_client():
    credentials = authenticate()
    service = build("tpu", "v2alpha1", credentials=credentials)
    return service

def test_list_runtime_versions(tpu_client):
    parent = "your_parent_value"  # Replace with actual value
    request = tpu_client.projects().locations().runtimeVersions().list(parent=parent)

    response = request.execute()

    assert isinstance(response, dict)
    assert "runtimeVersions" in response
    assert isinstance(response["runtimeVersions"], list)
    assert "nextPageToken" in response or "unreachable" in response