# pytest_deactivate_beacon.py

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_deactivate_beacon():
    url = f"{BASE_URL}/v1beta1/beacons/deactivate"
    headers = {
        'Content-Type': 'application/json',
    }
    params = {
        'key': 'your_api_key',  # Replace with your actual API key
    }
    data = {}

    try:
        response = requests.post(url, json=data, headers=headers, params=params)
        assert response.status_code == 200
    except requests.exceptions.RequestException as e:
        pytest.fail(f"Request failed: {e}")