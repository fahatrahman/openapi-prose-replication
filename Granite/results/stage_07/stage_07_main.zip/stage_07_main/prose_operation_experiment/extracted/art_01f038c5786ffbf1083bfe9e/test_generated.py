import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Configure requests session for retries on failure
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

@pytest.fixture
def control_panels():
    headers = {
        'X-Amz-Algorithm': 'AWS4-HMAC-SHA256',
        'X-Amz-Content-Sha256': 'STRING',
        'X-Amz-Credential': 'CREDENTIALS',
        'X-Amz-Date': 'DATE',
        'X-Amz-Security-Token': 'TOKEN',
        'X-Amz-Signature': 'SIGNATURE'
    }

    params = {
        'ClusterArn': 'ARN',
        'MaxResults': 10,
        'NextToken': 'NEXT_TOKEN'
    }

    response = session.get(f"{BASE_URL}/controlpanels", headers=headers, params=params)
    if response.status_code == 200:
        return response.json()
    elif response.status_code == 480:
        raise Exception("ResourceNotFoundException")
    elif response.status_code == 481:
        raise Exception("ThrottlingException")
    elif response.status_code == 482:
        raise Exception("ValidationException")
    elif response.status_code == 483:
        raise Exception("InternalServerException")
    elif response.status_code == 484:
        raise Exception("AccessDeniedException")
    else:
        raise Exception(f"Unexpected status code: {response.status_code}")