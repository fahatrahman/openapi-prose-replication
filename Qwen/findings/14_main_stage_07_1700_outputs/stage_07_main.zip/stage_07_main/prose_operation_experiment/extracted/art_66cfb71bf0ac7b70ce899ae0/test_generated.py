import pytest
import requests

BASE_URL = "http://openapi.test"

def test_update_team():
    headers = {
        "Authorization": "Bearer YOUR_PERSONAL_ACCESS_TOKEN"
    }
    payload = {
        "data": {
            "gid": "12345",
            "name": "Updated Team Name",
            "description": "Updated team description",
            "html_description": "<body><em>Updated</em> team description.</body>",
            "organization": "123456789",
            "visibility": "public"
        }
    }
    params = {
        "pretty": True,
        "fields": ["id", "name", "description"],
        "limit": 50,
        "offset": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9"
    }
    response = requests.put(f"{BASE_URL}/teams", json=payload, headers=headers, params=params)
    assert response.status_code == 200
    assert response.json()["data"]["name"] == "Updated Team Name"
    assert response.json()["data"]["description"] == "Updated team description"
    assert response.json()["data"]["html_description"] == "<body><em>Updated</em> team description.</body>"
    assert response.json()["data"]["organization"] == "123456789"
    assert response.json()["data"]["visibility"] == "public"