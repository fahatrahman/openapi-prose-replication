import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_devices():
    url = f"{BASE_URL}/devices"
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "YOUR_CREDENTIALS",
        "X-Amz-Date": "CURRENT_DATE",
        "X-Amz-Security-Token": "YOUR_SECURITY_TOKEN",
        "X-Amz-Signature": "YOUR_SIGNATURE",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-security-token;x-amz-signature"
    }
    params = {
        "deviceType": "eovppf",
        "maxResults": 10,
        "nextToken": ""
    }
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 200
    assert "Devices" in response.json()
    assert "NextToken" in response.json()

def test_list_devices_with_invalid_request():
    url = f"{BASE_URL}/devices"
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "INVALID_CREDENTIALS",
        "X-Amz-Date": "CURRENT_DATE",
        "X-Amz-Security-Token": "INVALID_SECURITY_TOKEN",
        "X-Amz-Signature": "INVALID_SIGNATURE",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-security-token;x-amz-signature"
    }
    params = {
        "deviceType": "eovppf",
        "maxResults": 10,
        "nextToken": ""
    }
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 481

def test_list_devices_with_range_not_satisfiable():
    url = f"{BASE_URL}/devices"
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "YOUR_CREDENTIALS",
        "X-Amz-Date": "CURRENT_DATE",
        "X-Amz-Security-Token": "YOUR_SECURITY_TOKEN",
        "X-Amz-Signature": "YOUR_SIGNATURE",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-security-token;x-amz-signature"
    }
    params = {
        "deviceType": "eovppf",
        "maxResults": 251,
        "nextToken": ""
    }
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 480

def test_list_devices_with_internal_failure():
    url = f"{BASE_URL}/devices"
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "INTERNAL_FAILURE_CREDENTIALS",
        "X-Amz-Date": "CURRENT_DATE",
        "X-Amz-Security-Token": "INTERNAL_FAILURE_SECURITY_TOKEN",
        "X-Amz-Signature": "INTERNAL_FAILURE_SIGNATURE",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-security-token;x-amz-signature"
    }
    params = {
        "deviceType": "eovppf",
        "maxResults": 10,
        "nextToken": ""
    }
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 482