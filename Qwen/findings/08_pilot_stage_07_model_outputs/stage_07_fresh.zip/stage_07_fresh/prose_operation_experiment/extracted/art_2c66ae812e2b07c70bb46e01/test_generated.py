import pytest
import requests

BASE_URL = "http://openapi.test"

def test_update_route():
    api_id = "your_api_id"
    route_id = "your_route_id"
    url = f"{BASE_URL}/v2/apis/{api_id}/routes/{route_id}"
    
    payload = {
        "apiKeyRequired": False,
        "authorizationScopes": ["scope1", "scope2"],
        "authorizationType": "NONE",
        "authorizerId": "your_authorizer_id",
        "modelSelectionExpression": "$input.body.action",
        "operationName": "update_operation",
        "requestModels": {"application/json": "YourModel"},
        "requestParameters": {},
        "routeKey": "ANY /new-route",
        "routeResponseSelectionExpression": "$context.routeKey",
        "target": "integrations/integration-id"
    }
    
    headers = {
        "Content-Type": "application/json",
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Date": "20230401T000000Z",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "your_credential",
        "X-Amz-Security-Token": "your_security_token",
        "X-Amz-SignedHeaders": "host;x-amz-content-sha256;x-amz-date;x-amz-algorithm;x-amz-credential;x-amz-security-token"
    }
    
    response = requests.patch(url, json=payload, headers=headers)
    
    assert response.status_code == 200
    assert "routeId" in response.json()