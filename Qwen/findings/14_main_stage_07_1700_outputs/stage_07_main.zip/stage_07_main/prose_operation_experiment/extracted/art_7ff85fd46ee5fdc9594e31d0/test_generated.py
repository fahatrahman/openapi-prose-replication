import pytest
import requests

BASE_URL = "http://openapi.test"

def test_divisions_search_total_results_json():
    params = {
        "format": "json",
        "queryParameters.searchTerm": "test"
    }
    response = requests.get(f"{BASE_URL}/data/divisions.json/searchTotalResults", params=params)
    assert response.status_code == 200
    assert isinstance(response.json(), int)

def test_divisions_search_total_results_xml():
    params = {
        "format": "xml",
        "queryParameters.searchTerm": "test"
    }
    response = requests.get(f"{BASE_URL}/data/divisions.xml/searchTotalResults", params=params)
    assert response.status_code == 200
    assert isinstance(int(response.text), int)

def test_divisions_search_total_results_with_member_id():
    params = {
        "format": "json",
        "queryParameters.searchTerm": "test",
        "queryParameters.memberId": 123
    }
    response = requests.get(f"{BASE_URL}/data/divisions.json/searchTotalResults", params=params)
    assert response.status_code == 200
    assert isinstance(response.json(), int)

def test_divisions_search_total_results_with_teller_info():
    params = {
        "format": "json",
        "queryParameters.searchTerm": "test",
        "queryParameters.includeWhenMemberWasTeller": True
    }
    response = requests.get(f"{BASE_URL}/data/divisions.json/searchTotalResults", params=params)
    assert response.status_code == 200
    assert isinstance(response.json(), int)

def test_divisions_search_total_results_with_date_range():
    params = {
        "format": "json",
        "queryParameters.searchTerm": "test",
        "queryParameters.startDate": "2023-01-01",
        "queryParameters.endDate": "2023-12-31"
    }
    response = requests.get(f"{BASE_URL}/data/divisions.json/searchTotalResults", params=params)
    assert response.status_code == 200
    assert isinstance(response.json(), int)

def test_divisions_search_total_results_with_division_number():
    params = {
        "format": "json",
        "queryParameters.searchTerm": "test",
        "queryParameters.divisionNumber": 12345
    }
    response = requests.get(f"{BASE_URL}/data/divisions.json/searchTotalResults", params=params)
    assert response.status_code == 200
    assert isinstance(response.json(), int)