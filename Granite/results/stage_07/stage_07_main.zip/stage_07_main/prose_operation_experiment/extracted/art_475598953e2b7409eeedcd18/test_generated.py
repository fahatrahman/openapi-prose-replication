import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_PATH = "credentials.json"

@pytest.fixture
def auth():
    credentials = service_account.Credentials.from_service_account_file(
        CREDENTIALS_PATH, scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )
    return credentials

def test_list_service_project_attachments(auth):
    path = "/v1alpha/{}/serviceProjectAttachments".format("your_parent_value")
    headers = {
        "x-goog-api-client": "gl-python",
        "x-goog-api-version": "1",
    }

    response = requests.get(BASE_URL + path, headers=headers, auth=auth)
    assert response.status_code == 200
    
    result = response.json()
    # Add assertions here based on the expected structure of ListServiceProjectAttachmentsResponse
