import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_put_function_event_invoke_config():
    timestamp = datetime.utcnow().isoformat()
    headers = {
        'X-Amz-Algorithm': 'AWS4-HMAC-SHA256',
        'X-Amz-Content-Sha256': 'a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6',
        'X-Amz-Credential': 'AKIDEXAMPLE/20210924/us-east-1/lambda/aws4_request',
        'X-Amz-Date': timestamp,
        'X-Amz-Security-Token': 'FQoDYXdzEE4aDJ//////////wEaZT4ZM5kbG9NQWJhc2ljIEFDQ0VTU0lHTkJVNElDQVRFLU1BTExJQ0FNQURBUUVBVElDUyIsImtpZCI6IkpXVCIsImlhdCI6MTY1OTE0NDMyOSwiZXhwIjoxNjU5MTQ0ODI5LCJuYW1lIjoiSm9obiBEb2UiLCJuYW1pdHkiOiJDbGFzc2lkIiwiaWF0IjoxNjU5MTQ0MjI5LCJuYW1lIjoiSm9obiBEb2UiLCJuYW1pdHkiOiJDbGFzc2lkIn0=.EyRrP6QK5j5b7g5C2pT+8jZ7j8p9O9g9L9K9I9H9G9E9C9A9w==',
        'X-Amz-Signature': 'a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6',
        'X-Amz-SignedHeaders': 'host;x-amz-date'
    }
    
    data = {
        "DestinationConfig": {
            "OnFailure": {
                "Destination": "arn:aws:sqs:us-east-1:123456789012:my-queue"
            },
            "OnSuccess": {
                "Destination": "arn:aws:sns:us-east-1:123456789012:my-topic"
            }
        },
        "MaximumEventAgeInSeconds": 3600,
        "MaximumRetryAttempts": 1
    }

    response = requests.put(
        f"{BASE_URL}/2019-09-25/functions/my-function/event-invoke-config",
        json=data,
        headers=headers
    )

    assert response.status_code == 200