import pytest
import requests

BASE_URL = "http://openapi.test"

def test_transfer_tokens():
    address = "test_address"
    url = f"{BASE_URL}/erc20/{address}"
    payload = {}  # Assuming no body is needed for this POST request
    headers = {
        "Content-Type": "application/json",
    }
    response = requests.post(url, json=payload, headers=headers)
    assert response.status_code == 200
    assert response.json() == {}