# -*- coding: utf-8 -*-

import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_issue_list_blocks():
    owner = "your_owner"
    repo = "your_repo"
    index = "1"
    page = 1
    limit = 10
    
    url = f"{BASE_URL}/repos/{owner}/{repo}/issues/{index}/blocks"
    
    headers = {
        # You can add your auth token here, e.g., 
        # 'Authorization': 'Bearer YOUR_TOKEN',
        # 'Sudo': 'YOUR_USERNAME'
    }
    
    params = {
        'page': page,
        'limit': limit
    }
    
    response = requests.get(url, headers=headers, params=params)
    
    assert response.status_code == 200
    
    try:
        response_json = response.json()
        
        # You can check the response content here
        print(response_json)
        
    except ValueError:
        pytest.fail("Invalid JSON response")
    
    finally:
        if 'Content-Encoding' in response.headers and response.headers['Content-Encoding'] == 'gzip':
            pytest.skip('Gzip encoding is not supported')