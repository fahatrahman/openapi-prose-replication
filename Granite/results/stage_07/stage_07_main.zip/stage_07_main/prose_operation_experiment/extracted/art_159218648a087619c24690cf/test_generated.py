import os
import pytest
import requests
from googleapiclient.discovery import build

BASE_URL = "http://openapi.test"

# Setup OAuth2 credentials
credentials = {'access_token': 'YOUR_ACCESS_TOKEN'}

def test_list_publisher_accounts():
    service = build('admob', 'v1beta', credentials=credentials)

    request = service.accounts().list(
        pageSize=10,
        pageToken='page_token'
    )

    response = request.execute()

    assert 'account' in response
    assert 'nextPageToken' in response

if __name__ == '__main__':
    pytest.main([__file__])