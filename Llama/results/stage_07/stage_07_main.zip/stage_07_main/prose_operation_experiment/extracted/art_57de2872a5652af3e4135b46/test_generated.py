# openapi_test.py

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_directory_roles_update():
    url = f"{BASE_URL}/admin/directory/v1/customer/{'test_customer'}/roles/{'test_role_id'}"
    headers = {
        'Content-Type': 'application/json',
    }
    body = {
        "etag": "1234567890",
        "isSuperAdminRole": True,
        "isSystemRole": False,
        "kind": "admin#directory#role",
        "roleDescription": "Test role description",
        "roleId": "1234567890",
        "roleName": "Test role name",
        "rolePrivileges": [
            {"privilegeName": "Test privilege", "serviceId": "Test service ID"}
        ]
    }

    response = requests.put(url, headers=headers, json=body)
    assert response.status_code == 200
    assert response.json() == body

if __name__ == "__main__":
    pytest.main([__file__, "-vv"])