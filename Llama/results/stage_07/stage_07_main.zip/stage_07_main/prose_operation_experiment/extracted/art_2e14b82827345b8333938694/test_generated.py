# -*- coding: utf-8 -*-
import pytest
import requests

BASE_URL = "http://openapi.test"

def test_keep_notes_delete():
    name = 'MHOCL'
    url = f"{BASE_URL}/v1/{name}"
    headers = {}
    
    response = requests.delete(
        url,
        headers=headers,
    )
    
    assert response.status_code == 200
    
    # The API does not return any meaningful content in this case, so we don't check the body.