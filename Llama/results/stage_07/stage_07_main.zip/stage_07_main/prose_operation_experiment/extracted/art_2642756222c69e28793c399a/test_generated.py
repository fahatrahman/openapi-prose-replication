# -*- coding: utf-8 -*-
"""Tests for openapi.py."""

import pytest
from requests import Response
from requests.exceptions import Timeout


BASE_URL = "http://openapi.test"


def test_create_connector():
    """Test create connector."""
    url = f"{BASE_URL}/v1/{'projects(locations(connectors))'}"
    headers = {"Content-Type": "application/json"}
    params = {
        "$.xgafv": "1",
        "access_token": "",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "",
        "oauth_token": "",
        "prettyPrint": "false",
        "quotaUser": "",
        "upload_protocol": "",
        "uploadType": "",
        "connectorId": "test_connector_id",
    }
    body = {
        "name": "test_connector_name",
        "network": "test_network",
        "state": "READY",
        "subnet": {"name": "test_subnet", "projectId": "test_project_id"},
        "connectedProjects": ["test_project"],
        "ipCidrRange": "10.132.0.0/28",
        "machineType": "h2-jcuuc",
        "maxInstances": 100,
        "maxThroughput": 300,
        "minInstances": 50,
        "minThroughput": 200,
    }

    response = Response()
    response.status_code = 200
    response.json = lambda: {"name": "test_connector_name"}

    def mock_post(url, headers=headers, params=params, json=body):
        return response

    # Disable the 'requests.post' function
    original_post = requests.post
    requests.post = mock_post

    try:
        response = requests.post(url, headers=headers, params=params, json=body)
        assert response.status_code == 200
        assert response.json()["name"] == "test_connector_name"
    finally:
        # Restore the original 'requests.post' function
        requests.post = original_post

    assert True


@pytest.fixture(autouse=True)
def disable_requests_warnings(requests_mock):
    """Disable the 'requests' library's warnings."""
    # Suppress the 'requests.packages.urllib3.util.retry' warning
    import urllib3

    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


import requests