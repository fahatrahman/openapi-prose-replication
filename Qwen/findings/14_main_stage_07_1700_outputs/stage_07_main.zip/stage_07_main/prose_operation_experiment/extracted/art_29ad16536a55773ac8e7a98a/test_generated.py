import pytest
import requests

BASE_URL = "http://openapi.test"

def test_retrieve_all_hooks():
    authtoken = "your_authtoken_here"
    login = "your_login_here"
    limit = 50
    page = 1

    url = f"{BASE_URL}/hooks.json"
    params = {
        "authtoken": authtoken,
        "login": login,
        "limit": limit,
        "page": page
    }

    response = requests.get(url, params=params)

    assert response.status_code == 200
    hooks = response.json()
    assert isinstance(hooks, list)
    for hook in hooks:
        assert isinstance(hook, dict)
        assert "hook" in hook
        hook_data = hook["hook"]
        assert "created_at" in hook_data
        assert "event" in hook_data
        assert "id" in hook_data
        assert "name" in hook_data
        assert "url" in hook_data
        assert isinstance(hook_data["id"], int)