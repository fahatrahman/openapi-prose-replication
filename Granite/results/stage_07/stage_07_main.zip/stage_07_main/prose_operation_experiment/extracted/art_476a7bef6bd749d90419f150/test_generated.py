import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
RETRY_STRATEGY = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    method_whitelist=["GET", "OPTIONS"],
)
adapter = HTTPAdapter(max_retries=RETRY_STRATEGY)
http = requests.Session()
http.mount("https://", adapter)
http.mount("http://", adapter)

@pytest.fixture
def vulnerability_summary():
    parent = "projects/your_project_id"  # Replace 'your_project_id' with the actual project ID
    url = f"{BASE_URL}/v1/{parent}/occurrences:vulnerabilitySummary"

    params = {
        "filter": "/*",  # Example filter, adjust as needed
        # Add other required parameters like access_token or oauth_token if necessary
    }

    response = http.get(url, params=params)
    response.raise_for_status()
    return response.json()

def test_vulnerability_summary(vulnerability_summary):
    assert isinstance(vulnerability_summary, dict)
    assert "counts" in vulnerability_summary
    assert all(isinstance(item, dict) for item in vulnerability_summary["counts"])