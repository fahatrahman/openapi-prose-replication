import pytest
import requests
from datetime import datetime
import json

BASE_URL = "http://openapi.test"

class SyntheticTimestamp:
    @staticmethod
    def date_time():
        return datetime.now().isoformat()

class RegionList(list):
    pass

class TagMap(dict):
    pass

class IndexState(str):
    enum = ["CREATING", "ACTIVE", "DELETING", "DELETED", "UPDATING"]

class IndexType(str):
    enum = ["LOCAL", "AGGREGATOR"]

def get_index():
    headers = {
        'X-Amz-Algorithm': '',
        'X-Amz-Content-Sha256': '',
        'X-Amz-Credential': '',
        'X-Amz-Date': SyntheticTimestamp.date_time(),
        'X-Amz-Security-Token': '',
        'X-Amz-Signature': '',
        'X-Amz-SignedHeaders': ''
    }

    response = requests.post(
        f"{BASE_URL}/GetIndex",
        headers=headers,
    )

    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert all(key in data for key in ['Arn', 'CreatedAt', 'LastUpdatedAt', 'ReplicatingFrom', 'ReplicatingTo', 'State', 'Tags', 'Type'])

def test_get_index():
    get_index()