import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

def test_global_images():
    url = f"{BASE_URL}/api/v2/GlobalImages"

    # Add query parameters if needed
    params = {
        "limit": 10,
        "offset": 0,
    }

    response = SESSION.get(url, params=params)
    response.raise_for_status()

    data = response.json()

    assert isinstance(data, dict)
    assert "Entities" in data
    assert "Metadata" in data

    entities = data["Entities"]
    metadata = data["Metadata"]

    assert isinstance(entities, list)
    assert isinstance(metadata, dict)
    assert all(isinstance(item, dict) for item in entities)

    for entity in entities:
        assert all(key in entity for key in ["CRC", "ThumbnailCRC", "State", "Name", "Description", "Width", "Height"])
        assert all(isinstance(value, str) for value in [entity["CRC"], entity["ThumbnailCRC"], entity["Name"], entity["Description"]])
        assert entity["State"] in ["Created", "Available", "Removed"]
        assert isinstance(entity["Width"], int)
        assert isinstance(entity["Height"], int)

    assert all(key in metadata for key in ["TotalCount", "Limit", "Offset"])
    assert metadata["TotalCount"] > 0
    assert metadata["Limit"] == params.get("limit")
    assert metadata["Offset"] == params.get("offset")