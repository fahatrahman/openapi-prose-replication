import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from typing import List

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
SESSION.mount("https://", HTTPAdapter(max_retries=3))
SESSION.mount("http://", HTTPAdapter(max_retries=3))

@pytest.fixture
def designer_templates():
    headers = {"x-api-key": os.getenv("OPENAPI_TEST_API_KEY")}

    def _get():
        params = {"limit": 10, "offset": 0}
        response = SESSION.get(f"{BASE_URL}/designer/templates", headers=headers, params=params)

        if response.status_code == 200:
            return response.json()["results"]
        elif 400 <= response.status_code < 500:
            raise Exception(response.json())
        else:
            raise Exception(response.json())

    return _get


def test_designer_templates(designer_templates):
    templates = designer_templates()
    assert isinstance(templates, List)
    for template in templates:
        assert isinstance(template, dict)
        assert all(key in template for key in ["name", "template_html", "css", "format", "orientation", "components", "preview_payload", "margin", "id"])