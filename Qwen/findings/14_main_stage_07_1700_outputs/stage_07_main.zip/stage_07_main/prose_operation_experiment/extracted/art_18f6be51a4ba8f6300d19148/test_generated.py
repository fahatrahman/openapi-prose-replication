import pytest
import requests

BASE_URL = "http://openapi.test"

def test_post_origin_keys_basic():
    headers = {
        "Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed",
        "X-API-Key": "your_api_key_here"
    }
    payload = {
        "originDomains": [
            "https://www.your-domain1.com",
            "https://www.your-domain2.com",
            "https://www.your-domain3.com"
        ]
    }

    response = requests.post(f"{BASE_URL}/originKeys", headers=headers, json=payload)

    assert response.status_code == 200
    assert "originKeys" in response.json()

def test_post_origin_keys_invalid_idempotency_key():
    headers = {
        "Idempotency-Key": "invalid-idempotency-key",
        "X-API-Key": "your_api_key_here"
    }
    payload = {
        "originDomains": [
            "https://www.your-domain1.com",
            "https://www.your-domain2.com",
            "https://www.your-domain3.com"
        ]
    }

    response = requests.post(f"{BASE_URL}/originKeys", headers=headers, json=payload)

    assert response.status_code == 400
    assert response.json()["errorCode"] == "702"
    assert response.json()["errorType"] == "validation"
    assert response.json()["message"].startswith("Unexpected input")

def test_post_origin_keys_unauthorized():
    headers = {
        "Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed"
    }
    payload = {
        "originDomains": [
            "https://www.your-domain1.com",
            "https://www.your-domain2.com",
            "https://www.your-domain3.com"
        ]
    }

    response = requests.post(f"{BASE_URL}/originKeys", headers=headers, json=payload)

    assert response.status_code == 401
    assert response.json()["errorCode"] == "000"
    assert response.json()["errorType"] == "security"
    assert response.json()["message"] == "HTTP Status Response - Unauthorized"

def test_post_origin_keys_forbidden():
    headers = {
        "Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed",
        "X-API-Key": "your_api_key_here"
    }
    payload = {
        "originDomains": [
            "https://www.your-domain1.com",
            "https://www.your-domain2.com",
            "https://www.your-domain3.com"
        ]
    }

    response = requests.post(f"{BASE_URL}/originKeys", headers=headers, json=payload)

    assert response.status_code == 403
    assert response.json()["errorCode"] == "901"
    assert response.json()["errorType"] == "security"
    assert response.json()["message"] == "Invalid Merchant Account"

def test_post_origin_keys_missing_return_url():
    headers = {
        "Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed",
        "X-API-Key": "your_api_key_here"
    }
    payload = {
        "originDomains": [
            "https://www.your-domain1.com",
            "https://www.your-domain2.com",
            "https://www.your-domain3.com"
        ]
    }

    response = requests.post(f"{BASE_URL}/originKeys", headers=headers, json=payload)

    assert response.status_code == 422
    assert response.json()["errorCode"] == 14030
    assert response.json()["errorType"] == "validation"
    assert response.json()["message"] == "Return URL is missing"

def test_post_origin_keys_internal_server_error():
    headers = {
        "Idempotency-Key": "37ca9c97-d1d1-4c62-89e8-706891a563ed",
        "X-API-Key": "your_api_key_here"
    }
    payload = {
        "originDomains": [
            "https://www.your-domain1.com",
            "https://www.your-domain2.com",
            "https://www.your-domain3.com"
        ]
    }

    response = requests.post(f"{BASE_URL}/originKeys", headers=headers, json=payload)

    assert response.status_code == 500
    assert response.json()["errorCode"] == "905"
    assert response.json()["errorType"] == "configuration"
    assert response.json()["message"] == "Payment details are not supported"