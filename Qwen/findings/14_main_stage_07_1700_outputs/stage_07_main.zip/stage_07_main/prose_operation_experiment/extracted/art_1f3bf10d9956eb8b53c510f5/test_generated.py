import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_source():
    url = f"{BASE_URL}/v1/projects/locations/sources/source-name"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token",
        "alt": "json",
        "fields": "name",
        "key": "your_api_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": False,
        "quotaUser": "user",
        "uploadType": "multipart",
        "upload_protocol": "raw",
        "requestId": "unique-request-id"
    }
    headers = {
        "Authorization": "Bearer your_access_token"
    }
    response = requests.delete(url, params=params, headers=headers)
    assert response.status_code == 200
    assert "name" in response.json()