import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_cis_instruction_from_subcontractor():
    employer_id = "GD001"
    subcontractor_id = "VVZ001"
    cis_instruction_id = "QXG001"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    
    response = requests.get(
        f"{BASE_URL}/Employer/{employer_id}/SubContractor/{subcontractor_id}/CisInstruction/{cis_instruction_id}",
        headers=headers
    )
    
    assert response.status_code == 200
    assert "Content-Type" in response.headers and response.headers["Content-Type"] == "application/json"
    assert isinstance(response.json(), dict)
    assert "CisInstruction" in response.json()

if __name__ == "__main__":
    pytest.main()