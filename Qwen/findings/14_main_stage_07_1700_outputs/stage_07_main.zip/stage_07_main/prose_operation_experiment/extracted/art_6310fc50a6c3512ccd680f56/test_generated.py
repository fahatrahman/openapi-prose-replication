import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_operation():
    url = f"{BASE_URL}/v1/{name}"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token",
        "alt": "json",
        "callback": "your_callback",
        "fields": "your_fields",
        "key": "your_key",
        "oauth_token": "your_oauth_token",
        "prettyPrint": False,
        "quotaUser": "your_quota_user",
        "uploadType": "media",
        "upload_protocol": "raw"
    }
    response = requests.delete(url, params=params)
    assert response.status_code == 200
    assert response.json() == {}