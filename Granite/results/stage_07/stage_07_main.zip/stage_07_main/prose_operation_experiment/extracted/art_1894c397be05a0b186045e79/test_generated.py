import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.fixture
def namespace():
    return "mynamespace"

@pytest.fixture
def repository():
    return "myrepo"

@pytest.fixture
def digest():
    return "sha256:mydigest"

@pytest.mark.parametrize(
    "page, page_size", [(None, None), (1, 20), (4, 20), (2, 20)]
)
def test_get_namespace_repository_images_tags(
    session,
    namespace,
    repository,
    digest,
    page,
    page_size,
):
    url = f"{BASE_URL}/v2/namespaces/{namespace}/repositories/{repository}/images/{digest}/tags"
    params = {"page": page, "page_size": page_size}

    response = SESSION.get(url, params=params)
    assert response.status_code == 200

    expected_response = {
        "count": 100,
        "next": "https://hub.docker.com/v2/namespaces/mynamespace/repositories/myrepo/images/sha256:mydigest/tags?&page=4&page_size=20",
        "previous": "https://hub.docker.com/v2/namespaces/mynamespace/repositories/myrepo/images/sha256:mydigest/tags?&page=2&page_size=20",
        "results": [
            {
                "is_current": True,
                "tag": "latest",
            },
            # Add more test cases for 'results' as needed
        ],
    }

    assert response.json() == expected_response