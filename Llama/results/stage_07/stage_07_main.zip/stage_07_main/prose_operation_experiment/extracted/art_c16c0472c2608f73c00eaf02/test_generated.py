import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_update_comment_threads():
    comment_thread = {
        "snippet": {
            " topLevelComment": {
                "snippet": {
                    "textDisplay": "Test comment",
                    "textOriginal": "Test comment"
                },
                "authorChannelId": {"value": "test_channel_id"},
                "authorDisplayName": "Test User",
                "authorProfileImageUrl": "https://example.com/test_user.jpg",
                "canRate": True,
                "channelId": "test_channel_id",
                "likeCount": 10,
                "moderationStatus": "published",
                "parentId": None,
                "publishedAt": datetime.now().isoformat(),
                "textDisplay": "Test comment",
                "textOriginal": "Test comment",
                "updatedAt": datetime.now().isoformat(),
                "videoId": "test_video_id",
                "viewerRating": "none"
            }
        },
        "etag": "test_etag",
        "id": "test_id",
        "kind": "youtube#commentThread",
        "replies": {}
    }

    headers = {
        'Content-Type': 'application/json',
        '.xgafv': '1'
    }

    response = requests.put(f"{BASE_URL}/youtube/v3/commentThreads", json=comment_thread, params={"part": ["snippet"], "key": "test_key"}, headers=headers)

    assert response.status_code == 200