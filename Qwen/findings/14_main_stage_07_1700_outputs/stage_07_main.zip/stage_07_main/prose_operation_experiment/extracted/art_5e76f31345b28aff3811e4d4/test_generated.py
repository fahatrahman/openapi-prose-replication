import pytest
import requests

BASE_URL = "http://openapi.test"

def test_upsert_datapoints():
    url = f"{BASE_URL}/v1beta1/zynntaco/autfnhu/yzvrewumc/vmdixebo/aymysvb/mohgw:upsertDatapoints"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = {
        "datapoints": [
            {
                "datapointId": "dp1",
                "featureVector": [1.0, 2.0, 3.0],
                "numericRestricts": [],
                "restricts": []
            }
        ],
        "updateMask": "*"
    }
    response = requests.post(url, headers=headers, json=payload)
    assert response.status_code == 200
    assert "application/json" in response.headers["Content-Type"]