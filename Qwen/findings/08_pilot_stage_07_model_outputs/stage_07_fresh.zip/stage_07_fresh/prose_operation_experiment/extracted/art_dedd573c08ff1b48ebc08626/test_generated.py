import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_activity():
    headers = {
        "X-AIO-Key": "your_master_key",
        "X-AIO-Signature": "your_signature"
    }
    params = {
        "type": "example_type",
        "start_time": "2023-01-01T00:00:00Z",
        "end_time": "2023-12-31T23:59:59Z",
        "limit": 10
    }
    response = requests.get(f"{BASE_URL}/username/activities/type", headers=headers, params=params)
    
    assert response.status_code == 200
    assert isinstance(response.json(), list)

if __name__ == "__main__":
    pytest.main()