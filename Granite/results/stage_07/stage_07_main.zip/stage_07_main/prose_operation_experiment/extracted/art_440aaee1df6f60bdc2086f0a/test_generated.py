import pytest
import requests
from requests.exceptions import HTTPError

BASE_URL = "http://openapi.test"

def test_simulate_inbound_wire_drawdown_request():
    headers = {"Authorization": "Bearer YOUR_ACCESS_TOKEN"}
    payload = {
        "amount": 10000,
        "beneficiary_account_number": "987654321",
        "beneficiary_address_line1": "33 Liberty Street",
        "beneficiary_address_line2": "New York, NY, 10045",
        "beneficiary_name": "Ian Crease",
        "beneficiary_routing_number": "101050001",
        "currency": "USD",
        "message_to_recipient": "Invoice 29582",
        "originator_account_number": "987654321",
        "originator_address_line1": "33 Liberty Street",
        "originator_address_line2": "New York, NY, 10045",
        "originator_name": "Ian Crease",
        "originator_routing_number": "101050001",
        "originator_to_beneficiary_information_line1": "",
        "originator_to_beneficiary_information_line2": "",
        "originator_to_beneficiary_information_line3": "",
        "originator_to_beneficiary_information_line4": "",
        "recipient_account_number_id": "account_number_v18nkfqm6afpsrvy82b2",
    }

    url = f"{BASE_URL}/simulations/inbound_wire_drawdown_requests"

    try:
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()

        simulated_request = response.json()
        assert isinstance(simulated_request, dict)
        assert simulated_request["type"] == "inbound_wire_drawdown_request"
        assert simulated_request["id"] is not None
        # Add more assertions based on expected structure or values

    except HTTPError as http_err:
        print(f"HTTP error occurred: {http_err}")
        assert False, f"An error occurred: {http_err}"
    except Exception as err:
        print(f"Other error occurred: {err}")
        assert False, f"An unexpected error occurred: {err}"