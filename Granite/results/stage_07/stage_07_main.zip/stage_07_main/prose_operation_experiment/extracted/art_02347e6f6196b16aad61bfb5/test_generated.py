import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.fixture
def client():
    return SESSION

def test_list_subscribers(client):
    owner = "test_owner"
    repo = "test_repo"
    page = 1
    limit = 10

    url = f"{BASE_URL}/repos/{owner}/{repo}/subscribers"
    params = {
        "page": page,
        "limit": limit,
    }

    response = client.get(url, params=params)
    assert response.status_code == 200

    users = response.json()["items"]
    assert isinstance(users, list)
    for user in users:
        assert all(key in user for key in ["active", "avatar_url", "created", "description", "email", "followers_count", "following_count", "full_name", "id", "is_admin", "language", "last_login", "location", "login", "login_name", "prohibit_login", "restricted", "starred_repos_count", "visibility", "website"])