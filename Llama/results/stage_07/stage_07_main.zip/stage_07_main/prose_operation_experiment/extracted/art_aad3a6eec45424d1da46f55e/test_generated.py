import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_automation_action_revision():
    """Test GET /automation/v4/actions/{appId}/{definitionId}/revisions/{revisionId}"""
    
    # Define parameters
    app_id = 12345
    definition_id = "my-definition-id"
    revision_id = "my-revision-id"
    
    # Construct full path
    url = f"{BASE_URL}/automation/v4/actions/{app_id}/{definition_id}/revisions/{revision_id}"
    
    # Send request
    response = requests.get(url)
    
    # Check status code
    assert response.status_code == 200
    
    # Parse JSON response
    data = response.json()
    
    # Verify response schema
    assert data["id"]
    assert data["definition"]["actionUrl"]
    assert data["definition"]["labels"]["actionName"]
    assert data["definition"]["labels"]["actionDescription"]
    assert data["definition"]["labels"]["actionCardContent"]
    assert data["definition"]["labels"]["appDisplayName"]
    assert data["definition"]["labels"]["executionRules"]
    assert data["definition"]["labels"]["inputFieldDescriptions"]
    assert data["definition"]["labels"]["inputFieldLabels"]
    assert data["definition"]["labels"]["inputFieldOptionLabels"]
    assert data["definition"]["labels"]["outputFieldLabels"]

# Run tests
pytest.main([__file__])