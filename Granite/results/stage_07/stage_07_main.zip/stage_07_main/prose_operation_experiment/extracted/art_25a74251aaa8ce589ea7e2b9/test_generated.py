import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.fixture
def header():
    return {"X-API-Key": os.getenv("X-API-KEY")}

def get_terminal_action(company_id, action_id):
    url = f"{BASE_URL}/companies/{company_id}/terminalActions/{action_id}"

    try:
        response = SESSION.get(url, headers=header())
        response.raise_for_status()

        if response.status_code == 200:
            data = response.json()
            return data["actionType"], data["config"], data["confirmedAt"], \
                   data["id"], data["result"], data["scheduledAt"], \
                   data["status"], data["terminalId"]
        else:
            raise Exception(f"Unexpected status code: {response.status_code}")

    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")
        raise
    except ValueError as e:
        print(f"Invalid JSON response: {e}")
        raise

def test_get_terminal_action(header):
    company_id = "your_company_id"
    action_id = "your_action_id"

    try:
        action_type, config, confirmed_at, id, result, scheduled_at, status, terminal_id = \
            get_terminal_action(company_id, action_id)

        assert action_type is not None
        assert config is not None
        assert confirmed_at is not None
        assert id is not None
        assert result is not None
        assert scheduled_at is not None
        assert status is not None
        assert terminal_id is not None

    except Exception as e:
        print(f"Test failed: {e}")
        pytest.fail(str(e))