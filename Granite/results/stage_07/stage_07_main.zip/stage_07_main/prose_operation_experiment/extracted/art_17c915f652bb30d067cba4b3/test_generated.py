import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_PATH = "path/to/credentials.json"

# Authenticate using service account credentials
credentials = service_account.Credentials.from_service_account_file(
    CREDENTIALS_PATH)

@pytest.mark.parametrize("name", ["your_project_location_processor_version"])
def test_delete_processor_version(name):
    url = f"{BASE_URL}/v1/{name}"

    headers = {
        "_": "1"
    }

    response = requests.delete(url, headers=headers, auth=credentials)

    assert response.status_code == 200
    print("Test successful.")