import os
import pytest
import requests
from requests.exceptions import HTTPError

BASE_URL = "http://openapi.test"
USERNAME = "Nxvhwzfd"
PASSWORD = "Tpmakj-Lg"

@pytest.fixture
def api():
    session = requests.Session()
    session.auth = (USERNAME, PASSWORD)
    return session

def test_reset_api_key_from_group_quotas(api):
    group_id = "test_group"
    client_id = "test_client"

    url = f"{BASE_URL}/api/groups/{group_id}/apikeys/{client_id}/quotas"

    try:
        response = api.delete(url)
        response.raise_for_status()

        quotas = response.json()
        assert isinstance(quotas, dict)
        required_fields = [
            "authorizedCallsPerSec",
            "currentCallsPerSec",
            "remainingCallsPerSec",
            "authorizedCallsPerDay",
            "currentCallsPerDay",
            "remainingCallsPerDay",
            "authorizedCallsPerMonth",
            "currentCallsPerMonth",
            "remainingCallsPerMonth",
        ]
        for field in required_fields:
            assert field in quotas

        print("Test passed successfully.")
    except HTTPError as http_err:
        print(f"HTTP error occurred: {http_err}")
    except Exception as err:
        print(f"An error occurred: {err}")