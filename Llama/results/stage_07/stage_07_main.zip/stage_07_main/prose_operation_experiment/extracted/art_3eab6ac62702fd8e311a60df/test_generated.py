# -*- coding: utf-8 -*-

import pytest
import requests
from unittest.mock import Mock
from datetime import datetime

BASE_URL = "http://openapi.test"

def test_get_hash_files():
    # Create a mock API token
    api_token = "mock_api_token"

    # Construct the full path for the request
    owner_name = "example_owner"
    app_name = "example_app"
    url = f"{BASE_URL}/v0.1/apps/{owner_name}/{app_name}/test/export/hashFiles"

    # Add the API token to the headers
    headers = {"X-API-Token": api_token}

    # Send the GET request
    response = requests.get(url, headers=headers)

    # Check if the response was successful
    assert response.status_code == 200

    # Parse the JSON response
    data = response.json()

    # Check if the response contains the expected keys
    assert "filename" in data
    assert "id" in data

    # Check if the id is a valid UUID
    try:
        datetime.strptime(data["id"], "%43s-%04x-%04x-%04x-%04hx%04hx%04hx%04hx%04hx")
    except ValueError:
        pytest.fail("Invalid UUID")

def test_get_hash_files_unauthorized():
    # Create a mock API token (empty string)
    api_token = ""

    # Construct the full path for the request
    owner_name = "example_owner"
    app_name = "example_app"
    url = f"{BASE_URL}/v0.1/apps/{owner_name}/{app_name}/test/export/hashFiles"

    # Add the API token to the headers
    headers = {"X-API-Token": api_token}

    # Send the GET request
    response = requests.get(url, headers=headers)

    # Check if the response was unauthorized
    assert response.status_code == 401