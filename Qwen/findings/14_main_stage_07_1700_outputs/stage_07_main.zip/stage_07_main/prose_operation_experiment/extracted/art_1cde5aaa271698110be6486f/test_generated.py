import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_employer_revisions():
    employer_id = "example_employer_id"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    url = f"{BASE_URL}/Employer/{employer_id}/Revisions"
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 200
    assert response.json().get("Links") is not None

def test_get_employer_revisions_bad_request():
    employer_id = "invalid_employer_id"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    url = f"{BASE_URL}/Employer/{employer_id}/Revisions"
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 400
    error_model = response.json()
    assert error_model.get("ErrorCategory") in ["General", "NotFound", "NotAuthorised", "ValidationFailure"]

def test_get_employer_revisions_unauthorized():
    employer_id = "example_employer_id"
    headers = {
        "Authorization": "InvalidToken",
        "Api-Version": "default"
    }
    url = f"{BASE_URL}/Employer/{employer_id}/Revisions"
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 401
    error_model = response.json()
    assert error_model.get("ErrorCategory") == "NotAuthorised"

def test_get_employer_revisions_not_found():
    employer_id = "non_existent_employer_id"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    url = f"{BASE_URL}/Employer/{employer_id}/Revisions"
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 404
    error_model = response.json()
    assert error_model.get("ErrorCategory") == "NotFound"

def test_get_employer_revisions_internal_server_error():
    employer_id = "example_employer_id"
    headers = {
        "Authorization": "Auto",
        "Api-Version": "default"
    }
    url = f"{BASE_URL}/Employer/{employer_id}/Revisions"
    
    response = requests.get(url, headers=headers)
    
    assert response.status_code == 500
    error_model = response.json()
    assert error_model.get("ErrorCategory") == "General"