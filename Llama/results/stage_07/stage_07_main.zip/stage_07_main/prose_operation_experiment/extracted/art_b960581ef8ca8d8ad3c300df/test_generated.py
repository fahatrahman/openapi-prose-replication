import pytest
import requests
from datetime import datetime

BASE_URL = "http://openapi.test"

def get_timestamp():
    return datetime.now().strftime("%Y%m%dT%H%M%SZ")

def sign_request(method, path, headers, body):
    timestamp = get_timestamp()
    credential = f"AWS4-HMAC-SHA256 Credential={headers['X-Amz-Credential']},SignedHeaders={headers['X-Amz-SignedHeaders']}&Signature={headers['X-Amz-Signature']}"

    signature = requests.auth.HTTPSignRequest(
        method=method,
        url=f"{BASE_URL}{path}",
        headers=headers,
        body=body.encode("utf-8"),
        digest=requests.utils.get_signature_digest_from_request(
            method=method,
            url=f"{BASE_URL}{path}",
            headers=headers,
            body=body.encode("utf-8"),
        ),
    ).sign()

    return {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Date": timestamp,
        "X-Amz-Credential": credential,
        "X-Amz-Security-Token": headers["X-Amz-Security-Token"],
        "X-Amz-SignedHeaders": headers["X-Amz-SignedHeaders"],
        "X-Amz-Signature": signature.hex(),
    }

def update_recipe(name, description, steps):
    url = f"/recipes/{name}"
    headers = {
        "X-Amz-Algorithm": "",
        "X-Amz-Content-Sha256": "",
        "X-Amz-Credential": "",
        "X-Amz-Date": get_timestamp(),
        "X-Amz-Security-Token": "",
        "X-Amz-SignedHeaders": "host;x-amz-date;x-amz-security-token",
    }
    payload = {
        "Description": description,
        "Steps": [{"Action": {"Operation": "", "Parameters": {}}} for _ in range(len(steps))],
    }
    signed_headers = sign_request("PUT", url, headers, json=payload)

    response = requests.put(
        f"{BASE_URL}{url}",
        headers={**headers, **signed_headers},
        json=payload,
    )

    assert response.status_code == 200
    assert response.json()["Name"] == name

@pytest.mark.parametrize(
    "name,description,steps",
    [
        ("test_recipe", "This is a test recipe.", [{}]),
        ("another_test_recipe", "Another test recipe.", []),
    ],
)
def test_update_recipe(name, description, steps):
    update_recipe(name, description, steps)