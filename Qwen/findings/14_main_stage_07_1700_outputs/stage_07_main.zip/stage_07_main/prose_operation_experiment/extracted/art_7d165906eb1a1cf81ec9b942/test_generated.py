import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_maintenance_job():
    endpoint = f"{BASE_URL}/v3/maintenance/test/branch1/createmaintenancejob"
    headers = {
        "Content-Type": "application/json"
    }
    payload = {
        "Documents": [
            {
                "MimeType": "application/pdf",
                "URL": "http://example.com/document.pdf"
            }
        ],
        "ExternalID": "ABC123",
        "IssueFault": "Leaky faucet",
        "IssueNotes": "Fix the dripping faucet in the kitchen sink.",
        "IssuePriority": "Medium",
        "IssueTitle": "Kitchen Sink Leak",
        "PropertyAddress1": "123 Main St",
        "PropertyAddress2": "",
        "PropertyAddress3": "",
        "PropertyAddress4": "",
        "PropertyCountry": "USA",
        "PropertyPostcode": "12345",
        "ReportedAt": "2023-10-01T12:00:00Z",
        "TenantEMailAddress": "tenant@example.com",
        "TenantForename": "John",
        "TenantPhonePrimary": "123-456-7890",
        "TenantPhoneSecondary": "",
        "TenantPresenceRequested": False,
        "TenantSurname": "Doe",
        "TenantTitle": ""
    }

    response = requests.post(endpoint, headers=headers, json=payload)

    assert response.status_code == 200
    assert isinstance(response.json(), dict)