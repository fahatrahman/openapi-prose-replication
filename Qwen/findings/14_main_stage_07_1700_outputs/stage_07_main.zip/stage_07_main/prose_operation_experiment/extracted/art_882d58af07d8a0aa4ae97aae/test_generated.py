import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_forwarding_addresses():
    url = f"{BASE_URL}/gmail/v1/users/me/settings/forwardingAddresses"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token_here",
        "alt": "json",
        "prettyPrint": False,
        "quotaUser": "your_quota_user_here",
        "uploadType": "multipart",
        "upload_protocol": "raw"
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    data = response.json()
    assert "forwardingAddresses" in data
    for forwarding_address in data["forwardingAddresses"]:
        assert "forwardingEmail" in forwarding_address
        assert "verificationStatus" in forwarding_address
        assert forwarding_address["verificationStatus"] in ["verificationStatusUnspecified", "accepted", "pending"]