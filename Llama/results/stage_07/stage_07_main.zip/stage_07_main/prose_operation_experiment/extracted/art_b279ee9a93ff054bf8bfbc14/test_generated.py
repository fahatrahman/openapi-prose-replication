# -*- coding: utf-8 -*-
import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_cancel_execution():
    execution_name = "projects/my-project/locations/us-central1/jobs/my-job/executions/my-execution"
    headers = {
        'Content-Type': 'application/json'
    }
    data = {
        "etag": "",
        "validateOnly": False
    }

    response = requests.post(
        urljoin(BASE_URL, f'/v2/{execution_name}:cancel'),
        json=data,
        headers=headers
    )
    assert response.status_code == 200
    assert isinstance(response.json(), dict)