import pytest
import requests
BASE_URL = "http://openapi.test"

@pytest.fixture
def floodlight_configuration():
    return {
        "accountId": 123456789,
        "advertiserId": 123456789,
        "advertiserIdDimensionValue": {"dimensionName": "ADVERTISER_ID", "id": "123456", "kind": "dfareporting#dimensionValue", "matchType": "EXACT", "value": "123456"},
        "analyticsDataSharingEnabled": True,
        "customViewabilityMetric": {
            "configuration": {
                "audible": True,
                "timeMillis": 5000,
                "timePercent": 20,
                "viewabilityPercent": 80
            },
            "id": 123456,
            "name": "CUSTOM_VIEWABILITY_METRIC"
        },
        "exposureToConversionEnabled": True,
        "firstDayOfWeek": "MONDAY",
        "id": 123456,
        "idDimensionValue": {"dimensionName": "FLIGHTLIGHT_CONFIGURATION_ID", "id": "123456", "kind": "dfareporting#dimensionValue", "matchType": "EXACT", "value": "123456"},
        "inAppAttributionTrackingEnabled": True,
        "kind": "dfareporting#floodlightConfiguration",
        "lookbackConfiguration": {
            "clickDuration": 1000,
            "postImpressionActivitiesDuration": 2000
        },
        "naturalSearchConversionAttributionOption": "INCLUDE_NATURAL_SEARCH_CONVERSION_ATTRIBUTION",
        "omnitureSettings": {
            "omnitureCostDataEnabled": False,
            "omnitureIntegrationEnabled": True
        },
        "subaccountId": 123456789,
        "tagSettings": {"dynamicTagEnabled": True, "imageTagEnabled": True},
        "thirdPartyAuthenticationTokens": [],
        "userDefinedVariableConfigurations": []
    }

def test_patch_floodlight_configuration(floodlight_configuration):
    url = f"{BASE_URL}/userprofiles/{floodlight_configuration['id']}"
    response = requests.patch(url, json=floodlight_configuration)
    assert response.status_code == 200
    updated_config = response.json()
    # Add more assertions based on expected updates if needed