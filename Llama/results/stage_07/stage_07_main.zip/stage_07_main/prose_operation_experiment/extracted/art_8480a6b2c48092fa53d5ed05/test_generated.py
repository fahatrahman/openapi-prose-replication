# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_get_member_synopsis():
    """Test getting member synopsis"""
    
    # Construct full path for the API request
    path = "/api/Members/{}/Synopsis"
    
    # Test happy path (200 OK)
    id = 12345
    response = requests.get(urljoin(BASE_URL, path.format(id)))
    assert response.status_code == 200
    
    # Check if response content type is application/json or text/json
    if 'application/json' in response.headers['Content-Type'] or 'text/json' in response.headers['Content-Type']:
        # Parse JSON response
        try:
            data = response.json()
        except ValueError:
            pytest.fail("Failed to parse JSON response")
        
        # Validate response schema
        assert isinstance(data, dict)
        assert 'value' in data
        assert isinstance(data['value'], str)
        
        # Validate links property
        links = data.get('links')
        if links is not None:
            assert all(isinstance(link, dict) for link in links)
            assert all('href' in link and 'method' in link and 'rel' in link for link in links)
            
    else:
        pytest.fail(f"Unexpected Content-Type: {response.headers['Content-Type']}")

    # Test bad request (400 Bad Request)
    id = 99999
    response = requests.get(urljoin(BASE_URL, path.format(id)))
    assert response.status_code == 400

    # Test not found (404 Not Found)
    id = 88888
    response = requests.get(urljoin(BASE_URL, path.format(id)))
    assert response.status_code == 404