import os
import pytest
import requests
from requests_toolbelt import MultipartEncoder

BASE_URL = "http://openapi.test"
HEADERS = {
    "Content-Type": "application/json",
}

def test_put_function_event_invoke_config():
    function_name = "example-function"
    qualifier = "$LATEST"
    destination_config = {
        "OnSuccess": {
            "Destination": "arn:aws:lambda:us-east-1:123456789012:function:example-function:1",
        }
    }
    max_event_age_seconds = 120
    max_retry_attempts = 2

    url = f"{BASE_URL}/2019-09-25/functions/{function_name}/{qualifier}/event-invoke-config"

    payload = {"DestinationConfig": destination_config, "MaximumEventAgeInSeconds": max_event_age_seconds, "MaximumRetryAttempts": max_retry_attempts}

    response = requests.put(url, headers=HEADERS, json=payload)

    assert response.status_code == 200, f"Request failed with status code {response.status_code}"

    result = response.json()
    assert result["FunctionArn"] == f"arn:aws:lambda:us-east-1:123456789012:function:example-function:1"
    assert result["DestinationConfig"]["OnSuccess"]["Destination"] == "arn:aws:lambda:us-east-1:123456789012:function:example-function:1"
    assert result["MaximumEventAgeInSeconds"] == max_event_age_seconds
    assert result["MaximumRetryAttempts"] == max_retry_attempts