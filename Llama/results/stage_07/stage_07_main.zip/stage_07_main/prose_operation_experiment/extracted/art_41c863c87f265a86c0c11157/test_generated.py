# -*- coding: utf-8 -*-

import pytest
import requests
from requests.auth import HTTPBasicAuth
import json

BASE_URL = "http://openapi.test"

def test_get_assets():
    auth = HTTPBasicAuth('username', 'password') # replace with your actual username and password
    params = {}
    if 'ordering' in pytest.config.getoption('--params'):
        params['ordering'] = pytest.config.getoption('--params').split(',')
    if 'page' in pytest.config.getoption('--params'):
        params['page'] = int(pytest.config.getoption('--params').split(',')[1])
    if 'pageLength' in pytest.config.getoption('--params'):
        params['length'] = int(pytest.config.getoption('--params').split(',')[2])
    if 'search' in pytest.config.getoption('--params'):
        params['search'] = pytest.config.getoption('--params').split(',')[3]

    response = requests.get(f'{BASE_URL}/targets/{pytest.config.getoption("--target_id")}/assets/', 
                            auth=auth,
                            params=params)

    assert response.status_code == 200
    try:
        data = response.json()
        assert data['count']
        assert data['length']
        assert data['page']
        assert data['page_total']
        assert data['results']
    except json.JSONDecodeError:
        print(response.text)
        assert False