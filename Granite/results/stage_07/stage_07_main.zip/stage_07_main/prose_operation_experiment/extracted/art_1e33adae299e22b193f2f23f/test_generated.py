import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

# Create a session with a custom adapter for retrying requests
session = requests.Session()
adapter = HTTPAdapter(max_retries=3)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def client():
    return session

def test_get_video_captions(client):
    video_id = "your_video_id_here"  # Replace with actual video ID
    endpoint = f"/api/v1/videos/{video_id}/captions"

    response = client.get(urljoin(BASE_URL, endpoint), headers={"Content-Type": "application/json"})
    assert response.status_code == 200

    expected_data_structure = {
        "data": [],
        "total": 0,
    }

    response_data = response.json()
    assert response_data["data"] == expected_data_structure["data"]
    assert response_data["total"] == expected_data_structure["total"]