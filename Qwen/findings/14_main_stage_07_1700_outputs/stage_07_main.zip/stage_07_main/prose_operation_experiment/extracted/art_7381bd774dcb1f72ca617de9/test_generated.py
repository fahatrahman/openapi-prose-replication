import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_bep20_balance():
    url = f"{BASE_URL}/v2/bsc/balances/0x1dDB2C0897daF18632662E71fdD2dbDC0eB3a9Ec/bep20/0x9dB475371B5cC2913D3219f72e16a3F101339a05"
    response = requests.get(url)
    
    assert response.status_code == 200
    assert response.headers['Cache-Control'] == 'max-age=0, must-revalidate, private'
    assert response.headers['Connection'] == 'keep-alive'
    assert response.headers['Date']
    assert response.headers['Expires']
    assert response.headers['Server'] == 'nginx/1.18.0 (Ubuntu)'
    assert response.headers['Set-Cookie']
    assert response.headers['Transfer-Encoding'] == 'chunked'
    assert response.headers['X-Debug-Token']
    assert response.headers['X-Debug-Token-Link']
    assert response.headers['X-Robots-Tag'] == 'noindex'
    
    data = response.json()
    assert isinstance(data, dict)
    assert 'data' in data
    assert 'balance' in data['data']
    assert data['data']['balance'] == '0'
    assert 'message' in data
    assert data['message'] == 'Token Balance has been successfully parsed.'
    assert 'ok' in data
    assert data['ok'] is True
    assert 'status' in data
    assert data['status'] == 200

if __name__ == "__main__":
    pytest.main()