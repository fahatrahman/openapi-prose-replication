# -*- coding: utf-8 -*-
"""Test suite for Normalized Judge Search API."""

import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_search_normalized_judges_by_id():
    """Test searching normalized judges by ID."""
    # Given
    norm_judge_search_id = "JSRCNUSK3pLGe48QcU"
    page_number = 1

    # When
    response = requests.get(
        urljoin(BASE_URL, f"/normJudgeSearch/{norm_judge_search_id}"),
        params={"pageNumber": page_number},
    )

    # Then
    assert response.status_code == 200, response.text
    response.raise_for_status()
    result = response.json()

    assert isinstance(result, dict)
    assert result["object"] == "NormJudgeSearchResponse"
    assert result["pageNumber"] == page_number
    assert result["totalCount"] >= 0
    assert result["totalPages"] > 0
    assert result["nextPageAPI"] is None or (
        isinstance(result["nextPageAPI"], str) and result["nextPageAPI"].startswith(BASE_URL)
    )
    assert result["previousPageAPI"] is None or (
        isinstance(result["previousPageAPI"], str) and result["previousPageAPI"].startswith(BASE_URL)
    )
    assert isinstance(result["normJudgeSearchResultArray"], list)
    for item in result["normJudgeSearchResultArray"]:
        assert isinstance(item, dict)
        assert item["object"] == "NormJudgeSearchResult"
        assert item["normJudgeId"]
        assert item["name"]
        assert item["firstFetchDate"]
        assert item["lastFetchDate"]
        assert isinstance(item["matchedObjectArray"], list)
        for matched_object in item["matchedObjectArray"]:
            assert isinstance(matched_object, dict)
            assert matched_object["object"] == "MatchedObject"
            assert matched_object["matchedObjectId"]
            assert matched_object["matchedObjectName"]
            assert matched_object["matchedObjectAttribute"]
            assert matched_object["highlightSnippet"]

def test_search_normalized_judges_by_id_invalid_page_number():
    """Test searching normalized judges by ID with invalid page number."""
    # Given
    norm_judge_search_id = "JSRCNUSK3pLGe48QcU"
    page_number = -1

    # When
    response = requests.get(
        urljoin(BASE_URL, f"/normJudgeSearch/{norm_judge_search_id}"),
        params={"pageNumber": page_number},
    )

    # Then
    assert response.status_code == 400, response.text
    result = response.json()
    assert result["object"] == "Exception"
    assert result["code"] == "UN400"
    assert result["details"] == "pageNumber value passed -1 is not valid."
    assert result["message"] == "INVALID_INPUT"

def test_search_normalized_judges_by_id_not_found_resource():
    """Test searching normalized judges by ID with not found resource."""
    # Given
    norm_judge_search_id = "JSRQaKMouYPFRkZMAt"

    # When
    response = requests.get(urljoin(BASE_URL, f"/normJudgeSearch/{norm_judge_search_id}"))

    # Then
    assert response.status_code == 404, response.text
    result = response.json()
    assert result["object"] == "Exception"
    assert result["code"] == "UN404"
    assert result["details"] == "normJudgeSearchId resource you were looking for doesn't exist."
    assert result["message"] == "RESOURCE_NOT_FOUND"