import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_ekm_connections():
    url = f"{BASE_URL}/v1/projects/my-project/locations/us-central1/ekmConnections"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token",
        "alt": "json",
        "key": "your_api_key",
        "prettyPrint": False,
        "quotaUser": "user",
        "upload_protocol": "raw",
        "uploadType": "media",
        "filter": "",
        "orderBy": "",
        "pageSize": 10,
        "pageToken": ""
    }
    headers = {
        "Authorization": "Bearer your_oauth_token"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert "ekmConnections" in data
    assert isinstance(data["ekmConnections"], list)

if __name__ == "__main__":
    pytest.main()