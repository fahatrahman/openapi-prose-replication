import os
import requests
import pytest
BASE_URL = "http://openapi.test"

@pytest.fixture
def test_client():
    def _test_client():
        endpoint = f"{BASE_URL}/self/calls"
        headers = {"Content-Type": "application/json"}
        payload = {
            "phoneNumber": "1234567890"
        }

        response = requests.post(endpoint, json=payload, headers=headers)
        assert response.status_code == 201
        return response.json()

    return _test_client

def test_create_call(test_client):
    calls = test_client()
    assert isinstance(calls, list)
    for call in calls:
        assert set(["id", "type", "accountId", "userId", "uciId", "direction", "duration", "state", "phoneNumber", "startTime"]).issubset(set(call.keys()))