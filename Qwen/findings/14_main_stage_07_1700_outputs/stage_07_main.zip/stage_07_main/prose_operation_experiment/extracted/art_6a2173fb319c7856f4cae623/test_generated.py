import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_fleet():
    url = f"{BASE_URL}/v1/Fleets"
    params = {
        "NetworkAccessProfile": "example_network_access_profile",
        "PageSize": 50,
        "Page": 1,
        "PageToken": None
    }
    response = requests.get(url, params=params, auth=("your_account_sid", "your_auth_token"))
    assert response.status_code == 200
    data = response.json()
    assert "fleets" in data
    assert isinstance(data["fleets"], list)
    assert "meta" in data
    meta = data["meta"]
    assert "first_page_url" in meta
    assert "key" in meta
    assert "next_page_url" in meta
    assert "page" in meta
    assert "page_size" in meta
    assert "previous_page_url" in meta
    assert "url" in meta