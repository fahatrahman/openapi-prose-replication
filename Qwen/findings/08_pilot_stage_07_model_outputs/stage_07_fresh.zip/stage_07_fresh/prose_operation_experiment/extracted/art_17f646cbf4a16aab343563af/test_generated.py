import pytest
import requests

BASE_URL = "http://openapi.test"

def test_delete_dedicated_ip_pool():
    headers = {
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Content-Sha256": "UNSIGNED-PAYLOAD",
        "X-Amz-Credential": "access-key-id/20230401/us-east-1/service/aws4_request",
        "X-Amz-Date": "20230401T000000Z",
        "X-Amz-Security-Token": "session-token",
        "X-Amz-Signature": "signature-value",
        "X-Amz-SignedHeaders": "host"
    }
    url = f"{BASE_URL}/v1/email/dedicated-ip-pools/testpool"
    response = requests.delete(url, headers=headers)
    
    assert response.status_code == 200
    assert response.json() == {}