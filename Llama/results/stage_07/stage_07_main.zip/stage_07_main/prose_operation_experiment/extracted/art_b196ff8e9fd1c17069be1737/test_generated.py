# -*- coding: utf-8 -*-
"""Test suite for operation /v1/{parent}/occurrences:vulnerabilitySummary"""
import pytest
import requests

BASE_URL = "http://openapi.test"

def test_containeranalysis_projects_occurrences_get_vulnerability_summary():
    """Tests GET /v1/{parent}/occurrences:vulnerabilitySummary"""
    url = f"{BASE_URL}/v1/{'parent'}"
    params = {}
    
    # Add parameters if they exist in the operation
    _.xgafv = "1"
    access_token = None
    alt = None
    callback = None
    fields = None
    key = None
    oauth_token = None
    prettyPrint = False
    quotaUser = None
    upload_protocol = None
    uploadType = None
    
    # Add query parameters if they exist in the operation
    filter = "filter"
    
    params["$.xgafv"] = _._xgafv
    params["access_token"] = access_token
    params["alt"] = alt
    params["callback"] = callback
    params["fields"] = fields
    params["key"] = key
    params["oauth_token"] = oauth_token
    params["prettyPrint"] = prettyPrint
    params["quotaUser"] = quotaUser
    params["upload_protocol"] = upload_protocol
    params["uploadType"] = uploadType
    params["filter"] = filter
    
    response = requests.get(url, params=params)
    
    assert response.status_code == 200
    
    # Validate JSON content
    assert response.json() is not None