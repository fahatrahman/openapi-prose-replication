import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

@pytest.fixture
def client():
    session = requests.Session()
    retry_strategy = Retry(
        total=3,
        backoff_factor=1,
        status_forcelist=[429, 500, 502, 503, 504],
    )
    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount("https://", adapter)
    session.mount("http://", adapter)

    return session

def test_aftermarket_services_put_iqacodes(client):
    serial_number = "example_serial_number"
    edt_instance_id = "example_edt_instance_id"
    iqacodes = ["code1", "code2"]

    response = client.put(
        f"{BASE_URL}/api/v2/AftermarketServices/Engines/{serial_number}/IQACodes",
        params={"EDTInstanceId": edt_instance_id},
        json=iqacodes,
    )

    assert response.status_code == 200