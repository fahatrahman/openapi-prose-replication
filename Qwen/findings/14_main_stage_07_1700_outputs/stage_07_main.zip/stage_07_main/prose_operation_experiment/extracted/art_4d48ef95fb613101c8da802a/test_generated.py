import pytest
import requests

BASE_URL = "http://openapi.test"

def test_update_user():
    # Replace with actual values
    user_id = "your_user_id"
    update_mask = "assignedUserRoles.displayName"
    new_display_name = "New Display Name"
    
    url = f"{BASE_URL}/v3/users/{user_id}"
    headers = {
        "Authorization": "Bearer your_access_token",
        "Content-Type": "application/json"
    }
    payload = {
        "updateMask": update_mask,
        "user": {
            "assignedUserRoles": [
                {
                    "displayName": new_display_name
                }
            ]
        }
    }
    
    response = requests.patch(url, headers=headers, json=payload)
    
    assert response.status_code == 200
    assert response.json()["name"] == f"users/{user_id}"
    assert response.json()["assignedUserRoles"][0]["displayName"] == new_display_name

if __name__ == "__main__":
    pytest.main()