import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = "path/to/your/service_account.json"

credentials = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE, scopes=["https://www.googleapis.com/auth/cloud-platform"]
)

requests.get.side_effect = lambda url, **kwargs: requests.Response()
requests.patch.side_effect = lambda url, **kwargs: requests.Response()

def test_accessapproval_projects_updateAccessApprovalSettings():
    name = "zynntaco/example_autfnhu/hbvbwoWhglwuvqIkmjspbm"
    update_mask = "enrolledServices"

    # Create the request body
    access_approval_settings = {
        "activeKeyVersion": "some_value",
        "ancestorHasActiveKeyVersion": True,
        "enrolledAncestor": True,
        "enrolledServices": [
            {
                "cloudProduct": "some_cloud_product",
                "enrollmentLevel": "ENROLLMENT_LEVEL_UNSPECIFIED"
            }
        ],
        "invalidKeyVersion": False,
        "name": name,
        "notificationEmails": ["example@example.com"],
        "notificationPubsubTopic": "topic",
        "preferNoBroadApprovalRequests": True,
        "preferredRequestExpirationDays": 10,
    }

    url = f"{BASE_URL}/v1/{name}"
    headers = {"Content-Type": "application/json"}

    response = requests.patch(url, json=access_approval_settings, headers=headers, auth=credentials)

    assert response.status_code == 200
    assert response.json() == access_approval_settings