# -*- coding: utf-8 -*-

import pytest
import requests
from jsonschema import validate

BASE_URL = "http://openapi.test"

def test_GetEmployeeSecrets():
    employer_id = "GD001"
    employee_id = "CT001"
    auth_header = {"Authorization": "Bearer Auto", "Api-Version": "default"}

    response = requests.get(
        f"{BASE_URL}/Employer/{employer_id}/Employee/{employee_id}/Secrets",
        headers=auth_header,
    )

    assert response.status_code == 200

    try:
        schema = {
            "$ref": "#/components/schemas/LinkCollection",
            "components": {
                "schemas": {
                    "LinkCollection": {
                        "type": "object",
                        "properties": {
                            "LinkCollection": {
                                "type": "object",
                                "properties": {
                                    "Links": {
                                        "type": "array",
                                        "items": {
                                            "type": "object",
                                            "properties": {
                                                "@href": {"type": "string"},
                                                "@rel": {"type": "string"},
                                                "@title": {"type": "string"},
                                            },
                                            "required": ["@href", "@rel", "@title"],
                                        },
                                    }
                                },
                                "required": ["Links"],
                            }
                        },
                        "required": ["LinkCollection"],
                    }
                }
            },
            "$schema": "https://json-schema.org/draft-07/schema#",
        }

        validate(instance=response.json(), schema=schema)
    except Exception as e:
        pytest.fail(f"Failed to validate JSON schema: {e}")