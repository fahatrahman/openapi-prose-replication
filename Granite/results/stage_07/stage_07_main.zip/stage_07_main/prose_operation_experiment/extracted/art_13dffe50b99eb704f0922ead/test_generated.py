import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Setup session with retry strategy
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retries)
session.mount("https://", adapter)
session.mount("http://", adapter)

# Replace placeholders with actual values
MERCHANT_ACCOUNT = os.getenv("MERCHANT_ACCOUNT")
SHOPPER_REFERENCE = os.getenv("SHOPPER_REFERENCE")

def test_get_stored_payment_methods():
    url = f"{BASE_URL}/storedPaymentMethods"
    params = {
        "shopperReference": SHOPPER_REFERENCE,
        "merchantAccount": MERCHANT_ACCOUNT,
    }

    response = session.get(url, headers={"Content-Type": "application/json"}, params=params)

    assert response.status_code == 200

    # Assuming we want to print out the response content for verification
    print(response.json())

if __name__ == "__main__":
    pytest.main([__file__])