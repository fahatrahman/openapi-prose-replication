# -*- coding: utf-8 -*-
import pytest
import requests
from jsonschema import ValidationError

BASE_URL = "http://openapi.test"

@pytest.fixture
def api_key():
    # Replace this with your actual API key
    return "your_api_key_here"

def test_defend_dispute(api_key):
    url = f"{BASE_URL}/defendDispute"
    headers = {"Authorization": f"Basic {api_key}", "X-API-Key": api_key}
    data = {
        "defenseReasonCode": "SupplyDefenseMaterial",
        "disputePspReference": "DZ4DPSHB4WD2WN82",
        "merchantAccountCode": "YOUR_MERCHANT_ACCOUNT"
    }
    
    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()
        assert response.json()["disputeServiceResult"]["success"] is True
    except requests.exceptions.HTTPError as errh:
        print(f"HTTP Error occurred: {errh}")
        raise
    except requests.exceptions.ConnectionError as errc:
        print(f"Error connecting: {errc}")
        raise
    except requests.exceptions.Timeout as errt:
        print(f"Timeout Error occurred: {errt}")
        raise
    except requests.exceptions.RequestException as err:
        print(f"Something went wrong: {err}")
        raise
    except KeyError as ke:
        print(f"Key error occurred: {ke}")
        raise
    except ValidationError as ve:
        print(f"Validation error occurred: {ve}")
        raise