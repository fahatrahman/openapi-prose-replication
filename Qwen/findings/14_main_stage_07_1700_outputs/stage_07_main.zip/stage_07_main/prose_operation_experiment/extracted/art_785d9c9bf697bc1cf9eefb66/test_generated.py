import pytest
import requests

BASE_URL = "http://openapi.test"

def test_retrieve_store_information():
    authtoken = "your_authtoken_here"
    login = "your_login_here"
    url = f"{BASE_URL}/store/info.json?authtoken={authtoken}&login={login}"
    
    response = requests.get(url)
    
    assert response.status_code == 200
    store_info = response.json()
    assert isinstance(store_info, dict)
    assert 'code' in store_info
    assert 'name' in store_info
    assert 'url' in store_info
    assert 'email' in store_info
    assert 'address' in store_info
    assert 'country' in store_info
    assert 'currency' in store_info
    assert 'timezone' in store_info
    assert 'logo' in store_info
    assert 'hooks_token' in store_info
    assert 'weight_unit' in store_info
    
    address = store_info['address']
    assert isinstance(address, dict)
    assert 'address' in address
    assert 'city' in address
    assert 'country' in address
    assert 'country_code' in address
    assert 'postal' in address
    assert 'region' in address
    assert 'region_code' in address