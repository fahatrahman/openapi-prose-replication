# -*- coding: utf-8 -*-

import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

def test_post_new_dps_job():
    """Test POST /Jobs/Dps"""
    
    # Create DpsJobInstruction object
    data = {
        "Apply": True,
        "Employer": {"@href": "/Employers/123", "@rel": "Employer", "@title": "My Employer"},
        "FromDate": "2022-01-01",
        "HoldingDate": "2022-01-02T12:00:00Z",
        "MessageTypes": [{"Type": {}}],
        "MessagesToProcess": [{"Message": {"@href": "/Messages/123", "@rel": "Message", "@title": "My Message"}}],
        "Retrieve": False
    }
    
    # Send request
    response = requests.post(
        f"{BASE_URL}/Jobs/Dps",
        headers={"Authorization": "Auto", "Api-Version": "default"},
        json=data,
        auth=HTTPBasicAuth("username", "password")
    )
    
    # Check status code
    assert response.status_code == 201
    
    # Check JSON response
    link = response.json()
    assert link["@href"]
    assert link["@rel"] == "Link"
    assert link["@title"]

def test_post_new_dps_job_400():
    """Test POST /Jobs/Dps with bad request"""
    
    # Create invalid DpsJobInstruction object
    data = {}
    
    # Send request
    response = requests.post(
        f"{BASE_URL}/Jobs/Dps",
        headers={"Authorization": "Auto", "Api-Version": "default"},
        json=data,
        auth=HTTPBasicAuth("username", "password")
    )
    
    # Check status code
    assert response.status_code == 400
    
    # Check JSON response
    error_model = response.json()
    assert error_model["ErrorModel"]["Description"]
    assert error_model["ErrorModel"]["ErrorCategory"] in ["General", "NotFound", "NotAuthorised", "ValidationFailure"]
    assert error_model["ErrorModel"]["Errors"]

def test_post_new_dps_job_401():
    """Test POST /Jobs/Dps with unauthorized"""
    
    # Send request without authentication
    response = requests.post(
        f"{BASE_URL}/Jobs/Dps",
        headers={"Authorization": "", "Api-Version": "default"},
        json={},
        auth=None
    )
    
    # Check status code
    assert response.status_code == 401
    
    # Check JSON response
    error_model = response.json()
    assert error_model["ErrorModel"]["Description"]
    assert error_model["ErrorModel"]["ErrorCategory"] in ["General", "NotFound", "NotAuthorised", "ValidationFailure"]
    assert error_model["ErrorModel"]["Errors"]

def test_post_new_dps_job_404():
    """Test POST /Jobs/Dps with not found"""
    
    # Send request to non-existent endpoint
    response = requests.post(f"{BASE_URL}/NonExistentEndpoint", headers={"Authorization": "Auto", "Api-Version": "default"}, json={}, auth=HTTPBasicAuth("username", "password"))
    
    # Check status code
    assert response.status_code == 404
    
    # Check JSON response
    error_model = response.json()
    assert error_model["ErrorModel"]["Description"]
    assert error_model["ErrorModel"]["ErrorCategory"] in ["General", "NotFound", "NotAuthorised", "ValidationFailure"]
    assert error_model["ErrorModel"]["Errors"]

def test_post_new_dps_job_500():
    """Test POST /Jobs/Dps with internal server error"""
    
    # Simulate internal server error by sending request to wrong port
    response = requests.post(f"{BASE_URL}:80/Jobs/Dps", headers={"Authorization": "Auto", "Api-Version": "default"}, json={}, auth=HTTPBasicAuth("username", "password"))
    
    # Check status code
    assert response.status_code == 500
    
    # Check JSON response
    error_model = response.json()
    assert error_model["ErrorModel"]["Description"]
    assert error_model["ErrorModel"]["ErrorCategory"] in ["General", "NotFound", "NotAuthorised", "ValidationFailure"]
    assert error_model["ErrorModel"]["Errors"]