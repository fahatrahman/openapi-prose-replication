import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
SESSION.mount("http://", HTTPAdapter())

@pytest.fixture
def api_key():
    return "K-GNA-BRX"  # Replace with actual API key

@pytest.fixture
def fossil_data():
    return {
        "fossil": "Spinosaurus",
        "colors": ["Brown"],
        "fossil_group": "Spinosaurus",
        "hha_base": 87,
        "image_url": "https://dodo.ac/np/images/7/7b/Spino_Skull_NH_Icon.png",
        "interactable": False,
        "length": 2,
        "name": "Spino Skull",
        "sell": 4000,
        "url": "https://nookipedia.com/wiki/Spinosaurus",
        "width": 2
    }

def test_get_individual_fossil(api_key, fossil_data):
    url = urljoin(BASE_URL, "/nh/fossils/individuals/{fossil}".format(**fossil_data))

    headers = {
        "X-API-KEY": api_key,
        "Accept-Version": "1.0.0"
    }

    response = SESSION.get(url, headers=headers)

    assert response.status_code == 200
    expected_data = fossil_data
    assert response.json() == expected_data

def test_get_individual_fossil_401():
    url = urljoin(BASE_URL, "/nh/fossils/individuals/invalid")

    headers = {
        "X-API-KEY": "INVALID-API-KEY",
        "Accept-Version": "1.0.0"
    }

    response = SESSION.get(url, headers=headers)

    assert response.status_code == 401
    expected_error = {"details": "Details unknown.", "title": "Failed to authenticate."}
    assert response.json() == expected_error

def test_get_individual_fossil_500():
    url = urljoin(BASE_URL, "/nh/fossils/individuals/unknown")

    headers = {
        "X-API-KEY": api_key,
        "Accept-Version": "1.0.0"
    }

    response = SESSION.get(url, headers=headers)

    assert response.status_code == 500
    expected_error = {"details": "Details unknown.", "title": "API experienced a fatal error."}
    assert response.json() == expected_error