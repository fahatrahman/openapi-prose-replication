import pytest
import requests

BASE_URL = "http://openapi.test"

def test_publishers_list():
    params = {
        "page": 1,
        "page_size": 10
    }
    response = requests.get(f"{BASE_URL}/publishers", params=params)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)
    assert "count" in data
    assert "results" in data
    for publisher in data["results"]:
        assert "id" in publisher
        assert "name" in publisher
        assert "slug" in publisher
        assert "games_count" in publisher
        assert "image_background" in publisher