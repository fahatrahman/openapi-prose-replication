import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
RETRY_STRATEGY = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
adapter = HTTPAdapter(max_retries=RETRY_STRATEGY)
http = requests.Session()
http.mount("https://", adapter)
http.mount("http://", adapter)

@pytest.fixture
def header():
    return {"Authorization": f"Bearer {os.environ['DIGITALOCEAN_TOKEN']}"}

def test_get_instance_size(header):
    response = http.get(
        f"{BASE_URL}/v2/apps/tiers/instance_sizes/basic-xxs", headers=header
    )

    assert response.status_code == 200
    assert response.json()["instance_size"]["cpu_type"] == "SHARED"
    assert response.json()["instance_size"]["cpus"] == "1"
    assert response.json()["instance_size"]["memory_bytes"] == "536870912"
    assert response.json()["instance_size"]["name"] == "Basic XXS"
    assert response.json()["instance_size"]["slug"] == "basic-xxs"
    assert response.json()["instance_size"]["tier_slug"] == "basic"
    assert response.json()["instance_size"]["tier_upgrade_to"] == "professional-xs"
    assert response.json()["instance_size"]["usd_per_month"] == "5.00"
    assert response.json()["instance_size"]["usd_per_second"] == "0.000002066799"