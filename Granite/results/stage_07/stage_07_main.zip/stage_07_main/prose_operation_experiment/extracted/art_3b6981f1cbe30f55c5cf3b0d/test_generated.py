import os
import pytest
import requests
from requests.exceptions import RequestException
BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def setup():
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {os.environ['AZURE_ACCESS_TOKEN']}"
    }
    return headers

def test_list_history_for_web_app(setup):
    subscription_id = "<subscription_id>"
    resource_group_name = "<resource_group_name>"
    site_name = "<site_name>"

    url = f"{BASE_URL}/subscriptions/{subscription_id}/resourceGroups/{resource_group_name}/providers/Microsoft.Web/sites/{site_name}/recommendationHistory"

    try:
        response = requests.get(url, headers=setup["Authorization"], params={"expiredOnly": True})

        # Check for successful request
        assert response.status_code == 200

        recommendations = response.json()["value"]
        assert len(recommendations) > 0

        # Additional assertions can be added here based on specific requirements

        print("Test passed successfully.")

    except RequestException as e:
        print(f"An error occurred: {str(e)}")
    except Exception as e:
        print(f"Unexpected error: {str(e)}")