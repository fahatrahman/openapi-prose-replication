import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retry logic
session = requests.Session()
retry_strategy = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)
session.mount("http://", adapter)

@pytest.fixture
def client():
    return session

def test_get_registry(client):
    registry_name = "your_registry_name"  # Replace with your desired registry name
    url = f"{BASE_URL}/registries/{registry_name}"

    response = client.get(url)
    assert response.status_code == 200

    # Assuming you want to validate the response content
    registry_configurations = response.json()
    assert isinstance(registry_configurations, list)
    assert all(isinstance(item, dict) for item in registry_configurations)