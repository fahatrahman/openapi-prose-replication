import os
import base64
import pytest
import requests
BASE_URL = "http://openapi.test"

def test_upload_ephemeral_image():
    # Read the local image file
    with open("myImage.jpg", "rb") as image_file:
        image_data = image_file.read()

    # Encode the image data to base64
    encoded_image = base64.b64encode(image_data).decode("utf-8")

    # Prepare the request payload
    payload = {"base64_image": encoded_image}

    # Send the POST request
    response = requests.post(
        f"{BASE_URL}/v2/images",
        headers={"Authorization": "", "Content-Type": "application/json"},
        json=payload
    )

    # Check the response status code
    assert response.status_code == 201, f"Unexpected status code: {response.status_code}"

    # Extract the image ID from the response
    image_id = response.json()["id"]

    # Ensure the image ID is not empty
    assert image_id, "Image ID was not returned in the response"