import pytest
import requests

BASE_URL = "http://openapi.test"

def test_start_pipe():
    headers = {
        "X-Amz-Content-Sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "X-Amz-Date": "20230401T000000Z",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20230401/us-east-1/sts/aws4_request",
        "X-Amz-Security-Token": "AQoDYXdzEPT//////////wEXAMPLEnVbKGtK7JF5ZmL/GSgq9tzgRy1kUMsrXU1lCpciQrYRfSCbuu9gjIFf3JBYk7uG5+MgAAAGJvYXJkMFNlcnZlclRoZWFkbWluQXV0aG9yaXR5IENhbXBvc2lvbg==",
        "X-Amz-Signature": "EXAMPLEHASH",
        "X-Amz-SignedHeaders": "host;x-amz-algorithm;x-amz-content-sha256;x-amz-credential;x-amz-date;x-amz-security-token"
    }
    params = {
        "Name": "test-pipe"
    }
    response = requests.post(f"{BASE_URL}/v1/pipes/{params['Name']}/start", headers=headers)
    assert response.status_code == 200
    assert "StartPipeResponse" in response.json()
    assert "Arn" in response.json()["StartPipeResponse"]
    assert "CreationTime" in response.json()["StartPipeResponse"]
    assert "CurrentState" in response.json()["StartPipeResponse"]
    assert "DesiredState" in response.json()["StartPipeResponse"]
    assert "LastModifiedTime" in response.json()["StartPipeResponse"]
    assert "Name" in response.json()["StartPipeResponse"]

if __name__ == "__main__":
    pytest.main()