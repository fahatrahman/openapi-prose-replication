import os
import requests
import pytest

BASE_URL = "http://openapi.test"

@pytest.fixture(scope="session")
def plaid_client():
    client_id = os.environ["PLAID_CLIENT_ID"]
    secret = os.environ["PLAID_SECRET"]

    headers = {
        "PLAID-CLIENT-ID": client_id,
        "PLAID-VERSION": "2021-07-28",
        "Content-Type": "application/json"
    }

    return requests.Client(headers=headers), secret

def test_transfer_refund_get(plaid_client):
    _, secret = plaid_client
    url = f"{BASE_URL}/transfer/refund/get"

    refund_request = {
        "refund_id": "<REPLACE_WITH_ACTUAL_REFUND_ID>",
        "client_id": "<REPLACE_WITH_ACTUAL_CLIENT_ID>"
    }

    response = requests.post(url, json=refund_request, headers=plaid_client[0].headers)

    assert response.status_code == 200, response.text
    refund_data = response.json()["refund"]

    # Add additional assertions based on expected refund details
    assert refund_data["amount"] == "<EXPECTED_AMOUNT>"
    assert refund_data["created"] == "<EXPECTED_CREATED_DATE>"
    assert refund_data["id"] == "<EXPECTED_REFUND_ID>"
    assert refund_data["status"] == "<EXPECTED_STATUS>"
    assert refund_data["transfer_id"] == "<EXPECTED_TRANSFER_ID>"