import pytest
import requests
from jsonschema import validate
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_dfareporting_subaccounts_insert():
    profile_id = "test_profile"
    subaccount = {
        "accountId": "12345",
        "availablePermissionIds": [1, 2],
        "id": None,
        "kind": "dfareporting#subaccount",
        "name": "Test Subaccount"
    }

    headers = {"Content-Type": "application/json"}
    response = requests.post(
        urljoin(BASE_URL, f"userprofiles/{profile_id}/subaccounts"),
        headers=headers,
        json=subaccount
    )

    assert response.status_code == 200
    result = response.json()
    schema = {
        "type": "object",
        "properties": {
            "accountId": {"type": "string", "format": "int64"},
            "availablePermissionIds": {"type": "array", "items": {"format": "int64"}},
            "id": {"type": "string", "format": "int64"},
            "kind": {"type": "string"},
            "name": {"type": "string"}
        }
    }
    validate(instance=result, schema=schema)