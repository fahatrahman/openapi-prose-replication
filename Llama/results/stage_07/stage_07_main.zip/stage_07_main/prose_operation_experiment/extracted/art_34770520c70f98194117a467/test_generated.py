# -*- coding: utf-8 -*-
import json
import os
from typing import Dict
import pytest
import requests

BASE_URL = "http://openapi.test"

def load_openapi(openapi_data: str) -> Dict:
    """Load OpenAPI data into a dictionary."""
    return json.loads(openapi_data)

def get_drillers_files_list(person_guid: str):
    """Get drillers files list."""
    url = f"{BASE_URL}/drillers/{person_guid}/files/"
    headers = {"Authorization": "Bearer"}
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    return response.json()

def test_get_drillers_files_list():
    """Test getting drillers files list."""
    person_guid = "test-guid"
    result = get_drillers_files_list(person_guid)
    # Add assertions here based on expected response content
    pass

if __name__ == "__main__":
    pytest.main([os.path.basename(__file__)])