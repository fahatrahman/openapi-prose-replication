import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = "path/to/service_account.json"
SCOPES = ["https://www.googleapis.com/auth/cloud-platform"]

credentials = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE, scopes=SCOPES)

# Setup requests session with authenticated credentials
session = requests.Session()
session.auth = (credentials.service_account_email, credentials.id_token)
headers = {"x-goog-api-client": "gl-python/0.1.0",
           "x-goog-api-version": "2"}

@pytest.fixture
def context_created():
    parent = "zynntaco/your_autfnhu/yzvrewumc/your_vmdixebo/uygfpobrVnvmot/your_viuzchcddyfsn"
    context_id = "your_context_id"

    url = f"{BASE_URL}/v1/{parent}/contexts"
    payload = {
        "displayName": "Test Context Display Name",
        "description": "This is a test context.",
        "contextId": context_id
    }

    response = requests.post(url, json=payload, headers=headers, verify=False)

    assert response.status_code == 200
    return response.json()