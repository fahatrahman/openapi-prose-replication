import pytest
import requests

BASE_URL = "http://openapi.test"

def test_list_locations():
    url = f"{BASE_URL}/v2alpha/projects/-/locations"
    params = {
        "_xgafv": "1",
        "access_token": "your_access_token_here",
        "alt": "json",
        "callback": None,
        "fields": None,
        "key": "your_api_key_here",
        "oauth_token": None,
        "prettyPrint": False,
        "quotaUser": None,
        "uploadType": None,
        "upload_protocol": None,
        "filter": None,
        "pageSize": None,
        "pageToken": None
    }
    response = requests.get(url, params=params)
    assert response.status_code == 200
    assert "locations" in response.json()