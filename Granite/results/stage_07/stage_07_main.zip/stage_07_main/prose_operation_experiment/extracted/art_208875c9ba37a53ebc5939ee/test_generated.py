import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"
SESSION = requests.Session()
RETRY_STRATEGY = Retry(
    total=3,
    status_forcelist=[429, 500, 502, 503, 504],
    backoff_factor=1,
)
ADAPTER = HTTPAdapter(max_retries=RETRY_STRATEGY)
SESSION.mount("https://", ADAPTER)
SESSION.mount("http://", ADAPTER)

@pytest.fixture
def transfer_instruments():
    """Test fixture for updating a transfer instrument."""

    def _transfer_instruments(
        id,
        bank_account,
        legal_entity_id,
        x_requested_verification_code=None,
    ):
        url = f"{BASE_URL}/transferInstruments/{id}"
        headers = {"Content-Type": "application/json"}

        if x_requested_verification_code:
            headers["x-requested-verification-code"] = str(x_requested_verification_code)

        update_transfer_instrument = {
            "bankAccount": {
                "currencyCode": bank_account.get("currencyCode"),
                "iban": bank_account.get("iban"),
            },
            "legalEntityId": legal_entity_id,
        }

        response = SESSION.patch(url, json=update_transfer_instrument, headers=headers)
        response.raise_for_status()

        return response.json()

    return _transfer_instruments