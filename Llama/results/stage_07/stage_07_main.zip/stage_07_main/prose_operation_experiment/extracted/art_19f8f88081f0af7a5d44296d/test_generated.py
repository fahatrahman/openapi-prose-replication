# -*- coding: utf-8 -*-

import pytest
import requests
from pydantic import BaseModel

BASE_URL = "http://openapi.test"

class Quotas(BaseModel):
    authorizedCallsPerDay: int
    authorizedCallsPerMonth: int
    authorizedCallsPerSec: int
    currentCallsPerDay: int
    currentCallsPerMonth: int
    currentCallsPerSec: int
    remainingCallsPerDay: int
    remainingCallsPerMonth: int
    remainingCallsPerSec: int

def test_reset_api_key_from_group_quotas():
    # Prepare the request
    groupId = "some_group_id"
    clientId = "some_client_id"
    
    url = f"{BASE_URL}/api/groups/{groupId}/apikeys/{clientId}/quotas"
    headers = {"Authorization": "Basic Nxvhwzfd-Tpmakj-Lg"}
    response = requests.delete(url, headers=headers)

    # Check if the request was successful
    assert response.status_code == 200
    
    # Parse the JSON response
    quotas = Quotas.parse_raw(response.text)
    
    # Assert the expected values
    assert quotas.authorizedCallsPerDay == 123
    assert quotas.authorizedCallsPerMonth == 123
    assert quotas.authorizedCallsPerSec == 123
    assert quotas.currentCallsPerDay == 123
    assert quotas.currentCallsPerMonth == 123
    assert quotas.currentCallsPerSec == 123
    assert quotas.remainingCallsPerDay == 123
    assert quotas.remainingCallsPerMonth == 123
    assert quotas.remainingCallsPerSec == 123

# Run all tests in this file
pytest.main([__file__])