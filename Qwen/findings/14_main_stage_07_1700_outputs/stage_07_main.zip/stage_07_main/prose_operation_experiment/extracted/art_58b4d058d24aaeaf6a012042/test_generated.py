import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_secrets():
    url = f"{BASE_URL}/secrets"
    params = {
        "page": 0,
        "size": 20
    }
    headers = {
        "Authorization": "Bearer <your_jwt_token>"
    }
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    secrets = response.json()
    assert isinstance(secrets, list)
    for secret in secrets:
        assert "id" in secret
        assert "name" in secret
        assert "description" in secret
        assert "username" in secret
        assert "password" in secret
        assert "caCertPem" in secret