# -*- coding: utf-8 -*-
"""Tests for Operation Slice."""

import pytest
import requests


BASE_URL = "http://openapi.test"


def test_list_adaptive_mt_files():
    """Test list adaptive mt files."""
    url = f"{BASE_URL}/v3/{'zynntaco/{autfnhu}/yzvrewumc/{vmdixebo}/mqjnhollLcUuzcfmmz/{anynvkz}'}/adaptiveMtFiles"
    params = {
        '_.xgafv': '1',
        'access_token': '',
        'alt': 'json',
        'callback': '',
        'fields': '',
        'key': '',
        'oauth_token': '',
        'prettyPrint': 'false',
        'quotaUser': '',
        'upload_protocol': 'upload_protocol',
        'uploadType': 'uploadType',
        'pageSize': '10',
        'pageToken': ''
    }
    headers = {}
    response = requests.get(url, params=params, headers=headers)
    assert response.status_code == 200
    assert response.json()['adaptiveMtFiles'] is not None