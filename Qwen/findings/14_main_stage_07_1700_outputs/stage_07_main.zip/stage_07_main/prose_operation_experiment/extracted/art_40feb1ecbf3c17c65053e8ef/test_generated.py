import pytest
import requests

BASE_URL = "http://openapi.test"

def test_query_status_names_v1_asn_status_all_get():
    url = f"{BASE_URL}/v1/asn/status/all"
    headers = {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"  # Replace with actual access token
    }
    response = requests.get(url, headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    for item in data:
        assert "self" in item
        assert "name" in item
        assert "code" in item
        assert item["code"] in ["assigned", "reserved", "allocated", "available"]