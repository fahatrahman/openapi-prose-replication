import pytest
import requests

BASE_URL = "http://openapi.test"

def test_query_prediction_results():
    project_id = "bc3f7dad-5544-468c-8573-3ef04d55463e"
    api_key = "{API Key}"
    url = f"{BASE_URL}/projects/{project_id}/predictions/query"
    
    headers = {
        "Training-Key": api_key,
    }
    
    payload = {
        "Application": None,
        "Continuation": None,
        "EndTime": None,
        "IterationId": None,
        "MaxCount": 0,
        "OrderBy": "Newest",
        "Session": None,
        "StartTime": None,
        "Tags": []
    }
    
    response = requests.post(url, headers=headers, json=payload)
    
    assert response.status_code == 200
    assert "Results" in response.json()
    assert isinstance(response.json()["Results"], list)