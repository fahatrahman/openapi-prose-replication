import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retry mechanism
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)

@pytest.fixture
def maintenance_issue():
    return {
        "ExternalID": "TEST_EXTERNAL_ID",
        "IssueFault": "Sample Fault",
        "IssueNotes": "Some sample notes.",
        "IssuePriority": "Medium",
        "IssueTitle": "Test Maintenance Job",
        "PropertyAddress1": "123 Sample St",
        "PropertyAddress2": "Unit A",
        "PropertyAddress3": "",
        "PropertyAddress4": "",
        "PropertyCountry": "USA",
        "PropertyPostcode": "12345",
        "ReportedAt": "2023-04-01T00:00:00Z",
        "TenantEMailAddress": "tenant@example.com",
        "TenantForename": "John",
        "TenantPhonePrimary": "555-1234",
        "TenantPhoneSecondary": "555-5678",
        "TenantPresenceRequested": False,
        "TenantSurname": "Doe",
        "TenantTitle": "Mr."
    }

def test_create_maintenance_job(maintenance_issue):
    url = f"{BASE_URL}/v3/maintenance/sampleShortName/maintenance/sampleBranchID/createmaintenancejob"
    response = session.post(url, json=maintenance_issue)

    assert response.status_code == 200
    print("Test Passed: Maintenance job created successfully.")
