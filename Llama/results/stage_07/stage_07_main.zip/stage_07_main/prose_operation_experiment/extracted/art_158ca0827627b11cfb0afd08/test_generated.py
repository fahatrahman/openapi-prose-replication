# -*- coding: utf-8 -*-
import pytest
import requests

BASE_URL = "http://openapi.test"

def test_sandbox_bank_transfer_simulate():
    # Define the API client ID and secret
    client_id = "your_client_id"
    secret = "your_secret"

    # Define the sandbox bank transfer simulate request
    request_body = {
        "bank_transfer_id": "your_bank_transfer_id",
        "event_type": "posted",  # or 'failed', or 'reversed'
        "client_id": client_id,
        "secret": secret
    }

    # Send a POST request to the /sandbox/bank_transfer/simulate endpoint
    headers = {"PLAID-CLIENT-ID": client_id, "PLAID-SECRET": secret}
    response = requests.post(f"{BASE_URL}/sandbox/bank_transfer/simulate", json=request_body, headers=headers)

    # Check if the response was successful (200 OK)
    assert response.status_code == 200

    # Parse the JSON response
    response_json = response.json()

    # Check if the response contains the expected keys
    assert "request_id" in response_json

    # Print the request ID for debugging purposes
    print(response_json["request_id"])