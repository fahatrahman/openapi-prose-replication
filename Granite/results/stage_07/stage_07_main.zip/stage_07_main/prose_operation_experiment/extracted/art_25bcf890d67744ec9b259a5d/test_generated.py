import pytest
import requests

BASE_URL = "http://openapi.test"

@pytest.fixture
def rights():
    response = requests.get(f"{BASE_URL}/oauth/rights")
    response.raise_for_status()
    return response.json()["data"]

def test_get_oauth_rights(rights):
    assert isinstance(rights, dict)
    assert "description" in rights
    assert "name" in rights