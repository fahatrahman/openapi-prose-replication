import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_aiplatform_projects_locations_metadataStores_list():
    parent = "/v1/zynntaco/autfnhu/yzvrewumc/vmdixebo"
    params = {
        "pageSize": 10,
        "pageToken": ""
    }
    
    response = requests.get(
        urljoin(BASE_URL, parent),
        params=params,
        headers={"Content-Type": "application/json"},
    )
    
    assert response.status_code == 200
    
    try:
        response.json()
    except ValueError:
        assert False, "Invalid JSON in response"