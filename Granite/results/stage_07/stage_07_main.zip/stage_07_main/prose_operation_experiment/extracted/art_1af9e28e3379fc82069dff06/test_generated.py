# Import required libraries
import pytest
import requests
import base64
import json

BASE_URL = "http://openapi.test"

@pytest.fixture
def image_data():
    # Replace 'myImage.jpg' with actual image file content
    with open("myImage.jpg", "rb") as img_file:
        return base64.b64encode(img_file.read()).decode()

def test_upload_ephemeral_image(image_data):
    url = f"{BASE_URL}/v2/images"

    headers = {
        "Authorization": "",
        "Content-Type": "application/json",
    }

    payload = {
        "base64_image": image_data
    }

    response = requests.post(url, headers=headers, data=json.dumps(payload))

    assert response.status_code == 201
    assert "id" in response.json()