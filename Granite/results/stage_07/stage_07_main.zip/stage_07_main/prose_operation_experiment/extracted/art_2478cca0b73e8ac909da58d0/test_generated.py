import os
import pytest
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

BASE_URL = "http://openapi.test"

# Create a session with retries
session = requests.Session()
retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 429, 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retries)
session.mount('https://', adapter)
session.mount('http://', adapter)

@pytest.fixture
def client():
    return session

def test_tag_resource(client):
    headers = {
        'X-Amz-Algorithm': 'AWS4-HMAC-SHA256',
        'X-Amz-Content-Sha256': 'STRING',
        'X-Amz-Date': 'DATE',
        'X-Amz-Credential': 'CREDENTIALS',
        'X-Amz-Security-Token': 'TOKEN',
        'X-Amz-Signature': 'SIGNATURE',
        'X-Amz-SignedHeaders': 'SIGNED_HEADERS'
    }

    data = {
        'arn': 'STRING',
        'tags': {
            'key1': '__string',
            'key2': '__string'
        }
    }

    response = client.post(
        f"{BASE_URL}/2017-08-29/tags",
        json=data,
        headers=headers
    )

    assert response.status_code == 200