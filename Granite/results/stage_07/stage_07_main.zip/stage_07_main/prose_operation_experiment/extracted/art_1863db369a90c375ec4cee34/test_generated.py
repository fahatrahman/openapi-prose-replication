import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
CREDENTIALS_PATH = "path/to/credentials.json"

@pytest.fixture
def authentication():
    credentials = service_account.Credentials.from_service_account_file(
        CREDENTIALS_PATH, scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )
    return credentials

def test_list_locations(authentication):
    headers = {"Authorization": f"Bearer {authentication.token}"}

    name = "projects/your-project-id"  # Replace with your project ID
    params = {
        "filter": "some_filter",  # Optional filter parameter
        "pageSize": 10,  # Optional page size
        "pageToken": "some_page_token"  # Optional page token
    }

    response = requests.get(
        f"{BASE_URL}/v2/{name}/locations", headers=headers, params=params
    )

    assert response.status_code == 200

    locations_response = response.json()
    locations = locations_response["locations"]
    next_page_token = locations_response["nextPageToken"]

    assert isinstance(locations, list)
    assert isinstance(next_page_token, str)