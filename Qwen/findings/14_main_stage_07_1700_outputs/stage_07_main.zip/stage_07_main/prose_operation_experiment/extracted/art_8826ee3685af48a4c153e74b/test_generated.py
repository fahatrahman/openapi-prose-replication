import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_recipe_taste_by_id():
    headers = {
        "x-api-key": "your_api_key_here"
    }
    params = {
        "normalize": True
    }
    response = requests.get(f"{BASE_URL}/recipes/69095/tasteWidget.json", headers=headers, params=params)
    
    assert response.status_code == 200
    assert "sweetness" in response.json()
    assert "saltiness" in response.json()
    assert "sourness" in response.json()
    assert "bitterness" in response.json()
    assert "savoriness" in response.json()
    assert "fattiness" in response.json()
    assert "spiciness" in response.json()

if __name__ == "__main__":
    pytest.main()