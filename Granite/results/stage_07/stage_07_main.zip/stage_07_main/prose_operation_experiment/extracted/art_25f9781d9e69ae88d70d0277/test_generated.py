import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

@pytest.fixture
def auth():
    return HTTPBasicAuth("username", "password")

def test_list_application(auth):
    for page in range(1, 6):
        params = {"page_size": 10, "page": page}
        response = requests.get(
            f"{BASE_URL}", params=params, auth=auth, verify=False
        )

        if response.status_code == 200:
            data = response.json()
            assert isinstance(data, dict)
            assert "applications" in data
            assert isinstance(data["applications"], list)
        elif response.status_code == 400:
            assert response.json()["title"] == "Bad Request"
        elif response.status_code == 401:
            assert response.json()["title"] == "Invalid credentials supplied"
        elif response.status_code == 405:
            assert response.json()["title"] == "Request method not allowed"
        elif response.status_code == 406:
            assert response.json()["title"] == "Invalid Accept header"
        else:
            pytest.fail(f"Unexpected status code: {response.status_code}")