import pytest
import requests

BASE_URL = "http://openapi.test"

def test_retrieve_partner_stores_statistics():
    params = {
        "partner_code": "test_partner",
        "auth_token": "test_auth_token",
        "page": 1,
        "from": "2023-01-01",
        "to": "2023-01-31"
    }
    response = requests.get(f"{BASE_URL}/partners/stores.json", params=params)
    
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    assert all(isinstance(item, dict) for item in data)

if __name__ == "__main__":
    pytest.main([__file__])