import pytest
import requests

BASE_URL = "http://openapi.test"

def test_key_options():
    url = f"{BASE_URL}/key"
    response = requests.options(url)
    assert response.status_code == 200
    assert 'Access-Control-Allow-Headers' in response.headers
    assert 'Access-Control-Allow-Methods' in response.headers
    assert 'Access-Control-Allow-Origin' in response.headers