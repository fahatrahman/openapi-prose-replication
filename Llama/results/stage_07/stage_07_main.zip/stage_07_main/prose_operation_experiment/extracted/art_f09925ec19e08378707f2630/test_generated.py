# -*- coding: utf-8 -*-

import pytest
import requests
from urllib.parse import urljoin, urlencode

BASE_URL = "http://openapi.test"

def test_delete_workflow():
    url = urljoin(BASE_URL, "/v1beta/workflows/projects/test/locations/test/workflows/test")
    params = {
        "$.xgafv": "1",
        "access_token": "",
        "alt": "json",
        "callback": "",
        "fields": "",
        "key": "",
        "oauth_token": "",
        "prettyPrint": "true",
        "quotaUser": "",
        "upload_protocol": "raw",
        "uploadType": "multipart"
    }
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    response = requests.request("DELETE", url, params=urlencode(params), headers=headers)
    assert response.status_code == 200