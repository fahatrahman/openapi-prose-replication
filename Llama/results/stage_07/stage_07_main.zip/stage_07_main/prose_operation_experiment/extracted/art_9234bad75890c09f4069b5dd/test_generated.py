# -*- coding: utf-8 -*-
import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_get_default_voice_settings():
    """Test getting default voice settings."""
    response = requests.get(urljoin(BASE_URL, "/v1/voices/settings/default"))
    assert response.status_code == 200
    try:
        response_json = response.json()
        required_keys = ["similarity_boost", "stability"]
        for key in required_keys:
            assert key in response_json
    except ValueError:
        pytest.fail("Failed to parse JSON response")