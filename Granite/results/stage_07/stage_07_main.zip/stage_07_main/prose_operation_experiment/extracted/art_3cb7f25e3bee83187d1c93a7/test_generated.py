import pytest
import requests
from requests.exceptions import RequestException

BASE_URL = "http://openapi.test"
BASIC_AUTH = ("xyvylscj", "lcknolcj")

@pytest.fixture
def client():
    def _client():
        session = requests.Session()
        session.auth = BASIC_AUTH
        return session

    yield _client()

def test_list_product_modules(client):
    url = f"{BASE_URL}/productmodule"
    response = client().get(url)

    if response.status_code == 200:
        assert response.headers["Content-Type"] in ["application/json", "application/xml"]
        # Add more assertions based on expected response structure
    elif response.status_code == 400:
        assert "xsjnuofyp sg ucwodji diimyfa" in str(response.text)
    elif response.status_code == 403:
        assert "fdyyjz fj zqqlce" in str(response.text)
    elif response.status_code == 404:
        assert "nbbcmoio hwy aqprs" in str(response.text)
    elif response.status_code == 500:
        assert "eigktkne zqlxfuz phbnl" in str(response.text)
    else:
        raise AssertionError(f"Unexpected status code: {response.status_code}")
