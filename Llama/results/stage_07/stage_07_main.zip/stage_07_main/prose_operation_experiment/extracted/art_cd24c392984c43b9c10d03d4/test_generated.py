# -*- coding: utf-8 -*-
import pytest
import requests
from urllib.parse import urljoin

BASE_URL = "http://openapi.test"

def test_list_sites():
    url = urljoin(BASE_URL, "/v1/partners/{partnerId}/channels/{channelId}/sites")
    params = {
        "partnerId": "partner_id",
        "channelId": "channel_id"
    }
    headers = {}
    query_params = {}

    # Send GET request
    response = requests.get(url, params=params, headers=headers, params=query_params)

    # Check status code
    assert response.status_code == 200

    # Parse JSON response
    data = response.json()

    # Assert expected structure
    assert isinstance(data, dict)
    assert 'nextPageToken' in data
    assert 'sites' in data

    # Iterate over sites and check their structure
    for site in data['sites']:
        assert isinstance(site, dict)
        assert 'name' in site
        assert 'urlOrAppId' in site
