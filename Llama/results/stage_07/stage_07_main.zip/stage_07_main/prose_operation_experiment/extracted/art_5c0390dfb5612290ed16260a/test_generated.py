import pytest
import requests

BASE_URL = "http://openapi.test"

def test_migrationcenter_projects_locations_sources_patch():
    url = f"{BASE_URL}/v1/{'source_name'}"
    headers = {
        'Content-Type': 'application/json'
    }
    body = {
        "name": "source_name",
        "description": "test_source_description",
        "displayName": "test_display_name",
        "managed": True,
        "name": "source_name",
        "pendingFrameCount": 10,
        "priority": 50,
        "state": "ACTIVE",
        "type": "SOURCE_TYPE_UNKNOWN",
        "updateTime": "2022-01-01T12:00:00Z",
    }
    params = {
        "requestId": "test_request_id",
        "updateMask": "test_update_mask",
    }

    response = requests.patch(url, json=body, headers=headers, params=params)
    assert response.status_code == 200