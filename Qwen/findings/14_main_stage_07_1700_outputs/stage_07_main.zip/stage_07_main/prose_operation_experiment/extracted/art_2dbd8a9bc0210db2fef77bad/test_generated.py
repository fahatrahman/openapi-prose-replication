import pytest
import requests

BASE_URL = "http://openapi.test"

def test_cancel_job():
    headers = {
        "X-Amz-Content-Sha256": "example",
        "X-Amz-Date": "example",
        "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
        "X-Amz-Credential": "example",
        "X-Amz-Security-Token": "example",
        "X-Amz-Signature": "example",
        "X-Amz-SignedHeaders": "example"
    }
    url = f"{BASE_URL}/2017-08-29/jobs/example_id"
    response = requests.delete(url, headers=headers)
    assert response.status_code == 202
    assert response.json() == {}