import os
import pytest
import requests
from google.oauth2 import service_account

BASE_URL = "http://openapi.test"
SERVICE_ACCOUNT_FILE = "path/to/service_account.json"
SCOPES = ["https://www.googleapis.com/auth/adsense"]

def get_authenticated_session():
    credentials = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    return requests.Session(), credentials

@pytest.fixture
def adsense_session():
    session, _ = get_authenticated_session()
    yield session
    session.close()

def test_list_url_channels(adsense_session):
    parent = "accounts/your_account/adclients/your_adclient"

    url = f"{BASE_URL}/v2/{parent}/urlchannels"
    response = adsense_session.get(url, headers={"Content-Type": "application/json"})
    response.raise_for_status()

    result = response.json()
    assert "urlChannels" in result
    assert isinstance(result["urlChannels"], list)
    assert "nextPageToken" in result