# -*- coding: utf-8 -*-

import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

def test_get_user():
    url = f"{BASE_URL}/user/"
    response = requests.get(url, auth=HTTPBasicAuth("your_username", "your_password"))
    assert response.status_code == 200
    response.raise_for_status()
    data = response.json()
    assert isinstance(data, dict)
    assert "userId" in data
    assert "username" in data
    assert "accountType" in data
    if data["accountType"] == "BUSINESS":
        assert "businessAccount" in data
        assert isinstance(data["businessAccount"], dict)
        assert "address" in data["businessAccount"]
        assert isinstance(data["businessAccount"]["address"], dict)
        assert "addressLine1" in data["businessAccount"]["address"]
        assert "city" in data["businessAccount"]["address"]
        assert "country" in data["businessAccount"]["address"]
        assert "county" in data["businessAccount"]["address"]
        assert "postalCode" in data["businessAccount"]["address"]
        assert "stateOrProvince" in data["businessAccount"]["address"]
    elif data["accountType"] == "INDIVIDUAL":
        assert "individualAccount" in data
        assert isinstance(data["individualAccount"], dict)
        assert "email" in data["individualAccount"]
        assert "firstName" in data["individualAccount"]
        assert "lastName" in data["individualAccount"]
        assert "primaryPhone" in data["individualAccount"]
        assert isinstance(data["individualAccount"]["primaryPhone"], dict)
        assert "number" in data["individualAccount"]["primaryPhone"]
        assert "countryCode" in data["individualAccount"]["primaryPhone"]
        assert "phoneType" in data["individualAccount"]["primaryPhone"]
        assert "registrationAddress" in data["individualAccount"]
        assert isinstance(data["individualAccount"]["registrationAddress"], dict)
        assert "addressLine1" in data["individualAccount"]["registrationAddress"]
        assert "city" in data["individualAccount"]["registrationAddress"]
        assert "country" in data["individualAccount"]["registrationAddress"]
        assert "county" in data["individualAccount"]["registrationAddress"]
        assert "postalCode" in data["individualAccount"]["registrationAddress"]
        assert "stateOrProvince" in data["individualAccount"]["registrationAddress"]

if __name__ == "__main__":
    pytest.main([__file__])