import pytest
import requests
from datetime import datetime
import hmac
import hashlib

BASE_URL = "http://openapi.test"

def get_amz_date():
    return datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")

def get_amz_signed_headers(headers):
    signed_headers = ""
    for header in headers:
        if header.startswith("X-Amz-"):
            signed_headers += header + ";"
    return signed_headers[:-1]

def sign_request(method, path, date, credential, secret_key, headers):
    payload = method.upper() + "\n" + path + "\n" + date + "\n" + "/".join(sorted([k.lower() for k in headers.keys()])) + "\n" + str(len(headers))
    signature = hmac.new(secret_key.encode(), payload.encode(), hashlib.sha256).hexdigest()
    return signature

class TestBatchSnoozeAlarm:
    def test_batch_snooze_alarm(self):
        url = f"{BASE_URL}/alarms/snooze"
        headers = {
            "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
            "X-Amz-Content-Sha256": "6ba7b810-01fb-1010-ba43-e2ad6c79b86d",
            "X-Amz-Credential": "AKIAIOSFODNN7EXAMPLE/20220926/us-east-1/s3/aws4_request",
            "X-Amz-Date": get_amz_date(),
            "X-Amz-Security-Token": "FQodXJ1MjM=",
            "X-Amz-Signature": sign_request("POST", "/alarms/snooze", get_amz_date(), "AKIAIOSFODNN7EXAMPLE/20220926/us-east-1/s3/aws4_request", "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY", ["X-Amz-Algorithm", "X-Amz-Content-Sha256", "X-Amz-Credential", "X-Amz-Date", "X-Amz-Security-Token"]),
            "X-Amz-SignedHeaders": get_amz_signed_headers(["X-Amz-Algorithm", "X-Amz-Content-Sha256", "X-Amz-Credential", "X-Amz-Date", "X-Amz-Security-Token"])
        }
        data = {
            "snoozeActionRequests": [
                {"alarmModelName": "example-alarm-model-name", "keyValue": "example-key-value", "note": "example-note", "requestId": "example-request-id", "snoozeDuration": 3600}
            ]
        }
        response = requests.post(url, json=data, headers=headers)
        assert response.status_code == 202