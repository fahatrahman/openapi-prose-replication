import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_member_synopsis():
    member_id = 123  # Replace with actual member ID
    url = f"{BASE_URL}/api/Members/{member_id}/Synopsis"
    
    response = requests.get(url)
    
    assert response.status_code == 200
    assert 'Content-Type' in response.headers
    content_type = response.headers['Content-Type']
    
    if content_type == 'application/json':
        data = response.json()
        assert isinstance(data, dict)
        assert 'StringItem' in data
        string_item = data['StringItem']
        assert isinstance(string_item, dict)
        assert 'value' in string_item
        assert isinstance(string_item['value'], str)
        if 'links' in string_item:
            links = string_item['links']
            assert isinstance(links, list)
            for link in links:
                assert isinstance(link, dict)
                assert 'href' in link or 'method' in link or 'rel' in link
    elif content_type == 'text/json':
        data = response.json()
        assert isinstance(data, dict)
        assert 'StringItem' in data
        string_item = data['StringItem']
        assert isinstance(string_item, dict)
        assert 'value' in string_item
        assert isinstance(string_item['value'], str)
        if 'links' in string_item:
            links = string_item['links']
            assert isinstance(links, list)
            for link in links:
                assert isinstance(link, dict)
                assert 'href' in link or 'method' in link or 'rel' in link
    elif content_type == 'text/plain':
        data = response.text
        assert isinstance(data, str)

if __name__ == "__main__":
    pytest.main([__file__])