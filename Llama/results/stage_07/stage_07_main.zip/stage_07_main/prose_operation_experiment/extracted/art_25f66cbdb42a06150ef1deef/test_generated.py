# -*- coding: utf-8 -*-

import pytest
import requests

BASE_URL = "http://openapi.test"

def test_get_diary_appointment_types():
    url = f"{BASE_URL}/v2/tier2/{'example_short_name'}/diary/appointmenttypes"
    params = {"offset": 0, "count": 10}

    response = requests.get(url, params=params)

    assert response.status_code == 200

    results = response.json()
    assert isinstance(results["Count"], int)
    assert isinstance(results["Data"], list)
    for item in results["Data"]:
        assert isinstance(item, dict)
        assert all(key in item for key in ["ETag", "Name", "OID", "SystemType"])