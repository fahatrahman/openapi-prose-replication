import pytest
import requests

BASE_URL = "http://openapi.test"

def test_create_allowed_origin():
    url = f"{BASE_URL}/companies/{company_id}/apiCredentials/{api_credential_id}/allowedOrigins"
    headers = {"Content-Type": "application/json"}
    response = requests.post(url, headers=headers, json={"domain": "https://www.eu.mystore.com"})
    
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data["data"], list)
    assert len(data["data"]) > 0
    
def test_invalid_domain():
    url = f"{BASE_URL}/companies/{company_id}/apiCredentials/{api_credential_id}/allowedOrigins"
    headers = {"Content-Type": "application/json"}
    response = requests.post(url, headers=headers, json={"domain": "invalid-domain"})
    
    assert response.status_code == 422
    error_data = response.json()
    assert isinstance(error_data, dict)
    assert error_data.get("errorCode") == "VALIDATION_ERROR"
    assert isinstance(error_data.get("invalidFields"), list)

def test_no_api_key():
    url = f"{BASE_URL}/companies/{company_id}/apiCredentials/{api_credential_id}/allowedOrigins"
    response = requests.post(url, json={"domain": "https://www.eu.mystore.com"})
    
    assert response.status_code == 401
    error_data = response.json()
    assert isinstance(error_data, dict)
    assert error_data.get("errorCode") == "AUTHENTICATION_ERROR"
    assert isinstance(error_data.get("invalidFields"), list)

company_id = "your_company_account"
api_credential_id = "your_api_credential"