import os
import pytest
import requests
from requests.auth import HTTPBasicAuth

BASE_URL = "http://openapi.test"

@pytest.fixture
def auth():
    return HTTPBasicAuth("your_api_key", "your_api_key")

def test_get_saved_ad_style(auth):
    saved_ad_style_id = "your_saved_ad_style_id"
    endpoint = f"{BASE_URL}/savedadstyles/{saved_ad_style_id}"

    response = requests.get(endpoint, auth=auth)

    assert response.status_code == 200
    assert isinstance(response.json(), dict)
    assert "adStyle" in response.json()
    assert "id" in response.json()
    assert "kind" in response.json()
    assert "name" in response.json()