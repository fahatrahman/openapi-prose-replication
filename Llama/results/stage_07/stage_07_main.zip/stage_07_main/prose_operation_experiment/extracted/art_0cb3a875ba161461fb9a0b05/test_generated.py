import pytest
import json
import requests

BASE_URL = "http://openapi.test"

def test_notify_shopper():
    url = f"{BASE_URL}/notifyShopper"
    
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Basic Auth'
    }

    payload = {
        "amount": {"currency": "INR", "value": 1000},
        "billingDate": "2021-03-16",
        "displayedReference": "exampleDisplayedReference",
        "merchantAccount": "YOUR_MERCHANT_ACCOUNT",
        "reference": "Example reference",
        "shopperReference": "YOUR_SHOPPER_REFERENCE",
        "storedPaymentMethodId": "8415995487234100"
    }
    
    response = requests.post(url, headers=headers, json=payload)
    
    assert response.status_code == 200
    
    result = response.json()
    
    expected_result = {
        "displayedReference": "exampleDisplayedReference",
        "message": "Request Processed Successfully",
        "pspReference": "M5N7TQ4TG5PFWR50",
        "reference": "Example reference",
        "resultCode": "Success",
        "shopperNotificationReference": "9915003646742627",
        "storedPaymentMethodId": "8415995487234100"
    }
    
    assert result == expected_result